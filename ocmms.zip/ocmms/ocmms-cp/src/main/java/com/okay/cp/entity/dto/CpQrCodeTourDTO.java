package com.okay.cp.entity.dto;

import com.okay.cp.entity.CpQrCodeTour;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 二维码导览表DTO
 *
 * @author CZJ[OKAY]
 * @date 2021-12-15 10:42:23
 */
@Data
@ApiModel(value = "二维码导览表DTO")
public class CpQrCodeTourDTO extends CpQrCodeTour {

    @ApiModelProperty(value = "藏品名称")
    private String collectName;

    @ApiModelProperty(value = "藏品编号")
    private String collectCode;

    @ApiModelProperty(value = "附件信息")
    private List<String> resInfoIds;


}