package com.okay.cp.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.TextureType;
import com.okay.cp.service.TextureTypeService;
import com.okay.framework.controller.BaseController;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: TextureTypeController
 * @Description: 藏品质地管理
 * @author: HQ.ZHU
 * @date: 2019-09-29 11:36
 * @version: V1.0
 */
@RestController
@RequestMapping("/textureType")
public class TextureTypeController extends BaseController {

    @Autowired
    private TextureTypeService textureTypeService;

    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getDataList(@RequestBody Page page){
        JSONObject jsonObject = new JSONObject();
        try{
            List<Map> list = textureTypeService.findDataList(page);
            jsonObject.put("code", 1);
            jsonObject.put("data",list);
            jsonObject.put("pages",page.getPages());
            jsonObject.put("total",page.getTotal());
            jsonObject.put("pageNum",page.getPageNum());
            jsonObject.put("pageSize",page.getPageSize());
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 质地树
     * @return
     */
    @RequestMapping(value = "/dataTree", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getDataTree(){
        JSONObject jsonObject = new JSONObject();
        try{
            List<Map> list = textureTypeService.findDataTree();
            jsonObject.put("code", 1);
            jsonObject.put("data",list);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @SysLog("藏品质地-新增")
    @RequestMapping(value = "/add", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject addData(@RequestBody @Valid TextureType textureType){
        JSONObject jsonObject = new JSONObject();
        try{
            //装配数据
            textureType.setTextureId(getSequence());
            int rows = textureTypeService.addData(textureType);
            if(rows == 1) {
                jsonObject.put("data",textureType);
                throw new BaseRuntimeException(CollectErrorDefine.ADD_SUCCESS);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.ADD_ERR);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @SysLog("藏品质地-删除")
    @PreAuthorize("@pms.hasPermission('TT_DEL')")
    @PostMapping("/remove")
    public JSONObject removeData(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            if (jsonParam.getBooleanValue("confirmFlg")){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            int rows = textureTypeService.removeData(jsonParam.getString("textureIds"));
            if(rows == 0) {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_ERR);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @PostMapping("/getById")
    public JSONObject getById(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            TextureType textureType = textureTypeService.findDataById(jsonParam.getString("textureId"));
            jsonObject.put("code", 1);
            jsonObject.put("data",textureType);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @SysLog("藏品质地-修改")
    @PostMapping("/modify")
    public JSONObject modifyData(@RequestBody @Valid TextureType textureType){
        JSONObject jsonObject = new JSONObject();
        try{
            int rows = textureTypeService.modifyData(textureType);
            if(rows == 0) {
                throw new BaseRuntimeException(CollectErrorDefine.UPDATE_ERR);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.UPDATE_SUCCESS);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }
}
