package com.okay.cp.entity.dto;

import com.okay.cp.entity.CpAppraisalExpert;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * 鉴定专家管理表DTO
 *
 * @author CZJ[OKAY]
 * @date 2021-12-14 20:07:31
 */
@Data
@ApiModel(value = "鉴定专家管理表DTO")
public class CpAppraisalExpertDTO extends CpAppraisalExpert {

}