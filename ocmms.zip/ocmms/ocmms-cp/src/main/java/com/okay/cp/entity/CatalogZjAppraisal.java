package com.okay.cp.entity;

import java.util.Date;

public class CatalogZjAppraisal {
    private String ideaId;

    private String collectId;

    private String identifyPeople;

    private String duty;

    private String identifyUnit;

    private String identifyDate;

    private String evaluateRange;

    private String identifyOpinion;

    private String creatUser;

    private Date creatTime;

    private String editUser;

    private Date editTime;

    public String getIdeaId() {
        return ideaId;
    }

    public void setIdeaId(String ideaId) {
        this.ideaId = ideaId;
    }

    public String getCollectId() {
        return collectId;
    }

    public void setCollectId(String collectId) {
        this.collectId = collectId;
    }

    public String getIdentifyPeople() {
        return identifyPeople;
    }

    public void setIdentifyPeople(String identifyPeople) {
        this.identifyPeople = identifyPeople;
    }

    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public String getIdentifyUnit() {
        return identifyUnit;
    }

    public void setIdentifyUnit(String identifyUnit) {
        this.identifyUnit = identifyUnit;
    }

    public String getIdentifyDate() {
        return identifyDate;
    }

    public void setIdentifyDate(String identifyDate) {
        this.identifyDate = identifyDate;
    }

    public String getEvaluateRange() {
        return evaluateRange;
    }

    public void setEvaluateRange(String evaluateRange) {
        this.evaluateRange = evaluateRange;
    }

    public String getIdentifyOpinion() {
        return identifyOpinion;
    }

    public void setIdentifyOpinion(String identifyOpinion) {
        this.identifyOpinion = identifyOpinion;
    }

    public String getCreatUser() {
        return creatUser;
    }

    public void setCreatUser(String creatUser) {
        this.creatUser = creatUser;
    }

    public Date getCreatTime() {
        return creatTime;
    }

    public void setCreatTime(Date creatTime) {
        this.creatTime = creatTime;
    }

    public String getEditUser() {
        return editUser;
    }

    public void setEditUser(String editUser) {
        this.editUser = editUser;
    }

    public Date getEditTime() {
        return editTime;
    }

    public void setEditTime(Date editTime) {
        this.editTime = editTime;
    }
}