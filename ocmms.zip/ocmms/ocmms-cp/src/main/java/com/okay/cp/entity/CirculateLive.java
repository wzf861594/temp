package com.okay.cp.entity;

import java.util.Date;

public class CirculateLive {
    private String liveId;

    private String collectId;

    private String institution;

    private String collectUser;

    private String collectTimeScope;

    private String liveSummary;

    private String creatUser;

    private Date creatTime;

    private String updateUser;

    private Date updateTime;

    public String getLiveId() {
        return liveId;
    }

    public void setLiveId(String liveId) {
        this.liveId = liveId;
    }

    public String getCollectId() {
        return collectId;
    }

    public void setCollectId(String collectId) {
        this.collectId = collectId;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getCollectUser() {
        return collectUser;
    }

    public void setCollectUser(String collectUser) {
        this.collectUser = collectUser;
    }

    public String getCollectTimeScope() {
        return collectTimeScope;
    }

    public void setCollectTimeScope(String collectTimeScope) {
        this.collectTimeScope = collectTimeScope;
    }

    public String getLiveSummary() {
        return liveSummary;
    }

    public void setLiveSummary(String liveSummary) {
        this.liveSummary = liveSummary;
    }

    public String getCreatUser() {
        return creatUser;
    }

    public void setCreatUser(String creatUser) {
        this.creatUser = creatUser;
    }

    public Date getCreatTime() {
        return creatTime;
    }

    public void setCreatTime(Date creatTime) {
        this.creatTime = creatTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}