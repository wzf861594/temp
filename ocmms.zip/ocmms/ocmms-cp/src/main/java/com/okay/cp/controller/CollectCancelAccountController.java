package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.okay.cp.baseBusiness.CollectInfoBaseBusiness;
import com.okay.cp.entity.CollectInfo;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.CollectInfoService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 藏品注销账控制层
 *
 * @author zhangyx
 * @since 2019/9/18 14:50
 */
@RestController
@RequestMapping(value = "/cancelAccount")
public class CollectCancelAccountController extends CollectInfoBaseBusiness {

    @Autowired
    private CollectInfoService collectInfoService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;

    /**
     * 初始化查询表单
     *
     * @return
     */
    @RequestMapping(value = "/query", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject initForm() {
        JSONObject jsonObject = new JSONObject();
        try {
            //获取藏品类别
            JSONArray typeArray = collectCommonCodeService.selectCollectType();
            jsonObject.put("collectType", typeArray);

            //获取级别
            JSONArray levelOptions = collectCommonCodeService.selectCollectLev();
            jsonObject.put("cpLevel", levelOptions);

            //获取完残程度
            JSONArray degreeOptions = collectCommonCodeService.completeDegreeOptions();
            jsonObject.put("completeDegree", degreeOptions);

            //库房树形结构
            JSONArray storehouseTree = collectCommonCodeService.selectCollectStorehouseTree();
            jsonObject.put("storehouseTree", storehouseTree);

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 加载数据列表
     *
     * @return JSONObject
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();
        try {
            selectParam(page);

            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);

            JSONArray dataList = new JSONArray();
            for (int i = 0; i < collectInfoList.size(); i++) {
                CollectInfo collectInfo = collectInfoList.get(i);
                String jsonString = JSONObject.toJSONString(collectInfo);
                JSONObject collectInfoJson = JSONObject.parseObject(jsonString);

                //小图
//                JSONObject jsonObject1 = collectCommonBusinessService.getMainBodyRes("90", collectInfo.getCollectId());
//                collectInfoJson.put("image", jsonObject1.getString("coverUrl"));
                String imgBase64 = collectCommonBusinessService.getCoverImg("90", collectInfo.getCollectId());
                collectInfoJson.put("image", imgBase64);

                //藏品类别
                String collectType_t = collectCommonCodeService.collectType_t(collectInfo.getCollectType());
                collectInfoJson.put("collectType", collectType_t);

                //完残程度
                String completeDegree_t = collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree());
                collectInfoJson.put("completeDegree", completeDegree_t);

                //级别
                String cpLev_t = collectCommonCodeService.cpLev_t(collectInfo.getCpLevel());
                collectInfoJson.put("cpLevel", cpLev_t);

                //来源方式
                String source_t = collectCommonCodeService.source_t(collectInfo.getSource());
                collectInfoJson.put("source", source_t);

                //库房
                String storehouse_t = collectCommonCodeService.storehouse_t(collectInfo.getStorehouse());
                collectInfoJson.put("storehouse", storehouse_t);

                dataList.add(collectInfoJson);
            }
            jsonObject.put("data", dataList);
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 选择导出的表头
     *
     * @return
     */
    @RequestMapping(value = "/exportHeaderOptions", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeaderOptions() {
        JSONObject jsonObject = new JSONObject();
        try {

            List headers = new ArrayList();
            JSONObject headerJson = new JSONObject();
            headerJson.put("label", "藏品名称");
            headerJson.put("key", "collectName");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品原名");
            headerJson.put("key", "collectNameOld");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "普查名称");
            headerJson.put("key", "censusName");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "总登记号");
            headerJson.put("key", "totalNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "分类号");
            headerJson.put("key", "classNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品编号");
            headerJson.put("key", "collectCode");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "收入号");
            headerJson.put("key", "incomeNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "年代");
            headerJson.put("key", "years");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体年代");
            headerJson.put("key", "specificAge");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "级别");
            headerJson.put("key", "cpLevel");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品类别");
            headerJson.put("key", "collectType");
            headers.add(headerJson);

//            headerJson = new JSONObject();
//            headerJson.put("label", "质地类别");
//            headerJson.put("key", "textureType");
//            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体质地");
            headerJson.put("key", "texture");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "质量范围");
            headerJson.put("key", "massRange");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "质量单位");
            headerJson.put("key", "massUnit");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体质量");
            headerJson.put("key", "specificMass");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "数量");
            headerJson.put("key", "quantity");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "实际数量");
            headerJson.put("key", "realNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "长(cm)");
            headerJson.put("key", "length");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "宽(cm)");
            headerJson.put("key", "width");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "高(cm)");
            headerJson.put("key", "height");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "口径(cm)");
            headerJson.put("key", "bore");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "底径(cm)");
            headerJson.put("key", "bottomDiameter");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "腹经(cm)");
            headerJson.put("key", "abdominal");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "直径(cm)");
            headerJson.put("key", "diameter");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体尺寸");
            headerJson.put("key", "specificSize");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "完残程度");
            headerJson.put("key", "completeDegree");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "保存状态");
            headerJson.put("key", "keepState");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "完残状况");
            headerJson.put("key", "completeDesc");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "包装情况");
            headerJson.put("key", "packCondition");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "来源方式");
            headerJson.put("key", "source");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "产地");
            headerJson.put("key", "productPlace");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "入馆时间");
            headerJson.put("key", "inMsDt");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "入藏时间");
            headerJson.put("key", "collectTimeRange");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销登记号");
            headerJson.put("key", "cancelNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销经办人");
            headerJson.put("key", "cancelHandelUser");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销经办时间");
            headerJson.put("key", "cancelHandelDate");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销去向");
            headerJson.put("key", "cancelWhere");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销批准人");
            headerJson.put("key", "cancelApproveUser");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销日期");
            headerJson.put("key", "cancelDate");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销批准文号");
            headerJson.put("key", "cancelApproveNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "注销批准单位");
            headerJson.put("key", "cancelApproveUnit");
            headers.add(headerJson);

            jsonObject.put("headerOptions", headers);
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 数据导出
     *
     * @return
     */
    @SysLog("注销帐-数据导出")
    @RequestMapping(value = "/dataExport", method = RequestMethod.POST, produces = "application/json")
    public void dataExport(@RequestBody JSONObject json, HttpServletRequest request, HttpServletResponse response) {
        try {
            //查询数据 转换查询条件
            JSONObject pageJson = json.getJSONObject("page");
            Page page = pageJson.toJavaObject(Page.class);

            selectParam(page);

            //导出类型
            String exportType = json.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }

            if (exportType.equals("0")) {
                //导出查询的全部数据
                page.setPageSize(0);
                page.getConditionMap().put("orderBy", "pubDate desc");
            } else if (exportType.equals("1")) {
                //导出当前页的数据
                page.setOrderBy("pubDate desc");
            } else if (exportType.equals("2")) {
                page.setOrderBy("pubDate desc");
                //2：选择的数据
                String collectIds = json.getString("collectIds");
                page.getConditionMap().put("collectIds", Arrays.asList(collectIds.split(",")));
            }

            //获取选择的头部
            List headerNameList = new ArrayList(10);
            List headerKeyList = new ArrayList(10);
            JSONArray exportColumn = json.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            //封装实体数据
            List dataList = new ArrayList(10);
            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);
            for (int i = 0; i < collectInfoList.size(); i++) {
                CollectInfo collectInfo = collectInfoList.get(i);
                //实体类转换成 json对象
                JSONObject collectInfo_inObject = JSONObject.parseObject(JSONObject.toJSONString(collectInfo, SerializerFeature.WriteNullStringAsEmpty));
                //获取选择的列数据
                boolean calcInStoreNum = false;//是否已经计算过在库数量
                int inStoreNum = 0;//在库数量
                List obj = new ArrayList();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = headerKeyList.get(j).toString();
                    String value = collectInfo_inObject.getString(key);

                    //---------------------获取翻译值---------------------------------
                    if (key.equals("years")) {
                        //年代
                        value = collectCommonCodeService.collectAge_t(collectInfo.getYears());
                    } else if (key.equals("cpLevel")) {
                        //级别
                        value = collectCommonCodeService.cpLev_t(collectInfo.getCpLevel());
                    } else if (key.equals("collectType")) {
                        //藏品类别;
                        value = collectCommonCodeService.collectType_t(collectInfo.getCollectType());
                    } else if (key.equals("textureType")) {
                        //质地类别;
                        value = collectCommonCodeService.textureType_t(collectInfo.getTextureType());
                    } else if (key.equals("texture")) {
                        // 质地;
                        //value = collectCommonCodeService.texture_t(collectInfo.getTexture());
                    } else if (key.equals("massRange")) {
                        // 质量范围;
                        value = collectCommonCodeService.massRange_t(collectInfo.getMassRange());
                    } else if (key.equals("massUnit")) {
                        // 质量单位;
                        value = collectCommonCodeService.massUnit_t(collectInfo.getMassUnit());
                    } else if (key.equals("quantity")) {
                        // 数量;
                        if(collectInfo.getNumUnit() != null && collectInfo.getNumUnit() != ""){
                            value = collectInfo.getQuantity() + collectCommonCodeService.numUnit_t(collectInfo.getNumUnit());
                        }else {
                            value = collectInfo.getQuantity();
                        }
                    } else if (key.equals("completeDegree")) {
                        // 完残程度;
                        value = collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree());
                    } else if (key.equals("keepState")) {
                        // 保存状态;
                        value = collectCommonCodeService.keepState_t(collectInfo.getKeepState());
                    } else if (key.equals("source")) {
                        // 来源方式;
                        value = collectCommonCodeService.source_t(collectInfo.getSource());
                    } else if (key.equals("cancelHandelUser")) {
                        value = collectCommonBusinessService.getUserNames(collectInfo.getCancelHandelUser());
                    }
                    obj.add(value);
                }
                dataList.add(obj);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, dataList);
            DataExportUtils.setResponseHeader(response, wb, "藏品正式账");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 通用查询条件
     *
     * @return
     */
    private static void selectParam(Page page) {
        page.setOrderBy("cancelDate desc");
    }
}
