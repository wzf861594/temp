package com.okay.cp.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectInfo;
import com.okay.cp.entity.QrCode;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.CollectInfoService;
import com.okay.cp.service.QrCodeService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DateUtil;
import com.okay.framework.utils.QRCodeUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @Description: 二维码控制器
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-12 13:34
 */

@RestController
@RequestMapping("/qrCode")
public class QRCodeController {

    @Autowired
    private CollectInfoService collectInfoService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private QrCodeService qrCodeService;

    /**
     * 获取二维码图片
     * @param id
     * @return
     */
    @RequestMapping(value = "/image/{id}/{version}", method = RequestMethod.GET)
    public JSONObject getCodeImage(@PathVariable String id, @PathVariable Integer version) {

        JSONObject jsonObject = new JSONObject();

        try {
            if (!StringUtils.isEmpty(id)) {
                jsonObject = qrCodeService.findQrCodeStream(id, version);
                String imageToBase64 = QRCodeUtils.inputStreamToBase64((InputStream)jsonObject.remove("inputStream"));
                jsonObject.put("imageBase64", imageToBase64);
            }
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @RequestMapping(value = "/imageIo/{id}/{version}", method = RequestMethod.GET)
    public void getimageIo(HttpServletResponse response, @PathVariable String id, @PathVariable Integer version) {

        InputStream inputStream = null;
        OutputStream outputStream = null;
        byte[] data = null;

        try {
            // 创建图片输出流
            response.setContentType("image/jpeg");
            response.setCharacterEncoding("UTF-8");

            inputStream = qrCodeService.findQrCodeInputStream(id, version);

            if (inputStream != null) {
                data = new byte[(int) inputStream.available()];
                inputStream.read(data);
                inputStream.close();
            }

            if (data != null) {
                outputStream = response.getOutputStream();
                outputStream.write(data);
                outputStream.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("图片获取失败");
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                }
            }
        }
    }

    /**
     * 二维码logo添加
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/insertLogo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject insertLogo(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();

        try {
            String qrCodeId = jsonParam.getString("qrCodeId");
            String collcetId = jsonParam.getString("collcetId");

            if (!StringUtils.isEmpty(qrCodeId) && !StringUtils.isEmpty(collcetId)) {
                QrCode qrCode = qrCodeService.insertLogo(qrCodeId, collcetId);
                String imageToBase64 = QRCodeUtils.byteToBase64(qrCode.getQrCodeImg());
                jsonObject.put("imageBase64", imageToBase64);
            }
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 藏品二维码检索
     * @return
     */
    @RequestMapping(value = "/searchList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject search(@RequestBody JSONObject json) {

        // 查询结果
        List<Map<String, Object>> dataList = null;
        // 返回结果
        JSONObject jsonObject = new JSONObject();

        try {
            // 搜索框查询条件
            JSONObject searchParam = json.getJSONObject("searchParam");
            String labelName = searchParam.getString("labelName");
            // 查询面板过滤条件
            JSONObject filterParam = json.getJSONObject("filterParam");
            //藏品类别
            List typeList = filterParam.getJSONArray("type");
            //来源方式
            List sourceList = filterParam.getJSONArray("source");
            //完残程度
            List completeDegreeList = filterParam.getJSONArray("completeDegree");
            //保存状况
            List keepStateList = filterParam.getJSONArray("keepState");
            //级别
            List levList = filterParam.getJSONArray("lev");
            //库房位置
            String storehouse = filterParam.getString("storehouse");
            //年代
            String age_string = getAgeString(filterParam.getJSONArray("year"));
            //藏品分类
            String collectClass = filterParam.getString("collectClass");
            //分页
            JSONObject pageData = json.getJSONObject("pageData");
            // 查询版本
            Integer version = 1;
            Integer v = json.getInteger("version");
            if (v != null) {
                version = v;
            }

            Map<String, Object> conditionMap = new HashMap();
            conditionMap.put("labelName", labelName);
            conditionMap.put("typeList", typeList);
            conditionMap.put("sourceList", sourceList);
            conditionMap.put("completeDegreeList", completeDegreeList);
            conditionMap.put("keepStateList", keepStateList);
            conditionMap.put("levList", levList);
            conditionMap.put("years", age_string);
            conditionMap.put("storehouse", storehouse);
            conditionMap.put("collectClass", collectClass);
            conditionMap.put("version", version);

            Page page = new Page();
            page.setConditionMap(conditionMap);
            page.setPageNum(pageData.getInteger("pageNum"));
            page.setPageSize(pageData.getInteger("pageSize"));

            dataList = qrCodeService.findMapOfProcessedByQuery(page);

            jsonObject.put("data", dataList);
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("code", "1");

        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 藏品二维码导出
     * @return
     */
    @RequestMapping(value = "/export", method = RequestMethod.POST)
    public void export(@RequestBody JSONObject json, HttpServletRequest request, HttpServletResponse response) {

        try {
            // 响应信息
            String fileName = "藏品二维码_" + DateUtil.getNextTime() + ".zip";
            fileName = URLEncoder.encode(fileName, "UTF-8"); // 支持中文
            response.reset();// 重置响应头
            response.setCharacterEncoding("UTF-8");
            response.setDateHeader("Expires", 0);
            response.setHeader("filename",fileName);
            response.setHeader("Pragma", "no-cache");
            response.setHeader("Cache-Control", "no-cache");
            response.setContentType("application/octet-stream"); // 设置以流的形式下载文件
            response.setHeader("Content-Disposition","attachment;filename=" + fileName);

            // 导出二维码主键
            List<String> exportIdList = new ArrayList<String>();
            // 导出类型
            String exportType = json.getString("exportType");

            if ("0".equals(exportType)) {
                List activeKeyList = json.getJSONArray("activeKey");
                if (activeKeyList == null || activeKeyList.size() <= 0){
                    throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
                }
                exportIdList = activeKeyList;
            }

            // 搜索框查询条件
            JSONObject searchParam = json.getJSONObject("searchParam");
            String labelName = searchParam.getString("labelName");
            // 查询面板过滤条件
            JSONObject filterParam = json.getJSONObject("filterParam");
            //藏品类别
            List typeList = filterParam.getJSONArray("type");
            //来源方式
            List sourceList = filterParam.getJSONArray("source");
            //完残程度
            List completeDegreeList = filterParam.getJSONArray("completeDegree");
            //保存状况
            List keepStateList = filterParam.getJSONArray("keepState");
            //级别
            List levList = filterParam.getJSONArray("lev");
            //库房位置
            String storehouse = filterParam.getString("storehouse");
            //年代
            String age_string = getAgeString(filterParam.getJSONArray("year"));
            //藏品分类
            String collectClass = filterParam.getString("collectClass");
            //分页
            JSONObject pageData = json.getJSONObject("pageData");
            // 查询版本
            Integer version = 1;
            Integer v = json.getInteger("version");
            if (v != null) {
                version = v;
            }

            Map<String, Object> conditionMap = new HashMap();
            conditionMap.put("labelName", labelName);
            conditionMap.put("typeList", typeList);
            conditionMap.put("sourceList", sourceList);
            conditionMap.put("completeDegreeList", completeDegreeList);
            conditionMap.put("keepStateList", keepStateList);
            conditionMap.put("levList", levList);
            conditionMap.put("years", age_string);
            conditionMap.put("storehouse", storehouse);
            conditionMap.put("collectClass", collectClass);
            conditionMap.put("version", version);
            conditionMap.put("exportIdList", exportIdList);

            Page page = new Page();
            page.setConditionMap(conditionMap);
            page.setPageNum(pageData.getInteger("pageNum"));
            page.setPageSize("2".equals(exportType) ? 0 : pageData.getInteger("pageSize"));

            // 查询结果
            List<Map<String, Object>> dataList = qrCodeService.findMapOfProcessedByQuery(page);
            // 客户端响应
            clientResponse(dataList, response.getOutputStream());

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    public void clientResponse(List<Map<String, Object>> dataList,OutputStream outputStream) throws IOException {

        ZipOutputStream zipOutputStream = null;
        try {
            zipOutputStream = new ZipOutputStream(outputStream);
            byte[] buffer = new byte[1024];
            for (Map<String, Object> dataMap : dataList) {
                if ("null".equals(String.valueOf(dataMap.get("qrCodeImg")))) {
                    continue;
                }
                // 藏品名称
                CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(String.valueOf(dataMap.get("collectId")));
                String collectName = collectInfo.getCollectName();

                String name = collectName == null ? String.valueOf(dataMap.get("qrCodeImg")) : collectName;
                byte[] qrCodeByte = (byte[])dataMap.get("qrCodeImg");
                InputStream inputStream = new ByteArrayInputStream(qrCodeByte);
                zipOutputStream.putNextEntry(new ZipEntry(name + "." + QRCodeUtils.FORMAT));
                int len;
                while ((len = inputStream.read(buffer)) != -1) {
                    zipOutputStream.write(buffer, 0, len);
                }
                zipOutputStream.flush();
                zipOutputStream.closeEntry();
                inputStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (zipOutputStream != null) {
                zipOutputStream.close();
            }
            outputStream.close();
        }
    }

//    public String getAgeString(List ageList){
//        StringBuilder ageString = new StringBuilder();
//        if (ageList != null) {
//            for (int i = 0; i < ageList.size(); i++) {
//                Object ageObject = ageList.get(i);
//                if (ageObject != null) {
//                    ageString.append(ageObject.toString());
//                }
//            }
//        }
//        return ageString.toString();
//    }

    public String getAgeString(List ageList){
        String ids = "";
        if (ageList != null){
            for (int i = 0; i < ageList.size(); i++){
                String age = ageList.get(i).toString();
                if (ids.equals("")){
                    ids = age;
                } else {
                    ids += ",";
                    ids += age;
                }
            }
        }
        return ids;
    }

}
