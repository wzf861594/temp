package com.okay.cp.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 修复仪器管理表
 *
 * @author CZJ[OKAY]
 * @date 2021-12-13 09:55:31
 */
@Data
@ApiModel(value = "修复仪器管理表")
public class CpRepairInstrument extends BaseModel {

    @ExcelIgnore
    @TableId(type = IdType.INPUT)
    @ApiModelProperty(value = "主键")
    private String id;

    @ExcelProperty(value = "仪器名称")
    private String name;

    @ExcelProperty(value = "品牌")
    private String brand;

    @ExcelProperty(value = "仪器型号")
    private String model;

    @ExcelProperty(value = "仪器功能")
    private String features;

    @ExcelProperty(value = "购买数量")
    private BigDecimal quantity;

    @ExcelProperty(value = "购买价格")
    private BigDecimal amount;

    @ExcelProperty(value = "购买时间")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd", iso = DateTimeFormat.ISO.DATE)
    @com.alibaba.excel.annotation.format.DateTimeFormat(value = "yyyy-MM-dd")
    private Date buyTime;

    @ExcelProperty(value = "产地")
    private String origin;

    @ExcelProperty(value = "供应商")
    private String supplier;

    @ExcelProperty(value = "联系人")
    private String contactPerson;

    @ExcelProperty(value = "联系方式")
    private String contactWay;

    @ExcelProperty(value = "备注")
    private String remark;

}