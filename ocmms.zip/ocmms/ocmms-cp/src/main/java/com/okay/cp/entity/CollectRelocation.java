package com.okay.cp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class CollectRelocation {
    private String relocationId;

    private String relocationCollectId;

    private String relocationReason;

    private String relocationBefore;

    private String relocationAfter;

    private String createUser;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    public String getRelocationId() {
        return relocationId;
    }

    public void setRelocationId(String relocationId) {
        this.relocationId = relocationId;
    }

    public String getRelocationCollectId() {
        return relocationCollectId;
    }

    public void setRelocationCollectId(String relocationCollectId) {
        this.relocationCollectId = relocationCollectId;
    }

    public String getRelocationReason() {
        return relocationReason;
    }

    public void setRelocationReason(String relocationReason) {
        this.relocationReason = relocationReason;
    }

    public String getRelocationBefore() {
        return relocationBefore;
    }

    public void setRelocationBefore(String relocationBefore) {
        this.relocationBefore = relocationBefore;
    }

    public String getRelocationAfter() {
        return relocationAfter;
    }

    public void setRelocationAfter(String relocationAfter) {
        this.relocationAfter = relocationAfter;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}