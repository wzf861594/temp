package com.okay.cp.controller;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.R;
import com.okay.cp.baseBusiness.CollectInfoBaseBusiness;
import com.okay.cp.entity.BrowseRecord;
import com.okay.cp.entity.CollectInfo;
import com.okay.cp.entity.CpLabel;
import com.okay.cp.service.*;
import com.okay.cp.utils.CollectUtils;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.ComUtils;
import com.okay.framework.utils.DataUtil;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 藏品检索
 *
 * @author zhangyx
 * @since 2019/7/23 20:36
 */
@RestController
@AllArgsConstructor
@RequestMapping(value = "/cpSearch")
public class CpSearchController extends CollectInfoBaseBusiness {


    private final CpLabelService cpLabelService;
    private final CollectCommonCodeService collectCommonCodeService;
    private final CollectInfoService collectInfoService;
    private final BrowseRecordService browseRecordService;
    private final CollectSingleListService collectSingleListService;

    /**
     * 初始化条件参数
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/initParam", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject initParam(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //藏品类别
            JSONArray typeOptions = collectCommonCodeService.selectCollectType();
            for (int i = 0; i < typeOptions.size(); i++) {
                JSONObject jsonObject1 = (JSONObject) typeOptions.get(i);
                jsonObject1.put("selected", false);
            }
            jsonObject.put("typeOptions", typeOptions);

            //来源方式
            JSONArray sourceOptions = collectCommonCodeService.sourceOptions();
            for (int i = 0; i < sourceOptions.size(); i++) {
                JSONObject jsonObject1 = (JSONObject) sourceOptions.get(i);
                jsonObject1.put("selected", false);
            }
            jsonObject.put("sourceOptions", sourceOptions);

            //完残程度
            JSONArray completeDegreeOptions = collectCommonCodeService.completeDegreeOptions();
            for (int i = 0; i < completeDegreeOptions.size(); i++) {
                JSONObject jsonObject1 = (JSONObject) completeDegreeOptions.get(i);
                jsonObject1.put("selected", false);
            }
            jsonObject.put("completeDegreeOptions", completeDegreeOptions);

            //保存状况
            JSONArray keepStateOptions = collectCommonCodeService.keepStateOptions();
            for (int i = 0; i < keepStateOptions.size(); i++) {
                JSONObject jsonObject1 = (JSONObject) keepStateOptions.get(i);
                jsonObject1.put("selected", false);
            }
            jsonObject.put("keepStateOptions", keepStateOptions);

            //级别
            JSONArray levOptions = collectCommonCodeService.selectCollectLev();
            for (int i = 0; i < levOptions.size(); i++) {
                JSONObject jsonObject1 = (JSONObject) levOptions.get(i);
                jsonObject1.put("selected", false);
            }
            jsonObject.put("levOptions", levOptions);

            //质量范围
            JSONArray massRangeOptions = collectCommonCodeService.massRangeOptions();
            for (int i = 0; i < massRangeOptions.size(); i++) {
                JSONObject jsonObject1 = (JSONObject) massRangeOptions.get(i);
                jsonObject1.put("selected", false);
            }
            jsonObject.put("massRangeOptions", massRangeOptions);

            //质量单位
            JSONArray massUnitOptions = collectCommonCodeService.massUnitOptions();
            jsonObject.put("massUnitOptions", massUnitOptions);

            //年代
            JSONArray yearOptions = collectCommonCodeService.selectCollectAgeTree();
            jsonObject.put("yearOptions", yearOptions);

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取库房选项
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/storehouseOptions", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject storehouseOptions(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //库房选择
            JSONArray storehouseOptions = collectCommonCodeService.selectCollectStorehouseTree();
            jsonObject.put("storehouseOptions", storehouseOptions);

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }


    /**
     * 藏品检索
     *
     * @return
     */
    @RequestMapping(value = "/searchDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject search(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //查询条件
            JSONObject searchParam = json.getJSONObject("searchParam");
            String labelName = searchParam.getString("labelName");//检索标签名称

            //过滤条件
            JSONObject filterParam = json.getJSONObject("filterParam");

            //藏品类别
            List typeList = filterParam.getJSONArray("type");
            //来源方式
            List sourceList = filterParam.getJSONArray("source");
            //完残程度
            List completeDegreeList = filterParam.getJSONArray("completeDegree");
            //保存状况
            List keepStateList = filterParam.getJSONArray("keepState");
            //级别
            List levList = filterParam.getJSONArray("lev");
            //质量范围
            List massRangeList = filterParam.getJSONArray("massRange");
            //质量单位
            String massUnit = filterParam.getString("massUnit");
            //库房位置
            String storehouse = filterParam.getString("storehouse");
            //年代
            List ageList = filterParam.getJSONArray("year");
            String age_string = "";
            if (ageList != null) {
                for (int i = 0; i < ageList.size(); i++) {
                    String str = ageList.get(i).toString();
                    if (age_string.equals("")) {
                        age_string += str;
                    } else {
                        age_string += ",";
                        age_string += str;
                    }
                }
            }
            //藏品分类
            String collectClass = filterParam.getString("collectClass");

            //排序
            JSONObject orderByJson = json.getJSONObject("orderBy");

            String type = orderByJson.getString("type");
            String sort = orderByJson.getString("sort");
            String orderBy = "pubDate desc,browseCount desc";
            if (type.equals("0")) {
                //综合
            } else if (type.equals("1")) {
                if (sort.equals("1")) {
                    orderBy = "browseCount asc";
                } else {
                    orderBy = "browseCount desc";
                }
            } else if (type.equals("2")) {
                if (sort.equals("1")) {
                    orderBy = "collectCount asc";
                } else {
                    orderBy = "collectCount desc";
                }
            }

            //分页
            JSONObject pageData = json.getJSONObject("pageData");
            Page page = new Page();
            page.setPageNum(pageData.getInteger("pageNum"));
            page.setPageSize(pageData.getInteger("pageSize"));

            Map<String, Object> conditionMap = new HashMap();
            conditionMap.put("labelName", labelName);

            conditionMap.put("typeList", typeList);
            conditionMap.put("sourceList", sourceList);
            conditionMap.put("completeDegreeList", completeDegreeList);
            conditionMap.put("keepStateList", keepStateList);
            conditionMap.put("levList", levList);
            conditionMap.put("massRangeList", massRangeList);
            conditionMap.put("years", age_string);
            conditionMap.put("massUnit", massUnit);
            conditionMap.put("storehouse", storehouse);
            conditionMap.put("collectClass", collectClass);

            page.setConditionMap(conditionMap);

            page.setOrderBy(orderBy);

            List<CollectInfo> collectInfoList = collectInfoService.searchBySearchParameter(page);

            JSONArray jsonArray = new JSONArray();
            for (int i = 0; i < collectInfoList.size(); i++) {
                CollectInfo collectInfo = collectInfoList.get(i);

                String collectInfo_string = JSONObject.toJSONString(collectInfo);
                JSONObject jsonObject1 = JSONObject.parseObject(collectInfo_string);

                //来源
                String source = collectInfo.getSource();
                String source_t = collectCommonCodeService.source_t(source);
                jsonObject1.put("source_t", source_t);

                //级别
                String cpLevel = collectInfo.getCpLevel();
                String cpLevel_t = collectCommonCodeService.cpLev_t(cpLevel);
                jsonObject1.put("cpLevel_t", cpLevel_t);

                //类别
                String typeId = collectInfo.getCollectType();
                String collectType_t = collectCommonCodeService.collectType_t(typeId);
                jsonObject1.put("collectType_t", collectType_t);

                //年代翻译值
                String years = collectInfo.getYears();
                String years_t = collectCommonCodeService.collectAge_t(years);
                jsonObject1.put("years_t", years_t);

                //藏品封面图
                jsonObject1.put("imgUrl", CollectUtils.getCollectImageIoUrl(collectInfo.getCollectId()));

                //判断当前藏品是否已经收藏
                User user = ComUtils.getLoginUser();
                int record = collectSingleListService.selectCollectCpRecord(collectInfo.getCollectId(), user.getUserId());
                if (record > 0) {
                    jsonObject1.put("collectFlg", "1");
                } else {
                    jsonObject1.put("collectFlg", "0");
                }

                // 对浏览量、下载量、收藏量1000以上用万做单位
                Integer browseCount = collectInfo.getBrowseCount();
                Integer collectCount = collectInfo.getCollectCount();
                if (browseCount > 1000) {
                    BigDecimal bigDecimal = new BigDecimal((double) browseCount / 10000);
                    // 四舍五入后保留两位小数
                    double result = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
                    jsonObject1.put("browseCount", result + "万");
                }
                if (collectCount > 1000) {
                    BigDecimal bigDecimal = new BigDecimal((double) collectCount / 10000);
                    // 四舍五入后保留两位小数
                    double result = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
                    jsonObject1.put("collectCount", result + "万");
                }
                jsonArray.add(jsonObject1);
            }

            jsonObject.put("data", jsonArray);
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("code", "1");

        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 检索词匹配
     *
     * @return
     */
    @RequestMapping(value = "/wordsMatching", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject wordsMatching(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String words = json.getString("labelName");

            JSONArray jsonArray = new JSONArray();
            if (!DataUtil.isEmpty(words)) {
                CpLabel cpLabel = new CpLabel();
                cpLabel.setLabName(words);
                List<CpLabel> labelList = cpLabelService.selectCpLabelNameGroup(cpLabel);

                for (int i = 0; i < labelList.size(); i++) {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("value", labelList.get(i).getLabName());
                    jsonArray.add(jsonObject1);
                }
            } else {
                //如果输入的关键词为空的 则显示浏览量前五的数据
                CollectInfo collectInfo = new CollectInfo();
                List<CollectInfo> collectInfoList = collectInfoService.searchHotCollect(collectInfo);
                for (int i = 0; i < collectInfoList.size(); i++) {
                    CollectInfo collectInfo1 = collectInfoList.get(i);
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("value", collectInfo1.getCollectName());
                    jsonArray.add(jsonObject1);
                }
            }
            jsonObject.put("data", jsonArray);
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 增加藏品浏览量.
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/addBrowse", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject addBrowse(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            // 更新浏览记录表
            String collectId = json.getString("collectId");
            BrowseRecord browseRecord = new BrowseRecord();
            browseRecord.setCollectId(collectId);
            browseRecordService.addRecord(browseRecord);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 藏品检索
     *
     * @return JSONObject
     */
    @PostMapping(value = "/collectInfoList")
    public JSONObject collectInfoList(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            Page page = new Page();
            // 处理查询条件
            queryConditions(page, json);
            List<CollectInfo> collectInfoList = collectInfoService.collectInfoSearch(page);
            jsonObject.put("data", collectInfoList);
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("code", "1");

        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 新-藏品检索
     *
     * @param json 查询条件
     * @return
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/collectionSearch")
    public JSONObject collectionSearch(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {

            Page page = new Page();
            // 处理查询条件
            queryConditions(page, json);
            // 查询数据
            List<CollectInfo> collectInfoList = collectInfoService.collectInfoSearch(page);

            jsonObject.put("data", collectInfoList);
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("code", "1");

        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 处理查询条件
     *
     * @param page 分页
     * @param json 查询条件
     * @author CZJ[OKAY]
     **/
    private void queryConditions(Page page, JSONObject json) {
        //查询条件
        JSONObject searchParam = json.getJSONObject("searchParam");
        //检索标签名称
        String labelName = searchParam.getString("labelName");

        //过滤条件
        JSONObject filterParam = json.getJSONObject("filterParam");

        //藏品类别
        List typeList = filterParam.getJSONArray("type");
        //来源方式
        List sourceList = filterParam.getJSONArray("source");
        //完残程度
        List completeDegreeList = filterParam.getJSONArray("completeDegree");
        //保存状况
        List keepStateList = filterParam.getJSONArray("keepState");
        //级别
        List levList = filterParam.getJSONArray("lev");
        //质量范围
        List massRangeList = filterParam.getJSONArray("massRange");
        //质量单位
        String massUnit = filterParam.getString("massUnit");
        //库房位置
        String storehouse = filterParam.getString("storehouse");
        // 所属单位
        List<String> ownerUnits = (List<String>) filterParam.get("ownerUnit");
        List<Integer> ownerUnitList = new ArrayList<>(1);
        if (CollectionUtil.isNotEmpty(ownerUnits)) {
            ownerUnitList = ownerUnits.stream().map(Integer::valueOf).collect(Collectors.toList());
        }

        // 提借大类
        List<String> borrowTotalTypes = (List<String>) filterParam.get("borrowTotalTypeList");
        List<Integer> borrowTotalTypeList = new ArrayList<>(1);
        boolean isGeneral = false;
        if (CollectionUtil.isNotEmpty(borrowTotalTypes)) {
            borrowTotalTypeList = borrowTotalTypes.stream().map(Integer::valueOf).collect(Collectors.toList());
            isGeneral = borrowTotalTypeList.contains(1);
        }

        // 具体提借类型
        List<String> borrowTypes = (List<String>) filterParam.get("borrowTypeList");
        List<Integer> borrowTypeList = new ArrayList<>(1);
        if (CollectionUtil.isNotEmpty(borrowTypes)) {
            borrowTypeList = borrowTypes.stream().map(Integer::valueOf).collect(Collectors.toList());
        }

        // 在库状态
        String inStockStatus = filterParam.getString("inStockStatus");

        // 可提借数量
        Boolean isBorrow = filterParam.getBoolean("isBorrow");

        //年代
        List ageList = filterParam.getJSONArray("year");
        String age_string = null;
        if (CollectionUtil.isNotEmpty(ageList)) {
            age_string = String.join(",", ageList);
        }

        //藏品分类
        String collectClass = filterParam.getString("collectClass");

        // 藏品ID
        List<String> notCollectId = (List<String>) filterParam.get("notCollectId");

        //排序
        JSONObject orderByJson = json.getJSONObject("orderBy");

        String type = orderByJson.getString("type");
        String sort = orderByJson.getString("sort");

        //分页
        JSONObject pageData = json.getJSONObject("pageData");

        page.setPageNum(pageData.getInteger("pageNum"));
        page.setPageSize(pageData.getInteger("pageSize"));

        Map<String, Object> conditionMap = new HashMap();
        conditionMap.put("labelName", labelName);

        conditionMap.put("typeList", typeList);
        conditionMap.put("sourceList", sourceList);
        conditionMap.put("completeDegreeList", completeDegreeList);
        conditionMap.put("keepStateList", keepStateList);
        conditionMap.put("levList", levList);
        conditionMap.put("massRangeList", massRangeList);
        conditionMap.put("years", age_string);
        conditionMap.put("massUnit", massUnit);
        conditionMap.put("storehouse", storehouse);
        conditionMap.put("collectClass", collectClass);
        conditionMap.put("ownerUnitList", ownerUnitList);
        conditionMap.put("borrowTotalTypeList", borrowTotalTypeList);
        conditionMap.put("isGeneral", isGeneral);
        conditionMap.put("borrowTypeList", borrowTypeList);
        conditionMap.put("inStockStatus", inStockStatus);
        conditionMap.put("sortType", type);
        conditionMap.put("isBorrow", isBorrow);
        conditionMap.put("notCollectId", notCollectId);

        page.setConditionMap(conditionMap);

        String orderBy = "pubDate desc";
        if (type.equals("0")) {
            //综合
        } else if (type.equals("1")) {
            if (sort.equals("1")) {
                orderBy = "sortCount asc";
            } else {
                orderBy = "sortCount desc";
            }
        } else if (type.equals("2")) {
            if (sort.equals("1")) {
                orderBy = "sortCount asc";
            } else {
                orderBy = "sortCount desc";
            }
        }
        page.setOrderBy(orderBy);
    }

    /**
     * 根据藏品ID获取藏品信息
     *
     * @param collectIdList 藏品ID
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/collectInfoByCollectId")
    public R collectInfoByCollectId(@RequestBody List<String> collectIdList) {
        List<CollectInfo> collectInfos = collectInfoService.collectInfoByCollectId(collectIdList);
        return R.ok(collectInfos).setMsg("");
    }

}
