package com.okay.cp.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.baseBusiness.CollectInfoBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectSingle;
import com.okay.cp.entity.CollectSingleList;
import com.okay.cp.service.*;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/7/12 14:05
 * @Version: 1.0
 * @Description: 收藏单控制类
 */

@RestController
@RequestMapping(value = "/collect")
public class CollectSingleController extends CollectInfoBaseBusiness {
    @Autowired
    private CollectSingleService collectSingleService;
    @Autowired
    private CollectSingleListService collectSingleListService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;

    /**
     * 收藏单新增
     * @param collectSingle
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject add(@RequestBody @Valid CollectSingle collectSingle){
        JSONObject jsonObject = new JSONObject();
        try{
            collectSingle = collectSingleService.saveSingle(collectSingle);
            jsonObject.put("id",collectSingle.getSingleId());
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.ADD_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 收藏单更新.
     * @param collectSingle
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject update(@RequestBody @Valid CollectSingle collectSingle){
        JSONObject jsonObject = new JSONObject();
        try{
            String id = collectSingle.getSingleId();
            if (DataUtil.isEmpty(id)){
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            collectSingleService.updateSingle(collectSingle);
            jsonObject.put("id",collectSingle.getSingleId());
            throw new BaseRuntimeException(CollectErrorDefine.UPDATE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 根据主键查询收藏单
      *@Return :
      **/
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getSingle(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("singleId");
        try{
            if (DataUtil.isEmpty(id)){
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            CollectSingle collectSingle = collectSingleService.findBySingleId(id);
            jsonObject.put("data",collectSingle);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 收藏单明细查询
      *@Return :
      **/
    @RequestMapping(value = "/singleList", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getSingleList(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("singleId");
        String searchName = jsonParam.getString("searchName");
        try{
            if (DataUtil.isEmpty(id)){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            List<Map<String,Object>> resList = collectSingleListService.findListBySingleId(id,searchName);
            jsonObject.put("data",resList);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 收藏单删除
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject delete(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("singleId");
        try{
            if (DataUtil.isEmpty(id)){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (!jsonParam.getBooleanValue("confirmFlg")){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            List<String> idList = Arrays.asList(id.split(","));
            collectSingleService.deleteBySngleId(idList);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     *@Author : xdn
     *@Description : 清单挑选页 => 收藏资源、收藏单
     *@Return :
     **/
    @RequestMapping(value = "/getResource", method = RequestMethod.POST, produces = "application/json")
    public JSONObject getCollectResource(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String  tabIndex = jsonParam.getString("tabIndex").toString();
            String searchName = jsonParam.getString("searchName").toString();
            if(DataUtil.isEmpty(tabIndex) || "1".equals(tabIndex)){
                // 我收藏的全部资源
                List<Map<String,Object>> resInfoList = collectSingleListService.findCollectList(searchName);
                // 取藏品封面
                for (int j = 0; j < resInfoList.size(); j++) {
                    Map<String,Object> mapObject = resInfoList.get(j);
                    if (mapObject != null){
                        String imgToBase64 = collectCommonBusinessService.getCoverImg("90", String.valueOf(mapObject.get("collectId")));
                        mapObject.put("image",imgToBase64);

                        int num = getCollectInStoreNum(String.valueOf(mapObject.get("collectId")));
                        mapObject.put("inStoreroomNum",num);

                        String outStateName = "不详";
                        if (num == 0){
                            outStateName = "出库";
                        }else {
                            outStateName = "在库";
                        }
                        mapObject.put("outStateName", outStateName);
                    }
                }
                jsonObject.put("data",resInfoList);
            }else if("2".equals(tabIndex)){
                // 收藏单
                List<Map<String,Object>> collectSingles = collectSingleService.findSingleByParams(searchName);
                jsonObject.put("data",collectSingles);
            }
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 收藏明细数据新增
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/addList", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject saveCollectSingleList(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        JSON.parse(jsonParam.toString());
        String singleId = jsonParam.getString("singleId");
        String infoId = jsonParam.getString("infoId");
        try{
            if (DataUtil.isEmpty(singleId)){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA,"收藏单"));
            }
            if (DataUtil.isEmpty(infoId)){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR,"收藏资源"));
            }
            collectSingleListService.insert(singleId,infoId);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.ADD_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 收藏明细数据删除
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/removeList", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject removeCollectSingleList(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        JSON.parse(jsonParam.toString());
        String singleId = jsonParam.getString("singleId");
        String infoId = jsonParam.getString("infoId");
        try{
            if (DataUtil.isEmpty(singleId)){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (DataUtil.isEmpty(infoId)){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (!jsonParam.getBooleanValue("confirmFlg")){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            Set<String> infoIdList = new HashSet<String>(Arrays.asList(infoId.split(",")));
            collectSingleListService.deleteByForeignKey(singleId,infoIdList);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 根据藏品主键获取信息.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getByCollectId", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getByCollectId(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        String collectId = jsonParam.getString("collectId");
        try{
            List<CollectSingleList> collectSingleLists = collectSingleListService.findByCollectId(collectId);
            jsonObject.put("data",collectSingleLists);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

}
