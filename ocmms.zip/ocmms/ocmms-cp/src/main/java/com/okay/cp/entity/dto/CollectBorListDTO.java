package com.okay.cp.entity.dto;

import com.okay.cp.entity.CollectBorList;
import com.okay.cp.entity.Grading;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author CZJ[OKAY]
 * @date 2021/1/25 14:40
 * @description 提借明细
 **/
@Data
@EqualsAndHashCode(callSuper = false)
public class CollectBorListDTO extends CollectBorList {

    /**
     * 提借数量
     **/
    private Integer borrowNum;

    /**
     * 藏品尺寸
     **/
    private String specificSize;

    /**
     * 藏品质量
     **/
    private String specificMass;

    /***
     * 藏品鉴定信息
     * */
    private Grading ratingInfo;

    /**
     * 类型1一般提借 2藏品研究 3藏品修复 4藏品鉴定定级
     */
    private Integer type;
    /**
     * 提借创建时间
     */
    private Date createTime;

}
