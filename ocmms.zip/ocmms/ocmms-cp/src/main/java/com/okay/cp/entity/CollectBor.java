package com.okay.cp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.okay.cp.utils.OaSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@TableName(value = "cp_collectbor")
public class CollectBor  {






    private String workOrderId;
    @ApiModelProperty(value = "主键")
    @TableId(type = IdType.INPUT,value = "colBorId")
    private String colBorId;

    private Integer useRange;
    @JsonSerialize(using = OaSerializer.IntegerToStringSerizlizer.class)
    private Integer useType;
    @TableField(value = "borCode")

    private String borCode;
    @TableField(value = "borTitle")
    @NotBlank(message = "提借单名称不能为空")
    private String borTitle;
    @TableField(value = "borAims")

    private String borAims;
    @TableField(value = "borDept")
    @NotBlank(message = "提借部门不能为空")
    private String borDept;

    private String borDept_t;
    @TableField(value = "borUser")

    @NotBlank(message = "提借人不能为空")
    private String borUser;

    private String borUser_t;
    @TableField(value = "contactInfo")

    @NotBlank(message = "联系信息不能为空")
    private String contactInfo;

    private String content;



    @NotNull(message = "提借类型不能为空")
    @JsonSerialize(using = OaSerializer.IntegerToStringSerizlizer.class)
    @TableField(value = "borType")

    private Integer borType;

    private String borType_t;
    @TableField(value = "borCount")

    private Integer borCount;
    @TableField(value = "state")

    private Integer state;

    @NotNull(message = "提借日期不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone="GMT+8")
    @TableField(value = "borDate")

    private Date borDate;

    @NotNull(message = "归还日期不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone="GMT+8")
    @TableField(value = "backDate")

    private Date backDate;
    @TableField(value = "taskDesc")

    private String taskDesc;

    @TableField(value = "createUserId")
    private String createUserId;

    private String createUserId_t;
    @TableField(value = "createTime")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date createTime;
    @TableField(value = "editUserId")

    private String editUserId;

    private String editUserId_t;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @TableField(value = "editTime")

    private Date editTime;
    @TableField(value = "manageDate")

    private Date manageDate;
    @TableField(value = "backState")

    private Integer backState;
    @TableField(value = "approveResult")
    private Integer approveResult;


}