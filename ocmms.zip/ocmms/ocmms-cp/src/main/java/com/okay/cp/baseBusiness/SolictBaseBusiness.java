package com.okay.cp.baseBusiness;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.ExpertIdenty;
import com.okay.cp.entity.SolicitSingle;
import com.okay.cp.entity.UserDefined;
import com.okay.cp.service.*;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DataUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/9/21 15:17
 * @Version: 1.0
 * @Description: 征集基类.
 */
public class SolictBaseBusiness {

    @Autowired
    private SolicInfoService solicInfoService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private SolicitSingleService solicitSingleService;

    /**
     * 获取征集鉴定- 专家鉴定列表.
     *
     * @param solicId
     * @return
     */
    public List<ExpertIdenty> getExpertIdentifyList(String solicId) {
        List<ExpertIdenty> dataList = solicInfoService.findExpertIdentifyListById(solicId);
        return dataList;
    }

    /**
     * 获取征集鉴定- 专家鉴定结果.
     *
     * @param solicId
     * @return
     */
    public Map<String, String> getExpertIdentifyResult(String solicId) {
        Map<String, String> dataMap = solicInfoService.findExpertIdentyResultById(solicId);
        return dataMap;
    }

    /**
     * 获取征集鉴定- 馆内评审结果.
     *
     * @param solicId
     * @return
     */
    public Map<String, String> getMuseumAuditResult(String solicId) {
        Map<String, String> dataMap = solicInfoService.findMuseumAuditById(solicId);
        return dataMap;
    }

    /**
     * 获取征集鉴定- 卖家谈判结果.
     *
     * @param solicId
     * @return
     */
    public Map<String, String> getSellerResut(String solicId) {
        Map<String, String> dataMap = solicInfoService.findSellerTalkById(solicId);
        return dataMap;
    }

    /**
     * 获取征集鉴定- 领导批复结果.
     *
     * @param solicId
     * @return
     */
    public Map<String, String> getLeaderReplyResult(String solicId) {
        Map<String, String> dataMap = solicInfoService.findLeaderReplyById(solicId);
        return dataMap;
    }

    /**
     * 获取征集鉴定- 最终审核结果.
     *
     * @param solicId
     * @return
     */
    public Map<String, String> getEndAuditResult(String solicId) {
        Map<String, String> dataMap = solicInfoService.findEndAuditById(solicId);
        return dataMap;
    }

    /**
     * 根据主键获取鉴定信息.
     *
     * @param id
     */
    public JSONObject getIdentifyInfoById(String id) {
        JSONObject jsonObject = new JSONObject();
        List<ExpertIdenty> identifyList = this.getExpertIdentifyList(id);
        Map<String, String> identifyResult = this.getExpertIdentifyResult(id);
        Map<String, String> museumAudit = this.getMuseumAuditResult(id);
        Map<String, String> selerTalk = this.getSellerResut(id);
        Map<String, String> leaderReply = this.getLeaderReplyResult(id);
        Map<String, String> endAudit = this.getEndAuditResult(id);

        jsonObject.put("identifyList", identifyList);
        jsonObject.put("identifyResult", identifyResult);
        jsonObject.put("museumAudit", museumAudit);
        jsonObject.put("selerTalk", selerTalk);
        jsonObject.put("leaderReply", leaderReply);
        jsonObject.put("endAudit", endAudit);
        return jsonObject;
    }

    /**
     * 获取下拉列表数据.
     *
     * @return
     */
    public JSONObject getOptions() {
        JSONObject json = new JSONObject();
        // 质量范围
        JSONArray massRangeArr = collectCommonCodeService.massRangeOptions();
        // 质量单位
        JSONArray massUnitArr = collectCommonCodeService.massUnitOptions();
        // 文物类型
        JSONArray typeArr = collectCommonCodeService.selectCollectType();
        // 年代
        JSONArray ageArr = collectCommonCodeService.selectCollectAgeTree();
        // 质地
        JSONArray textureArr = collectCommonCodeService.selectTexture();
        // 来源方式
        JSONArray solicWayList = collectCommonCodeService.sourceOptions();
        // 征集方式
        JSONArray sourceOptions = collectCommonCodeService.sourceOptions();
        // 征集单
        List<SolicitSingle> solicitSingleOptions = solicitSingleService.findDataList(new HashMap<String, Object>());
        // 征集单信息处理
        List<Map<String, Object>> solicitSingleArr = solicitSingleHandle(solicitSingleOptions);
        // 数量单位
        JSONArray numUnitOptionsArr = collectCommonCodeService.numUnitOptions();

        json.put("typeArr", typeArr);
        json.put("ageArr", ageArr);
        json.put("textureArr", textureArr);
        json.put("solicWayArr", solicWayList);
        json.put("massUnitArr", massUnitArr);
        json.put("massRangeArr", massRangeArr);
        json.put("sourceOptions", sourceOptions);
        json.put("solicitSingleOptions", solicitSingleArr);
        json.put("numUnitOptionsArr", numUnitOptionsArr);

        return json;
    }

    /**
     * 列表数据.
     *
     * @param page
     * @return
     */
    public JSONObject getDataList(Page page) {

        List<Map<String, Object>> pageResult = getDataByPage(page);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", pageResult);
        jsonObject.put("pages", page.getPages());
        jsonObject.put("total", page.getTotal());
        jsonObject.put("pageSize", page.getPageSize());
        jsonObject.put("code", 1);

        return jsonObject;
    }

    /**
     * 根据主键获取数据.
     *
     * @param mainKey
     * @return
     */
    public JSONObject getInfoByMainKey(String mainKey) {

        JSONObject jsonObject = new JSONObject();
        try {
            if (DataUtil.isEmpty(mainKey)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            // 基础数据
            Map<String, Object> dataMap = solicInfoService.findBySolicId(mainKey);

            // 自定义数据
            List<UserDefined> userDefinedList = collectCommonBusinessService.findUserDefinedList(mainKey);

            //信息关联附件
            String solicId = String.valueOf(dataMap.get("solicId"));
            JSONObject resObj = collectCommonBusinessService.getMainBodyRes("19", solicId);
            JSONArray attachList = resObj.getJSONArray("resList");

            // 封面
            dataMap.put("coverUrl", resObj.getString("coverUrl"));

            // 年代处理
            String yearId = String.valueOf(dataMap.get("culreliYear"));
            String yearName = getYearName(yearId);
            List<String> yearIdList = Arrays.asList(yearId.split(","));
            dataMap.put("culreliYearName", yearName);
            dataMap.put("culreliYear", yearIdList);

            // 质地处理
//            Object texture = dataMap.get("texture");
//            if (texture != null){
//                String textureName = getTextureName(texture.toString());
//                dataMap.put("textureName",textureName);
//                dataMap.put("texture",texture.toString());
//            }else {
//                dataMap.put("textureName","");
//                dataMap.put("texture","");
//            }

            // 字典值翻译，外部接口调用预留
            Object obj = dataMap.get("solicWay");
            if (obj != null) {
                dataMap.put("solicWay", String.valueOf(obj));
                dataMap.put("solicWayName", collectCommonCodeService.source_t(obj.toString()));
            }

            // 具体质量
            obj = dataMap.get("realMass");
            if (obj != null) {
                dataMap.put("realMass", String.valueOf(obj));
                dataMap.put("realMass_t", collectCommonCodeService.massRange_t(obj.toString()));
            }

            // 质量单位
            obj = dataMap.get("massUnit");
            if (obj != null) {
                dataMap.put("massUnit", String.valueOf(obj));
                dataMap.put("massUnitName", collectCommonCodeService.massUnit_t(obj.toString()));
            }

            // 数量单位
            obj = dataMap.get("numberUnit");
            if (obj != null) {
                dataMap.put("numberUnit", String.valueOf(obj));
                dataMap.put("numberUnit_t", collectCommonCodeService.numUnit_t(obj.toString()));
            }

            // 文物类别
            obj = dataMap.get("culreliType");
            if (obj != null) {
                dataMap.put("culreliType", String.valueOf(obj));
                dataMap.put("culreliTypeName", collectCommonCodeService.collectType_t(obj.toString()));
            }

            jsonObject.put("code", 1);
            jsonObject.put("solicInfo", dataMap);
            jsonObject.put("attachList", attachList);
            jsonObject.put("userDefinedList", userDefinedList);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 根据主键获取关联的合同附件.
     *
     * @param mainKey
     * @return
     */
    public JSONObject getAttachBymainKey(String mainKey) {
        JSONObject jsonObject = new JSONObject();
        try {
            if (DataUtil.isEmpty(mainKey)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            List<String> idList = new ArrayList<>(Arrays.asList(mainKey.split(",")));
            JSONArray arrayList = solicInfoService.findAttach(idList);
            jsonObject.put("attach", arrayList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取年代名称.
     *
     * @param yearId
     * @return
     */
    public String getYearName(String yearId) {
        return collectCommonCodeService.collectAge_t(yearId);
    }

    /**
     * 获取质地名称.
     *
     * @param textureId
     * @return
     */
    public String getTextureName(String textureId) {
        return collectCommonCodeService.textureType_t(textureId);
    }

    /**
     * 获取用户名称.
     *
     * @param userId
     * @return
     */
    public String getUserName(String userId) {
        return collectCommonBusinessService.getUserNames(userId);
    }

    /**
     * 征集单下拉框处理.
     *
     * @param solicitSingleList
     * @return
     */
    public List<Map<String, Object>> solicitSingleHandle(List<SolicitSingle> solicitSingleList) {
        List<Map<String, Object>> dataMapList = new ArrayList<Map<String, Object>>();
        for (SolicitSingle solicitSingle : solicitSingleList) {
            Map<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put("label", solicitSingle.getSolicitSingleName());
            dataMap.put("value", solicitSingle.getSolicitSingleId());
            dataMapList.add(dataMap);
        }
        return dataMapList;
    }

    /**
     * 导出选择列.
     *
     * @return
     */
    public JSONObject initExportHeader(String exportOrder) {

        String appdenStr = "";
        if ("6".equals(exportOrder)) {
            appdenStr = ",{'label':'关联合同名','key':'contractName'}";
        }
        String headerArray = "[" +
                "{'label':'文物名称','key':'culreliName'}," +
                "{'label':'征集编号','key':'solicCode'}," +
                "{'label':'征集来源','key':'solicWay_t'}," +
                "{'label':'文物类别','key':'culreliType_t'}," +
                "{'label':'文物年代','key':'culreliYear_t'}," +
                "{'label':'数量','key':'culreliNum'}," +
                "{'label':'具体质地','key':'texture'}," +
                "{'label':'长','key':'length'}," +
                "{'label':'宽','key':'width'}," +
                "{'label':'高','key':'height'}," +
                "{'label':'报价','key':'offer'}," +
                "{'label':'来源人/地址','key':'sourcePeople'}," +
                "{'label':'来源人地址','key':'sourceAddress'}," +
                "{'label':'具体尺寸','key':'realSize'}," +
                "{'label':'质量范围','key':'realMass'}," +
                "{'label':'质量单位','key':'massUnit_t'}," +
                "{'label':'附件附属物','key':'attachment'}," +
                "{'label':'完残状况','key':'completdesc'}," +
                "{'label':'征集经过','key':'aftercollecting'}," +
                "{'label':'文物简介','key':'introduction'}," +
                "{'label':'备注','key':'remark'}," +
                "{'label':'线索名称','key':'cluesName'}," +
                "{'label':'征集单名','key':'solicitSingle_t'}," +
                "{'label':'征集单编码','key':'solicitSingleCode'}" +
                appdenStr +
                "]";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("exportHeaderList", JSONArray.parseArray(headerArray));
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 数据导出.
     *
     * @param jsonParam
     * @param request
     * @param response
     */
    public void exportHandle(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {

        try {
            Page page = jsonParam.getJSONObject("page").toJavaObject(Page.class);

            //导出类型 0:导出查询的全部数据 1: 当前页数据 2：选择的数据
            String exportType = jsonParam.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }
            if (exportType.equals("0")) {
                page.setPageSize(0);
                page.setPageNum(0);
            } else if (exportType.equals("2")) {
                String solicId = String.valueOf(page.getConditionMap().get("solicId"));
                page.getConditionMap().put("solicIdList", Arrays.asList(solicId.split(",")));
            }

            //导出文件名
            String fileName = jsonParam.getString("exportFileName");
            if (DataUtil.isEmpty(fileName)) {
                fileName = "征集信息";
            }

            // 获取选择导出的列数据
            List headerNameList = new ArrayList();
            List headerKeyList = new ArrayList();
            JSONArray exportColumn = jsonParam.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            // 查询数据及结果处理
            List<Map<String, Object>> dataMapList = getDataByPage(page);
            nullToEmpty(dataMapList);

            // 根据选择导出列封装导出数据
            List<Object> exportDataList = new ArrayList<Object>();
            for (int i = 0; i < dataMapList.size(); i++) {
                Map<String, Object> dataMap = (Map<String, Object>) dataMapList.get(i);
                List<String> stringDataList = new ArrayList<String>();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = headerKeyList.get(j).toString();
                    String value = dataMap.get(key) == null ? "" : String.valueOf(dataMap.get(key));
                    stringDataList.add(value);
                }
                exportDataList.add(stringDataList);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, exportDataList);
            DataExportUtils.setResponseHeader(response, wb, fileName);
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 数据查询.
     *
     * @param page
     * @return
     */
    public List<Map<String, Object>> getDataByPage(Page page) {

        if (page != null && page.getConditionMap() != null) {
            // 查询时间
            Object timeObject = page.getConditionMap().get("creatTime");
            if (timeObject != null && !"".equals(timeObject)) {
                ArrayList<String> queryTime = (ArrayList) timeObject;
                if (null != queryTime && !"".equals(queryTime)) {
                    if (queryTime.size() == 2) {
                        page.getConditionMap().put("startCreatTime", queryTime.get(0));
                        page.getConditionMap().put("endCreatTime", queryTime.get(1));
                    } else if (queryTime.size() == 1) {
                        page.getConditionMap().put("startCreatTime", queryTime.get(0));
                    }
                }
            }
        }
        return solicInfoService.findBusinessResultDataList(page);
    }

    /**
     * 关联合同去重.
     *
     * @param handleArr
     * @return
     */
    public JSONArray moveRepeatAttahcment(JSONArray handleArr) {
        JSONArray resultArr = new JSONArray();
        Map<String, JSONObject> tempMap = new HashMap<String, JSONObject>();
        for (int i = 0; i < handleArr.size(); i++) {
            JSONObject dataObj = (JSONObject) handleArr.get(i);
            String infoId = dataObj.getString("infoId");
            JSONObject tempMapObj = tempMap.get(infoId);
            if (tempMapObj == null) {
                tempMap.put(infoId, dataObj);
                resultArr.add(dataObj);
            }
        }
        return resultArr;
    }

    public List<Map<String, Object>> nullToEmpty(List<Map<String, Object>> mapList) {
        for (int i = 0; i < mapList.size(); i++) {
            Map<String, Object> map = mapList.get(i);
            Set<String> keySet = map.keySet();
            if (keySet != null && !keySet.isEmpty()) {
                for (String key : keySet) {
                    if (map.get(key) == null || "null".equals(map.get(key))) {
                        map.put(key, "");
                    }
                }
            }
        }
        return mapList;
    }
}
