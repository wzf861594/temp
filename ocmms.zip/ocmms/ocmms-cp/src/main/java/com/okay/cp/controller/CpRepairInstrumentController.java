package com.okay.cp.controller;

import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.cp.entity.dto.CpRepairInstrumentDTO;
import com.okay.cp.service.CpRepairInstrumentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

/**
 * @author CZJ[OKAY]
 * @date 2021-12-13 09:55:31
 * @description 修复仪器管理表Controller
 **/
@RestController
@AllArgsConstructor
@Api(tags = "修复仪器管理表")
@RequestMapping(value = "/instrument")
public class CpRepairInstrumentController {

    private final CpRepairInstrumentService instrumentService;

    /**
     * 新增
     *
     * @param dto 记录数据
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/insert")
    @ApiOperation(value = "新增")
    public R insert(@Validated CpRepairInstrumentDTO dto) {
        return R.ok(instrumentService.insert(dto));
    }

    /**
     * 根据ID修改
     *
     * @param dto 记录数据
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/updateById")
    @ApiOperation(value = "根据ID修改")
    public R updateById(@Validated CpRepairInstrumentDTO dto) {
        return R.ok(instrumentService.updateById(dto));
    }

    /**
     * 根据ID删除
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/deleteById")
    @ApiOperation(value = "根据ID删除")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R deleteById(@RequestParam(value = "id") String id) {
        return R.ok(instrumentService.deleteById(id));
    }

    /**
     * 根据ID获取记录基本信息
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @GetMapping(value = "/getById")
    @ApiOperation(value = "根据ID获取记录基本信息")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R getById(@RequestParam(value = "id") String id) {
        return R.ok(instrumentService.getById(id)).setMsg("");
    }

    /**
     * 获取记录列表
     *
     * @param dto  查询条件
     * @param page 分页信息
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/listAll")
    @ApiOperation(value = "获取记录列表")
    public R listAll(Page page, CpRepairInstrumentDTO dto) {
        return R.ok(instrumentService.listAll(page, dto)).setMsg("");
    }

    /**
     * 导出
     *
     * @param dto
     * @param response
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/export")
    @ApiOperation(value = "导出")
    public void export(CpRepairInstrumentDTO dto, HttpServletResponse response) {
        instrumentService.export(dto, response);
    }
}