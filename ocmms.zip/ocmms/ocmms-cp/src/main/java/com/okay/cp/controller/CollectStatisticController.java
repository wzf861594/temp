package com.okay.cp.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.R;
import com.okay.cp.entity.dto.CollectStatisticsDTO;
import com.okay.cp.service.ViewCollectStatisService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: CollectStatisticController
 * @Description: 藏品统计
 * @author: zhongmz
 * @Date: 2019/9/27 14:57
 * @version: V1.0
 */
@RestController
@AllArgsConstructor
@RequestMapping(value = "/collectStatistic")
public class CollectStatisticController {

    private final ViewCollectStatisService viewCollectStatisService;

    /**
     * 藏品数量统概况计
     *
     * @return JSONObject
     * @Param json
     */
    @RequestMapping(value = "/total", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject total(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();

        String selectDate = jsonParam.getString("date");
        Map<String, Object> mapParam = new HashMap<>(1);
        mapParam.put("selectDate", selectDate);

        Map<String, Object> data = viewCollectStatisService.selectCollectTotalStatistic(mapParam);

        jsonObject.put("data", data);
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 藏品数量统计
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param json
     */
    @RequestMapping(value = "/number", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject number(@RequestParam(value = "status") String status) {
        JSONObject jsonObject = new JSONObject();
        //类别
//        List<Map<String, Object>> collectType = viewCollectStatisService.selectCollectTypeStatistic();
        List<Map<String, String>> collectType = viewCollectStatisService.statisticCollectByType(status);
        //级别
        //List<Map<String, Object>> collectLevel = viewCollectStatisService.selectCollectLevelStatistic();
        List<Map<String, String>> collectLevel = viewCollectStatisService.statisticCollectByLevel(status);
        //库房
        //List<Map<String, Object>> collectStorehouse = viewCollectStatisService.selectCollectStorehouseStatistic();
        List<Map<String, Object>> collectStorehouse = viewCollectStatisService.statisticCollectByStorehouse(status);
        //来源方式
        //List<Map<String, Object>> collectSource = viewCollectStatisService.selectCollectSourceStatistic();
        List<Map<String, String>> collectSource = viewCollectStatisService.statisticCollectBySource(status);

        JSONObject resultJson = new JSONObject();
        resultJson.put("collectType", collectType);
        resultJson.put("collectLevel", collectLevel);
        resultJson.put("collectStorehouse", collectStorehouse);
        resultJson.put("collectSource", collectSource);

        jsonObject.put("data", resultJson);
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 藏品年代分布统计
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param json
     */
    @RequestMapping(value = "/age", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject age(@RequestParam(value = "status") String status) {
        JSONObject jsonObject = new JSONObject();
        List<Map<String, Object>> data = viewCollectStatisService.selectCollectAgeStatistic(status);
        jsonObject.put("data", data);
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 藏品出库数量统计
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param json
     */
    @RequestMapping(value = "/outStorehouse", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject outStorehouse() {
        JSONObject jsonObject = new JSONObject();
        Map<String, List<Map<String, Object>>> data = viewCollectStatisService.selectCollectOutStorehouseStatistic();
        jsonObject.put("data", data);
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 藏品热度排行榜统计
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param json
     */
    @RequestMapping(value = "/ranking", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject ranking() {
        JSONObject jsonObject = new JSONObject();
        Map<String, List<Map<String, Object>>> data = viewCollectStatisService.selectCollectHotRankingStatistic();
        jsonObject.put("data", data);
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 首页数据统计-藏品统计
     *
     * @param dto
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/collection")
    public R collectionStatistics(CollectStatisticsDTO dto) {
        return R.ok(viewCollectStatisService.collectionStatistics(dto)).setMsg("");
    }

    /**
     * 首页数据统计-藏品统计导出
     *
     * @param
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/collectionExport")
    public void collectionExport(CollectStatisticsDTO dto, HttpServletResponse response) {
        viewCollectStatisService.collectionExport(dto, response);
    }

    /**
     * 藏品数量统概况计
     *
     * @return R
     * @author okay
     */
    @GetMapping(value = "/statisticCollectTotal")
    public R statisticCollectTotal() {
        return R.ok(viewCollectStatisService.statisticCollectTotal()).setMsg("");
    }

}
