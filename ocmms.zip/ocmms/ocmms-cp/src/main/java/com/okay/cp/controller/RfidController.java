package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.service.RfidCollectInfoService;
import com.okay.cp.service.impl.RfidCollectInfoServiceImpl;
import com.okay.rfid.exception.*;
import com.okay.rfid.impl.query.Page;
import com.okay.rfid.query.*;
import com.okay.rfid.query.result.*;
import com.okay.rfid.service.*;
import com.okay.rfid.util.StringUtil;
import com.okay.framework.utils.DataExportUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.NonTransientDataAccessException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/rfid")
public class RfidController {

    @Autowired
    protected RfidCollectInfoService rfidCollectInfoService;

    @Autowired
    protected RfidBeaconService rfidBeaconService;

    @Autowired
    protected RfidInfoService rfidInfoService;

    @Autowired
    protected RfidAccessService rfidAccessService;

    @Autowired
    protected RfidTellLogService rfidTellLogService;

    @Autowired
    protected RfidTellBusinessService rfidTellBusinessService;

    @Autowired
    protected RfidBusinessService rfidBusinessService;

    @Autowired
    protected RfidService rfidService;

    @RequestMapping(value = "/collect/list/{pageNum}/{pageSize}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getCpListPage(@PathVariable int pageNum, @PathVariable int pageSize,
        String collectName, String totalNum, String classNum){

        Map<String,Object> param = new HashMap<>();
        param.put("unbound", true);

        param.put("collectName", collectName);
        param.put("totalNum", totalNum);
        param.put("classNum", classNum);

        Query query = rfidCollectInfoService.createCollectInfoQuery(param);
        List resultData = query.list(pageNum, pageSize);
        return buildPageResult(resultData, null);
    }

    @RequestMapping(value = "/collect/commitBind", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject commitBind(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            Map<String,String> bindMap = (Map<String, String>) param.get("bindData");
            rfidCollectInfoService.bindRfid(bindMap, RfidCollectInfoServiceImpl.RFID_TYPE, null, null);
            result.put("code", 1);
            result.put("msg", "绑定成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "绑定失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borOut", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject createBorOut(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidCollectInfoService.addRfidBorOut(param.getString("id"));
            result.put("code", 1);
            result.put("msg", "添加成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "添加失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borBack", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject createBorBack(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidCollectInfoService.addRfidBorBack(param.getString("id"));
            result.put("code", 1);
            result.put("msg", "添加成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "添加失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borOut/list/{id}/uncomplete", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getUncompleteBorOutList(@PathVariable String id){
        JSONObject result = new JSONObject();
        try {
            RfidBusinessResult resultData = rfidBusinessService.createRfidBusinessQuery().putAllSubset().uncomplete().businessId(id, RfidCollectInfoServiceImpl.BusinessType.COLLECTBOR_OUT.name()).singleResult();
            result.put("data", resultData);
            result.put("code", 1);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borBack/list/{id}/uncomplete", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getUncompleteBorBackList(@PathVariable String id){
        JSONObject result = new JSONObject();
        try {
            RfidBusinessResult resultData = rfidBusinessService.createRfidBusinessQuery().putAllSubset().uncomplete().businessId(id, RfidCollectInfoServiceImpl.BusinessType.COLLECTBOR_BACK.name()).singleResult();
            result.put("data", resultData);
            result.put("code", 1);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borOut/commit", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject commitRfidBorOut(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidCollectInfoService.commitRfidBorOut(param.getString("id"), param.getJSONObject("inputBorOutInfoMap"));
            result.put("msg", "提交成功");
            result.put("code", 1);
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "提交失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borBack/commit", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject commitRfidBorBack(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidCollectInfoService.commitRfidBorBack(param.getString("id"), param.getJSONObject("inputBorBackInfoMap"));
            result.put("msg", "提交成功");
            result.put("code", 1);
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "提交失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borOut/cancel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject cancelRfidBorOut(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidCollectInfoService.cancelRfidBorOut(param.getString("id"));
            result.put("msg", "撤销成功");
            result.put("code", 1);
        } catch(NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "撤销失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/collect/borBack/cancel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject cancelRfidBorBack(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidCollectInfoService.cancelRfidBorBack(param.getString("id"));
            result.put("msg", "撤销成功");
            result.put("code", 1);
        } catch(NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "撤销失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/beacon/list/{pageNum}/{pageSize}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getBeaconListPage(@PathVariable int pageNum, @PathVariable int pageSize,
                                        String rfidLike, String state, String updatedTimeStart, String updatedTimeEnd) throws Exception {
        RfidBeaconQuery query = rfidBeaconService.createRfidBeaconQuery().types(RfidCollectInfoServiceImpl.RFID_TYPE).orderByUpdateTimeDesc();
        if(!StringUtil.isNull(rfidLike)) {
            query.rfidLike(rfidLike);
        }
        if(StringUtil.isNull(state) || "none".equalsIgnoreCase(state)) {
            query.noneState();
        } else {
            state = state.toUpperCase();
            query.state(state);
        }
        if(!StringUtil.isNull(updatedTimeStart)) {
            query.gteUpdateTime(new SimpleDateFormat("yyyy-MM-dd").parse(updatedTimeStart));
        }
        if(!StringUtil.isNull(updatedTimeEnd)) {
            Calendar c = Calendar.getInstance();
            c.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(updatedTimeEnd));
            c.add(Calendar.DAY_OF_MONTH, 1);
            query.ltUpdateTime(c.getTime());
        }
        List<RfidBeaconResult> resultData = query.list(pageNum, pageSize);
        return buildPageResult(resultData, null);
    }

    @RequestMapping(value = "/beacon/create", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject createBeacon(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidBeaconService.createRfidBeacon(param.getString("rfid"), RfidCollectInfoServiceImpl.RFID_TYPE, null);
            result.put("code", 1);
            result.put("msg", "创建信标成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch(Exception e) {
            result.put("code", 4);
            result.put("msg", "创建信标失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/beacon/delete", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject deleteBeacon(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            JSONArray rfisList = param.getJSONArray("rfidList");
            if(rfisList == null || rfisList.isEmpty()) {
                throw new RuntimeException("rfid is null");
            }
            rfidBeaconService.deleteRfidBeacons(rfisList.toJavaList(String.class));
            result.put("code", 1);
            result.put("msg", "删除成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
            result.put("msg", "禁止删除");
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "删除失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/pu/info/list/{pageNum}/{pageSize}/export", method = RequestMethod.GET)
    public void exportRfidInfoListPage(HttpServletResponse response, @PathVariable int pageNum, @PathVariable int pageSize,
                                       String nameLike, String rfidLike, String businessType, Boolean deleted,
                                       String updatedTimeStart, String updatedTimeEnd) throws Exception{
        RfidInfoQuery query = rfidInfoService.createRfidInfoQuery().types(RfidCollectInfoServiceImpl.RFID_TYPE).orderByLastUpdateTimeDesc();
        if(!StringUtil.isNull(nameLike)) {
            query.nameLike(nameLike);
        }
        if(!StringUtil.isNull(rfidLike)) {
            query.rfidLike(rfidLike);
        }
        if(!StringUtil.isNull(businessType)) {
            query.businessType(businessType);
        }
        if(deleted == null || !deleted) {
            query.normal();
        } else {
            query.deleted();
        }

        if(!StringUtil.isNull(updatedTimeStart)) {
            query.gteLastUpdatedTime(new SimpleDateFormat("yyyy-MM-dd").parse(updatedTimeStart));
        }
        if(!StringUtil.isNull(updatedTimeEnd)) {
            Calendar c = Calendar.getInstance();
            c.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(updatedTimeEnd));
            c.add(Calendar.DAY_OF_MONTH, 1);
            query.ltLastUpdatedTime(c.getTime());
        }

        List<RfidInfoResult> resultData = query.list(pageNum, pageSize);
        if(resultData == null || resultData.isEmpty()) {

        }

        List<String> hreadList = new ArrayList<>();
        hreadList.add("名称");
        hreadList.add("RFID");

        List<List<String>> dataList = new ArrayList<>();

        for(RfidInfoResult rfidInfoResult: resultData) {
            List<String> obj = new ArrayList<>();
            dataList.add(obj);
            obj.add(rfidInfoResult.getName());
            obj.add(rfidInfoResult.getRfid());
        }

        HSSFWorkbook hssfWorkbook = DataExportUtils.creakWorkBook(hreadList, dataList);
        DataExportUtils.setResponseHeader(response, hssfWorkbook, UUID.randomUUID().toString());
    }

    @RequestMapping(value = "/info/list/{pageNum}/{pageSize}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getRfidInfoListPage(@PathVariable int pageNum, @PathVariable int pageSize,
                                          String nameLike, String rfidLike, String businessType, Boolean deleted,
                                          String updatedTimeStart, String updatedTimeEnd) throws Exception{
        RfidInfoQuery query = rfidInfoService.createRfidInfoQuery().types(RfidCollectInfoServiceImpl.RFID_TYPE).orderByLastUpdateTimeDesc();
        if(!StringUtil.isNull(nameLike)) {
            query.nameLike(nameLike);
        }
        if(!StringUtil.isNull(rfidLike)) {
            query.rfidLike(rfidLike);
        }
        if(!StringUtil.isNull(businessType)) {
            query.businessType(businessType);
        }
        if(deleted == null || !deleted) {
            query.normal();
        } else {
            query.deleted();
        }

        if(!StringUtil.isNull(updatedTimeStart)) {
            query.gteLastUpdatedTime(new SimpleDateFormat("yyyy-MM-dd").parse(updatedTimeStart));
        }
        if(!StringUtil.isNull(updatedTimeEnd)) {
            Calendar c = Calendar.getInstance();
            c.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(updatedTimeEnd));
            c.add(Calendar.DAY_OF_MONTH, 1);
            query.ltLastUpdatedTime(c.getTime());
        }

        List<RfidInfoResult> resultData = query.list(pageNum, pageSize);
        return buildPageResult(resultData, null);
    }

    @RequestMapping(value = "/info/remove", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject removeRfidInfo(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidInfoService.removeRfidInfo(param.getString("id"), null);
            result.put("code", 1);
            result.put("msg", "移除成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "移除失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/info/delete", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject deleteRfidInfo(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            rfidInfoService.deleteRfidInfo(param.getString("id"));
            result.put("code", 1);
            result.put("msg", "删除成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "删除失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/access/delete", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject deleteAccess(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            JSONArray idList = param.getJSONArray("idList");
            if(idList == null || idList.isEmpty()) {
                throw new RuntimeException("id is null");
            }
            rfidAccessService.deleteRfidAccess(idList.toJavaList(String.class));
            result.put("code", 1);
            result.put("msg", "删除成功");
        } catch (NonTransientDataAccessException e) {
            result.put("code", 4);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "删除失败:" + e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/access/list/{pageNum}/{pageSize}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getAccessListPage(@PathVariable Integer pageNum, @PathVariable Integer pageSize,
                                        String rfidLike, String accessBusiness, String nameLike,
                                        String createdTimeStart, String createdTimeEnd) throws ParseException {

        RfidAccessQuery query = rfidAccessService.createRfidAccessQuery().orderByCreatedTimeDesc();
        if(!StringUtil.isNull(rfidLike)) {
            query.rfidLike(rfidLike);
        }
        if(!StringUtil.isNull(nameLike)) {
            query.nameLike(nameLike);
        }
        if(!StringUtil.isNull(accessBusiness)) {
            query.accessBusiness(accessBusiness);
        }
        if(!StringUtil.isNull(createdTimeStart)) {
            query.gteCreatedTime(new SimpleDateFormat("yyyy-MM-dd").parse(createdTimeStart));
        }
        if(!StringUtil.isNull(createdTimeEnd)) {
            Calendar c = Calendar.getInstance();
            c.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(createdTimeEnd));
            c.add(Calendar.DAY_OF_MONTH, 1);
            query.gteCreatedTime(c.getTime());
        }
        List<RfidAccessResult> resultData = query.list(pageNum, pageSize);
        return buildPageResult(resultData, null);
    }


    @RequestMapping(value = "/tellLog/list/{pageNum}/{pageSize}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getTellLogListPage(@PathVariable Integer pageNum, @PathVariable Integer pageSize,
                                         String rfidLike, String nameLike, String timeStart, String timeEnd, String state) throws ParseException {
        RfidTellLogQuery query = rfidTellLogService.createRfidTellLogQuery().orderByTimeDesc().putCountTellBusiness().type(RfidCollectInfoServiceImpl.RFID_TYPE);
        if(!StringUtil.isNull(rfidLike)) {
            query.rfidLike(rfidLike);
        }
        if(!StringUtil.isNull(nameLike)) {
            query.nameLike(nameLike);
        }
        if(!StringUtil.isNull(state)) {
            query.state(state);
        }
        if(!StringUtil.isNull(timeStart)) {
            query.gteTime(new SimpleDateFormat("yyyy-MM-dd").parse(timeStart));
        }
        if(!StringUtil.isNull(timeEnd)) {
            Calendar c = Calendar.getInstance();
            c.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(timeEnd));
            c.add(Calendar.DAY_OF_MONTH, 1);
            query.ltTime(c.getTime());
        }
        List<RfidTellLogResult> resultData = query.list(pageNum, pageSize);
        return buildPageResult(resultData, null);
    }

    @RequestMapping(value = "/tellBusiness/list/{pageNum}/{pageSize}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getTellBusinessListPage(@PathVariable Integer pageNum, @PathVariable Integer pageSize,
                                              String rfidLike, String nameLike, String accessBusiness, String timeStart, String timeEnd) throws ParseException {
        RfidTellBusinessQuery query = rfidTellBusinessService.createRfidTellBusinessQuery().orderByTimeDesc().type(RfidCollectInfoServiceImpl.RFID_TYPE);
        if(!StringUtil.isNull(rfidLike)) {
            query.rfidLike(rfidLike);
        }
        if(!StringUtil.isNull(nameLike)) {
            query.nameLike(nameLike);
        }
        if(!StringUtil.isNull(accessBusiness)) {
            query.accessBusiness(accessBusiness);
        }
        if(!StringUtil.isNull(accessBusiness)) {
            query.accessBusiness(accessBusiness);
        }
        if(!StringUtil.isNull(timeStart)) {
            query.gteTime(new SimpleDateFormat("yyyy-MM-dd").parse(timeStart));
        }
        if(!StringUtil.isNull(timeEnd)) {
            Calendar c = Calendar.getInstance();
            c.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(timeEnd));
            c.add(Calendar.DAY_OF_MONTH, 1);
            query.ltTime(c.getTime());
        }
        List<RfidTellBusinessResult> resultData = query.list(pageNum, pageSize);
        return buildPageResult(resultData, null);
    }

    @RequestMapping(value = "/tellBusiness/list/{tellLogId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getTellBusiness(@PathVariable String tellLogId) {
        RfidTellBusinessQuery query = rfidTellBusinessService.createRfidTellBusinessQuery().type(RfidCollectInfoServiceImpl.RFID_TYPE).tellLogId(tellLogId);
        List<RfidTellBusinessResult> resultData = query.list();
        return buildPageResult(resultData, null);
    }

    @RequestMapping(value = "/pu/beacon/submitScan", method = RequestMethod.POST, produces = "application/json")
    public JSONObject submitBeaconScan(@RequestBody JSONObject param) {
        JSONObject result = new JSONObject();
        if(param.containsKey("data")) {
            JSONArray data = param.getJSONArray("data");
            for(int i = 0 ; i < data.size() ; i ++) {
                try {
                    rfidBeaconService.createRfidBeacon(data.getString(i), RfidCollectInfoServiceImpl.RFID_TYPE, null);
                } catch (Exception e) {
                }
            }
            result.put("code", 0);
        }
        return result;
    }

    @RequestMapping(value = "/execute/list/test", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject executeRfidListTest(@RequestBody JSONObject param){
        JSONObject result = new JSONObject();
        try {
            result.put("result", executeRfidList(param, true));
            result.put("code", 1);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", e.getMessage());
        }
        return result;
    }

    @RequestMapping(value = "/pu/execute/list", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject executeRfidList(@RequestBody JSONObject param){
//        {
//            code: 0  -- 0正常，1/2/3有异常，4程序级异常。大于0都是异常的信息
//            msg: "", -- 程序级异常信息
//            data: {
//                "#1a6520": [{
//                    code: 0  -- 0正常，1重复，2不通过，3异常，4程序级异常。 大于0都是异常的信息
//                    msg: "重复扫描，忽略处理." -- 异常信息
//                    rfid: "xxxx"
//                }]
//            }
//        }

        return executeRfidList(param, false);
    }

    protected JSONObject executeRfidList(JSONObject param, boolean isTest) {
        JSONObject result = new JSONObject();
        try {
            JSONArray executeResult = new JSONArray();
            Set<String> hasRfid = new HashSet<>();
            boolean isError = false;
            try {
                String deviceId = param.get("deviceId") == null ? null : param.get("deviceId").toString();
//                String operator = param.get("operator") == null ? null : param.get("operator").toString();
                JSONArray rfidList = param.getJSONArray("data");
                int state = handleRfidList(rfidList != null ? rfidList.toJavaList(String.class) : null, deviceId, null, hasRfid, executeResult);
                switch (state) {
                    case 0:
                        result.put("code", isTest ? 1 : 0);
                        result.put("msg", "成功");
                        break;
                    case 1:
                        result.put("code", 1);
                        result.put("msg", "不处理");
                        break;
                    case 2:
                        result.put("code", 2);
                        result.put("msg", "业务异常");
                        break;
                    case 3:
                        result.put("code", 3);
                        result.put("msg", "异常");
                        break;
                    case 4:
                        result.put("code", 4);
                        result.put("msg", "程序异常");
                        break;

                }
            } catch (Exception e) {
                throw new RuntimeException("param error");
            }
            result.put("data", executeResult);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "程序异常: " + e.getMessage());
        }
        return result;
    }


    protected JSONObject buildPageResult(List resultData, JSONObject result) {
        if(result == null) {
            result = new JSONObject();
        }
        if(resultData instanceof Page) {
            Page page = (Page) resultData;
            result.put("pageNum", page.getPageNum());
            result.put("pageSize", page.getPageSize());
            result.put("pageCount", page.getPageCount());
            result.put("total", page.getTotal());
        }
        result.put("data", resultData);
        result.put("code", 0);
        return result;
    }

    protected int handleRfidList(Collection<String> rfidList, String deviceId, String operator, Set<String> hasRfid, JSONArray result) {
        int currState = 0;
        if(rfidList != null && !rfidList.isEmpty()) {
            for(String rfid : rfidList) {
                if(!StringUtil.isNull(rfid) && !hasRfid.contains(rfid)) {
                    hasRfid.add(rfid);
                    JSONObject data = new JSONObject();
                    data.put("rfid", rfid);
                    try {
                        rfidService.execute(rfid, deviceId, operator, null);
                        data.put("code", 0);
                        data.put("msg", "成功");
                    } catch (RfidNotFoundException | RfidNotBindException | RfidNullException | RfidDeletedStateException | RfidNotHandleException e) {
                        currState = inState(currState, 1);
                        data.put("code", 1);
                        data.put("msg", e.getMessage());
                    } catch (RfidBusinessException e) {
                        currState = inState(currState, 2);
                        data.put("code", 2);
                        data.put("msg", e.getMessage());
                    } catch (RfidException e) {
                        currState = inState(currState, 3);
                        data.put("code", 3);
                        data.put("msg", e.getMessage());
                    } catch (Exception e) {
                        currState = inState(currState, 44);
                        data.put("code", 4);
                        data.put("msg", "程序异常: " + e.getMessage());
                    }
                    result.add(data);
                }
            }
        }
        return currState;
    }

    protected int inState(int curr, int newState) {
        return curr < newState ? newState : curr;
    }

}


