package com.okay.cp.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@TableName(value = "cp_collectborlist")
public class CollectBorList {

    @TableId(type = IdType.ASSIGN_UUID,value = "colBorListId")
    @ApiModelProperty(value = "主键")
    @TableField(value = "colBorListId")

    private String colBorListId;

    @ApiModelProperty(value = "关联业务ID")
    @TableField(value = "colBorId")
    private String colBorId;
    @ApiModelProperty(value = "藏品ID")

    @TableField(value = "collectId")
    private String collectId;

    @TableField(value = "borCode")
    private String borCode;
    @TableField(value = "borUser")
    private String borUser;
    @TableField(value = "borCount")

    private Integer borCount;
    @TableField(value = "numUnit")
    private String numUnit;
    @TableField(value = "totalNum")

    private String totalNum;
    @TableField(value = "classNum")

    private String classNum;
    @TableField(value = "collectName")

    private String collectName;
    @TableField(value = "collectType")

    private String collectType;
    @TableField(value = "completeDegree")

    private String completeDegree;
    @TableField(value = "cpLevel")

    private String cpLevel;
    @TableField(value = "specificAge")

    private String specificAge;
    @TableField(value = "realSize")

    private String realSize;
    @TableField(value = "realMass")

    private String realMass;
    @TableField(value = "storehouse")

    private String storehouse;
    @TableField(value = "completeDesc")

    private String completeDesc;
    @TableField(value = "acceptUser")

    private String acceptUser;
    @TableField(value = "borDate")
    @JSONField(format = "yyyy-MM-dd")
    private Date borDate;
    @TableField(value = "backDate")
    @JSONField(format = "yyyy-MM-dd")
    private Date backDate;
    @TableField(value = "outState")

    private Integer outState;
    @TableField(value = "backState")

    private Integer backState;
    @TableField(value = "outCount")

    private Integer outCount;
    @TableField(value = "backCount")

    private Integer backCount;
    @TableField(value = "remarks")

    private String remarks;
    @TableField(value = "isError")

    private Integer isError;
    @TableField(value = "errorMsg")

    private String errorMsg;

}