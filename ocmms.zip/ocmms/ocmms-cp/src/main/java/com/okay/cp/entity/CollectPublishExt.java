package com.okay.cp.entity;

import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description:
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-08-26 9:39
 */

public class CollectPublishExt extends CollectPublish {

    // 藏品名称
    private String collectName;

    // 藏品类别
    private String collectType;

    // 藏品级别
    private String cpLevel;

    // 藏品年代
    private String years;

    // 具体年代
    private String specificAge;

    // 具体尺寸
    private String specificSize;

    // 简介
    private String introduction;

    // 总登记号
    private String totalNum;

    private String imageUrl;
    private List<String> imageMaxList = new ArrayList<String>();
    private List<String> audioUrlList = new ArrayList<String>();
    private List<String> videoUrlList = new ArrayList<String>();
    private List<String> modelUrlList = new ArrayList<String>();
    private List<JSONObject> imageList = new ArrayList<JSONObject>();
    private List<JSONObject> audioList = new ArrayList<JSONObject>();
    private List<JSONObject> videoList = new ArrayList<JSONObject>();
    private List<JSONObject> modelList = new ArrayList<JSONObject>();

    public String getCollectName() {
        return collectName;
    }

    public void setCollectName(String collectName) {
        this.collectName = collectName;
    }

    public String getCollectType() {
        return collectType;
    }

    public void setCollectType(String collectType) {
        this.collectType = collectType;
    }

    public String getCpLevel() {
        return cpLevel;
    }

    public void setCpLevel(String cpLevel) {
        this.cpLevel = cpLevel;
    }

    public String getYears() {
        return years;
    }

    public void setYears(String years) {
        this.years = years;
    }

    public String getSpecificAge() {
        return specificAge;
    }

    public void setSpecificAge(String specificAge) {
        this.specificAge = specificAge;
    }

    public String getSpecificSize() {
        return specificSize;
    }

    public void setSpecificSize(String specificSize) {
        this.specificSize = specificSize;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public List<String> getImageMaxList() {
        return imageMaxList;
    }

    public void setImageMaxList(List<String> imageMaxList) {
        this.imageMaxList = imageMaxList;
    }

    public List<String> getAudioUrlList() {
        return audioUrlList;
    }

    public void setAudioUrlList(List<String> audioUrlList) {
        this.audioUrlList = audioUrlList;
    }

    public List<String> getVideoUrlList() {
        return videoUrlList;
    }

    public void setVideoUrlList(List<String> videoUrlList) {
        this.videoUrlList = videoUrlList;
    }

    public List<String> getModelUrlList() {
        return modelUrlList;
    }

    public void setModelUrlList(List<String> modelUrlList) {
        this.modelUrlList = modelUrlList;
    }

    public List<JSONObject> getImageList() {
        return imageList;
    }

    public void setImageList(List<JSONObject> imageList) {
        this.imageList = imageList;
    }

    public List<JSONObject> getAudioList() {
        return audioList;
    }

    public void setAudioList(List<JSONObject> audioList) {
        this.audioList = audioList;
    }

    public List<JSONObject> getVideoList() {
        return videoList;
    }

    public void setVideoList(List<JSONObject> videoList) {
        this.videoList = videoList;
    }

    public List<JSONObject> getModelList() {
        return modelList;
    }

    public void setModelList(List<JSONObject> modelList) {
        this.modelList = modelList;
    }

    public String getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(String totalNum) {
        this.totalNum = totalNum;
    }
}
