package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.okay.common.model.MetadataModel;
import com.okay.common.util.MetadataUtil;
import com.okay.cp.baseBusiness.CollectInfoBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectInfo;
import com.okay.cp.entity.StoreHouse;
import com.okay.cp.entity.TextureType;
import com.okay.cp.entity.UserDefined;
import com.okay.cp.entity.vo.ViewImgVO;
import com.okay.cp.outside.clients.ResServerInterface;
import com.okay.cp.service.*;
import com.okay.cp.utils.CollectUtils;
import com.okay.cp.utils.DownExcelUtil;
import com.okay.cp.utils.ExcelWriterUtil;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 藏品编目控制层
 *
 * @author zhangyx
 * @since 2019/9/18 14:50
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping(value = "/collectEdit")
public class CollectEditController extends CollectInfoBaseBusiness {

    private final CollectInfoService collectInfoService;
    private final CollectCommonCodeService collectCommonCodeService;
    private final CollectCommonBusinessService collectCommonBusinessService;
    private final TextureTypeService textureTypeService;
    private final CollectImportService collectImportService;
    private final ResServerInterface resServerInterface;
    private final AttachInfoService attachInfoService;

    /**
     * 初始化查询表单
     *
     * @return
     */
    @RequestMapping(value = "/query", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject initForm() {
        JSONObject jsonObject = new JSONObject();
        MetadataModel model = MetadataUtil.getMetadataModel();
        try {
            //获取藏品类别
            JSONArray typeArray = collectCommonCodeService.selectCollectType();
            jsonObject.put("collectType", typeArray);
            //获取库房联动
            JSONArray storehouseArray = collectCommonCodeService.selectCollectStorehouseTree();
            jsonObject.put("storehouse", storehouseArray);

            //获取来源方式
            JSONArray sourceOptions = collectCommonCodeService.sourceOptions();
            jsonObject.put("source", sourceOptions);

            //获取级别
            JSONArray levelOptions = collectCommonCodeService.selectCollectLev();
            jsonObject.put("cpLevel", levelOptions);

            //获取完残程度
            JSONArray degreeOptions = collectCommonCodeService.completeDegreeOptions();
            jsonObject.put("completeDegree", degreeOptions);

            // 参考账类型
            jsonObject.put("referAccountType", MetadataUtil.getDictByType("cp_refer_account_type").getData());

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 加载数据列表
     *
     * @return JSONObject
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();
        MetadataModel model = MetadataUtil.getMetadataModel();
        try {
            selectParam(page);
            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);

            // 查询藏品类别
            List<String> typeIds = collectInfoList.stream().map(CollectInfo::getCollectType).distinct().collect(Collectors.toList());
            final Map<String, String> typeMap = collectCommonCodeService.getTypeToMap(typeIds);
            // 库房
            Map<String, Map<String, String>> storeroomMap = collectCommonCodeService.getStoreroomToMap();

            List<String> cIds = collectInfoList.stream().map(CollectInfo::getCollectId).collect(Collectors.toList());
            // 获取所有附件缩略图
            List<ViewImgVO> viewImgList = resServerInterface.getCoverBatchByBody("90", cIds);
            final Map<String, String> viewImgMap = new HashMap<>(1);
            if (CollectionUtils.isNotEmpty(viewImgList)) {
                viewImgMap.putAll(viewImgList.stream().collect(Collectors.toMap(ViewImgVO::getMainBodyId, ViewImgVO::getUrl)));
            }

            JSONArray dataList = new JSONArray();
            for (int i = 0; i < collectInfoList.size(); i++) {
                CollectInfo collectInfo = collectInfoList.get(i);
                String jsonString = JSONObject.toJSONString(collectInfo);
                JSONObject collectInfoJson = JSONObject.parseObject(jsonString);

                //小图
                collectInfoJson.put("image", viewImgMap.getOrDefault(collectInfo.getCollectId(), CollectUtils.getViewUnfind()));

                //藏品类别
                collectInfoJson.put("collectType", typeMap.get(collectInfo.getCollectType()));

                //完残程度
                String completeDegree_t = collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree());
                collectInfoJson.put("completeDegree", completeDegree_t);

                //级别
                String cpLev_t = collectCommonCodeService.cpLev_t(collectInfo.getCpLevel());
                collectInfoJson.put("cpLevel", cpLev_t);

                //来源方式
                String source_t = collectCommonCodeService.source_t(collectInfo.getSource());
                collectInfoJson.put("source", source_t);

                //库房
                String storehouse_t = collectCommonCodeService.storehouseShow(collectInfo.getStorehouse(), storeroomMap);
                collectInfoJson.put("storehouse", storehouse_t);
                String storehouse = collectInfo.getStorehouse();
                List houseList = Strings.isNotBlank(storehouse) ? Arrays.asList(storehouse.split(",")) : new ArrayList();
                collectInfoJson.put("storeHouseList", houseList);

                // 参考账类型
                collectInfoJson.put("referAccountTypeShow", model.getDictName("cp_refer_account_type", String.valueOf(collectInfo.getReferAccountType())));

                dataList.add(collectInfoJson);
            }
            jsonObject.put("data", dataList);
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 藏品编目初始化页面
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/initPage", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject initPage(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //藏品基础信息
            JSONObject baseInfo = null;
            try {
                baseInfo = getCollectBaseInfo(json);
            } catch (Exception e) {
                throw new BaseRuntimeException(e.getMessage());
            }

            String collectId = json.getString("collectId");

            //获取自定义属性
            List<UserDefined> userDefinedList = collectCommonBusinessService.findUserDefinedList(collectId);
            baseInfo.put("userDefinedFieldList", userDefinedList);

            //年代
            String years = baseInfo.getString("years");
            baseInfo.put("years", Arrays.asList(years.split(",")));

            // 质地类别
            String textureType = baseInfo.getString("textureType");
            if (!DataUtil.isEmpty(textureType)) {
                baseInfo.put("textureType", Arrays.asList(textureType.split(",")));
            } else {
                baseInfo.put("textureType", new ArrayList());
            }

            //质地
            String texture = baseInfo.getString("texture");
            if (!DataUtil.isEmpty(texture)) {
                baseInfo.put("texture", Arrays.asList(texture.split(",")));
            } else {
                baseInfo.put("texture", new ArrayList());
            }

            //在库位置
            String storehouse = baseInfo.getString("storehouse");
            List storehouseList = Arrays.asList(storehouse.split(","));
            baseInfo.put("storehouse", storehouseList);

            jsonObject.put("baseInfo", baseInfo);

            // 获取库房管理员
            String storeHouseId = storehouseList.get(0).toString();
            StoreHouse storeHouse = collectCommonBusinessService.selectStoreHouseByPrimaryKey(storeHouseId);
            List userNameList = new ArrayList();
            if (storeHouse != null) {
                String manager = storeHouse.getManager();
                String useName = collectCommonBusinessService.getUserNames(manager);
                userNameList = Arrays.asList(useName.split(","));
            }
            jsonObject.put("userNameList", userNameList);


            //-------------------下面是初始化下拉选项
            //年代树
            JSONArray ageTree = collectCommonCodeService.selectCollectAgeTree();
            jsonObject.put("ageTree", ageTree);

            //质地类别树
            JSONArray textureTypeTree = collectCommonCodeService.selectTextureTypeTree();
            jsonObject.put("textureTypeTree", textureTypeTree);

            //质地
            JSONArray textureList = collectCommonCodeService.selectTexture();
            jsonObject.put("textureList", textureList);

            //级别
            JSONArray cpLevOptions = collectCommonCodeService.selectCollectLev();
            jsonObject.put("cpLevOptions", cpLevOptions);

            //藏品类别
            JSONArray typeOptions = collectCommonCodeService.selectCollectType();
            jsonObject.put("typeOptions", typeOptions);

            //质量范围
            JSONArray massRangeOptions = collectCommonCodeService.massRangeOptions();
            jsonObject.put("massRangeOptions", massRangeOptions);

            //质量单位
            JSONArray massUnitOptions = collectCommonCodeService.massUnitOptions();
            jsonObject.put("massUnitOptions", massUnitOptions);

            //完残程度
            JSONArray completeDegreeOptions = collectCommonCodeService.completeDegreeOptions();
            jsonObject.put("completeDegreeOptions", completeDegreeOptions);

            //保存状态
            JSONArray keepStateOptions = collectCommonCodeService.keepStateOptions();
            jsonObject.put("keepStateOptions", keepStateOptions);

            //来源方式
            JSONArray sourceOptions = collectCommonCodeService.sourceOptions();
            jsonObject.put("sourceOptions", sourceOptions);

            //库房位置
            JSONArray storehouseOptions = collectCommonCodeService.selectCollectStorehouseTree();
            jsonObject.put("storehouseOptions", storehouseOptions);

            //在库状态
            JSONArray outStateOptions = collectCommonCodeService.outStateOptions();
            jsonObject.put("outStateOptions", outStateOptions);

            //数量单位
            JSONArray numUnitOptions = collectCommonCodeService.numUnitOptions();
            jsonObject.put("numUnitOptions", numUnitOptions);

            //判断当前质地是单一质地 还是 多个质地
//            String textureTypeJudge = textureTypeJudge(baseInfo.getJSONArray("textureType"));
//            if (textureTypeJudge.equals("1")) {
//                jsonObject.put("textureTypeJudge", textureTypeJudge);
//                baseInfo.put("texture", baseInfo.getJSONArray("texture").get(0));
//            }

            //藏品分类
            JSONArray collectClassOptions = collectCommonCodeService.collectClassOptions();
            jsonObject.put("collectClassOptions", collectClassOptions);

            //关联藏品
            jsonObject.put("groupCollect", getGroupCollect(collectId, false));

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品附件
     * @param json
     * @return
     */
    @PostMapping(value = "/mainBodyRes", produces = "application/json;charset=UTF-8")
    public JSONObject getCollectMainBodyRes(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        String collectId = json.getString("collectId");
        //藏品信息关联附件列表
        JSONObject resObj = collectCommonBusinessService.getMainBodyRes("90", collectId);
        JSONArray jsonArray = resObj.getJSONArray("resList");
        //返回的资源分组
        JSONArray imgList = new JSONArray();
        JSONArray audioList = new JSONArray();
        JSONArray videoList = new JSONArray();
        JSONArray modelList = new JSONArray();
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject fileObj = (JSONObject) jsonArray.get(i);
            if (fileObj.getString("resType").equals("1")) {
                imgList.add(fileObj);
            } else if (fileObj.getString("resType").equals("2")) {
                audioList.add(fileObj);
            } else if (fileObj.getString("resType").equals("3")) {
                videoList.add(fileObj);
            } else if (fileObj.getString("resType").equals("4")) {
                modelList.add(fileObj);
            }
        }
        jsonObject.put("imgList", imgList);
        jsonObject.put("audioList", audioList);
        jsonObject.put("videoList", videoList);
        jsonObject.put("modelList", modelList);
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 藏品编目暂存
     *
     * @param json
     * @return
     */
    @SysLog("藏品编目暂存")
    @RequestMapping(value = "/tempSave", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject tempSave(@RequestBody JSONObject json) {
        json.put("saveOrCommit", "0");
        return saveOrCommit(json);
    }

    /**
     * 藏品编目提交
     *
     * @param json
     * @return
     */
    @SysLog("藏品编目提交")
    @RequestMapping(value = "/saveCommit", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject saveCommit(@RequestBody JSONObject json) {
        json.put("saveOrCommit", "1");
        return saveOrCommit(json);
    }

    /**
     * 贴标签
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/editAddLabel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editAddLabel(@RequestBody JSONObject json) {
        JSONObject jsonObject = addLabel(json);
        return jsonObject;
    }

    /**
     * 删除标签
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/editDelLabel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editDelLabel(@RequestBody JSONObject json) {
        JSONObject jsonObject = delLabel(json);
        return jsonObject;
    }

    /**
     * 编目设置封面
     */
    @RequestMapping(value = "/setCover", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editSetCover(@RequestBody JSONObject json) {
        JSONObject jsonObject = setCover(json);
        return jsonObject;
    }

    /**
     * 查询关联藏品
     */
    @RequestMapping(value = "/searchLinkCollect", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editSearchLinkCollect(@RequestBody JSONObject json) {
        JSONObject jsonObject = searchLinkCollect(json);
        return jsonObject;
    }

    /**
     * 添加关联藏品
     */

    @RequestMapping(value = "/editAddLinkCollect", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editAddLinkCollect(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = addLinkCollect(json);
            JSONArray jsonArray = jsonObject.getJSONArray("groupList");

            JSONObject returnJson = new JSONObject();
            if (jsonArray != null) {
                JSONArray jsonArray1 = new JSONArray();
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
                    jsonObject = getCollectBaseInfo(jsonObject1);
                    jsonArray1.add(jsonObject);
                }
                returnJson.put("groupList", jsonArray1);
            }
            returnJson.put("code", "1");
            returnJson.put("msg", "关联成功！");
            return returnJson;
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 删除关联藏品
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/editDelLinkCollect", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editDelLinkCollect(@RequestBody JSONObject json) {
        JSONObject jsonObject = delLinkCollect(json);
        return jsonObject;
    }

    /**
     * 添加扩展属性记录
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/editAddExpand", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editAddExpand(@RequestBody JSONObject json) {
        return addExpand(json);
    }

    /**
     * 删除扩展属性记录
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/editDelExpand", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject editDelExpand(@RequestBody JSONObject json) {
        return delExpand(json);
    }

    /**
     * 批量提交
     *
     * @return
     */
    @SysLog("藏品编目批量提交")
    @RequestMapping(value = "/batchCommit", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject batchCommit(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectIds = json.getString("collectIds");
            String status = json.getString("status");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }

            String[] collectIdArray = collectIds.split(",");
            //提交之前先做数据校验
            String mes = "";
            for (int i = 0; i < collectIdArray.length; i++) {
                String collectId = collectIdArray[i];
                CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(collectId);

                mes = checkCollectInfo(collectInfo);
                if (!DataUtil.isEmpty(mes)) {
                    mes += "（第" + (i + 1) + "条数据）";
                    break;
                }
            }
            if (!DataUtil.isEmpty(mes)) {
                throw new BaseRuntimeException(mes);
            }

            String confirmFlg = json.getString("confirmFlg");
            if (!"1".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_COMMIT);
            }
            List<CollectInfo> collectInfoList = new ArrayList<>();

            for (int i = 0; i < collectIdArray.length; i++) {
                CollectInfo collectInfo = new CollectInfo();
                collectInfo.setCollectId(collectIdArray[i]);

                collectInfo.setStatus(status);
                collectInfo.setCommitDate(new Date());

                collectInfoList.add(collectInfo);
            }

            collectInfoService.batchUpdate(collectInfoList);
            throw new BaseRuntimeException(CollectErrorDefine.COMMIT_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 自定义属性添加
     *
     * @param userDefined
     * @return
     */
    @RequestMapping(value = "/addField", method = RequestMethod.POST, produces = "application/json")
    public JSONObject addField(@RequestBody UserDefined userDefined) {
        JSONObject jsonObject = new JSONObject();
        try {
            UserDefined newUserDefined = collectCommonBusinessService.addUserDefinedField(userDefined);
            jsonObject.put("userDefined", newUserDefined);
            throw new BaseRuntimeException(CollectErrorDefine.ADD_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 自定义属性删除
     *
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/delField", method = RequestMethod.POST, produces = "application/json")
    public JSONObject delField(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String fieldId = jsonParam.getString("fieldId");
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (DataUtil.isEmpty(fieldId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR, "自定义属性"));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL, ""));
            }
            int handleNum = collectCommonBusinessService.delUserDefinedField(fieldId);
            if (handleNum == 1) {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_ERR);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取库房管理员
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/getStoreManager", method = RequestMethod.POST, produces = "application/json")
    public JSONObject getStoreManager(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            List storeHouseIdList = json.getJSONArray("storeHouseId");
            String storeHouseId = storeHouseIdList.get(0).toString();

            StoreHouse storeHouse = collectCommonBusinessService.selectStoreHouseByPrimaryKey(storeHouseId);
            String manager = storeHouse.getManager();
            String useName = collectCommonBusinessService.getUserNames(manager);

            if (!DataUtil.isEmpty(useName)) {
                jsonObject.put("userNameList", Arrays.asList(useName.split(",")));
            } else {
                jsonObject.put("userNameList", new ArrayList<>());
            }
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 数据查重
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/dataRepeatSelect", method = RequestMethod.POST, produces = "application/json")
    public JSONObject dataRepeatSelect(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String totalNum = json.getString("totalNum");//总账号
            String classNum = json.getString("classNum");//分类帐号
            String collectId = json.getString("collectId");//藏品Id

            CollectInfo collectInfo = new CollectInfo();
            collectInfo.setCollectId(collectId);
            collectInfo.setTotalNum(totalNum);
            collectInfo.setClassNum(classNum);

            List<CollectInfo> list = collectInfoService.selectRepeatRecord(collectInfo);
            String msg = "";
            if (list.size() > 0) {
                if (!DataUtil.isEmpty(totalNum)) {
                    msg = "总账号 已经被占用";
                } else if (!DataUtil.isEmpty(classNum)) {
                    msg = "分类账号 已经被占用";
                }
            }
            jsonObject.put("msgInfo", msg);
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 质地类别查询
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/selectTextureType", method = RequestMethod.POST, produces = "application/json")
    public JSONObject selectTextureType(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            List list = json.getJSONArray("textureId");
            jsonObject.put("textureType", textureTypeJudge(list));

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    private String textureTypeJudge(List list) {
        String textureType = "";
        if (list.size() > 0) {
            TextureType textureTypeObj = textureTypeService.findDataById(list.get(0).toString());
            if (null != textureTypeObj && textureTypeObj.getTextureName().equals("单一质地")) {
                textureType = "1";
            }
        }

        return textureType;
    }

    /**
     * 选择导出的表头
     *
     * @return
     */
    @RequestMapping(value = "/exportHeaderOptions", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeaderOptions() {
        JSONObject jsonObject = new JSONObject();
        try {

            List headers = new ArrayList();
            JSONObject headerJson = new JSONObject();
            headerJson.put("label", "藏品名称");
            headerJson.put("key", "collectName");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品原名");
            headerJson.put("key", "collectNameOld");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "普查名称");
            headerJson.put("key", "censusName");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "总登记号");
            headerJson.put("key", "totalNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "分类号");
            headerJson.put("key", "classNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品编号");
            headerJson.put("key", "collectCode");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "收入号");
            headerJson.put("key", "incomeNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "年代");
            headerJson.put("key", "years");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体年代");
            headerJson.put("key", "specificAge");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "级别");
            headerJson.put("key", "cpLevel");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品类别");
            headerJson.put("key", "collectType");
            headers.add(headerJson);

//            headerJson = new JSONObject();
//            headerJson.put("label", "质地类别");
//            headerJson.put("key", "textureType");
//            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体质地");
            headerJson.put("key", "texture");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "质量范围");
            headerJson.put("key", "massRange");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "质量单位");
            headerJson.put("key", "massUnit");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体质量");
            headerJson.put("key", "specificMass");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "数量");
            headerJson.put("key", "quantity");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "实际数量");
            headerJson.put("key", "realNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "长(cm)");
            headerJson.put("key", "length");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "宽(cm)");
            headerJson.put("key", "width");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "高(cm)");
            headerJson.put("key", "height");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "口径(cm)");
            headerJson.put("key", "bore");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "底径(cm)");
            headerJson.put("key", "bottomDiameter");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "腹经(cm)");
            headerJson.put("key", "abdominal");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "直径(cm)");
            headerJson.put("key", "diameter");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体尺寸");
            headerJson.put("key", "specificSize");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "完残程度");
            headerJson.put("key", "completeDegree");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "保存状态");
            headerJson.put("key", "keepState");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "完残状况");
            headerJson.put("key", "completeDesc");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "包装情况");
            headerJson.put("key", "packCondition");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "来源方式");
            headerJson.put("key", "source");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "产地");
            headerJson.put("key", "productPlace");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "入馆时间");
            headerJson.put("key", "inMsDt");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "入藏时间");
            headerJson.put("key", "collectTimeRange");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "在库位置");
            headerJson.put("key", "storehouse");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体方位");
            headerJson.put("key", "specificPosition");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "在库状态");
            headerJson.put("key", "outState");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "参考账类型");
            headerJson.put("key", "referAccountType");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "在库数量");
            headerJson.put("key", "inStoreNum");
            headers.add(headerJson);

            jsonObject.put("headerOptions", headers);
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 数据导出
     *
     * @return
     */
    @SysLog("藏品编目导出")
    @RequestMapping(value = "/dataExport", method = RequestMethod.POST, produces = "application/json")
    public void dataExport(@RequestBody JSONObject json, HttpServletRequest request, HttpServletResponse response) {
        try {
            //查询数据 转换查询条件
            JSONObject pageJson = json.getJSONObject("page");
            Page page = pageJson.toJavaObject(Page.class);
            selectParam(page);

            //导出类型
            String exportType = json.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }

            if (exportType.equals("0")) {
                //导出查询的全部数据
                page.setPageSize(0);
                page.getConditionMap().put("orderBy", "createTime desc");
            } else if (exportType.equals("1")) {
                //导出当前页的数据 什么也不做
            } else if (exportType.equals("2")) {
                //2：选择的数据
                String collectIds = json.getString("collectIds");
                page.getConditionMap().put("collectIds", Arrays.asList(collectIds.split(",")));
            }

            //获取选择的头部
            List headerNameList = new ArrayList(10);
            List headerKeyList = new ArrayList(10);
            // 新头部
            List<List<String>> headerList = new ArrayList(1);
            JSONArray exportColumn = json.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
                List<String> header = new ArrayList(10);
                header.add(jsonObject.getString("label"));
                headerList.add(header);
            }

            //封装实体数据
            List dataList = new ArrayList(10);

            // 数据
            List<List<String>> bodyList = new ArrayList(1);

            MetadataModel model = MetadataUtil.getMetadataModel();
            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);
            // 查询藏品类别
            List<String> typeIds = collectInfoList.stream().map(CollectInfo::getCollectType).distinct().collect(Collectors.toList());
            Map<String, String> typeMap = collectCommonCodeService.getTypeToMap(typeIds);
            // 库房
            Map<String, Map<String, String>> storeroomMap = collectCommonCodeService.getStoreroomToMap();
            // 年代
            Map<String, String> ageMap = collectCommonCodeService.getAgeToMap();
            // 质地类别
            Map<String, String> textureTypeMap = collectCommonCodeService.getTextureTypeToMap();
            // 出库藏品
            List<String> coIds = collectInfoList.stream().map(CollectInfo::getCollectId).collect(Collectors.toList());
            Map<String, Integer> outStoreNumMap = getOutStoreNum(coIds);

            List<String> collectIdList = new ArrayList<>(1);
            Map<String, String> collectMap = new HashMap<>(1);
            for (int i = 0; i < collectInfoList.size(); i++) {
                List<String> body = new ArrayList(1);
                CollectInfo collectInfo = collectInfoList.get(i);
                collectIdList.add(collectInfo.getCollectId());
                collectMap.put(collectInfo.getCollectId(), collectInfo.getTotalNum());
                //实体类转换成 json对象
                JSONObject collectInfo_inObject = JSONObject.parseObject(JSONObject.toJSONString(collectInfo, SerializerFeature.WriteNullStringAsEmpty));
                //获取选择的列数据
                boolean calcInStoreNum = false;//是否已经计算过在库数量
                int inStoreNum = 0;//在库数量
                List obj = new ArrayList();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    Integer realNum = Integer.valueOf(collectInfo.getRealNum());
                    String key = headerKeyList.get(j).toString();
                    String value = collectInfo_inObject.getString(key);

                    //---------------------获取翻译值---------------------------------
                    if (key.equals("years")) {
                        //年代
                        value = collectCommonCodeService.collectAgeShow(collectInfo.getYears(), ageMap);
                    } else if (key.equals("cpLevel")) {
                        //级别
                        value = collectCommonCodeService.cpLev_t(collectInfo.getCpLevel());
                    } else if (key.equals("collectType")) {
                        //藏品类别;
                        value = typeMap.get(collectInfo.getCollectType());
                    } else if (key.equals("textureType")) {
                        //质地类别;
                        value = collectCommonCodeService.getTranslateShow(collectInfo.getTextureType(), textureTypeMap);
                    } else if (key.equals("texture")) {
                        // 质地;
                        value = collectCommonCodeService.getTranslateShow(collectInfo.getTexture(), textureTypeMap);
                    } else if (key.equals("massRange")) {
                        // 质量范围;
                        value = collectCommonCodeService.massRange_t(collectInfo.getMassRange());
                    } else if (key.equals("massUnit")) {
                        // 质量单位;
                        value = collectCommonCodeService.massUnit_t(collectInfo.getMassUnit());
                    } else if (key.equals("quantity")) {
                        // 数量;
                        value = collectInfo.getQuantity() + collectCommonCodeService.numUnit_t(collectInfo.getNumUnit());
                    } else if (key.equals("completeDegree")) {
                        // 完残程度;
                        value = collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree());
                    } else if (key.equals("keepState")) {
                        // 保存状态;
                        value = collectCommonCodeService.keepState_t(collectInfo.getKeepState());
                    } else if (key.equals("referAccountType")) {
                        // 参考账状态
                        value = model.getDictName("cp_refer_account_type", String.valueOf(collectInfo.getReferAccountType()));
                    } else if (key.equals("source")) {
                        // 来源方式;
                        value = collectCommonCodeService.source_t(collectInfo.getSource());
                    } else if (key.equals("storehouse")) {
                        // 在库位置;
                        value = collectCommonCodeService.storehouseShow(collectInfo.getStorehouse(), storeroomMap);
                    } else if (key.equals("outState")) {
                        // 在库状态
                        Integer outStoreNum = outStoreNumMap.getOrDefault(collectInfo.getCollectId(), 0);
                        inStoreNum = realNum - outStoreNum;
                        if (Objects.equals(realNum, inStoreNum)) {
                            value = "在库";
                        } else if (inStoreNum <= 0) {
                            value = "出库";
                        } else {
                            value = "部分在库";
                        }
                        calcInStoreNum = true;
                    } else if (key.equals("inStoreNum")) {
                        if (!calcInStoreNum) {
                            Integer outStoreNum = outStoreNumMap.getOrDefault(collectInfo.getCollectId(), 0);
                            inStoreNum = realNum - outStoreNum;
                        }
                        value = String.valueOf(inStoreNum);
                    }
                    obj.add(value);
                    body.add(value);
                }
                dataList.add(obj);
                bodyList.add(body);
            }
            /**
             * 之前的方法，太卡
             * HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, dataList);
             * DataExportUtils.setResponseHeader(response, wb, "藏品编目");
             * */

            ExcelWriterUtil.builder().response(response).fileName("藏品列表").build().writeCustomHeader(headerList, bodyList);

//            Map<String, String> filePathMap = resServerInterface.getSaveFilePath();
//            List<AttachInfoVO> attachInfoList = attachInfoService.listAttachInfoByCp(collectIdList);
//            CollectionExport.builder().fileName("藏品列表").response(response).build()
//                    .collectionExport(filePathMap, attachInfoList, collectMap, headerList, bodyList);

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(201);
        }
    }


    /**
     * 通用查询条件
     *
     * @return
     */
    private static void selectParam(Page page) {
        String storehouse = "";
        if (null != page.getConditionMap().get("storehouse") && !DataUtil.isEmpty(page.getConditionMap().get("storehouse").toString())) {
            List list = (List) page.getConditionMap().get("storehouse");
            storehouse = StringUtils.join(list.toArray(), ",");
        }
        page.getConditionMap().put("storehouse", storehouse);

        // 拨库管理
        Object bkStatus = page.getConditionMap().get("bkStatus");
        if (Objects.nonNull(bkStatus)) {
            List<String> statusList = Arrays.asList(bkStatus.toString().split(","));
            page.getConditionMap().put("statusList", statusList);
        }
//        page.setOrderBy("createTime desc");
    }

    /**
     * 文件下载功能
     *
     * @param request
     * @param response
     */
    @SysLog("藏品编目导入模板下载")
    @RequestMapping(value = "/downloadExcel", method = RequestMethod.POST, produces = "application/json")
    public void downloadExcel(HttpServletRequest request, HttpServletResponse response, @RequestBody JSONObject json) {
        String excelName = json.getString("name");
        try {
            DownExcelUtil.downloadExcel(response, 1, excelName);
            log.info("应用导入模板下载成功");
        } catch (Exception e) {
            log.error("应用导入模板下载失败！", e);
        }
    }

    /**
     * 藏品编目导入
     *
     * @param request
     * @param response
     * @param file
     * @return 状态
     */
    @RequestMapping("/dataImport")
    @ResponseBody
    public Map<String, Object> fileUpload(HttpServletRequest request, HttpServletResponse response, @RequestParam("excelFile") MultipartFile file) {
        String fileName = file.getOriginalFilename();
        Map<String, Object> retrunStart = new HashMap<>();

        try {
            InputStream in = file.getInputStream();
            collectImportService.importExcel(in, fileName);
            retrunStart.put("status", true);
            return retrunStart;
        } catch (Exception e) {
            retrunStart.put("status", false);
            retrunStart.put("msg", e.getMessage());
            log.error(e.getMessage(), e);
        }
        return retrunStart;
    }

    /**
     * 获取当前执行数
     *
     * @return 返回执行数集合
     */
    @GetMapping(value = "/getCurrent")
    public Map<String, Integer> totalMath() {
        Map<String, Integer> returnData = null;
        returnData = collectImportService.totalMath();
        return returnData;
    }

    /**
     * 藏品编目-编目中删除
     *
     * @param jsonParam
     * @return
     */
    @PreAuthorize("@pms.hasPermission('CPINFO_DEL')")
    @PostMapping(value = "/deleteByBatch")
    public JSONObject deleteByBatch(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();

        String ids = jsonParam.getString("collectId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(ids)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL, ""));
            }
            List<String> idList = new ArrayList<>(Arrays.asList(ids.split(",")));
            int handleNum = collectInfoService.deleteByBatch(idList);
            if (handleNum == idList.size()) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_SUCCESS));
            } else {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_ERR));
            }

        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 流水账统计导出
     * @param request
     * @param response
     */
    @PostMapping("/collectStatisticsExport")
    public void collectStatisticsExport(HttpServletRequest request, HttpServletResponse response) {
        collectInfoService.selectCollectStatisticsExport(request, response);
    }
}
