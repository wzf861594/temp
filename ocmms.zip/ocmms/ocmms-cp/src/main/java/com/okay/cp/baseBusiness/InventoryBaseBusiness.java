package com.okay.cp.baseBusiness;

import cn.afterturn.easypoi.entity.ImageEntity;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.Inventory;
import com.okay.cp.entity.InventoryList;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.InventoryListService;
import com.okay.cp.service.InventoryService;
import com.okay.cp.utils.CollectUtils;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DataUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import sun.misc.BASE64Decoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.NumberFormat;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/11 17:18
 * @Version: 1.0
 * @Description: 盘点基类
 */
public class InventoryBaseBusiness extends CollectInfoBaseBusiness{

    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private InventoryListService inventoryListService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private UserService userService;


    public JSONObject initData() {
        JSONObject jsonObject = new JSONObject();
        // 盘点类型下拉
        JSONArray typeOptions = collectCommonCodeService.inventoryTypeOptions();
        // 库房下拉
        JSONArray storeOptions = collectCommonCodeService.selectCollectStorehouseTree();
        // 获取创建人
        Map<String,Object> queryMap = new HashMap<String,Object>();
        queryMap.put("status","1");
        List<User> userDataList = userService.findUserWithDeptByQuery(queryMap);
        List<Map<String,Object>> userOptions = handleUserOptions(userDataList);

        jsonObject.put("creatUserOptions",userOptions);
        jsonObject.put("typeOptions",typeOptions);
        jsonObject.put("storeOptions",storeOptions);
        jsonObject.put("code",1);

        return jsonObject;
    }

    /**
     * 列表数据.
     * @param page
     * @return
     */
    public JSONObject getDataList(Page page){

        com.github.pagehelper.Page pageResult = getDataByPage(page);
        pageResult = resultDataHandle(pageResult);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data",pageResult);
        jsonObject.put("pages",pageResult.getPages());
        jsonObject.put("total",pageResult.getTotal());
        jsonObject.put("pageSize",page.getPageSize());
        jsonObject.put("code",1);

        return jsonObject;
    }

    /**
     * 根据主键获取信息.
     * @param jsonParam
     * @return
     */
    public JSONObject getDataById(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String inventoryId = jsonParam.getString("inventoryId");
        try{
            if (DataUtil.isEmpty(inventoryId)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            Map<String, Object> dataMap = inventoryService.findByIdForMap(inventoryId);
            jsonObject.put("singleData",dataMap);
            jsonObject.put("code",1);
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 盘点明细分页查询.
     * @param page
     * @return
     */
    public JSONObject getInventoryListByQuery(@RequestBody Page page){
        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
        List<InventoryList> dataResult = null;

        Integer pages = 0;
        Long total = 0L;

        JSONObject jsonObject = new JSONObject();
        try{
            if (page != null) {
                Map<String,Object> queryMap = page.getConditionMap();
                if (page.getPageSize() > 0) {
                    try(com.github.pagehelper.Page resultPages = PageHelper.startPage(page.getPageNum(), page.getPageSize(), true)) {
                        inventoryListService.findByQuery(queryMap);
                        dataResult = (List<InventoryList>)resultPages;
                        pages  = resultPages.getPages();
                        total = resultPages.getTotal();
                    }
                }else {
                    dataResult = inventoryListService.findByQuery(queryMap);
                }
            }

            int collectNum = dataResult.size();
            int normalNum = 0;
            int unnormalNum = 0;
            // 翻译值处理
            for (int i = 0; i < dataResult.size(); i++) {
                InventoryList inventoryList = dataResult.get(i);
                // 实体转Map
                String jsonString = JSONObject.toJSONString(inventoryList);
                Map<String, Object> dataMap = JSONObject.parseObject(jsonString);

                // 获取对应的封面
                String collectId = String.valueOf(inventoryList.getCollectId());
                dataMap.put("image", CollectUtils.getCollectImageIoUrl(collectId));
                // 盘点状态
                dataMap.put("state_t",inventoryList.getState().equals(1) ? "未盘点" : "已盘点");
                // 保存状态
                dataMap.put("keepState_t",collectCommonCodeService.keepState_t(inventoryList.getKeepState()));
                // 库房位置
                dataMap.put("storehouse_t",collectCommonCodeService.storehouse_t(inventoryList.getStorehouse()));
                // 完成程度
                dataMap.put("completeDegree_t",collectCommonCodeService.completeDegree_t(inventoryList.getCompleteDegree()));
                // 数量单位
                dataMap.put("numUnit_t",collectCommonCodeService.numUnit_t(inventoryList.getNumUnit()));
                // 具体方位
                dataMap.put("specificPosition",inventoryList.getSpecificPosition());
                // 在库数量
                int inStoreNum = getCollectInStoreNum(inventoryList.getCollectId());
                dataMap.put("inStoreNum",inStoreNum);
                // 在库状态
                String outState = "在库";
                String realNum = inventoryList.getRealNum();
                if (inStoreNum == 0) {
                    outState = "出库";
                } else if (inStoreNum < Integer.parseInt(realNum)) {
                    outState = "部分出库";
                }
                dataMap.put("outState_t",outState);

                // ========== 导出使用
                Boolean b = (Boolean)page.getConditionMap().get("isExport");
                if (b != null && b) {
                    String imgBase64 = collectCommonBusinessService.getCoverImg("90", collectId);
                    byte[] imageByte = null;
                    if (StringUtils.isNotEmpty(imgBase64)) {
                        String base64Code = imgBase64.indexOf(",") != -1 ? imgBase64.split(",")[1] : imgBase64;//去掉头部
                        imageByte = new BASE64Decoder().decodeBuffer(base64Code);
                    }
                    ImageEntity imageEntity = new ImageEntity();
                    imageEntity.setData(imageByte);
                    dataMap.put("imageByte",imageEntity);

                    dataMap.put("indexNum",(i + 1));

                    if (inventoryList.getInventResult() == 1) {
                        normalNum += 1;
                    }
                    if (inventoryList.getInventResult() == 2) {
                        unnormalNum ++;
                    }
                }
                dataList.add(dataMap);
            }

            jsonObject.put("singleList", dataList);
            jsonObject.put("collectNum", collectNum + "件");
            jsonObject.put("normalNum", normalNum + "件");
            jsonObject.put("unnormalNum", unnormalNum + "件");
            jsonObject.put("pages",pages);
            jsonObject.put("total",total);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 更新盘点单状态.
     * @param inventoryState
     * @param inventoryId
     */
    public int updateState(String inventoryState, String inventoryId){
        List<String> idList = new ArrayList<String>(Arrays.asList(inventoryId.split(",")));
        List<Inventory> inventoryList = new ArrayList<>();
        for (String id : idList) {
            Inventory inventory = new Inventory();
            inventory.setInventoryId(id);
            inventory.setState(inventoryState);
            inventoryList.add(inventory);
        }
        int handleNum = inventoryService.updateMainInfo(inventoryList);
        return handleNum;
    }

    /**
     * 获取用户名称.
     * @param userId
     * @return
     */
    public String getUserName(String userId){
        return collectCommonBusinessService.getUserNames(userId);
    }

    /**
     * 列表数据查询.
     * @param page
     * @return
     */
    public com.github.pagehelper.Page getDataByPage(Page page){
        com.github.pagehelper.Page pageResult = null;

        Map<String,Object> conditionMap = new HashMap<String,Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询时间
                Object timeObject = conditionMap.get("creatTime");
                if (timeObject != null && !"".equals(timeObject)) {
                    ArrayList<String> creatTime = (ArrayList)timeObject;
                    if (null != creatTime && !"".equals(creatTime)) {
                        if (creatTime.size() == 2) {
                            conditionMap.put("startCreateTime", creatTime.get(0));
                            conditionMap.put("endCreateTime", creatTime.get(1));
                        }
                    }
                }
            }
            // 查询
            try(com.github.pagehelper.Page pages = PageHelper.startPage(page.getPageNum(), page.getPageSize(), true)) {
                inventoryService.findDataList(conditionMap);
                pageResult = pages;
            }
        }
        return pageResult;
    }

    /**
     * 查询结果处理.
     * @param pageResult
     * @return
     */
    public com.github.pagehelper.Page resultDataHandle(com.github.pagehelper.Page pageResult){

        for (int i = 0; i < pageResult.size(); i++) {
            Map<String,Object> dataMap = (Map<String,Object>)pageResult.get(i);
            dataMap.put("acceptUser_t",getUserName(String.valueOf(dataMap.get("acceptUser"))));
            dataMap.put("createUser_t",getUserName(String.valueOf(dataMap.get("createUser"))));
            dataMap.put("inventoryUser_t",getUserName(String.valueOf(dataMap.get("inventoryUser"))));
            dataMap.put("storeHouse_t",collectCommonCodeService.storehouse_t(String.valueOf(dataMap.get("storeHouse"))));
            dataMap.put("inventoryType_t",collectCommonCodeService.inventoryType_t(String.valueOf(dataMap.get("inventoryType"))));

            Map<String,Object> queryMap = new HashMap<String,Object>();
            queryMap.put("inventoryId",dataMap.get("inventoryId"));
            List<InventoryList> inventoryLists = inventoryListService.findByQuery(queryMap);
            
            // 对应房间数量
            if (inventoryLists != null) {
                dataMap.put("inventoryStock",inventoryLists.size());
            }else {
                dataMap.put("inventoryStock",0);
            }
            // 盘点进度
            int normalProgress = 0;
            for (InventoryList inventoryList : inventoryLists) {
                if (inventoryList.getInventResult() != null) {
                    normalProgress ++;
                }
            }
            NumberFormat numberFormat = NumberFormat.getInstance();
            numberFormat.setMaximumFractionDigits(2);
            String inventoryProgress = numberFormat.format((float) normalProgress/ (float) inventoryLists.size() * 100);

            dataMap.put("inventoryProgress", inventoryProgress + "%");
        }
        return pageResult;
    }

    /**
     * 导出选择列.
     * @return
     */
    public JSONObject initExportHeader() {

        String headerArray = "[" +
                "{'label':'盘点任务名','key':'taskName'}," +
                "{'label':'盘点类别','key':'inventoryType_t'}," +
                "{'label':'盘点人','key':'inventoryUser_t'}," +
                "{'label':'接收人','key':'acceptUser_t'}," +
                "{'label':'任务描述','key':'taskDesc'}," +
                "{'label':'创建人','key':'createUser_t'}," +
                "{'label':'创建时间','key':'createTime'}," +
                "{'label':'库房位置','key':'storeHouse_t'}," +
                "]";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("exportHeaderList", JSONArray.parseArray(headerArray));
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    public void exportHandle(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        try{
            Page page = jsonParam.getJSONObject("page").toJavaObject(Page.class);

            //导出类型 0:导出查询的全部数据 1: 当前页数据 2：选择的数据
            String exportType = jsonParam.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }
            if (exportType.equals("0")) {
                page.setPageSize(0);
                page.setPageNum(0);
            } else  if (exportType.equals("2")) {
                String inventoryId = String.valueOf(page.getConditionMap().get("inventoryId"));
                page.getConditionMap().put("inventoryIdList",Arrays.asList(inventoryId.split(",")));
            }

            //导出文件名
            String fileName = jsonParam.getString("exportFileName");
            if (DataUtil.isEmpty(fileName)) {
                fileName = "盘点单";
            }

            // 获取选择导出的列数据
            List headerNameList = new ArrayList();
            List headerKeyList = new ArrayList();
            JSONArray exportColumn = jsonParam.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            // 查询数据及结果处理
            com.github.pagehelper.Page pageResult = getDataByPage(page);
            List<Map<String,Object>> dataMapList = resultDataHandle(pageResult);

            // 根据选择导出列封装导出数据
            List<Object> exportDataList = new ArrayList<Object>();
            for(Map<String,Object> dataMap : dataMapList){
                List<String> stringDataList = new ArrayList<String>();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = headerKeyList.get(j).toString();
                    String value = dataMap.get(key) == null ? "" : String.valueOf(dataMap.get(key));
                    stringDataList.add(value);
                }
                exportDataList.add(stringDataList);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, exportDataList);
            DataExportUtils.setResponseHeader(response, wb, fileName);
        }catch (Exception e){
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 获取盘点报告数据.
     * @param jsonParam
     * @return
     */
    public List<Map<String, Object>> getInventoryExportData(JSONObject jsonParam){

        Page page = jsonParam.getJSONObject("page").toJavaObject(Page.class);
        //导出类型 0:导出查询的全部数据 1: 当前页数据 2：选择的数据
        String exportType = jsonParam.getString("exportType");
        if (DataUtil.isEmpty(exportType)) {
            exportType = "0";
        }
        if (exportType.equals("0")) {
            page.setPageSize(0);
        } else  if (exportType.equals("2")) {
            if (page.getConditionMap().get("inventoryId") == null) {
                throw new BaseRuntimeException("请选择导出数据");
            }
            page.setPageSize(0);
            String inventoryId = String.valueOf(page.getConditionMap().get("inventoryId"));
            page.getConditionMap().put("inventoryIdList", Arrays.asList(inventoryId.split(",")));
        }
        // 盘点单数据
        List<Map<String,Object>> dataMapList = (List<Map<String,Object>>)getDataByPage(page);

        // 获取明细数据
        for (Map<String,Object> dataMap : dataMapList) {
            dataMap.put("acceptUser_t", getUserName(String.valueOf(dataMap.get("acceptUser"))));
            dataMap.put("createUser_t", getUserName(String.valueOf(dataMap.get("createUser"))));
            dataMap.put("inventoryUser_t", getUserName(String.valueOf(dataMap.get("inventoryUser"))));
            dataMap.put("storeHouse_t", collectCommonCodeService.storehouse_t(String.valueOf(dataMap.get("storeHouse"))));
            dataMap.put("inventoryType_t", collectCommonCodeService.inventoryType_t(String.valueOf(dataMap.get("inventoryType"))));

            Page newPage = new Page();
            newPage.setPageSize(0);
            newPage.getConditionMap().put("isExport",true);
            newPage.getConditionMap().put("inventoryId",String.valueOf(dataMap.get("inventoryId")));
            JSONObject jsonObject = getInventoryListByQuery(newPage);
            List<Map<String,Object>> detailDataMapList = (List<Map<String,Object>>)jsonObject.get("singleList");

            dataMap.put("dataMapList", detailDataMapList);
            dataMap.put("collectNum", jsonObject.get("collectNum"));
            dataMap.put("normalNum", jsonObject.get("normalNum"));
            dataMap.put("unnormalNum", jsonObject.get("unnormalNum"));

            dataMap.put("exportFileName",dataMap.get("taskName") + "_盘点报告");
            dataMap.put("sheetName",dataMap.get("taskName"));
        }
        return dataMapList;
    }

    public Map<Integer, List<Map<String, Object>>> getInventoryExportDataClone(JSONObject jsonParam){
        Map<Integer, List<Map<String, Object>>> exportDataMap = new HashMap<Integer, List<Map<String, Object>>>();
        exportDataMap.put(0,getInventoryExportData(jsonParam));
        return exportDataMap;
    }

    public List<Map<String,Object>> handleUserOptions(List<User> userDataList){
        List<Map<String,Object>> userMapList = new ArrayList<Map<String,Object>>();

        for (int i = 0; i < userDataList.size(); i++) {
            User user = userDataList.get(i);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("label",user.getUserName());
            jsonObject.put("value", user.getUserId());
            userMapList.add(jsonObject);
        }
        return userMapList;
    }
}
