package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.common.util.MetadataUtil;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.BillInfo;
import com.okay.cp.entity.BillInfoList;
import com.okay.cp.service.BillInfoListService;
import com.okay.cp.service.BillInfoService;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import com.okay.okay.admin.api.metadata.UserInfo;
import com.okay.okay.common.log.annotation.SysLog;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

@RestController
@RequestMapping(value = "/bill")
public class BillInfoController{

    @Autowired
    private BillInfoService billInfoService;
    @Autowired
    private BillInfoListService billInfoListService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;


    /**
     * 清单数据列表查询
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();
        List<Map<String,Object>> dataList = billInfoService.findDataList(page);
        for (int i = 0; i < dataList.size() ; i++) {
            Map<String,Object> dataMap = dataList.get(i);

            // 创建人
            Object userIdObj = dataMap.get("createUser");
            if (userIdObj != null) {
                String userName = MetadataUtil.getMetadataModel().getUserName(Integer.valueOf(userIdObj.toString()).intValue());
                if (StringUtils.isNotEmpty(userName)) {
                    dataMap.put("createUserName", userName);
                }
            }
            // 共享人
            Object shareUserObj = dataMap.get("shareuser");
            if (shareUserObj != null) {
                String userName = MetadataUtil.getMetadataModel().getUserName(Integer.valueOf(shareUserObj.toString()).intValue());
                if (StringUtils.isNotEmpty(userName)) {
                    dataMap.put("shareUser", userName);
                }
            }

            // 共享状态
            String shareState = String.valueOf(dataMap.get("shareState"));
            if ("0".equals(shareState)) {
                dataMap.put("shareStateName","未共享");
            }else if ("1".equals(shareState)) {
                dataMap.put("shareStateName","已共享");
                // 获取共享人员
                List<UserInfo> userList = billInfoService.findShareUserByBillId(String.valueOf(dataMap.get("billId")));
                List<String> userNameList = (List<String>)userResultHandle(userList).get("userNameList");
                if (userNameList.size() > 0) {
                    dataMap.put("shareObject", StringUtils.join(userNameList,"; "));
                }
            }

            // 提借总数量
            int count = 0;
            List<BillInfoList> billInfoListList = billInfoListService.findByBillId(String.valueOf(dataMap.get("billId")));
            for (BillInfoList billInfoList : billInfoListList) {
                if (billInfoList.getBorrowNum() != null) {
                    count += billInfoList.getBorrowNum();
                }
            }
            dataMap.put("borrowCount",count);
        }

        jsonObject.put("data",dataList);
        jsonObject.put("pages",page.getPages());
        jsonObject.put("total",page.getTotal());
        jsonObject.put("pageSize",page.getPageSize());
        jsonObject.put("code",1);
        return jsonObject;
    }

    /**
     * 检索页面加入清单的展示数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataListForShow", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataListForShow(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();
        List<Map<String,Object>> dataList = billInfoService.findDataList(page);
        for (Map<String,Object> dataMap : dataList) {
            if (dataMap != null) {
                String billId = String.valueOf(dataMap.get("billId"));
                List<BillInfoList> billInfoListList = billInfoListService.findByBillId(billId);
                List<String> imageList = new ArrayList<String>();
                for (int i = 0; i < billInfoListList.size(); i++) {
                    BillInfoList billInfoList = billInfoListList.get(i);
                    String  imgToBase64= collectCommonBusinessService.getCoverImg("90", billInfoList.getCollectId());
                    imageList.add(imgToBase64);
                    if (i == 3) {
                        break;
                    }
                }
                dataMap.put("imageList",imageList);
            }
        }
        jsonObject.put("data",dataList);
        jsonObject.put("pages",page.getPages());
        jsonObject.put("total",page.getTotal());
        jsonObject.put("pageSize",page.getPageSize());
        jsonObject.put("code",1);
        return jsonObject;
    }

    /**
     * 检索页面 => 加入清单弹层 的清单详情
     * @param page
     * @return
     */
    @RequestMapping(value = "/detailForShow", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject detailForShow(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();
        try{
            String  id = String.valueOf(page.getConditionMap().get("billId"));
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }

            List<Map<String, Object>> dataList = billInfoListService.findLinkData(page);
			
            jsonObject.put("resInfoList",dataList);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 清单基本信息、明细信息查询
     * @param jsonParam
     * @return
     */
    @SysLog("藏品清单信息编辑")
    @RequestMapping(value = "/detail", method = RequestMethod.POST, produces = "application/json")
    @PreAuthorize("@pms.hasPermission('cp_bill_manage')")
    public JSONObject detail(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String  billId = jsonParam.getString("billId");
            if (DataUtil.isEmpty(billId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            BillInfo billInfo = billInfoService.findBillInfoByBillId(billId);

            Map<String,Object> queryMap = new HashMap<String,Object>();
            queryMap.put("billId",billId);
            Page page = new Page();
            page.setPageSize(0);
            page.setConditionMap(queryMap);
            List<Map<String, Object>> dataList = billInfoListService.findLinkData(page);

            jsonObject.put("billInfo",billInfo);
            jsonObject.put("resInfoList",dataList);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 清单新增
     * @param billInfo
     * @return
     */
    @SysLog("藏品清单新增")
    @RequestMapping(value = "/insert", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('cp_bill_add')")
    public JSONObject insert(@RequestBody @Valid BillInfo billInfo){
        JSONObject jsonObject = new JSONObject();
        try{
            billInfo = billInfoService.insert(billInfo);
            jsonObject.put("billInfo",billInfo);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.ADD_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 清单修改
     * @param billInfo
     * @return
     */
    @SysLog("藏品清单修改")
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject update(@RequestBody @Valid BillInfo billInfo){
        JSONObject jsonObject = new JSONObject();
        try{
            if (DataUtil.isEmpty(billInfo.getBillId())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            billInfoService.modifyByPrimaryKeySelective(billInfo);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.UPDATE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 清单明细新增.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/addBillList", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject addBillList(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            String billId = jsonParam.getString("billId");
            List<String> infoIdList = jsonParam.getJSONArray("infoId").toJavaList(String.class);
            if (DataUtil.isEmpty(billId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (infoIdList == null || infoIdList.size() == 0) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            List<String> billIdList = Arrays.asList(billId.split(","));
            billInfoService.batchSaveBillInfoList(billIdList,infoIdList);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 清单明细删除
      *@Return :
      **/
    @RequestMapping(value = "/removeBillList", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject removeBillInfoList(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();

        try{
            String billId = jsonParam.getString("billId");
            List<String> infoIdList = jsonParam.getJSONArray("infoId").toJavaList(String.class);
            if (DataUtil.isEmpty(billId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }

            if (infoIdList == null || infoIdList.size() == 0) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            List<String> billIdList = Arrays.asList(billId.split(","));
            billInfoService.batchRemoveBillInfoList(billIdList,infoIdList);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 清单删除
     * @param jsonParam
     * @return
     */
    @SysLog("藏品清单删除")
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('cp_bill_delete')")
    public JSONObject delete(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();

        String billId = jsonParam.getString("billId");
        Boolean confirmFlg = jsonParam.getBooleanValue("confirmFlg");
        try{
            if (DataUtil.isEmpty(billId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            List<String> billIdList = Arrays.asList(billId.split(","));
            billInfoService.batchRemoveByBillId(confirmFlg,billIdList);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 清单复制
     * @return
     */
    @SysLog("藏品清单复制")
    @RequestMapping(value = "/copy", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('cp_bill_copy')")
    public JSONObject singleCopy(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();

        try{
            String id = jsonParam.getString("billId");
            // 空校验
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            Set<String> billIdList = new HashSet<>(Arrays.asList(id.split(",")));
            billInfoService.batchCopyBill(billIdList);
            throw new BaseRuntimeException(CollectErrorDefine.COPY_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
         }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 清单共享--共享用户初始化
      *@Return :
      **/
    @RequestMapping(value = "/shareUser", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getShareUser(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();

        String billId = jsonParam.getString("billId");
        try{
            // 空校验
            if (DataUtil.isEmpty(billId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            List<UserInfo> userList = billInfoService.findShareUserByBillId(billId);
            List<String> userIdList = (List<String>)userResultHandle(userList).get("userIdList");
            jsonObject.put("dataList",userIdList);
            jsonObject.put("code", 1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 清单共享
      *@Return :
      **/
    @SysLog("藏品清单共享")
    @RequestMapping(value = "/share", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('cp_bill_share')")
    public JSONObject billShare(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        String billId = jsonParam.getString("billId");
        JSONArray userIdArray = jsonParam.getJSONArray("userIds");
        try{
            // 空校验
            if (DataUtil.isEmpty(billId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (userIdArray == null || userIdArray.size() == 0) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR,"共享对象"));
            }

            List<String> billIdList = Arrays.asList(billId.split(","));
            List<String> userIdList = JSONObject.parseArray(userIdArray.toJSONString(),String.class);
            billInfoService.batchShareBill(billIdList,userIdList);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.SHARE_SUCCESS,"清单"));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 取消共享
      *@Return :
      **/
    @SysLog("藏品清单取消共享")
    @RequestMapping(value = "/cancelShare", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('cp_bill_cancel_share')")
    public JSONObject cancelShare(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("billId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            // 空校验
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_CANCEl_SHARE);
            }
            List<String> billIdList = Arrays.asList(id.split(","));
            billInfoService.batchCancelShareBill(billIdList);
            throw new BaseRuntimeException(CollectErrorDefine.CANCEL_SHARE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 清单编码
      *@Return :
      **/
    @RequestMapping(value = "/code", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getCode(){
        JSONObject jsonObject = new JSONObject();
        try{
            jsonObject.put("data", "QD_" + DateUtil.getNextTime());
            jsonObject.put("code", 1);
        }catch (Exception e){
            e.printStackTrace();
        }
        return jsonObject;
    }

    /**
     * 获取清单明细藏品主键.
     * @return
     */
    @RequestMapping(value = "/getBillCollectId/{billId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getBillCollectId(@PathVariable String billId){
        JSONObject jsonObject = new JSONObject();
        try{

            List<BillInfoList> billInfoLists = billInfoListService.findByBillId(billId);

            List<String> infoIdList = new ArrayList<String>();
            for (BillInfoList billInfoList : billInfoLists) {
                infoIdList.add(billInfoList.getCollectId());
            }

            jsonObject.put("infoIdList",infoIdList);
            jsonObject.put("code", 1);
        }catch (Exception e){
            e.printStackTrace();
        }
        return jsonObject;
    }

    /**
     * 保存基本信息、清单明细信息.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/saveBill", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject saveBill(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            BillInfo billInfo = jsonParam.getJSONObject("billInfo").toJavaObject(BillInfo.class);
            if (DataUtil.isEmpty(billInfo.getBillCode())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR,"清单编码"));
            }
            if (DataUtil.isEmpty(billInfo.getBillName())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR,"清单名称"));
            }
            List<BillInfoList> billInfoListList = jsonParam.getJSONArray("billInfoList").toJavaList(BillInfoList.class);
            billInfoService.saveBillInfoAndBillInfoList(billInfo, billInfoListList);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.UPDATE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    JSONObject userResultHandle(List<UserInfo> userList){
        List<String> userIdList = new ArrayList<String>();
        List<String> userNameList = new ArrayList<String>();
        for (UserInfo user : userList) {
            if (user != null) {
                if (!userIdList.contains(user.getUserId().toString())) {
                    userIdList.add(user.getUserId().toString());
                }
                if (!userNameList.contains(user.getChineseName())) {
                    userNameList.add(user.getChineseName());
                }
            }
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userIdList",userIdList);
        jsonObject.put("userNameList",userNameList);
        return jsonObject;
    }
}
