package com.okay.cp.baseBusiness;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.okay.common.model.MetadataModel;
import com.okay.common.util.MetadataUtil;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.*;
import com.okay.cp.service.*;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.SequenceService;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 藏品各种信息获取
 *
 * @author zhangyx
 * @since 2019/7/13 16:59
 */
public class CollectInfoBaseBusiness extends CollectHandleBaseBusiness {

    @Autowired
    private CollectInfoService collectInfoService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private CpLabelService cpLabelService;
    @Autowired
    private SequenceService sequenceService;
    @Autowired
    private CatalogZjAppraisalService catalogZjAppraisalService;
    @Autowired
    private GradingService gradingService;
    @Autowired
    private CirculateLiveService circulateLiveService;
    @Autowired
    private BreakDownService breakDownService;
    @Autowired
    private BookmakingService bookmakingService;
    @Autowired
    private UserService userService;
    @Autowired
    private ExamineRecordService examineRecordService;
    @Autowired
    private AgainEditRecordService againEditRecordService;
    @Autowired
    private CollectBorService collectBorService;
    @Autowired
    private CollectBorListService collectBorListService;
    @Autowired
    private CollectInfoHistoryService collectInfoHistoryService;
    @Autowired
    private CollectRelocationServer collectRelocationServer;
    @Autowired
    private PublishRecordService publishRecordService;
    @Autowired
    private CollectSingleListService collectSingleListService;

    /**
     * 获取藏品基本信息
     *
     * @param json
     * @return
     */
    public JSONObject getCollectBaseInfo(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        MetadataModel metadataModel = MetadataUtil.getMetadataModel();
        try {
            //获取藏品基本信息
            String collectId = json.getString("collectId");
            CollectInfo collectInfo = null;
            if (null == collectId || "".equals(collectId.trim())) {
                collectInfo = new CollectInfo();
                collectId = sequenceService.getSequence();
                collectInfo.setCollectId(collectId);
                collectInfo.setQuantity("1");
                collectInfo.setRealNum("1");
                collectInfo.setLength("0.00");
                collectInfo.setWidth("0.00");
                collectInfo.setHeight("0.00");
                collectInfo.setBore("0.00");
                collectInfo.setBottomDiameter("0.00");
                collectInfo.setAbdominal("0.00");
                collectInfo.setBottomDiameter("0.00");
                collectInfo.setCollectClass("1");

                collectInfo.setNumUnit("10");//默认单位 "件"
                collectInfo.setMassUnit("3");
            } else {
                collectInfo = collectInfoService.selectByPrimaryKey(collectId);
            }

            // 获取当前收藏数
            Integer collectSum = collectSingleListService.getCollectingCount(collectInfo.getCollectId());
            collectInfo.setCollectCount(collectSum);

            String jsonString = JSONObject.toJSONString(collectInfo, SerializerFeature.WriteNullStringAsEmpty);
            jsonObject = JSONObject.parseObject(jsonString);

            //审核人
            if (!DataUtil.isEmpty(collectInfo.getExamineUserId())) {
//                User user = userService.findUserById(collectInfo.getExamineUserId());
                String username = metadataModel.getUserName(Integer.parseInt(collectInfo.getExamineUserId()));
                if (username != null) {
                    jsonObject.put("examineUserName", username);
                }
            }

            String outState = collectInfo.getOutState();
            if (DataUtil.isEmpty(outState)) {
                jsonObject.put("outState", "1");//默认在库
            }

            //审批状态
            if (jsonObject.getString("status").equals("1")) {
                jsonObject.put("examineState", "0");
                jsonObject.put("pubState", "0");
            } else if (jsonObject.getString("status").equals("3") || jsonObject.getString("status").equals("4")) {
                jsonObject.put("examineState", "1");
            }

            //发布状态
            if (jsonObject.getString("status").equals("3")) {
                jsonObject.put("pubState", "0");
            } else if (jsonObject.getString("status").equals("3") || jsonObject.getString("status").equals("4")) {
                jsonObject.put("pubState", "1");
            }

            //重编目经办人
            String againEditOperator_t = "";
            if (jsonObject.getString("status").equals("6")) {
                if (!DataUtil.isEmpty(collectInfo.getAgainEditOperator())) {
//                    User user = userService.findUserById(collectInfo.getAgainEditOperator());
                    String username = metadataModel.getUserName(Integer.parseInt(collectInfo.getAgainEditOperator()));
                    if (username != null) {
                        againEditOperator_t = username;
                    }
                }
            }
            jsonObject.put("againEditOperator_t", againEditOperator_t);

            //注销附件信息
            JSONArray zxFileList = new JSONArray();
            if (jsonObject.getString("status").equals("7")) {
                if (!DataUtil.isEmpty(collectInfo.getCancelHandelUser())) {
//                    User user = userService.findUserById(collectInfo.getCancelHandelUser());
                    String username = metadataModel.getUserName(Integer.parseInt(collectInfo.getCancelHandelUser()));
                    if (username != null) {
                        jsonObject.put("cancelHandelUser_t", username);
                    }
                }
                //获取注销附件
                JSONObject resObj = collectCommonBusinessService.getMainBodyRes("96", collectId);
                zxFileList = resObj.getJSONArray("resList");
            }
            jsonObject.put("zxFileList", zxFileList);


            //藏品信息关联附件列表
            JSONObject resObj = collectCommonBusinessService.getMainBodyRes("90", collectId);
            JSONArray jsonArray = resObj.getJSONArray("resList");

            //返回的资源分组
            JSONArray imgList = new JSONArray();
            JSONArray audioList = new JSONArray();
            JSONArray videoList = new JSONArray();
            JSONArray modelList = new JSONArray();
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject fileObj = (JSONObject) jsonArray.get(i);
                if (fileObj.getString("resType").equals("1")) {
                    imgList.add(fileObj);
                } else if (fileObj.getString("resType").equals("2")) {
                    audioList.add(fileObj);
                } else if (fileObj.getString("resType").equals("3")) {
                    videoList.add(fileObj);
                } else if (fileObj.getString("resType").equals("4")) {
                    modelList.add(fileObj);
                }
            }
            jsonObject.put("imgList", imgList);
            jsonObject.put("audioList", audioList);
            jsonObject.put("videoList", videoList);
            jsonObject.put("modelList", modelList);

            //藏品的封面图片
            jsonObject.put("coverUrl", resObj.getString("coverUrl"));

            //藏品标签
            JSONObject jsonObject1 = getCollectTags(collectId);
            jsonObject.put("labelList", jsonObject1.getJSONArray("labelList"));

            //获取藏品的实际在库数量
            int inStoreNum = getCollectInStoreNum(collectId);
            jsonObject.put("inStoreNum", inStoreNum);

        } catch (Exception e) {
            e.printStackTrace();
            throw new BaseRuntimeException(e.getMessage());
        }
        return jsonObject;
    }

    /**
     * 获取单个藏品标签
     *
     * @param collectId
     * @return
     */
    public JSONObject getCollectTags(String collectId) {
        JSONObject jsonObject = new JSONObject();
        try {
            CpLabel cpLabel = new CpLabel();
            cpLabel.setCollectId(collectId);
            List<CpLabel> cpLabels = cpLabelService.selectByCpLabel(cpLabel);

            jsonObject.put("labelList", cpLabels);
        } catch (Exception e) {
            throw new BaseRuntimeException(CollectErrorDefine.GET_LABEL);
        }
        return jsonObject;
    }

    /**
     * 批量查询标签
     *
     * @return
     */
    public JSONObject batchSelectLabel(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectIds = json.getString("collectIds");
            if (!DataUtil.isEmpty(collectIds)) {
                String[] collectIdList = collectIds.split(",");

                JSONArray jsonArray = new JSONArray();
                for (int i = 0; i < collectIdList.length; i++) {
                    String collectId = collectIdList[i];

                    JSONObject jsonObj = new JSONObject();
                    JSONObject jsonObject1 = getCollectTags(collectId);
                    jsonObj.put("labelList", jsonObject1.getJSONArray("labelList"));

                    CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(collectId);
                    String imgBase64 = collectCommonBusinessService.getCoverImg("90", collectInfo.getCollectId());
                    jsonObj.put("image_min", imgBase64);
                    jsonObj.put("collectType_t", collectCommonCodeService.collectType_t(collectInfo.getCollectType()));
                    jsonObj.put("collectName", collectInfo.getCollectName());
                    jsonObj.put("collectId", collectId);
                    jsonArray.add(jsonObj);
                }

                jsonObject.put("data", jsonArray);
                jsonObject.put("code", "1");
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }


    /**
     * 获取藏品征集信息
     *
     * @param collectId
     * @return
     */
    public JSONArray getCatalogZjAppraisalList(String collectId) {
        JSONArray jsonArray = new JSONArray();
        try {
            List<CatalogZjAppraisal> CatalogZjAppraisalList = catalogZjAppraisalService.selectByCollectId(collectId);
            if (CatalogZjAppraisalList.size() == 0) {
                CatalogZjAppraisal catalogZjAppraisal = new CatalogZjAppraisal();
                catalogZjAppraisal.setIdeaId(sequenceService.getSequence());
                catalogZjAppraisal.setCollectId(collectId);
                CatalogZjAppraisalList.add(catalogZjAppraisal);
            }

            jsonArray = new JSONArray();
            for (int i = 0; i < CatalogZjAppraisalList.size(); i++) {
                CatalogZjAppraisal catalogZjAppraisal = CatalogZjAppraisalList.get(i);
                String jsonString = JSONObject.toJSONString(catalogZjAppraisal, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject catalogZjAppraisalJson = JSONObject.parseObject(jsonString);
                //获取相关附件
                JSONObject resInfo = collectCommonBusinessService.getMainBodyRes("91", catalogZjAppraisal.getIdeaId());
                JSONArray resInfoList = resInfo.getJSONArray("resList");
                catalogZjAppraisalJson.put("resList", resInfoList);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "91");
                mainBody.put("mainBodyId", catalogZjAppraisal.getIdeaId());
                catalogZjAppraisalJson.put("mainBody", mainBody);
                jsonArray.add(catalogZjAppraisalJson);
            }
        } catch (Exception e) {
            new RuntimeException();
        }
        return jsonArray;
    }

    /**
     * 获取定级鉴定信息
     *
     * @param collectId
     * @return
     */
    public JSONArray getGradingList(String collectId) {
        JSONArray jsonArray = null;
        try {
            List<Grading> gradingList = gradingService.selectByCollectId(collectId);
            if (gradingList.size() == 0) {
                Grading grading = new Grading();
                grading.setGradingId(sequenceService.getSequence());
                grading.setCollectId(collectId);
                gradingList.add(grading);
            }

            jsonArray = new JSONArray();
            for (int i = 0; i < gradingList.size(); i++) {
                Grading grading = gradingList.get(i);
                String jsonString = JSONObject.toJSONString(grading, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject gradingJson = JSONObject.parseObject(jsonString);
                //获取相关附件
                JSONObject resInfo = collectCommonBusinessService.getMainBodyRes("92", grading.getGradingId());
                JSONArray resInfoList = resInfo.getJSONArray("resList");
                gradingJson.put("resList", resInfoList);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "92");
                mainBody.put("mainBodyId", grading.getGradingId());
                gradingJson.put("mainBody", mainBody);

                jsonArray.add(gradingJson);
            }
        } catch (Exception e) {
            new RuntimeException();
        }
        return jsonArray;
    }

    /**
     * 获取流传经历信息
     *
     * @param collectId
     * @return
     */
    public JSONArray getCirculateLive(String collectId) {
        JSONArray jsonArray = null;
        try {
            List<CirculateLive> circulateLiveList = circulateLiveService.selectByCollectId(collectId);
            if (circulateLiveList.size() == 0) {
                CirculateLive circulateLive = new CirculateLive();
                circulateLive.setLiveId(sequenceService.getSequence());
                circulateLive.setCollectId(collectId);
                circulateLiveList.add(circulateLive);
            }

            jsonArray = new JSONArray();
            for (int i = 0; i < circulateLiveList.size(); i++) {
                CirculateLive circulateLive = circulateLiveList.get(i);
                String jsonString = JSONObject.toJSONString(circulateLive, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject circulateLiveJson = JSONObject.parseObject(jsonString);
                //获取相关附件
                JSONObject resInfo = collectCommonBusinessService.getMainBodyRes("93", circulateLive.getLiveId());
                JSONArray resInfoList = resInfo.getJSONArray("resList");
                circulateLiveJson.put("resList", resInfoList);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "93");
                mainBody.put("mainBodyId", circulateLive.getLiveId());
                circulateLiveJson.put("mainBody", mainBody);

                jsonArray.add(circulateLiveJson);
            }
        } catch (Exception e) {
            new RuntimeException();
        }
        return jsonArray;
    }


    /**
     * 获取损坏记录信息
     *
     * @param collectId
     * @return
     */
    public JSONArray getBreakDownList(String collectId) {
        JSONArray jsonArray = null;
        try {
            List<BreakDown> breakDownList = breakDownService.selectByCollectId(collectId);
            if (breakDownList.size() == 0) {
                BreakDown breakDown = new BreakDown();
                breakDown.setBreakId(sequenceService.getSequence());
                breakDown.setCollectId(collectId);
                breakDownList.add(breakDown);
            }

            jsonArray = new JSONArray();
            for (int i = 0; i < breakDownList.size(); i++) {
                BreakDown breakDown = breakDownList.get(i);
                String jsonString = JSONObject.toJSONString(breakDown, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject breakDownJson = JSONObject.parseObject(jsonString);
                //获取相关附件
                JSONObject resInfo = collectCommonBusinessService.getMainBodyRes("94", breakDown.getBreakId());
                JSONArray resInfoList = resInfo.getJSONArray("resList");
                breakDownJson.put("resList", resInfoList);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "94");
                mainBody.put("mainBodyId", breakDown.getBreakId());
                breakDownJson.put("mainBody", mainBody);

                jsonArray.add(breakDownJson);
            }
        } catch (Exception e) {
            new RuntimeException();
        }
        return jsonArray;
    }

    /**
     * 获取著录信息
     *
     * @param collectId
     * @return
     */
    public JSONArray getBookRecodeInfo(String collectId) {
        JSONArray jsonArray = null;
        try {
            List<Bookmaking> bookmakingList = bookmakingService.selectByCollectId(collectId);
            if (bookmakingList.size() == 0) {
                Bookmaking bookmaking = new Bookmaking();
                bookmaking.setBookId(sequenceService.getSequence());
                bookmaking.setCollectId(collectId);
                bookmakingList.add(bookmaking);
            }

            jsonArray = new JSONArray();
            for (int i = 0; i < bookmakingList.size(); i++) {
                Bookmaking bookmaking = bookmakingList.get(i);
                String jsonString = JSONObject.toJSONString(bookmaking, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject bookmakingJson = JSONObject.parseObject(jsonString);
                //获取相关附件
                JSONObject resInfo = collectCommonBusinessService.getMainBodyRes("95", bookmaking.getBookId());
                JSONArray resInfoList = resInfo.getJSONArray("resList");
                bookmakingJson.put("resList", resInfoList);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "95");
                mainBody.put("mainBodyId", bookmaking.getBookId());
                bookmakingJson.put("mainBody", mainBody);

                jsonArray.add(bookmakingJson);
            }
        } catch (Exception e) {
            new RuntimeException();
        }
        return jsonArray;
    }

    /**
     * 获取同组藏品
     */
    public JSONArray getGroupCollect(String collectId, Boolean isSearch) {

        JSONArray groupJsonList = new JSONArray();
        try {
            List<Group> groupList = collectCommonBusinessService.selectGroupCollect(collectId);
            //同组藏品对象 不包含本身
            for (int i = 0; i < groupList.size(); i++) {
                Group group = groupList.get(i);
                String cur_collectId = group.getCollectId();
                if (!cur_collectId.equals(collectId)) {
                    Group groupObj = groupList.get(i);

                    //关联藏品只需要获取封面图和藏品名称即可
                    CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(groupObj.getCollectId());
                    String imgBase64 = collectCommonBusinessService.getCoverImg("90", collectInfo.getCollectId());

                    JSONObject groupJsonObj = new JSONObject();
                    groupJsonObj.put("collectName", collectInfo.getCollectName());
                    groupJsonObj.put("coverUrl", imgBase64);
                    groupJsonObj.put("collectId", collectInfo.getCollectId());

                    // 检索页面只取已发布的藏品
                    if (isSearch) {
                        if ("4".equals(collectInfo.getStatus())) {
                            groupJsonList.add(groupJsonObj);
                        }
                    } else {
                        groupJsonList.add(groupJsonObj);
                    }
                }
            }
        } catch (Exception e) {
        }

        return groupJsonList;
    }

    /**
     * 获取藏品审核记录
     */
    public List<ExamineRecord> getExamineRecords(String collectId) {
        List<ExamineRecord> examineRecords = examineRecordService.searchByCollectId(collectId);
        for (int i = 0; i < examineRecords.size(); i++) {
            ExamineRecord examineRecord = examineRecords.get(i);
            String examineUser = examineRecord.getExamineUser();
            String useName = collectCommonBusinessService.getUserNames(examineUser);
            examineRecord.setExamineUser_t(useName);
            if (examineRecord.getExamineResults().equals("0")) {
                examineRecord.setExamineResults_t("驳回");
            } else if (examineRecord.getExamineResults().equals("1")) {
                examineRecord.setExamineResults_t("通过");
            }
        }
        return examineRecords;
    }

    /**
     * 获取藏品重编目历史记录
     */
    public List<AgainEditRecord> getAgainEditRecords(String collectId) {
        List<AgainEditRecord> againEditRecordList = againEditRecordService.searchByCollectId(collectId);
        for (int i = 0; i < againEditRecordList.size(); i++) {
            AgainEditRecord againEditRecord = againEditRecordList.get(i);
            String initiator = againEditRecord.getInitiator();
            String useName = collectCommonBusinessService.getUserNames(initiator);
            againEditRecord.setInitiator_t(useName);
        }
        return againEditRecordList;
    }

    /**
     * 获取藏品的保管事件
     *
     * @param collectId
     * @return
     */
    public JSONArray getKeepingEvents(String collectId) {
        JSONArray jsonArray = new JSONArray();

        List<CollectBorList> collectBorListList = collectBorListService.searchByCollectId(collectId);
        for (int i = 0; i < collectBorListList.size(); i++) {
            CollectBorList collectBorList = collectBorListList.get(i);
            CollectBor collectBor = collectBorService.selectByPrimaryKey(collectBorList.getColBorId());

            String collectBor_String = JSONObject.toJSONString(collectBor);
            JSONObject jsonObject = JSONObject.parseObject(collectBor_String);

            //申请借日期范围
            String borDate = DateUtil.convertDateToString(collectBor.getBorDate());
            String backDate = DateUtil.convertDateToString(collectBor.getBackDate());
            String borDtScope = borDate + "—" + backDate;
            jsonObject.put("borDtScope", borDtScope.replaceAll("-", "/"));//提借日期范围

            //申请提借日期
            jsonObject.put("createTime", DateUtil.convertDateToString(collectBor.getCreateTime()).replaceAll("-", "/"));
            //提借类型
            jsonObject.put("borType_t", collectCommonCodeService.borType_t(collectBorList.getCollectType()));

            jsonObject.put("borCount", collectBorList.getBorCount());//审核提借数量
            jsonObject.put("outCount", collectBorList.getOutCount());//出库数量
            jsonObject.put("backCount", collectBorList.getBackCount());//归库数量
            jsonObject.put("outStoreUser", collectBorList.getBorUser());//出库操作人
            jsonObject.put("outStoreDt", collectBorList.getBorDate());//出库时间
            jsonObject.put("remarks", collectBorList.getRemarks());//备注

            //出库操作人
            String outHandelUser = "--";
            if (!DataUtil.isEmpty(collectBorList.getBorUser())) {
                outHandelUser = collectCommonBusinessService.getUserNames(collectBorList.getBorUser());
            }
            jsonObject.put("outHandelUser", outHandelUser);
            //出库操作时间
            String outHandelDt = "--";
            if (null != collectBorList.getBorDate()) {
                outHandelDt = DateUtil.convertDateToString(collectBorList.getBorDate()).replaceAll("-", "/");
            }
            jsonObject.put("outHandelDt", outHandelDt);

            //归库操作人
            String backHandelUser = "--";
            if (!DataUtil.isEmpty(collectBorList.getAcceptUser())) {
                backHandelUser = collectCommonBusinessService.getUserNames(collectBorList.getAcceptUser());
            }
            jsonObject.put("backHandelUser", backHandelUser);
            //归库操作时间
            String backHandelDt = "--";
            if (null != collectBorList.getBackDate()) {
                backHandelDt = DateUtil.convertDateToString(collectBorList.getBackDate()).replaceAll("-", "/");
            }
            jsonObject.put("backHandelDt", backHandelDt);


            jsonArray.add(jsonObject);
        }
        return jsonArray;
    }

    /**
     * 获取藏品的实际在库数量
     */
    public int getCollectInStoreNum(String collectId) {
//        int collectInStoreNum = 0;
//        //获取库存的实际数量
//        CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(collectId);
//        if (collectInfo != null) {
//            int realNum = Integer.valueOf(collectInfo.getRealNum());
//            //已经预定的数量
//            List<CollectBorList> collectBorListList = collectBorListService.searchCollectOutInRecord(collectId);
//            //未出库的数量
//            int outCount_sum = 0;
//            //已归还总数量
//            int backCount_sum = 0;
//            for (int i = 0; i < collectBorListList.size(); i++) {
//                CollectBorList collectBorList = collectBorListList.get(i);
//                int outCount = collectBorList.getOutCount();//已出库的数量
//                int backCount = collectBorList.getBackCount();//已归还的数量
//                outCount_sum += outCount;
//                backCount_sum += backCount;
//            }
//            //在库的实际数量
//            collectInStoreNum = realNum - outCount_sum + backCount_sum;
//        }
//        return collectInfoService.getInStoreAmount(collectId);

        if (StringUtils.isEmpty(collectId)) {
            return 0;
        }
        return collectInfoService.getInStoreAmount(collectId);
    }

    /**
     * 获取藏品的可申请提借数量
     */
    public int getCanBorCollectNum(String collectId) {
//        int collectInStoreNum = 0;
//
//        //获取库存的实际数量
//        CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(collectId);
//        int realNum = Integer.valueOf(collectInfo.getRealNum());
//
//        //已经预定的数量
//        List<CollectBorList> collectBorListList = collectBorListService.searchCollectOutInRecord(collectId);
//
//        //提借总数量
//        int borCount_sum = 0;
//        //已归还总数量
//        int backCount_sum = 0;
//        for (int i = 0; i < collectBorListList.size(); i++) {
//
//            CollectBorList collectBorList = collectBorListList.get(i);
//            int borCount = collectBorList.getBorCount(); //提借数量
//            int outCount = collectBorList.getOutCount();//已出库的数量
//            int backCount = collectBorList.getBackCount();//已归还的数量
//
//            CollectBor collectBor = collectBorService.selectByPrimaryKey(collectBorList.getColBorId());
//
//            if (collectBor.getState() == 0) {
//                //未办结的单
//                borCount_sum += borCount;
//            } else if (collectBor.getState() == 1) {
//                //已办结的单
//                borCount_sum += outCount;
//            }
//            backCount_sum += backCount;
//        }
//        //预占在库的实际数量
//        collectInStoreNum = realNum - borCount_sum + backCount_sum;
        if (StringUtils.isEmpty(collectId)) {
            return 0;
        }
        return collectInfoService.getCanBorrowAmount(collectId);
    }

    /**
     * @Author : xdn
     * @Description : 获取藏品重拨库记录
     * @Return :
     **/
    public List<Map<String, Object>> getRelocationRecord(String collectId) {
        Map<String, Object> query = new HashMap<String, Object>();
        query.put("collectId", collectId);
        List<CollectRelocation> collectRelocationList = collectRelocationServer.findDataListByQuery(query);

        List<Map<String, Object>> dataMapList = new ArrayList<Map<String, Object>>();
        for (CollectRelocation collectRelocation : collectRelocationList) {
            String createUser_t = collectCommonBusinessService.getUserNames(collectRelocation.getCreateUser());
            String relocationAfter_t = collectCommonCodeService.storehouse_t(collectRelocation.getRelocationAfter());
            String relocationBefore_t = collectCommonCodeService.storehouse_t(collectRelocation.getRelocationBefore());

            String jsonString = JSONObject.toJSONStringWithDateFormat(collectRelocation, "yyyy-MM-dd HH:mm:ss");
            Map<String, Object> dataMap = JSONObject.parseObject(jsonString);

            dataMap.put("createUser_t", createUser_t);
            dataMap.put("relocationAfter_t", relocationAfter_t);
            dataMap.put("relocationBefore_t", relocationBefore_t);

            dataMapList.add(dataMap);
        }
        return dataMapList;
    }

    /**
     * @Author : xdn
     * @Description : 获取藏品发布记录
     * @Return :
     **/
    public List<Map<String, Object>> getPublislhRecord(String collectId) {
        Map<String, Object> query = new HashMap<String, Object>();
        query.put("pubCollectId", collectId);
        List<PublishRecord> publishRecordList = publishRecordService.findDataListByQuery(query);

        List<Map<String, Object>> dataMapList = new ArrayList<Map<String, Object>>();
        for (PublishRecord PublishRecord : publishRecordList) {

            String jsonString = JSONObject.toJSONStringWithDateFormat(PublishRecord, "yyyy-MM-dd HH:mm:ss");
            Map<String, Object> dataMap = JSONObject.parseObject(jsonString);

            String publishUser_t = collectCommonBusinessService.getUserNames(PublishRecord.getPublishUser());
            dataMap.put("publishUser_t", publishUser_t);

            String pubState_t = "";
            if ("0".equals(PublishRecord.getPubState())) {
                pubState_t = "未发布";
            } else if ("1".equals(PublishRecord.getPubState())) {
                pubState_t = "已发布";
            } else if ("2".equals(PublishRecord.getPubState())) {
                pubState_t = "撤销";
            }
            dataMap.put("pubState_t", pubState_t);

            dataMapList.add(dataMap);
        }
        return dataMapList;
    }

    /**
     * 根据藏品ID获取出库数量
     *
     * @param
     * @return
     * @author CZJ[OKAY]
     **/
    public Map<String, Integer> getOutStoreNum(List<String> collectIds) {
        return collectBorListService.getOutStoreNum(collectIds);
    }
}
