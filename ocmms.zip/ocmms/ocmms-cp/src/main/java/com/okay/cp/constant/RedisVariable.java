package com.okay.cp.constant;

/**
 * 缓存变量
 * @author zhangyx
 * @since 2019/12/2 10:32
 */
public class RedisVariable {
    /**
     * 年代树结构KEY
     */
    public static final String AGE_TREE_STRUCTURE = "age_tree_structure";

    /**
     * 库房树结构KEY
     */
    public static final String STORE_TREE_STRUCTURE = "store_tree_structure";

    /**
     * 质地树结构KEY
     */
    public static final String TEXTURE_TREE_STRUCTURE = "texture_tree_structure";

    /**
     * 质地类别
     */
    public static final String TEXTURE_TYPE = "texture_type";

    /**
     * 藏品类别
     */
    public static final String COLLECT_TYPE = "collect_type";
}
