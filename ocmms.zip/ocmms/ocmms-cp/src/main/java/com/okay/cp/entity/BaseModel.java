package com.okay.cp.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.write.style.*;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.HorizontalAlignment;

import java.util.Date;

/**
 * @Author CZJ[OKAY]
 * @Description 通用实体类
 **/
@Data
@ApiModel(value = " 通用实体类")
@HeadRowHeight(25)
@ContentRowHeight(25)
@ColumnWidth(value = 25)
@HeadStyle(horizontalAlignment = HorizontalAlignment.CENTER)
@HeadFontStyle(fontHeightInPoints = 15)
@ContentStyle(horizontalAlignment = HorizontalAlignment.CENTER, wrapped = true)
public class BaseModel {

    @JsonIgnore
    @ExcelIgnore
    @ApiModelProperty(value = "创建人")
    @TableField(fill = FieldFill.INSERT)
    private Integer creator;

    @JsonIgnore
    @ExcelIgnore
    @ApiModelProperty(value = "创建时间")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @JsonIgnore
    @ExcelIgnore
    @ApiModelProperty(value = "修改人")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Integer editor;

    @JsonIgnore
    @ExcelIgnore
    @ApiModelProperty(value = "修改时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date editTime;

    @JsonIgnore
    @TableLogic
    @ExcelIgnore
    @ApiModelProperty(value = "逻辑删除：0、未删除  1、已删除")
    @TableField(fill = FieldFill.INSERT)
    private Integer deleted;
}
