package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.baseBusiness.SolictBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.SolicInfo;
import com.okay.cp.entity.SolicitSingle;
import com.okay.cp.entity.UserDefined;
import com.okay.cp.service.*;
import com.okay.cp.utils.CollectUtils;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.SequenceService;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/4 11:55
 * @Version: 1.0
 * @Description: 征集录入控制类.
 */

@RestController
@RequestMapping(value = "/enter")
public class SolicitEnterController extends SolictBaseBusiness {

    @Autowired
    private SolicInfoService solicInfoService;
    @Autowired
    private SequenceService sequenceService;
    @Autowired
    private UserService userService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private SolicClueService solicClueService;
    @Autowired
    private SolicitSingleService solicitSingleService;


    /**
     * 查询列表初始化.
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initForm(){
        JSONObject jsonObject = new JSONObject();
        List<Map> clueOptions = solicClueService.findClueList();// 关联线索
        JSONArray sourceOptions = collectCommonCodeService.sourceOptions();// 征集方式
        jsonObject.put("clueOptions",clueOptions);
        jsonObject.put("sourceOptions",sourceOptions);
        jsonObject.put("code",1);
        return jsonObject;
    }

    /**
     * 信息页面初始化.
     * @return
     */
    @RequestMapping(value = "/initPage", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initPage(){
        JSONObject jsonObject = new JSONObject();
        // 征集编码
        String code = "ZJ_" + DateUtil.getNextTime();
        // 征集单
        List<SolicitSingle> dataList = solicitSingleService.findDataList(new HashMap<String, Object>());
        // 获取一个封面
        JSONObject resObj = collectCommonBusinessService.getMainBodyRes("19","aaa");

        JSONObject json = getOptions();
        json.put("code",code);
        json.put("offer","0.00");
        json.put("length","0");
        json.put("width","0");
        json.put("height","0");
        json.put("massUnit","3");
        json.put("numberUnit","10");
        json.put("solicitSingleList",dataList);
        json.put("coverUrl",resObj.getString("coverUrl"));
        jsonObject.put("code",1);
        jsonObject.put("data",json);
        return jsonObject;
    }

    /**
     * 列表数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        Map<String,Object> conditionMap = new HashMap<String,Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询状态
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state","0");
                }
            }
            return getDataList(page);
        }
        return null;
    }

    /**
     * 信息新增.
     * @param jsonParam
     * @return
     */
    @SysLog("征集录入新增")
    @RequestMapping(value="/insert", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
//    @PreAuthorize("@pms.hasPermission('SE_ADD')")
    public JSONObject addClues(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        SolicInfo solicInfo = jsonParam.getJSONObject("data").toJavaObject(SolicInfo.class);
        try{
            if (DataUtil.isEmpty(solicInfo.getSolicCode())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"文物编码"));
            }
            if (DataUtil.isEmpty(solicInfo.getCluesId())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"所属征集单"));
            }
            if (DataUtil.isEmpty(solicInfo.getCulreliName())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"文物名称"));
            }
            solicInfo.setCreatTime(new Date());
            solicInfo.setSolicState(0);
            solicInfo.setSolicId(sequenceService.getSequence().toString());
            solicInfo.setCreatUser(userService.getLoginUser().getUserId());
            solicInfo.setCulreliYear(CollectUtils.arrayChangeIds(solicInfo.getCulreliYear()));//年代 转换成 id串

            SolicInfo newSolicInfo = solicInfoService.add(solicInfo);
            jsonObject.put("solicInfo",newSolicInfo);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.ADD_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息修改.
     * @param jsonParam
     * @return
     */
    @SysLog("征集信息修改")
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject update(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            SolicInfo solicInfo = jsonParam.getJSONObject("solicInfo").toJavaObject(SolicInfo.class);
            String solicId = solicInfo.getSolicId();
            if (DataUtil.isEmpty(solicId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (DataUtil.isEmpty(solicInfo.getSolicCode())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"文物编码"));
            }
            if (DataUtil.isEmpty(solicInfo.getCluesId())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"所属征集单"));
            }
            if (DataUtil.isEmpty(solicInfo.getCulreliName())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"文物名称"));
            }
            solicInfo.setCulreliYear(CollectUtils.arrayChangeIds(solicInfo.getCulreliYear()));//年代 转换成 id串
            solicInfoService.modify(solicInfo);

            // 自定义属性更新
            JSONArray userDefinedFieldList = jsonParam.getJSONArray("userDefinedFieldList");
            if (userDefinedFieldList.size() > 0) {
                List<UserDefined> userDefinedList = new ArrayList<>();
                for (int i = 0; i < userDefinedFieldList.size(); i++) {
                    JSONObject jsonObject1 = (JSONObject) userDefinedFieldList.get(i);
                    UserDefined userDefined1 = new UserDefined();
                    userDefined1.setInfoId(solicId);
                    userDefined1.setFieldId(jsonObject1.getString("fieldId"));
                    userDefined1.setFieldValue(jsonObject1.getString("fieldValue"));
                    userDefinedList.add(userDefined1);
                }
                collectCommonBusinessService.updateUserDefinedField(userDefinedList);
            }
            throw new BaseRuntimeException(String.format(CollectErrorDefine.UPDATE_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息删除.
     * @param jsonParam
     * @return
     */
    @SysLog("征集录入删除")
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('SE_DEL')")
    public JSONObject delete(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();

        String id = jsonParam.getString("solicId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            List<String> idList = new ArrayList<>(Arrays.asList(id.split(",")));
            int handleNum = solicInfoService.remove(idList);
            if (handleNum == idList.size()) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_SUCCESS));
            }else {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_ERR));
            }

        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取数据.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam){

        String id = jsonParam.getString("solicId");
        return getInfoByMainKey(id);
    }

    /**
     * 信息提交 =》 鉴定.
     * @param jsonParam
     * @return
     */
    @SysLog("征集录入提交征集")
    @RequestMapping(value = "/commitToIdentify", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('SE_SUBMISSION')")
    public JSONObject commitToIdentify(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solicId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_COMMIT);
            }
            List<String> idList = new ArrayList<String>(Arrays.asList(id.split(",")));
            solicInfoService.commitToIdentify(idList);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.COMMIT_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 自定义属性添加
     * @param userDefined
     * @return
     */
    @RequestMapping(value = "/addField", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject addField(@RequestBody @Valid UserDefined userDefined){
        JSONObject jsonObject = new JSONObject();
        try {
            UserDefined newUserDefined  = collectCommonBusinessService.addUserDefinedField(userDefined);
            jsonObject.put("userDefined",newUserDefined);
            throw new BaseRuntimeException(CollectErrorDefine.ADD_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 自定义属性删除
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/delField", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject delField(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String fieldId = jsonParam.getString("fieldId");
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (DataUtil.isEmpty(fieldId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR, "自定义属性"));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL, ""));
            }
            int handleNum = collectCommonBusinessService.delUserDefinedField(fieldId);
            if (handleNum == 1) {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
            }else {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_ERR);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        return initExportHeader(null);
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("征集录入导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
    @PreAuthorize("@pms.hasPermission('SE_EXP')")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        exportHandle(jsonParam,request,response);
    }
}
