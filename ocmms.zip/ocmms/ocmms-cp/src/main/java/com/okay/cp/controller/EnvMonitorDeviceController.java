package com.okay.cp.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.cp.entity.EnvMonitorDevice;
import com.okay.cp.entity.dto.MonitorDataQueryDTO;
import com.okay.cp.service.EnvMonitorDeviceService;
import com.okay.okay.common.core.util.R;
import com.okay.okay.common.security.annotation.Inner;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @Author OKAY
 * @Date 2022/3/11 16:12
 * @Description
 */
@Api(tags = "环境监测")
@RestController
@RequestMapping("/monitor")
@AllArgsConstructor
@Inner
public class EnvMonitorDeviceController {

    private final EnvMonitorDeviceService envMonitorDeviceService;

    @ApiOperation("环境监测设备最新记录")
    @GetMapping("/pageLatestData")
    public R pageDeviceDataLatest(Page page, Integer siteType, Integer siteSecondary, String deviceName) {
        return envMonitorDeviceService.pageLatestData(page, siteType, siteSecondary, deviceName).setMsg("");
    }

    @ApiOperation("环境监测设备监测数据分页查询")
    @GetMapping("/pageDataById")
    public R pageDeviceDataByDeviceId(Page page, MonitorDataQueryDTO dto) {
        return envMonitorDeviceService.pageDeviceDataByDeviceId(page, dto);
    }

    @ApiOperation("环境监测设备分页查询")
    @GetMapping("/page")
    public R pageDevice(Page page, EnvMonitorDevice device) {
        return envMonitorDeviceService.pageDevice(page, device).setMsg("");
    }

    @ApiOperation("环境监测设备保存")
    @PostMapping("/save")
    public R saveDevice(@RequestBody @Valid EnvMonitorDevice device) {
        return envMonitorDeviceService.saveDevice(device);
    }

    @ApiOperation("环境监测设备更新")
    @PostMapping("/update")
    public R updateDevice(@RequestBody @Valid EnvMonitorDevice device) {
        return envMonitorDeviceService.updateDevice(device);
    }

    @ApiOperation("环境监测设备删除")
    @PostMapping("/delete")
    public R delete(@RequestBody List<Integer> ids) {
        return ids.isEmpty() ? R.failed("请输入设备id") : (envMonitorDeviceService.removeByIds(ids) ? R.ok().setMsg("操作成功") : R.failed("操作失败"));
    }

    @ApiOperation("根据设备id获取环境监测设备")
    @GetMapping("/{id}")
    public R getById(@PathVariable String id) {
        return R.ok(envMonitorDeviceService.getById(id)).setMsg("");
    }


}
