package com.okay.cp.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author okay
 */
@Data
@TableName(value = "cp_collectinfo")
public class CollectInfo {

    @TableId(value = "collectId", type = IdType.INPUT)
    private String collectId;

    @TableField(value = "collectName")
    private String collectName;

    @TableField(value = "totalNum")
    private String totalNum;

    @TableField(value = "classNum")
    private String classNum;

    @TableField(value = "incomeNum")
    private String incomeNum;

    @TableField(value = "collectNum")
    private String collectNum;

    @TableField(value = "collectNameOld")
    private String collectNameOld;

    @TableField(value = "source")
    private String source;

    @TableField(value = "collectType")
    private String collectType;

    @TableField(value = "cpLevel")
    private String cpLevel;

    @TableField(value = "years")
    private String years;

    @TableField(value = "specificAge")
    private String specificAge;

    @TableField(value = "realNum")
    private String realNum;

    @TableField(value = "textureType")
    private String textureType;

    @TableField(value = "texture")
    private String texture;

    @TableField(value = "completeDegree")
    private String completeDegree;

    @TableField(value = "keepState")
    private String keepState;

    @TableField(value = "completeDesc")
    private String completeDesc;

    @TableField(value = "length")
    private String length;

    @TableField(value = "width")
    private String width;

    @TableField(value = "height")
    private String height;

    @TableField(value = "massRange")
    private String massRange;

    @TableField(value = "specificSize")
    private String specificSize;

    @TableField(value = "specificMass")
    private String specificMass;

    @TableField(value = "massUnit")
    private String massUnit;

    @TableField(value = "collectTimeRange")
    private String collectTimeRange;

    @TableField(value = "collectYear")
    private String collectYear;

    @TableField(value = "offer")
    private String offer;

    @TableField(value = "safeAssess")
    private String safeAssess;

    @TableField(value = "annexRes")
    private String annexRes;

    @TableField(value = "outState")
    private String outState;

    @TableField(value = "completeType")
    private String completeType;

    @TableField(value = "thickness")
    private String thickness;

    @TableField(value = "searchNum")
    private String searchNum;

    @TableField(value = "fileNum")
    private String fileNum;

    @TableField(value = "fixedAssetsNum")
    private String fixedAssetsNum;

    @TableField(value = "assetsNum")
    private String assetsNum;

    @TableField(value = "unearthNum")
    private String unearthNum;

    @TableField(value = "collectingPlace")
    private String collectingPlace;

    @TableField(value = "formProperty")
    private String formProperty;

    @TableField(value = "bore")
    private String bore;

    @TableField(value = "bottomDiameter")
    private String bottomDiameter;

    @TableField(value = "abdominal")
    private String abdominal;

    @TableField(value = "diameter")
    private String diameter;

    @TableField(value = "storehouse")
    private String storehouse;

    @TableField(value = "specificPosition")
    private String specificPosition;

    @TableField(value = "productPlace")
    private String productPlace;

    @TableField(value = "specificTexture")
    private Integer specificTexture;

    @TableField(value = "strikePrice")
    private String strikePrice;

    @TableField(value = "censusName")
    private String censusName;

    @TableField(value = "importationCountry")
    private String importationCountry;

    @TableField(value = "collectCode")
    private String collectCode;

    @TableField(value = "inMsDt")
    private String inMsDt;

    @TableField(value = "cunJuan")
    private String cunJuan;

    @TableField(value = "quantity")
    private String quantity;

    @TableField(value = "packCondition")
    private String packCondition;

    @TableField(value = "checkDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date checkDate;

    @TableField(value = "createUser")
    private String createUser;

    @TableField(value = "createTime")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @TableField(value = "remark")
    private String remark;

    @TableField(value = "introduction")
    private String introduction;


    /**
     * 藏品状态
     * 0：编目中 1：已驳回 2：审核中 3：未发布 4：已发布 5：已撤销 6：再编目 7：已注销
     * 以下是新增状态
     * 8：流水账 9：流水账审核 10：流水账入库 11、参考账待审核 12、参考账/藏品待拨库
     **/
    @TableField(value = "status")
    @ApiModelProperty(value = "藏品状态 ")
    private String status;

    @TableField(value = "commitDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date commitDate;

    @TableField(value = "pubDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date pubDate;

    @TableField(value = "pubUserId")
    private String pubUserId;

    @TableField(value = "rebutDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date rebutDate;

    @TableField(value = "examineUserId")
    private String examineUserId;

    @TableField(value = "examineDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date examineDate;

    @TableField(value = "examineOpinion")
    private String examineOpinion;

    @TableField(value = "againEditDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date againEditDate;

    @TableField(value = "againEditReason")
    private String againEditReason;

    @TableField(value = "againEditOperator")
    private String againEditOperator;

    @TableField(value = "collectClass")
    @ApiModelProperty(value = "藏品分类（1、藏品，2、参考账）")
    private String collectClass;

    @TableField(value = "bkNum")
    private String bkNum;

    @TableField(value = "cancelNum")
    private String cancelNum;

    @TableField(value = "cancelHandelUser")
    private String cancelHandelUser;

    @TableField(value = "cancelHandelDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date cancelHandelDate;

    @TableField(value = "cancelRemark")
    private String cancelRemark;

    @TableField(value = "cancelWhere")
    private String cancelWhere;

    @TableField(value = "cancelApproveUser")
    private String cancelApproveUser;

    @TableField(value = "cancelDate")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date cancelDate;

    @TableField(value = "cancelApproveNum")
    private String cancelApproveNum;

    @TableField(value = "cancelApproveUnit")
    private String cancelApproveUnit;

    @TableField(value = "numUnit")
    private String numUnit;

    @TableField(value = "browseCount")
    private Integer browseCount;

    @TableField(value = "collectCount")
    private Integer collectCount;

    @ApiModelProperty(value = "参考账类型:cp_refer_account_type")
    private Integer referAccountType;

}