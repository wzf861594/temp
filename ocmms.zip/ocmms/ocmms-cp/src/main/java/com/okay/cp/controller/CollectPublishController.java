package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectPublishExt;
import com.okay.cp.outside.clients.ResServerInterface;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.CollectPublishService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * @Description: 藏品发布官网控制类.
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-08-26 8:44
 */

@RestController
@RequestMapping(value = "/publish")
public class CollectPublishController {

    @Autowired
    private CollectPublishService collectPublishService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private ResServerInterface resServerInterface;

    /**
     *  藏品发布官网.
     * @author: xiandn
     * @param jsonParam
     * @return:
     */
    @RequestMapping(value = "/officialWebsite", method = RequestMethod.POST, produces = "application/json")
    public JSONObject publishWebsite(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = jsonParam.getString("collectId");
            if (StringUtils.isEmpty(collectId)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            List<String> collectIdList = Arrays.asList(collectId.split(","));
            boolean isSuccess = collectPublishService.publishOfficialWebsite(collectIdList);
            if (!isSuccess) {
                throw new BaseRuntimeException(CollectErrorDefine.PUBLIC_ERR);
            } else {
                ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.PUBLIC_SUCCESS);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     *  取消发布官网.
     * @author: xiandn
     * @param jsonParam
     * @return:
     */
    @RequestMapping(value = "/cancelPublish", method = RequestMethod.POST, produces = "application/json")
    public JSONObject cancelPublish(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try {
            String publishId = jsonParam.getString("publishId");
            if (StringUtils.isEmpty(publishId)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            List<String> publishIdList = Arrays.asList(publishId.split(","));
            boolean isSuccess = collectPublishService.cancelPublishOfficialWebsite(publishIdList);
            if (!isSuccess) {
                throw new BaseRuntimeException(CollectErrorDefine.SAVE_ERR);
            } else {
                ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.SAVE_SUCCESS);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 列表查询条件初始化.
     * @return
     */
    @RequestMapping(value = "/initData", method = RequestMethod.GET)
    public JSONObject initData() {

        JSONArray collectTypeList = collectCommonCodeService.selectCollectType();
        JSONArray levelList = collectCommonCodeService.selectCollectLev();
        JSONArray ageList = collectCommonCodeService.selectCollectAgeTree();

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("ageList", ageList);
        jsonObject.put("levelList",levelList);
        jsonObject.put("collectTypeList", collectTypeList);
        return jsonObject;
    }

    /**
     *  发布数据列表.
     * @author: xiandn
     * @param jsonParam
     * @return:
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json")
    public JSONObject publishDataList(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        Page page = JSONObject.toJavaObject(jsonParam, Page.class);
        page.getConditionMap().put("publishState", "1");
        List<CollectPublishExt> collectPublishExtList = collectPublishService.getListByPage(page);
        for (CollectPublishExt collectPublishExt : collectPublishExtList) {
            collectPublishExt.setImageUrl(collectCommonBusinessService.getCoverImg("90", collectPublishExt.getPublishCollectId()));
        }
        jsonObject.put("code", 1);
        jsonObject.put("pages", page.getPages());
        jsonObject.put("total", page.getTotal());
        jsonObject.put("data", collectPublishExtList);
        return jsonObject;
    }

    /**
     *  获取藏品详细信息.
     * @author: xiandn
     * @param collectId 藏品主键.
     * @return:
     */
    @RequestMapping(value = "/collect/{collectId}", method = RequestMethod.GET)
    public JSONObject publishCollect(@PathVariable String collectId) {
        JSONObject jsonObject = new JSONObject();
        try {
            if (StringUtils.isEmpty(collectId)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            CollectPublishExt collectPublishExt = collectPublishService.getCollectInfoByCollectId(collectId);
            jsonObject.put("code", 1);
            jsonObject.put("data", collectPublishExt);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 列表查询条件初始化.
     * @return
     */
    @CrossOrigin(origins = "*",maxAge = 3600)
    @RequestMapping(value = "/initDataForWebsite", method = RequestMethod.GET)
    public JSONObject initDataForWebsite() {

        JSONArray collectTypeList = collectCommonCodeService.selectCollectType();
        JSONArray levelList = collectCommonCodeService.selectCollectLev();
        JSONArray ageList = collectCommonCodeService.selectCollectAgeTree();

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("ageList", ageList);
        jsonObject.put("levelList",levelList);
        jsonObject.put("collectTypeList", collectTypeList);
        JSONObject returnJson = new JSONObject();
        returnJson.put("code", 1);
        returnJson.put("data", jsonObject);
        return returnJson;
    }

    /**
     *  发布数据列表.
     * @author: xiandn
     * @return:
     */
    @CrossOrigin(origins = "*",maxAge = 3600)
    @RequestMapping(value = "/dataListForWebsite", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataListForWebsite(@RequestParam Map<String,Object> param) {
        JSONObject jsonObject = new JSONObject();
        Page page = new JSONObject(param).toJavaObject(Page.class);
        page.getConditionMap().put("publishState", "1");
        List<CollectPublishExt> collectPublishExtList = collectPublishService.getListByPageForWebsite(page);
        for (CollectPublishExt collectPublishExt : collectPublishExtList) {
            JSONObject mainBodyObject = new JSONObject();
            mainBodyObject.put("mainBodyObj", "90");
            mainBodyObject.put("mainBodyId", collectPublishExt.getPublishCollectId());
            JSONObject resObj = resServerInterface.getAppCoverImg(mainBodyObject);
            collectPublishExt.setImageUrl(resObj.getString("imageToBase64"));
        }
        jsonObject.put("code", 1);
        jsonObject.put("pages", page.getPages());
        jsonObject.put("total", page.getTotal());
        jsonObject.put("data", collectPublishExtList);
        return jsonObject;
    }
}
