package com.okay.cp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 二维码导览表
 *
 * @author CZJ[OKAY]
 * @date 2021-12-15 10:42:23
 */
@Data
@ApiModel(value = "二维码导览表")
public class CpQrCodeTour extends BaseModel {

    @TableId(type = IdType.INPUT)
    @ApiModelProperty(value = "主键")
    private String id;

    @ApiModelProperty(value = "藏品ID")
    private String collectId;

    @ApiModelProperty(value = "藏品介绍")
    private String synopsis;

    @ApiModelProperty(value = "状态 1、未发布 2、已发布")
    private Integer status;

    @ApiModelProperty(value = "备注")
    private String remark;

}