package com.okay.cp.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectType;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.CollectTypeService;
import com.okay.framework.controller.BaseController;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: CollectTypeController
 * @Description: 藏品类别管理
 * @author: HQ.ZHU
 * @date: 2019-09-28 10:42
 * @version: V1.0
 */
@RestController
@RequestMapping("/collectType")
public class CollectTypeController extends BaseController {

    @Autowired
    private CollectTypeService collectTypeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;

    @PostMapping("/dataList")
    public JSONObject getDataList(@RequestBody Page page){
        JSONObject jsonObject = new JSONObject();
        try{
            List<Map> list = collectTypeService.findDataList(page);
            for (int i = 0; i < list.size(); i++) {
                CollectType collectType = (CollectType)list.get(i);
                collectType.setCreatUser(collectCommonBusinessService.getUserNames(collectType.getCreatUser()));
            }
            jsonObject.put("code", 1);
            jsonObject.put("data",list);
            jsonObject.put("pages",page.getPages());
            jsonObject.put("total",page.getTotal());
            jsonObject.put("pageNum",page.getPageNum());
            jsonObject.put("pageSize",page.getPageSize());
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 新增
     * @param collectType
     * @return
     */
    @SysLog("藏品类别-新增")
    @PostMapping("/add")
    public JSONObject addData(@RequestBody @Valid CollectType collectType){
        JSONObject jsonObject = new JSONObject();
        try{
            //装配数据
            collectType.setTypeId(getSequence());
            collectType.setCreatUser(getLoginUser().getUserId());
            collectType.setCreatTime(new Date());
            int rows = collectTypeService.addData(collectType);
            if(rows == 1) {
                jsonObject.put("data",collectType);
                throw new BaseRuntimeException(CollectErrorDefine.ADD_SUCCESS);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.ADD_ERR);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 删除
     * @param jsonParam
     * @return
     */
    @SysLog("藏品类别-删除")
    @PreAuthorize("@pms.hasPermission('CT_DEL')")
    @PostMapping("/remove")
    public JSONObject removeData(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            if (jsonParam.getBooleanValue("confirmFlg")){
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }

            int rows = collectTypeService.removeData(jsonParam.getString("typeIds"));
            if(rows == 0) {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_ERR);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 根据ID获取藏品类型
     * @param typeId
     * @return
     */
    @PostMapping("/getById")
    public JSONObject getById(@RequestBody JSONObject typeId){
        JSONObject jsonObject = new JSONObject();
        try{
            CollectType collectType = collectTypeService.selectByPrimaryKey((String) typeId.get("typeId"));
            jsonObject.put("data", collectType);
            jsonObject.put("code", 1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 修改
     * @param collectType
     * @return
     */
    @SysLog("藏品类别-修改")
    @PostMapping("/modify")
    public JSONObject modifyData(@RequestBody @Valid CollectType collectType){
        JSONObject jsonObject = new JSONObject();
        try{
            //装配数据
            int rows = collectTypeService.modifyData(collectType);
            if(rows == 1) {
                jsonObject.put("data",collectType);
                throw new BaseRuntimeException(CollectErrorDefine.UPDATE_SUCCESS);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.UPDATE_ERR);
            }

        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }
}
