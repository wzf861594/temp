package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.SolicClues;
import com.okay.cp.entity.SolicitSingle;
import com.okay.cp.service.SolicClueService;
import com.okay.cp.service.SolicitSingleService;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/29 9:53
 * @Version: 1.0
 * @Description: 征集单控制类.
 */

@RestController
@RequestMapping(value = "/solicitSingle")
public class SolicitSingleController {

    @Autowired
    private SolicitSingleService solicitSingleService;
    @Autowired
    private SolicClueService solicClueService;

    /**
     * 页面初始化.
     * @return
     */
    @RequestMapping(value = "/initPage", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initPage(){
        JSONObject jsonObject = new JSONObject();
        // 征集编码
        String singleCode = "ZJD_" + DateUtil.getNextTime();
        // 关联线索
        List<Map> clueList = solicClueService.findClueList();
        jsonObject.put("code",1);
        jsonObject.put("clueList",clueList);
        jsonObject.put("singleCode",singleCode);
        return jsonObject;
    }

    @RequestMapping(value = "/dataTree", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getDataTree(){
        JSONObject jsonObject = new JSONObject();
        try{
            List<SolicitSingle> dataList = solicitSingleService.findDataList(new HashMap<String, Object>());
            JSONArray dataArray = dataTreeHandle(dataList);
            jsonObject.put("data", dataArray);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取数据.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("id");
        if (StringUtils.isNotEmpty(id)) {
            SolicitSingle solicitSingle = solicitSingleService.findBySolicitSingleId(id);
            // 实体转Map
            String jsonString = JSONObject.toJSONString(solicitSingle);
            Map<String, Object> dataMap = JSONObject.parseObject(jsonString);
            SolicClues solicClues = solicClueService.findByClueIdForBean(String.valueOf(solicitSingle.getLinkClueId()));
            if (solicClues != null) {
                dataMap.put("linkClueName",solicClues.getCluesName());
            }
            jsonObject.put("code",1);
            jsonObject.put("data",dataMap);
        }
        return jsonObject;
    }

    /**
     * 信息新增.
     * @param solicitSingle
     * @return
     */
    @SysLog("征集单添加")
    @RequestMapping(value="/insert", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject insert(@RequestBody @Valid SolicitSingle solicitSingle) {

        JSONObject jsonObject = new JSONObject();
        try{
            SolicitSingle newSolicitSingle = solicitSingleService.insert(solicitSingle);
            jsonObject.put("data",newSolicitSingle);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.ADD_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息修改.
     * @param solicitSingle
     * @return
     */
    @SysLog("征集单修改")
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject update(@RequestBody @Valid SolicitSingle solicitSingle){
        JSONObject jsonObject = new JSONObject();
        try{
            String id = solicitSingle.getSolicitSingleId();
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            solicitSingleService.modifyBySolicitSingleIdSelective(solicitSingle);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.UPDATE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息删除.
     * @param jsonParam
     * @return
     */
    @SysLog("征集单删除")
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject delete(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();

        String id = jsonParam.getString("id");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            solicitSingleService.removeSolicitSingleId(id);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.DELETE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 征集单树型结构处理.
     * @param dataList
     * @return
     */
    public JSONArray dataTreeHandle(List<SolicitSingle> dataList){
        Map<Integer,Map<String,Object>> yearMap = new HashMap<Integer,Map<String,Object>>();
        JSONArray resultArray = new JSONArray();
        for (int i = 0 ; i < dataList.size() ; i++) {
            SolicitSingle solicitSingle = dataList.get(i);
            if (solicitSingle.getSolicitAge() == null) {
                continue;
            }
            Calendar cal = Calendar.getInstance();
            cal.setTime(solicitSingle.getSolicitAge());
            Integer year = cal.get(Calendar.YEAR);

            // 是否存在于yearMap中
            Map<String,Object> yearData = yearMap.get(year);
            if (yearData == null) {
                yearData = new HashMap<String,Object>();
                yearData.put("solicitSingleName", year + "年");
                yearData.put("children", new ArrayList<Object>());
                yearData.put("solicitSingleId", new ArrayList<String>());
                yearMap.put(year, yearData);
                resultArray.add(yearData);
            }
            ((List<Object>)yearData.get("children")).add(solicitSingle);
            ((List<String>)yearData.get("solicitSingleId")).add(solicitSingle.getSolicitSingleId());
        }

        JSONArray jsonData = new JSONArray();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("solicitSingleName","征集单列表");
        dataMap.put("id","0");
        dataMap.put("children",resultArray);
        jsonData.add(dataMap);
        return jsonData;
    }

}
