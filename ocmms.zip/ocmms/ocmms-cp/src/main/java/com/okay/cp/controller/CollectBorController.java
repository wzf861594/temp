package com.okay.cp.controller;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.lang.Assert;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.api.R;
import com.okay.cp.baseBusiness.CollectInfoBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectBorList;
import com.okay.cp.entity.Workorder;
import com.okay.cp.entity.dto.CollectBorDTO;
import com.okay.cp.mapper.CollectBorMapper;
import com.okay.cp.mapper.OaWorkOrderMapper;
import com.okay.cp.service.*;
import com.okay.cp.service.impl.RfidCollectInfoServiceImpl;
import com.okay.cp.utils.CollectBorExcelUtils;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.SequenceService;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DateUtil;
import com.okay.okay.common.log.annotation.SysLog;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName: FlowSingleController
 * @Description: 流程清单控制类
 * @author: zhongmz
 * @Date: 2019/7/10 10:26
 * @version: V1.0
 */
@RestController
@RequestMapping(value = "/cpBor")
public class CollectBorController extends CollectInfoBaseBusiness {

    @Autowired
    private BillInfoListService billInfoListService;

    @Autowired
    private CollectBorService collectBorService;

    @Autowired
    private CollectBorListService collectBorListService;

    @Autowired
    private CollectBorMapper collectBorMapper;

    @Autowired
    private CollectCommonCodeService collectCommonCodeService;

    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;

    @Autowired
    private SequenceService sequenceService;

    @Autowired
    private UserService userService;

    @Autowired
    private StoreHouseService storeHouseService;
    @Autowired
    private OaWorkOrderMapper workOrderMapper;

    /**
     * 获取资源申请单编码
     *
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/applyCode", method = RequestMethod.POST, produces = "application/json")
    public JSONObject getApplyCode() {
        JSONObject jsonObject = new JSONObject();
        try {
            String resCode = "TJ_" + DateUtil.getNextTime();
            jsonObject.put("resCode", resCode);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取资源申请单的主键
     *
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/getColBorId", method = RequestMethod.POST, produces = "application/json")
    public JSONObject getColBorId() {
        JSONObject jsonObject = new JSONObject();
        try {
            String colBorId = sequenceService.getSequence();
            jsonObject.put("data", colBorId);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 根据主键查询提借单数据
     *
     * @param jsonParam
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject selectByColBorId(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String colBorId = jsonParam.getString("colBorId");
            Map<String, Object> dataMap = collectBorService.selectByColBorId(colBorId);
            if (dataMap == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.SELECT_RESULT_NULL, "藏品提借单"));
            }

            jsonObject.put("data", dataMap);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品ID列表
     *
     * @param jsonParam
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/getCollectIdList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject selectCollectIdList(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String colBorId = jsonParam.getString("colBorId");
            if (colBorId == null || "".equals(colBorId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "流程清单ID"));
            }
            List<String> collectIdList = collectBorListService.selectCollectIdList(colBorId);

            jsonObject.put("data", collectIdList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取提借申请单的信息（发起流程，同步清单明细）
     *
     * @param page
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/getApplyBill", method = RequestMethod.POST, produces = "application/json")
    public JSONObject getApplyBill(@RequestBody Page page) {
        JSONObject jsonObject = new JSONObject();
        try {
            // 查询数据
            billInfoListService.selectPageData(page);

            int borTotal = 0;
            //遍历设置图片预览URL
            if (page.getData() instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) page.getData();
                for (Map<String, Object> map : list) {
                    // 计算总提借量
                    if (map.get("borrowNum") != null) {
                        int borrowNum = Integer.valueOf(map.get("borrowNum").toString()).intValue();
                        borTotal += borrowNum;
                    }
                }
            }

            // 设置提借总数
            JSONObject resultJson = new JSONObject();
            resultJson.put("borTotal", borTotal);
            jsonObject.put("totalInfo", resultJson);

            jsonObject.put("data", page.getData());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pageNum", page.getPageNum());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取附件信息
     *
     * @param jsonParam
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/getAttachInfo", method = RequestMethod.POST, produces = "application/json")
    public JSONObject getAttachInfo(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            JSONArray jsonArray = new JSONArray();

            String id = jsonParam.getString("id");
            if (id != null && !"".equals(id)) {
                //获取信息关联附件列表
                JSONObject resList = collectCommonBusinessService.getMainBodyRes("100", id);
                jsonArray = resList.getJSONArray("resList");
            }

            jsonObject.put("data", jsonArray);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 出归库分页查询提借单数据
     *
     * @param page
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/colBorPage", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject selectCollectBorPageData(@RequestBody Page page) {
        JSONObject jsonObject = new JSONObject();
        try {
            //根据库房管理员过滤
//            User user = userService.getLoginUser();
//            page.getConditionMap().put("storehouseManagerId", user.getUserId());

            //设置日期范围
            Map<String, Object> query = page.getConditionMap();
            if (query.get("borDate") != null && !"".equals(query.get("borDate"))) {
                ArrayList<String> borDate = (ArrayList) query.get("borDate");
                if (borDate.size() == 2) {
                    page.getConditionMap().put("borDate_start", borDate.get(0));
                    page.getConditionMap().put("borDate_end", borDate.get(1));
                }
            }

            // 添加RFID 业务类型
            if (query.containsKey("rfidInState")) {
                String rfidBusinessType = "NULL";
                String outState = query.get("state").toString();
                String backState = query.get("backState").toString();
                if (outState.equals("0")) {
                    rfidBusinessType = RfidCollectInfoServiceImpl.BusinessType.COLLECTBOR_OUT.name();
                } else if (backState.equals("0")) {
                    rfidBusinessType = RfidCollectInfoServiceImpl.BusinessType.COLLECTBOR_BACK.name();
                }
                query.put("rfidBusinessType", rfidBusinessType);
                collectBorService.getRfidRelatedPageData(page);
            } else {
                collectBorService.selectPageData(page);
            }

            jsonObject.put("data", page.getData());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pageNum", page.getPageNum());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 分页查询提借单明细数据
     *
     * @param page
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/colBorListPage", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject selectCollectBorListPageData(@RequestBody Page page) {
        JSONObject jsonObject = new JSONObject();
        try {
            collectBorListService.selectPageData(page);

            int borTotal = 0;
            //遍历设置图片预览URL
            if (page.getData() instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) page.getData();
                for (Map<String, Object> map : list) {
                    // 设置实际库存
                    String collectId = String.valueOf(map.get("collectId"));
                    int inStorehouseCount = getCanBorCollectNum(collectId);
                    map.put("inStorehouseCount", inStorehouseCount);

                    // 计算总提借量
                    int borCount = Integer.valueOf(map.get("borCount").toString()).intValue();
                    borTotal += borCount;
                }
            }

            // 设置提借总数
            JSONObject resultJson = new JSONObject();
            resultJson.put("borTotal", borTotal);
            jsonObject.put("totalInfo", resultJson);

            jsonObject.put("data", page.getData());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pageNum", page.getPageNum());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 分页查询出归库提借单明细数据
     *
     * @param page
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/outBackColBorListPage", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject selectOutBackCollectBorListPageData(@RequestBody Page page) {
        JSONObject jsonObject = new JSONObject();
        try {
            //根据库房管理员过滤
//            User user = userService.getLoginUser();
//            page.getConditionMap().put("storehouseManagerId", user.getUserId());
            collectBorListService.selectPageData(page);

            //遍历设置图片预览URL
            if (page.getData() instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) page.getData();
                for (Map<String, Object> map : list) {
                    // 设置实际库存
                    String collectId = String.valueOf(map.get("collectId"));
                    int inStorehouseCount = getCanBorCollectNum(collectId);
                    map.put("inStorehouseCount", inStorehouseCount);

                }
            }

            //查询未出库/未归库的库房
            String colBorId = String.valueOf(page.getConditionMap().get("colBorId"));
            List<Map<String, Object>> collectBorList = collectBorListService.selectByColBorId(colBorId);

            List<String> notOutStorehouseList = new ArrayList<String>();
            List<String> notBackStorehouseList = new ArrayList<String>();
            for (Map<String, Object> item : collectBorList) {

                String storehouse = String.valueOf(item.get("storehouse"));
                String storehouse_t = collectCommonCodeService.storehouse_t(storehouse);
                item.put("storehouse_t", storehouse_t);

                //只取库房信息，过滤房间排架格子等其他信息
                storehouse = item.get("storehouse") == null ? "" : String.valueOf(item.get("storehouse")).split(",")[0];
                storehouse_t = collectCommonCodeService.storehouse_t(storehouse);
                if ("0".equals(String.valueOf(item.get("outState")))) {
                    if (!notOutStorehouseList.contains(storehouse_t)) {
                        notOutStorehouseList.add(storehouse_t);
                    }
                }

                if ("0".equals(String.valueOf(item.get("backState")))) {
                    if (!notBackStorehouseList.contains(storehouse_t)) {
                        notBackStorehouseList.add(storehouse_t);
                    }
                }
            }
            JSONObject resultJson = new JSONObject();
            resultJson.put("notOutStorehouseList", notOutStorehouseList);
            resultJson.put("notBackStorehouseList", notBackStorehouseList);
            jsonObject.put("storehouseInfo", resultJson);

            jsonObject.put("data", page.getData());
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pageNum", page.getPageNum());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 修改提借单数据（发起人节点修改表单，校验参数）
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品出库-修改提借单数据")
    @RequestMapping(value = "/updateColBor", method = RequestMethod.POST)
    public JSONObject updateCollectBor(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            if (jsonParam == null || "".equals(jsonParam)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "请求参数"));
            }
            if (jsonParam.get("collectBor") == null || "".equals(jsonParam.get("collectBor"))) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "提借单"));
            }

            if (jsonParam.get("collectBorList") == null || "".equals(jsonParam.get("collectBorList"))) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "提借单明细"));
            }

            collectBorService.updateCpProcessData(jsonParam);

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 修改提借单明细数据
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品出库-修改提借单明细数据")
    @RequestMapping(value = "/updateColBorList", method = RequestMethod.POST)
    public JSONObject updateCollectBorList(@RequestBody CollectBorList collectBorList) {
        JSONObject jsonObject = new JSONObject();
        try {
            int row = collectBorListService.updateByPrimaryKeySelective(collectBorList);
            if (row < 1) {
                throw new BaseRuntimeException(CollectErrorDefine.UPDATE_ERR);
            }
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 批量修改提借单办结状态
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品出库-批量修改提借单办结状态")
    @PreAuthorize("@pms.hasPermission('OSR_MANUAL')")
    @RequestMapping(value = "/updateStateBatch", method = RequestMethod.POST)
    public JSONObject updateStateBatch(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String colBorIdList = jsonParam.getString("colBorIdList");
            if (colBorIdList == null || "".equals(colBorIdList)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            String confirmFlg = jsonParam.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_END);
            }

            List<String> colBorIds = Arrays.asList(colBorIdList.split(","));
            int updates = collectBorService.updateStateBatch(colBorIds);
            int code = updates > 0 ? 1 : 0;
            jsonObject.put("code", code);
            if (code == 0) {
                jsonObject.put("msg", "需由对应库房管理员操作");
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 修改提借单明细数据
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品出库-保存提借单明细数据")
    @RequestMapping(value = "/saveColBorList", method = RequestMethod.POST)
    public JSONObject saveCollectBorApplyTaskData(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {

            String handleType = jsonParam.getString("type");
            if (handleType == null || "".equals(handleType)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "操作类型"));
            }

            String colBorId = jsonParam.getString("colBorId");
            if (colBorId == null || "".equals(colBorId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "提借单ID"));
            }

            String collectIds = jsonParam.getString("collectIds");
            if (collectIds == null || "".equals(collectIds)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "藏品ID"));
            }

            List<String> collectIdList = Arrays.asList(collectIds.split(","));
            if ("insert".equals(handleType)) {
                collectBorService.insertBatchByCollectIds(colBorId, collectIdList);
                jsonObject.put("msg", "数据保存成功");
            } else if ("delete".equals(handleType)) {
                collectBorListService.deleteBatch(collectIdList, colBorId);
                jsonObject.put("msg", "数据取消成功");
            }

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 提借单明细单个出库操作
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品出库-出库操作")
    @RequestMapping(value = "/outStorehouse", method = RequestMethod.POST)
    public JSONObject outStorehouse(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_OUT);
            }

            collectBorService.outStorehouse(jsonParam);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 提借单明细批量出库操作
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品出库-批量出库操作")
    @RequestMapping(value = "/outStorehouseBatch", method = RequestMethod.POST)
    public JSONObject outStorehouseBatch(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_OUT);
            }

            JSONArray colBorLists = jsonParam.getJSONArray("colBorLists");
            if (colBorLists == null || colBorLists.size() <= 0) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            for (int i = 0; i < colBorLists.size(); i++) {
                JSONObject json = colBorLists.getJSONObject(i);
                json.put("toOutCount", json.getJSONObject("storehouse").getInteger("toOutCount"));
                collectBorService.outStorehouse(json);
            }

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 提借单明细全部出库操作
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品出库-全部出库操作")
    @RequestMapping(value = "/outStorehouseAll", method = RequestMethod.POST)
    public JSONObject outStorehouseAll(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_OUT);
            }

            collectBorService.outStorehouseAll(jsonParam);

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 提借单明细单个归库操作
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品归库-归库操作")
    @RequestMapping(value = "/backStorehouse", method = RequestMethod.POST)
    public JSONObject backStorehouse(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_BACK);
            }

            collectBorService.backStorehouse(jsonParam);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 提借单明细批量归库操作
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品归库-批量归库操作")
    @RequestMapping(value = "/backStorehouseBatch", method = RequestMethod.POST)
    public JSONObject backStorehouseBatch(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_BACK);
            }

            JSONArray colBorLists = jsonParam.getJSONArray("colBorLists");
            if (colBorLists == null || colBorLists.size() <= 0) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            for (int i = 0; i < colBorLists.size(); i++) {
                JSONObject json = colBorLists.getJSONObject(i);
                json.put("toBackCount", json.getJSONObject("storehouse").getInteger("toBackCount"));
                json.put("isError", json.getJSONObject("error").getInteger("isError"));
                json.put("errorMsg", json.getJSONObject("error").getInteger("errorMsg"));
                collectBorService.backStorehouse(json);
            }

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 提借单明细全部归库操作
     *
     * @return com.alibaba.fastjson.JSONObject
     * @Param jsonParam
     */
    @SysLog("藏品归库-全部归库操作")
    @RequestMapping(value = "/backStorehouseAll", method = RequestMethod.POST)
    public JSONObject backStorehouseAll(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_BACK);
            }

            collectBorService.backStorehouseAll(jsonParam);

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }


    /**
     * 根据ID获取记录基本信息
     *
     * @param id 主键
     * @return R
     * @author WZF[OKAY]
     **/
    @GetMapping(value = "/getByIds")
    @ApiOperation(value = "根据ID获取记录基本信息")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R getById(@RequestParam(value = "id") String id) {
        return R.ok(collectBorService.getById(id)).setMsg("");
    }

    /**
     * 导出提借归还单EXCEL
     *
     * @return
     */
    @SysLog("藏品出（归）库-导出点交单excel")
    @RequestMapping(value = "/downloadExcel", method = RequestMethod.POST, produces = "application/json")
    public void downloadExcel(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        try {
            // 查询导出数据集
            JSONObject pageJson = jsonParam.getJSONObject("page");
            Page page = pageJson.toJavaObject(Page.class);

            //导出文件名
            String fileName = jsonParam.getString("fileName");
            if (fileName == null || "".equals(fileName)) {
                fileName = "点交单";
            }

            String colBorId = String.valueOf(page.getConditionMap().get("colBorId"));
            Map<String, Object> data = collectBorService.selectByColBorId(colBorId);
            if (data == null) {
                throw new BaseRuntimeException(CollectErrorDefine.SELECT_RESULT_NULL);
            }

            collectBorListService.selectPageData(page);
            List<Map<String, Object>> dataList = page.getData() == null ? new ArrayList<Map<String, Object>>() : (List<Map<String, Object>>) page.getData();

            // ---------------补充信息----------------
            //提借期限：归还时间 - 提借时间
            if (data.get("borDate") != null && data.get("backDate") != null) {
                int marginDays = DateUtil.getMargin(String.valueOf(data.get("backDate")), String.valueOf(data.get("borDate")));
                data.put("marginDays", marginDays);
            }

            //库房管理员和保管部门
            int realBorCount = 0;
            List<String> storehouseIdList = new ArrayList<String>();
            for (Map<String, Object> item : dataList) {
                // 只截取库房Id信息
                String storehouse = item.get("storehouse") == null ? "" : String.valueOf(item.get("storehouse")).split(",")[0];
                if (!storehouseIdList.contains(storehouse)) {
                    storehouseIdList.add(storehouse);
                }
                // 统计实际出库数量
                realBorCount += Integer.valueOf(String.valueOf(item.get("outCount")));
            }
            data.put("realBorCount", realBorCount);

            //用set集合是为了去掉重复的值。查询库房管理员和对应保管部门信息
            Set<String> storehouseManager = new TreeSet<String>();
            Set<String> storehouseManagerDept = new TreeSet<String>();
            List<Map<String, Object>> storehouseInfoList = storeHouseService.getStorehouseInfo(storehouseIdList);
            if (storehouseInfoList != null && storehouseInfoList.size() > 0) {
                for (Map<String, Object> item : storehouseInfoList) {
                    if (item.get("manager_t") != null) {
                        List<String> manager_t = (List<String>) item.get("manager_t");
                        storehouseManager.addAll(manager_t);
                    }

                    if (item.get("dept_t") != null) {
                        List<String> dept_t = (List<String>) item.get("dept_t");
                        storehouseManagerDept.addAll(dept_t);
                    }
                }
            }
            data.put("storehouseManager", StringUtils.strip(String.valueOf(storehouseManager), "[]"));
            data.put("storehouseManagerDept", StringUtils.strip(String.valueOf(storehouseManagerDept), "[]"));

            Map<String, Object> map = new HashMap<String, Object>();
            map.put("data", data);
            map.put("dataList", dataList);

            HSSFWorkbook wb = CollectBorExcelUtils.creakWorkBook(map);
            DataExportUtils.setResponseHeader(response, wb, fileName);
        } catch (Exception e) {
            throw new BaseRuntimeException(e.getMessage());
        }
    }

    /**
     * 选择导出的表头
     *
     * @return
     */
    @RequestMapping(value = "/exportHeaderOptions", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeaderOptions() {
        JSONObject jsonObject = new JSONObject();
        try {

            List headers = new ArrayList();
            JSONObject headerJson = new JSONObject();
            headerJson.put("label", "提借名称");
            headerJson.put("key", "borTitle");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "提借编号");
            headerJson.put("key", "borCode");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "提借人");
            headerJson.put("key", "borUser_t");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "提借部门");
            headerJson.put("key", "borDept_t");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "提借目的");
            headerJson.put("key", "borAims");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "联系信息");
            headerJson.put("key", "contactInfo");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "提借类型");
            headerJson.put("key", "borType_t");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "提借数量");
            headerJson.put("key", "borCount");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "提借日期");
            headerJson.put("key", "borDate");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "归还日期");
            headerJson.put("key", "backDate");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "任务描述");
            headerJson.put("key", "taskDesc");
            headers.add(headerJson);

            jsonObject.put("headerOptions", headers);
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 常规出归库列表数据导出
     *
     * @return
     */
    @SysLog("藏品出（归）库-常规出归库列表数据导出")
    @RequestMapping(value = "/dataExport", method = RequestMethod.POST, produces = "application/json")
    public void dataExport(@RequestBody JSONObject paramJson, HttpServletRequest request, HttpServletResponse response) {
        try {
            //查询数据 转换查询条件
            JSONObject pageJson = paramJson.getJSONObject("page");
            Page page = pageJson.toJavaObject(Page.class);

            //导出文件名
            String fileName = paramJson.getString("fileName");
            if (fileName == null || "".equals(fileName)) {
                fileName = "藏品出库（归库）单";
            }

            //导出类型
            String exportType = paramJson.getString("exportType");
            if (exportType == null || "".equals(exportType)) {
                exportType = "0";
            }

            if ("0".equals(exportType)) {
                //导出查询的全部数据
                page.setPageSize(0);
            } else if ("1".equals(exportType)) {
                //导出当前页的数据
            } else if ("2".equals(exportType)) {
                //2：选择的数据
                String colBorIdList = paramJson.getString("colBorIdList");
                page.getConditionMap().put("colBorIdList", Arrays.asList(colBorIdList.split(",")));
            }

            //获取选择的头部
            List headerNameList = new ArrayList();
            List headerKeyList = new ArrayList();
            JSONArray exportColumn = paramJson.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            //封装实体数据
            collectBorService.selectPageData(page);
            List<Map<String, Object>> collectBorList = (List<Map<String, Object>>) page.getData();
            List<List<String>> dataList = new ArrayList<List<String>>();
            for (Map<String, Object> item : collectBorList) {
                //实体类转换成 json对象
                List<String> columnData = new ArrayList<String>();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = String.valueOf(headerKeyList.get(j));
                    String value = item.get(key) == null ? "" : String.valueOf(item.get(key));
                    columnData.add(value);
                }
                dataList.add(columnData);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, dataList);
            DataExportUtils.setResponseHeader(response, wb, fileName);
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(201);
        }
    }



    @RequestMapping(value = "/updateById", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(rollbackFor = Exception.class)
    public JSONObject updateById(@RequestBody JSONObject formData) {
        JSONObject jsonObject = new JSONObject();
        try {
            // 工单信息保存

            Workorder workOrder = formData.getObject("workOrder", Workorder.class);
            workOrderMapper.updateWorkOrderTitle(workOrder);
            CollectBorDTO dto = JSON.parseObject(JSON.toJSONString(formData), CollectBorDTO.class);
            List<CollectBorList> collectList = dto.getCollectList();
            Assert.isTrue(CollectionUtils.isNotEmpty(collectList), "藏品不能为空");
            // 删除
            List<String> ids = collectList.stream().map(CollectBorList::getCollectId).collect(Collectors.toList());
            if (CollectionUtil.isNotEmpty(ids)) {
                LambdaQueryWrapper<CollectBorList> cpWrapper = Wrappers.lambdaQuery();
                cpWrapper.eq(CollectBorList::getColBorId, dto.getColBorId());
                cpWrapper.notIn(CollectBorList::getCollectId, ids);
                collectBorListService.remove(cpWrapper);
            }
            collectBorListService.saveOrUpdateBatch(collectList);
            collectBorMapper.updateById(dto);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

}
