package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.baseBusiness.SolictBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.ExpertIdenty;
import com.okay.cp.entity.SolicInfo;
import com.okay.cp.service.SolicInfoService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/4 12:27
 * @Version: 1.0
 * @Description: 征集鉴定控制类.
 */

@RestController
@RequestMapping(value = "/identify")
public class SolicitIdentifyController extends SolictBaseBusiness {

    @Autowired
    private SolicInfoService solicInfoService;
    @Autowired
    private UserService userService;

    /**
     * 查询列表初始化.
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initForm(){
        JSONObject jsonObject = new JSONObject();
        jsonObject = getOptions();
        jsonObject.put("code",1);
        return jsonObject;
    }


    /**
     * 列表数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        Map<String,Object> conditionMap = new HashMap<String,Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询状态
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state","2");
                }
            }
            return getDataList(page);
        }
        return null;
    }

    /**
     * 获取数据.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam){

        String id = jsonParam.getString("solicId");
        return getInfoByMainKey(id);
    }

    /**
     * 根据主键获取关联的合同附件.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getAttach", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getAttach(@RequestBody JSONObject jsonParam){

        String id = jsonParam.getString("solictId");
        return getAttachBymainKey(id);
    }

    /**
     * 鉴定终止.
     * @param jsonParam
     * @return
     */
    @SysLog("征集中终止")
    @RequestMapping(value = "/identifyStop", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('SLT_TERMINATION')")
    public JSONObject identifyStop(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solicId");
        SolicInfo solicInfo = jsonParam.getJSONObject("data").toJavaObject(SolicInfo.class);
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(solicInfo.getAbandonReason())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR,"终止原因"));
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_STOP);
            }
            solicInfoService.stop(id, solicInfo);
            throw new BaseRuntimeException(CollectErrorDefine.STOP_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息提交 =》 确认征集.
     * @param jsonParam
     * @return
     */
    @SysLog("藏品提交确认征集")
    @RequestMapping(value = "/commitToSureSolicit", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('SLT_SUBMITTRUE')")
    public JSONObject commitToSureSolict(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solicId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_COMMIT);
            }
            List<String> idList = new ArrayList<String>(Arrays.asList(id.split(",")));
            solicInfoService.commitToSureSolict(idList);
            throw new BaseRuntimeException(CollectErrorDefine.COMMIT_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取鉴定数据.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getIdentifyInfo", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getIdentifyInfo(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solicId");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            jsonObject = solicInfoService.findIdentifyInfoById(id);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 添加专家鉴定信息
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/addExpert", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject addExpert(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solicId");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR,"征集信息"));
            }
            ExpertIdenty expertIdenty = new ExpertIdenty();
            expertIdenty.setSolicId(id);
            expertIdenty.setCreatTime(new Date());
            expertIdenty.setCreatUser(userService.getLoginUser().getUserId());
            ExpertIdenty newExpertIdenty = solicInfoService.addExpert(expertIdenty);
            jsonObject.put("data",newExpertIdenty);
            throw new BaseRuntimeException(CollectErrorDefine.ADD_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 删除专家鉴定信息
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/delExpert", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject delExpert(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("ideaId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            int handleNum = solicInfoService.delExpert(id);
            if (handleNum == 1) {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
            }else {
                throw new BaseRuntimeException(CollectErrorDefine.DELETE_ERR);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 鉴定信息保存.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/saveIdentifyInfo", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject saveIdentifyInfo(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solicId");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR,"征集信息"));
            }
            solicInfoService.saveIdentifyInfo(jsonParam);
            throw new BaseRuntimeException(CollectErrorDefine.SAVE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        return initExportHeader("6");
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("征集中导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
    @PreAuthorize("@pms.hasPermission('SLT_EXP')")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        exportHandle(jsonParam,request,response);
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeaderStop", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeaderStop() {
        JSONObject jsonObject = initExportHeader("6");
        JSONArray exportHeaderList = (JSONArray)jsonObject.get("exportHeaderList");

        JSONObject json = new JSONObject();
        json.put("label","终止原因");
        json.put("key","abandonReason");
        exportHeaderList.add(json);

        json = new JSONObject();
        json.put("label","终止时间");
        json.put("key","abandonTime");
        exportHeaderList.add(json);

        return jsonObject;
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    @RequestMapping(value = "/exportStop", method = RequestMethod.POST, produces = "application/json")
    public void exportStop(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        exportHandle(jsonParam,request,response);
    }
}
