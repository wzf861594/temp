package com.okay.cp.entity;

import java.util.Date;

public class CollectSingleList {
    private String collectId;

    private String singleId;

    private String collectInfoId;

    private String collectUserId;

    private Date collectDate;

    private Integer state;

    private Date stateDate;

    public String getCollectId() {
        return collectId;
    }

    public void setCollectId(String collectId) {
        this.collectId = collectId;
    }

    public String getSingleId() {
        return singleId;
    }

    public void setSingleId(String singleId) {
        this.singleId = singleId;
    }

    public String getCollectInfoId() {
        return collectInfoId;
    }

    public void setCollectInfoId(String collectInfoId) {
        this.collectInfoId = collectInfoId;
    }

    public String getCollectUserId() {
        return collectUserId;
    }

    public void setCollectUserId(String collectUserId) {
        this.collectUserId = collectUserId;
    }

    public Date getCollectDate() {
        return collectDate;
    }

    public void setCollectDate(Date collectDate) {
        this.collectDate = collectDate;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Date getStateDate() {
        return stateDate;
    }

    public void setStateDate(Date stateDate) {
        this.stateDate = stateDate;
    }
}