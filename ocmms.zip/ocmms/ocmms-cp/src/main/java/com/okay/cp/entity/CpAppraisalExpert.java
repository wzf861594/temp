package com.okay.cp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 鉴定专家管理表
 *
 * @author CZJ[OKAY]
 * @date 2021-12-14 20:07:31
 */
@Data
@ApiModel(value = "鉴定专家管理表")
public class CpAppraisalExpert extends BaseModel {

    @TableId(type = IdType.INPUT)
    @ApiModelProperty(value = "主键")
    private String id;

    @ApiModelProperty(value = "专家名称")
    private String name;

    @ApiModelProperty(value = "联系电话")
    private String phone;

    @ApiModelProperty(value = "所在单位")
    private String unit;

    @ApiModelProperty(value = "职位")
    private String position;

    @ApiModelProperty(value = "备注")
    private String remark;

}