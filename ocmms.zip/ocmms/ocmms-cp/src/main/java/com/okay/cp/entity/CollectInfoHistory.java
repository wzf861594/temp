package com.okay.cp.entity;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.Date;

public class CollectInfoHistory {
    private String hisId;

    private String collectId;

    private String collectName;

    private String totalNum;

    private String classNum;

    private String incomeNum;

    private String collectNum;

    private String collectNameOld;

    private String source;

    private String collectType;

    private String cpLevel;

    private String years;

    private String specificAge;

    private String realNum;

    private String textureType;

    private String texture;

    private String completeDegree;

    private String keepState;

    private String completeDesc;

    private String length;

    private String width;

    private String height;

    private String massRange;

    private String specificSize;

    private String specificMass;

    private String massUnit;

    private String collectTimeRange;

    private String collectYear;

    private String offer;

    private String safeAssess;

    private String annexRes;

    private String outState;

    private String completeType;

    private String thickness;

    private String searchNum;

    private String fileNum;

    private String fixedAssetsNum;

    private String assetsNum;

    private String unearthNum;

    private String collectingPlace;

    private String formProperty;

    private String bore;

    private String bottomDiameter;

    private String abdominal;

    private String diameter;

    private String storehouse;

    private String specificPosition;

    private String productPlace;

    private Integer specificTexture;

    private String strikePrice;

    private String censusName;

    private String importationCountry;

    private String collectCode;

    private String inMsDt;

    private String cunJuan;

    private String quantity;

    private String packCondition;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date checkDate;

    private String remark;

    private String introduction;

    private String collectClass;

    private String bkNum;

    private String numUnit;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date updateDt;

    private String updateuser;

    private String commitSave;

    public String getHisId() {
        return hisId;
    }

    public void setHisId(String hisId) {
        this.hisId = hisId;
    }

    public String getCollectId() {
        return collectId;
    }

    public void setCollectId(String collectId) {
        this.collectId = collectId;
    }

    public String getCollectName() {
        return collectName;
    }

    public void setCollectName(String collectName) {
        this.collectName = collectName;
    }

    public String getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(String totalNum) {
        this.totalNum = totalNum;
    }

    public String getClassNum() {
        return classNum;
    }

    public void setClassNum(String classNum) {
        this.classNum = classNum;
    }

    public String getIncomeNum() {
        return incomeNum;
    }

    public void setIncomeNum(String incomeNum) {
        this.incomeNum = incomeNum;
    }

    public String getCollectNum() {
        return collectNum;
    }

    public void setCollectNum(String collectNum) {
        this.collectNum = collectNum;
    }

    public String getCollectNameOld() {
        return collectNameOld;
    }

    public void setCollectNameOld(String collectNameOld) {
        this.collectNameOld = collectNameOld;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCollectType() {
        return collectType;
    }

    public void setCollectType(String collectType) {
        this.collectType = collectType;
    }

    public String getCpLevel() {
        return cpLevel;
    }

    public void setCpLevel(String cpLevel) {
        this.cpLevel = cpLevel;
    }

    public String getYears() {
        return years;
    }

    public void setYears(String years) {
        this.years = years;
    }

    public String getSpecificAge() {
        return specificAge;
    }

    public void setSpecificAge(String specificAge) {
        this.specificAge = specificAge;
    }

    public String getRealNum() {
        return realNum;
    }

    public void setRealNum(String realNum) {
        this.realNum = realNum;
    }

    public String getTextureType() {
        return textureType;
    }

    public void setTextureType(String textureType) {
        this.textureType = textureType;
    }

    public String getTexture() {
        return texture;
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }

    public String getCompleteDegree() {
        return completeDegree;
    }

    public void setCompleteDegree(String completeDegree) {
        this.completeDegree = completeDegree;
    }

    public String getKeepState() {
        return keepState;
    }

    public void setKeepState(String keepState) {
        this.keepState = keepState;
    }

    public String getCompleteDesc() {
        return completeDesc;
    }

    public void setCompleteDesc(String completeDesc) {
        this.completeDesc = completeDesc;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getMassRange() {
        return massRange;
    }

    public void setMassRange(String massRange) {
        this.massRange = massRange;
    }

    public String getSpecificSize() {
        return specificSize;
    }

    public void setSpecificSize(String specificSize) {
        this.specificSize = specificSize;
    }

    public String getSpecificMass() {
        return specificMass;
    }

    public void setSpecificMass(String specificMass) {
        this.specificMass = specificMass;
    }

    public String getMassUnit() {
        return massUnit;
    }

    public void setMassUnit(String massUnit) {
        this.massUnit = massUnit;
    }

    public String getCollectTimeRange() {
        return collectTimeRange;
    }

    public void setCollectTimeRange(String collectTimeRange) {
        this.collectTimeRange = collectTimeRange;
    }

    public String getCollectYear() {
        return collectYear;
    }

    public void setCollectYear(String collectYear) {
        this.collectYear = collectYear;
    }

    public String getOffer() {
        return offer;
    }

    public void setOffer(String offer) {
        this.offer = offer;
    }

    public String getSafeAssess() {
        return safeAssess;
    }

    public void setSafeAssess(String safeAssess) {
        this.safeAssess = safeAssess;
    }

    public String getAnnexRes() {
        return annexRes;
    }

    public void setAnnexRes(String annexRes) {
        this.annexRes = annexRes;
    }

    public String getOutState() {
        return outState;
    }

    public void setOutState(String outState) {
        this.outState = outState;
    }

    public String getCompleteType() {
        return completeType;
    }

    public void setCompleteType(String completeType) {
        this.completeType = completeType;
    }

    public String getThickness() {
        return thickness;
    }

    public void setThickness(String thickness) {
        this.thickness = thickness;
    }

    public String getSearchNum() {
        return searchNum;
    }

    public void setSearchNum(String searchNum) {
        this.searchNum = searchNum;
    }

    public String getFileNum() {
        return fileNum;
    }

    public void setFileNum(String fileNum) {
        this.fileNum = fileNum;
    }

    public String getFixedAssetsNum() {
        return fixedAssetsNum;
    }

    public void setFixedAssetsNum(String fixedAssetsNum) {
        this.fixedAssetsNum = fixedAssetsNum;
    }

    public String getAssetsNum() {
        return assetsNum;
    }

    public void setAssetsNum(String assetsNum) {
        this.assetsNum = assetsNum;
    }

    public String getUnearthNum() {
        return unearthNum;
    }

    public void setUnearthNum(String unearthNum) {
        this.unearthNum = unearthNum;
    }

    public String getCollectingPlace() {
        return collectingPlace;
    }

    public void setCollectingPlace(String collectingPlace) {
        this.collectingPlace = collectingPlace;
    }

    public String getFormProperty() {
        return formProperty;
    }

    public void setFormProperty(String formProperty) {
        this.formProperty = formProperty;
    }

    public String getBore() {
        return bore;
    }

    public void setBore(String bore) {
        this.bore = bore;
    }

    public String getBottomDiameter() {
        return bottomDiameter;
    }

    public void setBottomDiameter(String bottomDiameter) {
        this.bottomDiameter = bottomDiameter;
    }

    public String getAbdominal() {
        return abdominal;
    }

    public void setAbdominal(String abdominal) {
        this.abdominal = abdominal;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    public String getStorehouse() {
        return storehouse;
    }

    public void setStorehouse(String storehouse) {
        this.storehouse = storehouse;
    }

    public String getSpecificPosition() {
        return specificPosition;
    }

    public void setSpecificPosition(String specificPosition) {
        this.specificPosition = specificPosition;
    }

    public String getProductPlace() {
        return productPlace;
    }

    public void setProductPlace(String productPlace) {
        this.productPlace = productPlace;
    }

    public Integer getSpecificTexture() {
        return specificTexture;
    }

    public void setSpecificTexture(Integer specificTexture) {
        this.specificTexture = specificTexture;
    }

    public String getStrikePrice() {
        return strikePrice;
    }

    public void setStrikePrice(String strikePrice) {
        this.strikePrice = strikePrice;
    }

    public String getCensusName() {
        return censusName;
    }

    public void setCensusName(String censusName) {
        this.censusName = censusName;
    }

    public String getImportationCountry() {
        return importationCountry;
    }

    public void setImportationCountry(String importationCountry) {
        this.importationCountry = importationCountry;
    }

    public String getCollectCode() {
        return collectCode;
    }

    public void setCollectCode(String collectCode) {
        this.collectCode = collectCode;
    }

    public String getInMsDt() {
        return inMsDt;
    }

    public void setInMsDt(String inMsDt) {
        this.inMsDt = inMsDt;
    }

    public String getCunJuan() {
        return cunJuan;
    }

    public void setCunJuan(String cunJuan) {
        this.cunJuan = cunJuan;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPackCondition() {
        return packCondition;
    }

    public void setPackCondition(String packCondition) {
        this.packCondition = packCondition;
    }

    public Date getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(Date checkDate) {
        this.checkDate = checkDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getCollectClass() {
        return collectClass;
    }

    public void setCollectClass(String collectClass) {
        this.collectClass = collectClass;
    }

    public String getBkNum() {
        return bkNum;
    }

    public void setBkNum(String bkNum) {
        this.bkNum = bkNum;
    }

    public String getNumUnit() {
        return numUnit;
    }

    public void setNumUnit(String numUnit) {
        this.numUnit = numUnit;
    }

    public Date getUpdateDt() {
        return updateDt;
    }

    public void setUpdateDt(Date updateDt) {
        this.updateDt = updateDt;
    }

    public String getUpdateuser() {
        return updateuser;
    }

    public void setUpdateuser(String updateuser) {
        this.updateuser = updateuser;
    }

    public String getCommitSave() {
        return commitSave;
    }

    public void setCommitSave(String commitSave) {
        this.commitSave = commitSave;
    }
}