package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.github.pagehelper.PageHelper;
import com.okay.common.util.MetadataUtil;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.StaffIntoStore;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.StaffIntoStoreService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/17 11:20
 * @Version: 1.0
 * @Description: 人员入库控制类.
 */

@RestController
@RequestMapping(value = "/intoStore")
public class StaffIntoStoreController {

    @Autowired
    private CollectCommonCodeService collectCommonService;
    @Autowired
    private StaffIntoStoreService staffIntoStoreService;

    /**
     * 查询列表初始化.
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initForm(){
        JSONObject jsonObject = new JSONObject();
        JSONArray storeHouseArr = collectCommonService.selectCollectStorehouseTree();
        jsonObject.put("storeOptions",storeHouseArr);
        jsonObject.put("code",1);
        return jsonObject;
    }

    /**
     * 页面初始化.
     * @return
     */
    @RequestMapping(value = "/initPage", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initPage(){
        return initForm();
    }

    /**
     * 列表数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        com.github.pagehelper.Page pageResult = getDataByPage(page);
        List<Map<String, Object>> dataList = resultDataHandle(pageResult);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data",dataList);
        jsonObject.put("pages",pageResult.getPages());
        jsonObject.put("total",pageResult.getTotal());
        jsonObject.put("pageSize",page.getPageSize());
        jsonObject.put("code",1);

        return jsonObject;
    }

    /**
     * 主键取信息.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value="/getById", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getById(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String id = jsonParam.getString("enterId");
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            StaffIntoStore staffIntoStore = staffIntoStoreService.findByEnterIdForBean(id);
            jsonObject.put("data",staffIntoStore);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息新增.
     * @param jsonParam
     * @return
     */
    @SysLog("人员入库-新增")
    @RequestMapping(value="/insert", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @PreAuthorize("@pms.hasPermission('SSM_ADD')")
    public JSONObject insertInfo(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        StaffIntoStore staffIntoStore = jsonParam.getObject("data",StaffIntoStore.class);
        try{
            if (staffIntoStore.getEnterPeopleName() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"入库人名"));
            }
            if (staffIntoStore.getStoreHouse() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"库房位置"));
            }
            if (staffIntoStore.getEnterTime() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"入库时间"));
            }
            if (staffIntoStore.getEnterGoal() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"入库目的"));
            }
            StaffIntoStore newPeopleInStore = staffIntoStoreService.insert(staffIntoStore);
            jsonObject.put("enterId",newPeopleInStore.getEnterId());
            throw new BaseRuntimeException(String.format(CollectErrorDefine.ADD_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 主键修改信息.
     * @param jsonParam
     * @return
     */
    @SysLog("人员入库-修改")
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject update(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        StaffIntoStore staffIntoStore = jsonParam.getObject("data",StaffIntoStore.class);
        try{
            if (DataUtil.isEmpty(staffIntoStore.getEnterId())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            if (staffIntoStore.getStoreHouse() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"库房位置"));
            }
            if (staffIntoStore.getEnterPeopleName() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"入库人名"));
            }
            if (staffIntoStore.getEnterTime() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"入库时间"));
            }
            if (staffIntoStore.getEnterGoal() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK,"入库目的"));
            }
            staffIntoStoreService.update(staffIntoStore);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.UPDATE_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 主键删除信息.
     * @param jsonParam
     * @return
     */
    @SysLog("人员入库-删除")
    @PreAuthorize("@pms.hasPermission('SSM_DEL')")
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject delete(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();

        String id = jsonParam.getString("enterId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            staffIntoStoreService.delete(id);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        String headerArray = "[" +
                "{'label':'入库人名','key':'enterPeopleName'}," +
                "{'label':'库房位置','key':'storeHouse_t'}," +
                "{'label':'入库目的','key':'enterGoal'}," +
                "{'label':'入库描述','key':'enterDescript'}," +
                "{'label':'入库时间','key':'enterTime'}," +
                "{'label':'出库时间','key':'outTime'}," +
                "{'label':'创建人','key':'createUser_t'}," +
                "{'label':'创建时间','key':'createTime'}," +
                "]";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("exportHeaderList", JSONArray.parseArray(headerArray));
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("人员入库-导出")
    @RequestMapping(value = "/exportHandle", method = RequestMethod.POST, produces = "application/json")
    @PreAuthorize("@pms.hasPermission('SSM_EXP')")
    public void exportHandle(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        try{
            Page page = jsonParam.getJSONObject("page").toJavaObject(Page.class);

            //导出类型 0:导出查询的全部数据 1: 当前页数据 2：选择的数据
            String exportType = jsonParam.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }
            if (exportType.equals("0")) {
                page.setPageSize(0);
                page.setPageNum(0);
            } else  if (exportType.equals("2")) {
                String enterId = String.valueOf(page.getConditionMap().get("enterId"));
                page.getConditionMap().put("enterIdList", Arrays.asList(enterId.split(",")));
            }

            //导出文件名
            String fileName = jsonParam.getString("exportFileName");
            if (DataUtil.isEmpty(fileName)) {
                fileName = "人员入库信息";
            }

            // 获取选择导出的列数据
            List headerNameList = new ArrayList();
            List headerKeyList = new ArrayList();
            JSONArray exportColumn = jsonParam.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            // 查询数据及结果处理
            com.github.pagehelper.Page pageResult = getDataByPage(page);
            List<Map<String,Object>> dataMapList = resultDataHandle(pageResult);
            nullToEmpty(dataMapList);

            // 根据选择导出列封装导出数据
            List<Object> exportDataList = new ArrayList<Object>();
            for (Map<String,Object> dataMap : dataMapList) {
                List<String> stringDataList = new ArrayList<String>();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = headerKeyList.get(j).toString();
                    String value = dataMap.get(key) == null ? "" : String.valueOf(dataMap.get(key));
                    stringDataList.add(value);
                }
                exportDataList.add(stringDataList);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, exportDataList);
            DataExportUtils.setResponseHeader(response, wb, fileName);
        }catch (Exception e){
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 获取列表数据.
     * @param page
     * @return
     */
    public com.github.pagehelper.Page getDataByPage(Page page){

        com.github.pagehelper.Page pageResult = null;

        Map<String, Object> conditionMap = new HashMap<String,Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询时间
                Object timeObject = conditionMap.get("enterTime");
                if (timeObject != null && !"".equals(timeObject)) {
                    ArrayList<String> enterTime = (ArrayList)timeObject;
                    if (null != enterTime && !"".equals(enterTime)) {
                        if (enterTime.size() == 2) {
                            conditionMap.put("eStartTime", enterTime.get(0));
                            conditionMap.put("eEndTime", enterTime.get(1));
                        }
                    }
                }
                timeObject = conditionMap.get("outTime");
                if (timeObject != null && !"".equals(timeObject)) {
                    ArrayList<String> outTime = (ArrayList)timeObject;
                    if (null != outTime && !"".equals(outTime)) {
                        if (outTime.size() == 2) {
                            conditionMap.put("oStartTime", outTime.get(0));
                            conditionMap.put("oEndTime", outTime.get(1));
                        }
                    }
                }
            }
            // 查询
            try(com.github.pagehelper.Page pages = PageHelper.startPage(page.getPageNum(), page.getPageSize(), true)) {
                pageResult = pages;
                staffIntoStoreService.findDataListForBean(conditionMap);
            }
        }
        return pageResult;
    }

    /**
     * 列表数据结果处理.
     * @param pageResult
     * @return
     */
    public List<Map<String, Object>> resultDataHandle(com.github.pagehelper.Page pageResult){
        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < pageResult.size(); i++) {
            StaffIntoStore staffIntoStore = (StaffIntoStore)pageResult.get(i);
            // 实体转Map
            String jsonString = JSONObject.toJSONStringWithDateFormat(staffIntoStore, "yyyy-MM-dd HH:mm:ss", SerializerFeature.WriteNullStringAsEmpty);
            Map<String, Object> dataMap = JSONObject.parseObject(jsonString);

            if (staffIntoStore != null) {
                String storeHouse = String.valueOf(staffIntoStore.getStoreHouse());
                dataMap.put("storeHouse_t", collectCommonService.storehouse_t(storeHouse));

                // 创建人
                String username= MetadataUtil.getMetadataModel().getUserName(Integer.parseInt(staffIntoStore.getCreateUser()));
                if (username != null) {
                    dataMap.put("createUser_t", username);
                }
            }
            dataList.add(dataMap);
        }
        return dataList;
    }

    public List<Map<String, Object>> nullToEmpty(List<Map<String, Object>> mapList) {
        for (int i = 0; i < mapList.size(); i++) {
            Map<String,Object> map = mapList.get(i);
            Set<String> keySet = map.keySet();
            if (keySet != null && !keySet.isEmpty()) {
                for (String key : keySet) {
                    if (map.get(key) == null || "null".equals(map.get(key))) {
                        map.put(key, "");
                    }
                }
            }
        }
        return mapList;
    }
}
