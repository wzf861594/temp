package com.okay.cp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class AgainEditRecord {
    private String recordId;

    private String collectId;

    private String initiator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date initiatDt;

    private String againEditOpinion;

    private Date creatDt;

    private String initiator_t;

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getCollectId() {
        return collectId;
    }

    public void setCollectId(String collectId) {
        this.collectId = collectId;
    }

    public String getInitiator() {
        return initiator;
    }

    public void setInitiator(String initiator) {
        this.initiator = initiator;
    }

    public Date getInitiatDt() {
        return initiatDt;
    }

    public void setInitiatDt(Date initiatDt) {
        this.initiatDt = initiatDt;
    }

    public String getAgainEditOpinion() {
        return againEditOpinion;
    }

    public void setAgainEditOpinion(String againEditOpinion) {
        this.againEditOpinion = againEditOpinion;
    }

    public Date getCreatDt() {
        return creatDt;
    }

    public void setCreatDt(Date creatDt) {
        this.creatDt = creatDt;
    }

    public String getInitiator_t() {
        return initiator_t;
    }

    public void setInitiator_t(String initiator_t) {
        this.initiator_t = initiator_t;
    }
}