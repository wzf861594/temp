package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.okay.cp.baseBusiness.SolictBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.ClueFollow;
import com.okay.cp.entity.ClueLog;
import com.okay.cp.service.ClueFollowService;
import com.okay.cp.service.ClueLogService;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/9/19 9:54
 * @Version: 1.0
 * @Description: java类作用描述
 */

@RestController
@RequestMapping(value = "/clueFollow")
public class SolicitClueFollowController extends SolictBaseBusiness {

    @Autowired
    private ClueFollowService clueFollowService;
    @Autowired
    private ClueLogService clueLogService;
    @Autowired
    private UserService userService;
    @Autowired
    private CollectCommonCodeService collectCommonService;


    /**
     * 查询列表初始化.
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initForm(){
        JSONObject jsonObject = new JSONObject();
        JSONArray sourceOptions = collectCommonService.sourceOptions();
        jsonObject.put("sourceOptions",sourceOptions);
        jsonObject.put("code",1);
        return jsonObject;
    }

    /**
     * 线索列表数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();

        com.github.pagehelper.Page pageResult = getDataByPage(page);
        pageResult = resultDataHandle(pageResult);

        jsonObject.put("data",pageResult);
        jsonObject.put("pages",pageResult.getPages());
        jsonObject.put("total",pageResult.getTotal());
        jsonObject.put("pageSize",page.getPageSize());
        jsonObject.put("code",1);

        return jsonObject;
    }

    /**
     * 线索进度终止.
     * @param jsonParam
     * @return
     */
    @SysLog("线索跟踪终止")
    @RequestMapping(value = "/breakUp", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @PreAuthorize("@pms.hasPermission('SCF_TERMINATION')")
    public JSONObject breakUp(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String confirmFlg = jsonParam.getString("confirmFlg");
            ClueFollow clueFollow = jsonParam.getJSONObject("data").toJavaObject(ClueFollow.class);
            if (DataUtil.isEmpty(clueFollow.getFollowId())) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(clueFollow.getBreakReason())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR,"终止原因"));
            }
            if (clueFollow.getBreakTime() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR,"终止时间"));
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_STOP);
            }
            clueFollow.setFollowState(2);
            clueFollowService.update(clueFollow);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.BREAKUP_SUCCESS));

        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 线索进度完成.
     * @param jsonParam
     * @return
     */
    @SysLog("线索完成跟踪")
    @RequestMapping(value = "/finish", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @PreAuthorize("@pms.hasPermission('SCF_COMPLETE')")
    public JSONObject finish(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String id = jsonParam.getString("followId");
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_FINISH_FOLLOW);
            }
            List<String> idList = new ArrayList<>(Arrays.asList(id.split(",")));
            Map<String,Object> updateMap = new HashMap<String,Object>();
            updateMap.put("followState",1);
            updateMap.put("idList",idList);
            int handleNum = clueFollowService.update(updateMap);
            if (handleNum != idList.size()) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.COMMIT_ERR));
            }else {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.COMMIT_SUCCESS));
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 日志添加.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/addLog", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject addLog(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String id = jsonParam.getString("clueId");
            ClueLog clueLog = jsonParam.getJSONObject("data").toJavaObject(ClueLog.class);
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (clueLog.getHandleUser() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR,"经办人"));
            }
            if (clueLog.getHandleTime() == null) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR,"经办时间"));
            }
            if (DataUtil.isEmpty(clueLog.getLogContent())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR,"跟踪日志"));
            }
            clueLogService.add(clueLog,id);
            throw new BaseRuntimeException(CollectErrorDefine.ADD_SUCCESS);

        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     *  日志列表.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getLog", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getLog(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String clueId = jsonParam.getString("clueId");

        List<Map<String, Object>> clueLogList = new ArrayList<Map<String, Object>>();
        if (!DataUtil.isEmpty(clueId)) {
            Map<String,Object> queryMap = new HashMap<String,Object>();
            queryMap.put("clueId",clueId);
            clueLogList = clueLogService.findDataList(queryMap);
        }
        jsonObject.put("data",clueLogList);
        jsonObject.put("code",1);

        return jsonObject;
    }

    /**
     * 日志内容编辑
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getInfoById", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getInfo(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        String logId = jsonParam.getString("logId");

        ClueLog clueLog = null;
        if (!DataUtil.isEmpty(logId)) {
            clueLog = clueLogService.selectByPrimaryKey(logId);
        }
        jsonObject.put("data",clueLog);
        jsonObject.put("code",1);

        return jsonObject;
    }

    /**
     * 日志内容修改.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject updateLog(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            ClueLog clueLog = jsonParam.getJSONObject("data").toJavaObject(ClueLog.class);
            clueLogService.modify(clueLog);
            throw new BaseRuntimeException(CollectErrorDefine.UPDATE_SUCCESS);

        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 日志删除.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject deleteLog(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String id = jsonParam.getString("logId");
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            clueLogService.remove(id);
            throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);

        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 根据followId查询.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getByFollowId", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getByFollowId(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String id = jsonParam.getString("followId");
            ClueFollow clueFollow = new ClueFollow();
            if (!DataUtil.isEmpty(id)) {
                clueFollow = clueFollowService.findById(id);
            }
            jsonObject.put("data",clueFollow);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {

        String headerArray = "[" +
                "{'label':'线索名称','key':'cluesName'}," +
                "{'label':'线索编码','key':'cluesCode'}," +
                "{'label':'线索来源','key':'cluesSource_t'}," +
                "{'label':'文物类别','key':'culturalType_t'}," +
                "{'label':'文物年代','key':'culturalAge_t'}," +
                "{'label':'具体年代','key':'specificAge'}," +
                "{'label':'联系人','key':'linkPeople'}," +
                "{'label':'联系电话','key':'linkTel'}," +
                "{'label':'指派人','key':'creatUser_t'}," +
                "{'label':'指派时间','key':'assignTime'}," +
                "{'label':'跟踪人','key':'assignUser_t'}" +
                "]";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("exportHeaderList", JSONArray.parseArray(headerArray));
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("线索跟踪导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
//    @PreAuthorize("@pms.hasPermission('SCF_EXP')")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {

        try{
            Page page = jsonParam.getJSONObject("page").toJavaObject(Page.class);

            //导出类型 0:导出查询的全部数据 1: 当前页数据 2：选择的数据
            String exportType = jsonParam.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }
            if (exportType.equals("0")) {
                page.setPageSize(0);
                page.setPageNum(0);
            } else  if (exportType.equals("2")) {
                String cluesId = String.valueOf(page.getConditionMap().get("cluesId"));
                page.getConditionMap().put("cluesIdList",Arrays.asList(cluesId.split(",")));
            }

            //导出文件名
            String fileName = jsonParam.getString("exportFileName");
            if (DataUtil.isEmpty(fileName)) {
                fileName = "线索信息跟踪";
            }

            // 获取选择导出的列数据
            List headerNameList = new ArrayList();
            List headerKeyList = new ArrayList();
            JSONArray exportColumn = jsonParam.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            // 查询数据及结果处理
            com.github.pagehelper.Page pageResult = getDataByPage(page);
            List<Map<String,Object>> dataMapList = resultDataHandle(pageResult);

            // 根据选择导出列封装导出数据
            List<Object> exportDataList = new ArrayList<Object>();
            for (Map<String,Object> dataMap : dataMapList) {
                List<String> stringDataList = new ArrayList<String>();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = headerKeyList.get(j).toString();
                    String value = dataMap.get(key) == null ? "" : String.valueOf(dataMap.get(key));
                    stringDataList.add(value);
                }
                exportDataList.add(stringDataList);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, exportDataList);
            DataExportUtils.setResponseHeader(response, wb, fileName);
        }catch (Exception e){
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 数据查询.
     * @param page
     * @return
     */
    public com.github.pagehelper.Page getDataByPage(Page page){
        com.github.pagehelper.Page pageResult = null;
        Map<String,Object> conditionMap = new HashMap<String,Object>();
        if (page != null){
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 当前用户
                User loginUser = userService.getLoginUser();
                if (loginUser != null) {
                    String loginUserId = loginUser.getUserId();
                    conditionMap.put("followUser",loginUserId);
                }
                // 查询状态
                String state = String.valueOf(conditionMap.get("followState"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("followState","0");
                }
                // 查询时间
                Object object = conditionMap.get("creatTime");
                if (object != null && !"".equals(object)) {
                    ArrayList<String> creatTime = (ArrayList)object;
                    if (creatTime.size() == 2) {
                        conditionMap.put("startCreatTime", creatTime.get(0));
                        conditionMap.put("endCreatTime", creatTime.get(1));
                    }
                }
            }
        }

        // 查询
        try(com.github.pagehelper.Page pages = PageHelper.startPage(page.getPageNum(), page.getPageSize(), true)) {
            pageResult = pages;
            clueFollowService.findDataList(conditionMap);
        }
        return pageResult;
    }

    /**
     * 查询结果处理.
     * @param pageResult
     * @return
     */
    public com.github.pagehelper.Page resultDataHandle(com.github.pagehelper.Page pageResult){
        for (int i = 0; i < pageResult.size(); i++) {
            Map<String,Object> dataMap = (Map<String,Object>)pageResult.get(i);
            if (dataMap != null) {
                // 年代处理
                String yearId = String.valueOf(dataMap.get("culturalAge"));
                String yearName = getYearName(yearId);
                dataMap.put("culturalAge_t",yearName);

                // 踪人员处理
                String userId = String.valueOf(dataMap.get("assignUser"));
                String userName = getUserName(userId);
                dataMap.put("assignUser_t", userName);

                // 来源方式
                String name = collectCommonService.source_t(String.valueOf(dataMap.get("cluesSource")));
                dataMap.put("cluesSource_t",name);

                // 创建人
                dataMap.put("creatUser_t", getUserName(String.valueOf(dataMap.get("creatUser"))));

                // 指派时间
                SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                if (dataMap.get("assignTime") != null) {
                    dataMap.put("assignTime", sDateFormat.format(dataMap.get("assignTime")));
                }
            }
        }
        return pageResult;
    }
}
