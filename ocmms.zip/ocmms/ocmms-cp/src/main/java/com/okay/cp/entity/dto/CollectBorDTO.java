package com.okay.cp.entity.dto;

import com.okay.cp.entity.CollectBor;
import com.okay.cp.entity.CollectBorList;
import lombok.Data;

import java.util.List;

/**
 * @author CZJ[OKAY]
 * @date 2021/1/25 11:56
 * @description 藏品提借dto
 **/
@Data
public class CollectBorDTO extends CollectBor {

    /**
     * 藏品提借清单明细
     */
    List<CollectBorList> collectList;


}
