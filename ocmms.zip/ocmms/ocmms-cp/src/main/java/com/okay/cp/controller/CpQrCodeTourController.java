package com.okay.cp.controller;


import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.cp.entity.dto.CpQrCodeTourDTO;
import com.okay.cp.entity.dto.CpQrCodeTourPageDTO;
import com.okay.cp.service.CpQrCodeTourService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author CZJ[OKAY]
 * @date 2021-12-15 10:42:23
 * @description 二维码导览表Controller
 **/
@RestController
@AllArgsConstructor
@Api(tags = "二维码导览表")
@RequestMapping(value = "/qrCodeTour")
public class CpQrCodeTourController {

    private final CpQrCodeTourService qrCodeTourService;

    /**
     * 新增
     *
     * @param dto 记录数据
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/insert")
    @ApiOperation(value = "新增")
    public R insert(@Validated CpQrCodeTourDTO dto) {
        return R.ok(qrCodeTourService.insert(dto));
    }

    /**
     * 根据ID修改
     *
     * @param dto 记录数据
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/updateById")
    @ApiOperation(value = "根据ID修改")
    public R updateById(@Validated CpQrCodeTourDTO dto) {
        return R.ok(qrCodeTourService.updateById(dto));
    }

    /**
     * 根据ID删除
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/deleteById")
    @ApiOperation(value = "根据ID删除")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R deleteById(@RequestParam(value = "id") String id) {
        return R.ok(qrCodeTourService.deleteById(id));
    }

    /**
     * 根据ID获取记录基本信息
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @GetMapping(value = "/getById")
    @ApiOperation(value = "根据ID获取记录基本信息")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R getById(@RequestParam(value = "id") String id) {
        return R.ok(qrCodeTourService.getById(id)).setMsg("");
    }

    /**
     * 获取记录列表
     *
     * @param dto  查询条件
     * @param page 分页信息
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/listAll")
    @ApiOperation(value = "获取记录列表")
    public R listAll(Page page, CpQrCodeTourDTO dto) {
        return R.ok(qrCodeTourService.listAll(page, dto)).setMsg("");
    }

    /**
     * 小程序获取记录列表
     *
     * @param pageDTO 查询条件
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/miniList")
    @ApiOperation(value = "获取记录列表")
    public R miniList(@RequestBody CpQrCodeTourPageDTO pageDTO) {
        CpQrCodeTourDTO dto = new CpQrCodeTourDTO();
        dto.setCollectCode(pageDTO.getCollectCode());
        dto.setCollectName(pageDTO.getCollectName());
        dto.setStatus(2);
        Page page = new Page(pageDTO.getCurrent(), pageDTO.getSize());
        return R.ok(qrCodeTourService.listAll(page, dto)).setMsg("");
    }

    /**
     * 发布藏品到小程序
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @GetMapping(value = "/release")
    @ApiOperation(value = "发布藏品到小程序")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R release(@RequestParam(value = "id") String id) {
        return R.ok(qrCodeTourService.updateStatus(id, 2)).setMsg("发布成功");
    }

    /**
     * 下架藏品
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @GetMapping(value = "/takeDown")
    @ApiOperation(value = "下架藏品")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R takeDown(@RequestParam(value = "id") String id) {
        return R.ok(qrCodeTourService.updateStatus(id, 1)).setMsg("下架成功");
    }
}