package com.okay.cp.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.cp.entity.Age;
import com.okay.cp.service.AgeService;
import com.okay.framework.controller.BaseController;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;

/**
 * @ClassName: AgeController
 * @Description: 类描述信息
 * @author: HQ.ZHU
 * @date: 2019-10-28 11:20
 * @version: V1.0
 */
@RestController
@RequestMapping("/age")
public class AgeController extends BaseController {

    @Autowired
    private AgeService ageService;

    @GetMapping("/dataTree")
    public JSONObject getDataTree(){
        JSONObject jsonObject = new JSONObject();
        try{
            List<Age> data = ageService.findDataTree();
            jsonObject.put("code", 1);
            jsonObject.put("data", data);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 增加
     * @param age
     * @return
     */
    @SysLog("藏品年代-新增")
    @PostMapping("/add")
    public JSONObject addData(@RequestBody @Valid Age age){
        JSONObject jsonObject = new JSONObject();
        try{
            age.setAgeId(getSequence());
            age.setCreatUser(getLoginUser().getUserId());
            age.setCreatTime(new Date());
            ageService.addData(age);

            jsonObject.put("data", age);
            jsonObject.put("code", 1);
            jsonObject.put("msg", "添加成功");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 删除
     * @param age
     * @return
     */
    @SysLog("藏品年代-删除")
    @PostMapping("/remove")
    public JSONObject removeData(@RequestBody Age age){
        JSONObject jsonObject = new JSONObject();
        try{
            ageService.removeData(age);
            jsonObject.put("code", 1);
            jsonObject.put("msg", "删除成功");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 修改
     * @param age
     * @return
     */
    @SysLog("藏品年代-修改")
    @PostMapping("/modify")
    public JSONObject modifyData(@RequestBody @Valid Age age){
        JSONObject jsonObject = new JSONObject();
        try{
            ageService.modify(age);
            jsonObject.put("code", 1);
            jsonObject.put("msg", "修改成功");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 年代树拖拽保存.
      *@Return :
      **/
    @SysLog("藏品年代-年代树拖拽修改")
    @PostMapping("/dragModify")
    public JSONObject dragModify(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            String ageId = jsonParam.getString("ageId");
            String parentId = jsonParam.getString("parentId");

            ageService.dragModify(ageId,parentId);
            jsonObject.put("code", 1);
            //jsonObject.put("msg", "修改成功");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }
}
