package com.okay.cp.entity.dto;

import com.okay.cp.entity.CpCommittee;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * 征集委员DTO
 * @author WZF[OKAY]
 * @date 2021-11-22 20:29:01
 */
@Data
@ApiModel(value = "征集委员DTO")
public class CpCommitteeDTO extends CpCommittee {
    private String chineseName;
    private String phone;
}