package com.okay.cp.controller;


import cn.afterturn.easypoi.excel.entity.TemplateExportParams;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.baseBusiness.InventoryBaseBusiness;
import com.okay.cp.service.InventoryListService;
import com.okay.cp.service.InventoryService;
import com.okay.cp.utils.EasyPoiExportUtils;
import com.okay.framework.entity.Page;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/11 15:20
 * @Version: 1.0
 * @Description: 藏品盘点完成控制器
 */

@RestController
@RequestMapping(value = "/after")
public class InventoryAfterController extends InventoryBaseBusiness {
    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private InventoryListService inventoryListService;

    /**
     * 查询列表初始化.
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initList(){
        return initData();
    }

    /**
     * 列表数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        Map<String,Object> conditionMap = new HashMap<String,Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询状态
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state","0");
                }
            }
        }
        // 在线用户
//        User user = ComUtils.getLoginUser();
//        conditionMap.put("inventoryObj", user.getUserId());

        return getDataList(page);
    }

    /**
     * 获取基本数据.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam){
        return getDataById(jsonParam);
    }

    /**
     * 获取盘点明细数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/getByQuery", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getByQuery(@RequestBody Page page){
        return getInventoryListByQuery(page);
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        return initExportHeader();
    }

    /**
     * 盘点报告导出.
     * @param jsonParam
     * @param response
     */
    @RequestMapping(value = "/inventoryReport", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public void inventoryReport(@RequestBody JSONObject jsonParam,HttpServletResponse response) {
        try {
            response.setCharacterEncoding("UTF-8");

            // 获取模板文件路径，easypoi的API只能接收文件路径，无法读取文件流
            String templateFilePath = "temp/InventoryResultExportTemp.xls";

            // 导出模板参数
            TemplateExportParams templateParams = new TemplateExportParams();
            templateParams.setTemplateUrl(templateFilePath);// 设置模板路径

            // 获取报表内容
            List<Map<String, Object>> dataList =  getInventoryExportData(jsonParam);

            EasyPoiExportUtils.batchExportToZip(templateParams, dataList,"盘点单报告_" + DateUtil.getNextTime() +".zip", response);

            // 导出同一个excel
            //Map<Integer, List<Map<String, Object>>> dataList =  getInventoryExportDataClone(jsonParam);
            //Workbook workbook = ExcelExportUtil.exportExcelClone(dataList, templateParams);
            //EasypoiExportExcelUtil.clientResponse(response,workbook,"盘点单报告_" + DateUtil.getNextTime() +".xls","");

        } catch (Exception e) {
            e.printStackTrace();
            try {
                response.sendError(500,e.getMessage());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
}
