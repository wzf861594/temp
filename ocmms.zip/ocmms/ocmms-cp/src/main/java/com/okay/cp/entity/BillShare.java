package com.okay.cp.entity;

import java.util.Date;

public class BillShare {
    private String shareId;

    private String billId;

    private Date shareDate;

    private String shareUser;

    private String shareObject;

    public String getShareId() {
        return shareId;
    }

    public void setShareId(String shareId) {
        this.shareId = shareId;
    }

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId;
    }

    public Date getShareDate() {
        return shareDate;
    }

    public void setShareDate(Date shareDate) {
        this.shareDate = shareDate;
    }

    public String getShareUser() {
        return shareUser;
    }

    public void setShareUser(String shareuser) {
        this.shareUser = shareuser;
    }

    public String getShareObject() {
        return shareObject;
    }

    public void setShareObject(String shareObject) {
        this.shareObject = shareObject;
    }
}