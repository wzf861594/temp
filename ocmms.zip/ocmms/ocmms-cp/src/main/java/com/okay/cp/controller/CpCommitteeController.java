package com.okay.cp.controller;

import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.cp.entity.dto.CpCommitteeDTO;
import com.okay.cp.service.CpCommitteeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author WZF[OKAY]
 * @date 2021-11-22 20:29:01
 * @description 征集委员Controller
 **/
@RestController
@AllArgsConstructor
@Api(tags = "征集委员")
@RequestMapping(value = "/committee")
public class CpCommitteeController {

    private final CpCommitteeService cpCommitteeService;
    
     /**
     * 新增
     *
     * @param dto 记录数据
     * @return R
     * @author WZF[OKAY]
     **/
    @PostMapping(value = "/insert")
    @ApiOperation(value = "新增")
    public R insert(@RequestBody CpCommitteeDTO dto) {
        return R.ok(cpCommitteeService.insert(dto));
    }
    
     /**
     * 根据ID修改
     *
     * @param dto 记录数据
     * @return R
     * @author WZF[OKAY]
     **/
    @PostMapping(value = "/updateById")
    @ApiOperation(value = "根据ID修改")
    public R updateById(@RequestBody CpCommitteeDTO dto) {
        return R.ok(cpCommitteeService.updateById(dto));
    }
    
    /**
     * 根据ID删除
     *
     * @param id 主键
     * @return R
     * @author WZF[OKAY]
     **/
    @PostMapping(value = "/deleteById")
    @ApiOperation(value = "根据ID删除")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R deleteById(@RequestParam(value = "id") String id) {
        return R.ok(cpCommitteeService.deleteById(id));
    }
    
     /**
     * 根据ID获取记录基本信息
     *
     * @param id 主键
     * @return R
     * @author WZF[OKAY]
     **/
    @GetMapping(value = "/getById")
    @ApiOperation(value = "根据ID获取记录基本信息")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R getById(@RequestParam(value = "id") String id) {
        return R.ok(cpCommitteeService.getById(id)).setMsg("");
    }
    
     /**
     * 获取记录列表
     *
     * @param dto  查询条件
     * @param page 分页信息
     * @return R
     * @author WZF[OKAY]
     **/
    @PostMapping(value = "/listAll")
    @ApiOperation(value = "获取记录列表")
    public R listAll(Page page, CpCommitteeDTO dto) {

        return R.ok(cpCommitteeService.getAllCommittee(page, dto)).setMsg("");
    }

    /**
     * 根据ID获取记录基本信息
     *
     * @return R
     * @author WZF[OKAY]
     **/
    @GetMapping(value = "/getByUserId")
    @ApiOperation(value = "根据UserId获取记录基本信息")
    @ApiImplicitParams({@ApiImplicitParam(name = "userId", value = "主键", required = true)})
    public R getByUserId(@RequestParam(value = "userId") String userId) {
        return R.ok(cpCommitteeService.getByUserId(userId)).setMsg("");
    }
}