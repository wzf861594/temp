package com.okay.cp.constant;

/***
 * 数字资源错误定义
 * 错误代码由 固定3位数+n位 构成
 * 错误代码的组成为：模块代码(2位)+错误级别(1位)+错误代码(n位)
 * 模块代码(2位)：
 * 01 门户
 * 02 数字资源
 * 03 藏品
 * 04 OA
 * 05 框架
 * 06 流程引擎
 * 07 自定义表单
 * 错误级别(1位)：
 * 1 正常
 * 2 警告
 * 3 询问
 * 4 错误
 * 错误代码(n位) ：
 * 可自行定义
 */
public class CollectErrorDefine {

    //--------------------通用信息message 公共序列号 1——100
    /*成功结果 code = 1的提示信息*/
    public static final String UPDATE_SUCCESS = "【0311】更新成功！";
    public static final String COMMIT_SUCCESS = "【0312】提交成功！";
    public static final String DELETE_SUCCESS = "【0313】删除成功！";
    public static final String UPLOAD_SUCCESS = "【0314】上传成功！";
    public static final String PUBLIC_SUCCESS = "【0315】发布成功！";
    public static final String CANCEL_SUCCESS = "【0316】撤销成功！";
    public static final String PASS_SUCCESS = "【0317】审核成功！";
    public static final String REBUT_SUCCESS = "【0318】驳回成功！";
    public static final String ADD_SUCCESS = "【0319】添加成功！";
    public static final String SAVE_SUCCESS = "【03110】保存成功！";
    public static final String STOP_SUCCESS = "【03111】终止成功！";
    public static final String SYNCHRONOU_SUCCESS = "【03112】同步成功！";

    /*警告 code = 2 的提示信息*/
    public static final String NOTNULL_CHECK = "【03230】%s 为必填项！";
    public static final String CHOOSE_HANDLE_DATA = "【03231】请选择操作数据！";
    public static final String DATE_FORMAT = "【03232】%s日期格式不正确！";
    public static final String DATE_SCOPE = "【03233】%s开始时间不能大于结束时间！";
    public static final String PARAMETER_NOTNULL = "【03234】%s不能为空！";
    public static final String CHAR_CHECK = "【03235】%s出现非法字符！";
    public static final String SELECT_RESULT_NULL = "【03236】查询结果为空！";
    public static final String HANDLE_DATA_NULL = "【03237】信息不存在！";
    public static final String PARAMETER_MISTAKE = "【03238】%s参数不正确！";
    public static final String INPUT_NAME_REPEAT = "【03239】名称重复！";
    public static final String INPUT_NUMBER_REPEAT = "【03240】%s 已存在！";

    /*询问 code = 3 的提示信息*/
    public static final String ASK_HANDLE_UPDATE = "【03370】是否更新？";
    public static final String ASK_HANDLE_DEL = "【03371】%s是否删除？";
    public static final String ASK_HANDLE_COMMIT = "【03372】是否提交？";
    public static final String ASK_HANDLE_PUBLIC = "【03373】是否发布？";
    public static final String ASK_HANDLE_CANCEL = "【03374】是否撤销？";
    public static final String ASK_AUDITING_PASS = "【03375】确定通过？";
    public static final String ASK_AUDITING_REBUT = "【03376】确定驳回？";
    public static final String ASK_HANDLE_STOP = "【03377】确定终止？";
    public static final String ASK_HANDLE_END = "【03378】是否办结？";

    /*错误 code = 4 的提示信息*/
    public static final String UPDATE_ERR = "【03480】更新失败！";
    public static final String COMMIT_ERR = "【03481】提交失败！";
    public static final String DELETE_ERR = "【03482】删除失败！";
    public static final String PUBLIC_ERR = "【03483】发布失败！";
    public static final String CANCEL_ERR = "【03484】撤销失败！";
    public static final String PASS_ERR = "【03485】审核失败！";
    public static final String REBUT_ERR = "【03486】驳回失败！";
    public static final String UPLOAD_ERR = "【03487】上传失败！";
    public static final String ADD_ERR = "【03488】添加失败！";
    public static final String SAVE_ERR = "【03489】保存失败！";
    public static final String STOP_ERR = "【03490】终止失败！";


    //以下自定义信息
    /*------------------zmz:序列位数  101— 200   -------------------*/

    public static final String PARAM_CHECK_FAIL = "【032101】 %s参数校验失败，请检查！";
    public static final String OUT_OVERNUMBER_FAIL = "【032102】超过最大出库数量！";
    public static final String BACK_OVERNUMBER_FAIL = "【032103】超过最大归库数量！";
    public static final String BORCOUNT_OVERNUMBER_FAIL = "【032104】%s超过最大提借数量！";
    public static final String ILLEGAL_TIMESECTION_FAIL = "【032105】%s开始时间不能大于结束时间！";

    public static final String ASK_HANDLE_OUT = "【033101】是否出库？";
    public static final String ASK_HANDLE_BACK = "【033102】是否归库？";

    //流程提交提示信息
    public static final String ASK_HANDLE_START = "【033103】是否发起？";
    public static final String ASK_HANDLE_REBUT = "【033104】是否驳回？";
    public static final String ASK_HANDLE_NULLFY = "【033105】是否作废？";

    public static final String OUT_ERROR = "【034101】出库失败！";
    public static final String BACK_ERROR = "【034102】归库失败！";

    public static final String LTOREQ_ZERO_FAIL = "【033106】%s必须大于零！";

    /*------------------xdn:序列位数  201— 400   -------------------*/
    /** 成功结果 code = 1  (201 - 250)的提示信息 */
    /** 警告 code = 2 (251 - 299)的提示信息 */
    /** 询问 code = 3 (300 - 350)的提示信息 */
    /**错误 code = 4 (351 - 399)的提示信息 */

    public static final String ASSIGN_SUCCESS = "【031201】指派成功！";
    public static final String BREAKUP_SUCCESS = "【031202】终止成功！";
    public static final String COPY_SUCCESS = "【031203】清单复制成功！";
    public static final String SHARE_SUCCESS = "【031204】共享成功！";
    public static final String CANCEL_SHARE_SUCCESS = "【031205】取消共享成功！";
    public static final String RECOVER_DELETE_SUCCESS = "【031206】数据恢复成功！";
    public static final String SOLICIT_BOKU_SUCCESS = "【031207】拨库成功！";
    public static final String CANCEL_ASSOCIATE_SUCCESS = "【031208】取消关联成功！";
    public static final String ABANDON_SUCCESS = "【031209】作废成功！";

    public static final String NOT_DATA_ERROR = "【032251】请填写%s！";
    public static final String CHOOSE_DATA_ERROR = "【032252】请选择%s！";
    public static final String EXIST_NOT_FINISH_ERROR = "【032253】存在%s的数据！";
    public static final String ONE_NOT_USER_ERROR = "【032254】该线索未添加指派人！";
    public static final String NOT_FINISH_ERROR = "【032255】未完成鉴定信息！";
    public static final String NOT_PASS_ERROR = "【032256】信息鉴定不通过！";
    public static final String NOT_ATTACH_ERROR = "【032257】未关联合同附件！";
    public static final String DATA_NOT_SHARE_ERROR = "【032258】清单未共享！";
    public static final String RECOVER_ERROR = "【032259】使用的列表数据已满，无法恢复数据！";
    public static final String NOT_RESULT_ERROR = "【032260】%s存在未盘点的藏品！";
    public static final String NOT_UNUSUAL_INFO_ERROR = "【032261】请填写异常信息！";

    public static final String ASK_CANCEl_SHARE = "【033301】是否取消共享？";
    public static final String ASK_RECOVER_DELETE = "【033302】是否恢复删除数据？";
    public static final String ASK_CANCEL_ASSOCIATE = "【033303】是否取消关联？";
    public static final String ASK_FINISH_FOLLOW = "【033304】是否完成跟踪？";
    public static final String ASK_ABANDON= "【033305】是否作废？";
    public static final String ASK_BOKU= "【033306】确定拨库？";
    public static final String ASK_ASSIGN= "【033307】确定指派？";

    public static final String ASSIGN_FAIL = "【034351】指派失败！";
    public static final String BREAKUP_FAIL = "【034352】终止失败！";
    public static final String COPY_FAIL = "【034353】清单复制失败！";
    public static final String SHARE_FAIL = "【034354】清单共享失败！";
    public static final String CANCEL_SHARE_FAIL = "【034355】取消共享失败！";
    public static final String RECOVER_DELETE_FAIL = "【034356】数据恢复失败！";
    public static final String SOLICIT_BOKU_FAIL = "【034357】拨库失败！";
    public static final String CANCEL_ASSOCIATE_FAIL = "【034358】取消关联失败！";
    public static final String ABANDON_FAIL = "【034359】作废失败！";



    /*------------------zyx:序列位数  401— 600   -------------------*/
    /*成功结果 code = 1  (401 - 450)的提示信息*/
    public static final String PASS_PUBLIC_SUCCESS = "【031401】通过并发布成功！";
    public static final String USE_SUCCESS = "【031402】使用成功！";
    public static final String AGAIN_EDIT_SUCCESS = "【031403】已提交重编目";

    /*警告 code = 2 (451 - 500)的提示信息*/
    public static final String FILE_NOT_SUPPORT = "【032451】不支持当前文件格式！";
    public static final String LABELLING_CHECK = "【032452】标签内容为空！";
    public static final String GROUP_NOT_DATA = "【032453】请选择关联藏品！";
    public static final String PLEASE_SAVE_DATA = "【032454】请先保存数据再关联！";
    public static final String PLEASE_SELECT_CANCEL_DATA = "【032455】请选择注销藏品！";
    public static final String PLEASE_INPUT_CANCEL_NUM = "【032456】请填写注销登记号！";
    public static final String PLEASE_INPUT_CANCEL_APPROVE_NUM = "【032457】请填写注销批准文号！";
    public static final String PLEASE_INPUT_CANCEL_WHERE = "【032458】请填写注销批去向！";
    public static final String PLEASE_INPUT_CANCEL_APPROVE_USER = "【032459】请填写注销批准人！";
    public static final String PLEASE_INPUT_CANCEL_DATE = "【032460】请填写注销日期！";
    public static final String PLEASE_INPUT_CANCEL_UNIT = "【032461】请填写注销批准单位！";



    /*询问 code = 3 (501 - 550)的提示信息*/
    public static final String AUDITING_PASS_PUBLIC = "【033501】确定审核通过并发布？";
    public static final String ASK_AGAIN_EDIT = "【033502】确定重编目，藏品会被撤销发布。";
    public static final String ASK_AGAIN_AGAIN_EDIT = "【033503】确定撤回重编目？";
    public static final String SURE_CANCEL_COLLECT = "【033504】注销后，无法恢复！确定注销？";
    public static final String SURE_CHANGE_STORE_CLASS = "【023505】确定调整库房位置？";


    /*错误 code = 4 (551 - 600)的提示信息*/
    public static final String GROUP_ERR = "【034551】关联失败！";
    public static final String GET_LABEL = "【034552】标签获取失败！";
    public static final String COLLECT_INFO_SAVE_ERR = "【034553】藏品信息保存失败！";
    public static final String ZJ_INFO_SAVE_ERR = "【034554】征集鉴定保存失败！";
    public static final String DJ_INFO_SAVE_ERR = "【034555】定级鉴定保存失败！";
    public static final String LC_INFO_SAVE_ERR = "【034556】流传信息保存失败！";
    public static final String SH_INFO_SAVE_ERR = "【034557】损坏信息保存失败！";
    public static final String ZL_INFO_SAVE_ERR = "【034558】著录信息保存失败！";
}
