package com.okay.cp.controller;


import com.alibaba.fastjson.JSONObject;
import com.okay.cp.baseBusiness.InventoryBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.InventoryList;
import com.okay.cp.service.InventoryListService;
import com.okay.cp.service.InventoryService;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.ComUtils;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/11 15:22
 * @Version: 1.0
 * @Description: 藏品盘点进行控制器
 */

@RestController
@RequestMapping(value = "/start")
public class InventoryStartController extends InventoryBaseBusiness {

    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private InventoryListService inventoryListService;

    /**
     * 查询列表初始化.
     *
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initList() {
        return initData();
    }

    /**
     * 列表数据.
     *
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        Map<String, Object> conditionMap = new HashMap<String, Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询状态
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state", "1");
                }
            }
        }
        // 在线用户
        User user = ComUtils.getLoginUser();
        conditionMap.put("inventoryObj", user.getUserId());

        return getDataList(page);
    }

    /**
     * 获取基本数据.
     *
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam) {
        return getDataById(jsonParam);
    }

    /**
     * 盘点记录主键获取明细数据.
     *
     * @param page
     * @return
     */
    @RequestMapping(value = "/getByQuery", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getByQuery(@RequestBody Page page) {
        return getInventoryListByQuery(page);
    }

    /**
     * 完成盘点.
     *
     * @param jsonParam
     * @return
     */
    @SysLog("我的盘点-完成盘点")
    @RequestMapping(value = "/finish", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject finish(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("inventoryId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_COMMIT);
            }
            int handleNum = inventoryService.finishInventory(id);
            if (handleNum != Arrays.asList(id.split(",")).size()) {
                throw new BaseRuntimeException(CollectErrorDefine.COMMIT_ERR);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.COMMIT_SUCCESS);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 保存盘点结果.
     *
     * @param jsonParam
     * @return
     */
    @SysLog("我的盘点-保存盘点结果")
    @RequestMapping(value = "/saveResult", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject saveResult(@RequestBody JSONObject jsonParam) {

        User user = ComUtils.getLoginUser();
        JSONObject jsonObject = new JSONObject();
        List<InventoryList> inventoryLists = jsonParam.getJSONArray("data").toJavaList(InventoryList.class);
        try {
            List<InventoryList> newInventoryLists = new ArrayList<InventoryList>();
            for (int i = 0; i < inventoryLists.size(); i++) {
                InventoryList inventoryList = inventoryLists.get(i);
                Integer result = inventoryList.getInventResult();
                String describe = inventoryList.getResultDescribe();
                if (result != null && result.equals(2) && DataUtil.isEmpty(describe)) {
                    throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR, "第" + (i + 1) + "个藏品 盘点的异常描述！"));
                }
                if (result != null || !DataUtil.isEmpty(describe)) {
                    InventoryList newInventoryList = new InventoryList();
                    if (result != null) {
                        newInventoryList.setState(2);
                    }
                    newInventoryList.setInventTime(new Date());
                    newInventoryList.setInventoryListId(inventoryList.getInventoryListId());
                    newInventoryList.setInventResult(inventoryList.getInventResult());
                    newInventoryList.setResultDescribe(inventoryList.getResultDescribe());
                    newInventoryList.setInventUser(user == null ? "" : user.getUserId());
                    newInventoryLists.add(newInventoryList);
                }
            }
            int handleNum = inventoryListService.update(newInventoryLists);
            if (handleNum != newInventoryLists.size()) {
                throw new BaseRuntimeException(CollectErrorDefine.SAVE_ERR);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.SAVE_SUCCESS);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     *
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        return initExportHeader();
    }

    /**
     * 数据导出.
     *
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("我的盘点-导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        exportHandle(jsonParam, request, response);
    }


    /**
     * 操作盘点所有的数据
     *
     * @param page
     * @return
     */
    @RequestMapping(value = "/allHandle", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject allHandle(@RequestBody Page page) {
        JSONObject jsonObject = new JSONObject();

        try {
            Map<String, Object> queryMap = page.getConditionMap();
            String inventResult = queryMap.get("inventResult").toString();
            if (DataUtil.isEmpty(inventResult)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK, "盘点结果"));
            }

            String resultDescribe = queryMap.get("resultDescribe").toString();
            if (inventResult.equals("2") && DataUtil.isEmpty(resultDescribe)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK, "异常结果"));
            }

            page.setPageNum(1);
            page.setPageSize(Integer.MAX_VALUE - 1);
            queryMap.put("inventResult", "");
            queryMap.put("resultDescribe", "");
            List<InventoryList> inventoryLists = inventoryListService.findByQuery(queryMap);

            for (int i = 0; i < inventoryLists.size(); i++) {
                InventoryList inventoryList = inventoryLists.get(i);
                inventoryList.setInventResult(Integer.valueOf(inventResult));
                inventoryList.setResultDescribe(resultDescribe);
                inventoryList.setState(2);
            }
            inventoryListService.update(inventoryLists);

            jsonObject.put("code", "1");
            jsonObject.put("msg", "全部处理完了！");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }


        return jsonObject;
    }
}
