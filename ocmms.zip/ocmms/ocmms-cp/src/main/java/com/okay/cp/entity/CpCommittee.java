package com.okay.cp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 征集委员
 * @author WZF[OKAY]
 * @date 2021-11-22 20:29:01
 */
@Data
@ApiModel(value = "征集委员")
public class CpCommittee extends BaseModel {

    @TableId(type = IdType.INPUT)
    @ApiModelProperty(value = "主键")
    private String id;

    
    @ApiModelProperty(value = "用户Id")
	private String userId;
    
    @ApiModelProperty(value = "备注")
	private String remark;
    

    
}