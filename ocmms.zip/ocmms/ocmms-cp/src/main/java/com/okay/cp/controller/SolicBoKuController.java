package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.cp.baseBusiness.SolictBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.SolicInfoService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: xdn
 * @CreateDate: 2019/9/21 16:31
 * @Version: 1.0
 * @Description: 拨库控制类.
 */

@RestController
@RequestMapping(value = "/boKu")
public class SolicBoKuController extends SolictBaseBusiness {

    @Autowired
    private SolicInfoService solicInfoService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;

    /**
     * 查询列表初始化.
     *
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initForm() {
        JSONObject jsonObject = new JSONObject();
        jsonObject = getOptions();
        jsonObject.put("code", 1);
        return jsonObject;
    }

    /**
     * 列表数据.
     *
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();
        Map<String, Object> conditionMap = new HashMap<String, Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询状态
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state", "7");
                }
            }
            return getDataList(page);
        }
        return null;
    }

    /**
     * 拨库数据初始化.
     *
     * @return
     */
    @RequestMapping(value = "/boKuInit", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject boKuInit() {

        JSONObject jsonObject = new JSONObject();
        JSONObject json = new JSONObject();
        try {
            // 拨库流水号
            String code = DateUtil.getNextTime();
            JSONArray storeHouseArr = collectCommonCodeService.selectCollectStorehouseTree();
            JSONArray collectClassArr = collectCommonCodeService.collectClassOptions();
            json.put("code", code);
            json.put("storeHouseArr", storeHouseArr);
            json.put("collectClassArr", collectClassArr);
            jsonObject.put("code", 1);
            jsonObject.put("data", json);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 确定拨库.
     *
     * @param jsonParam
     * @return
     */
    @SysLog("藏品拨库")
    @RequestMapping(value = "/sureBoKu", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('BK_DIAL')")
    public JSONObject sureBoKu(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        JSONArray solicitData = jsonParam.getJSONArray("solicitData");
        JSONObject baseData = jsonParam.getJSONObject("baseData");
        try {
            if (solicitData.size() == 0) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR, "拨库数据"));
            }
            if (baseData == null || baseData.size() == 0) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR, "拨库"));
            }
            if (!jsonParam.getBooleanValue("confirmFlg")) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_BOKU);
            }
            solicInfoService.sureBoKu(solicitData, baseData);
            throw new BaseRuntimeException(CollectErrorDefine.SOLICIT_BOKU_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     *
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        return initExportHeader(null);
    }

    /**
     * 数据导出.
     *
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("拨库管理导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
    @PreAuthorize("@pms.hasPermission('BK_EXP')")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        exportHandle(jsonParam, request, response);
    }

}
