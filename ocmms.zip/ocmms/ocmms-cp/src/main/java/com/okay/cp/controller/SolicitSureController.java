package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.R;
import com.okay.cp.baseBusiness.SolictBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.SolicInfoService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/4 14:08
 * @Version: 1.0
 * @Description: 确认征集控制类.
 */

@RestController
@RequestMapping(value = "/solicitSure")
public class SolicitSureController extends SolictBaseBusiness {

    @Autowired
    private SolicInfoService solicInfoService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;

    /**
     * 查询列表初始化.
     *
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initForm() {
        JSONObject jsonObject = new JSONObject();
        jsonObject = getOptions();
        jsonObject.put("code", 1);
        return jsonObject;
    }

    /**
     * 列表数据.
     *
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        Map<String, Object> conditionMap = new HashMap<String, Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询状态
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state", "5");
                }
            }
            return getDataList(page);
        }
        return null;
    }

    /**
     * 根据主键获取关联的合同附件.
     *
     * @param jsonParam
     * @return
     */
    @SysLog("藏品关联合同")
    @RequestMapping(value = "/getAttach", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('SLS_TRUERELATION')")
    public JSONObject getAttach(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solictId");
        JSONArray attachMentArr = (JSONArray) getAttachBymainKey(id).get("attach");
        // 关联合同去重
        JSONArray resultArr = moveRepeatAttahcment(attachMentArr);
        jsonObject.put("attach", resultArr);
        jsonObject.put("code", 1);
        return jsonObject;
    }

    /**
     * 取消关联合同.
     *
     * @param jsonParam
     * @return
     */
    @SysLog("藏品取消关联合同")
    @RequestMapping(value = "/cancelAssociate", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('SLS_FLASERELATION')")
    public JSONObject cancelAssociate(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("infoIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.NOT_ATTACH_ERROR);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_CANCEL_ASSOCIATE);
            }
            JSONObject param = new JSONObject();
            param.put("infoIds", id);
            param.put("confirmFlg", confirmFlg);
            JSONObject returnJson = collectCommonBusinessService.cpSysFileDel(param);
            Object code = returnJson.get("code");
            if (code != null) {
                if ("1".equals(code.toString())) {
                    ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.CANCEL_ASSOCIATE_SUCCESS);
                } else {
                    throw new BaseRuntimeException(CollectErrorDefine.CANCEL_ASSOCIATE_FAIL);
                }
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.CANCEL_ASSOCIATE_FAIL);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 提交拨库.
     *
     * @param jsonParam
     * @return
     */
    @SysLog("藏品提交拨库")
    @RequestMapping(value = "/commitToBoKu", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('SLS_SUBMITTRUE')")
    public JSONObject commitToBoku(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("solicId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_COMMIT);
            }
            List<String> idList = new ArrayList<>(Arrays.asList(id.split(",")));
            solicInfoService.commitToBoku(idList);
            throw new BaseRuntimeException(CollectErrorDefine.COMMIT_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     *
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        return initExportHeader("6");
    }

    /**
     * 数据导出.
     *
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("确认征集导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
    @PreAuthorize("@pms.hasPermission('SLS_EXP')")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        exportHandle(jsonParam, request, response);
    }

    /**
     * 确认征集文物-提交流水账
     *
     * @param solicIds 文物ID
     * @return R
     * @author CZJ[OKAY]
     **/
    @SysLog("提交流水账")
    @PostMapping(value = "/submitRunAccount")
    @PreAuthorize("@pms.hasPermission('SLS_SUBMITRUNACCOUNT')")
    public R submitRunAccount(@RequestParam(value = "solicIds") List<String> solicIds) {
        return R.ok(solicInfoService.submitRunAccount(solicIds));
    }
}
