package com.okay.cp.baseBusiness;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.ZipUtil;
import com.alibaba.excel.EasyExcel;
import com.okay.cp.entity.vo.AttachInfoVO;
import com.okay.cp.handler.CustomCellWriteHandler;
import com.okay.cp.handler.CustomRowHeightHandler;
import lombok.Builder;
import lombok.SneakyThrows;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

/**
 * @author CZJ[OKAY]
 * @date 2021/7/5 12:00
 * @description 藏品导出
 **/
@Builder
public class CollectionExport {

    private String fileName;
    private HttpServletResponse response;

    @SneakyThrows
    public void collectionExport(Map<String, String> filePathMap, List<AttachInfoVO> attachList,
                                 Map<String, String> collectMap, List<List<String>> headerList,
                                 List<List<String>> bodyList) {

        String os_Path = filePathMap.get("os_path");
        String tempFilePath = filePathMap.get("tempFilePath");
        if (new File(tempFilePath).exists()) {
            String rootPath = tempFilePath + File.separator + System.currentTimeMillis();
            File rootFile = new File(rootPath);
            if (!rootFile.exists()) {
                rootFile.mkdirs();
            }
            attachList.stream().forEach(f -> {
                File srcFile = new File(os_Path + f.getFilePath());
                if (srcFile.exists()) {
                    // 附件名称：登记号+附件名称+资源号
                    String fileName = collectMap.get(f.getMainBodyId()) + "_" + f.getFileName()
                            + "_" + f.getResCode() + "." + f.getExtName();
                    FileUtil.copy(srcFile.getPath(), rootPath + File.separator + fileName, true);
                }
            });

            setRepHeader();
            String excelPath = rootPath + File.separator + fileName + ".xls";
            EasyExcel.write(excelPath).head(headerList)
                    .registerWriteHandler(new CustomCellWriteHandler())
                    .registerWriteHandler(new CustomRowHeightHandler())
                    .sheet().doWrite(bodyList);
            File zip = ZipUtil.zip(rootPath);
            InputStream inputStream = new FileInputStream(zip);
            IoUtil.write(response.getOutputStream(), Boolean.TRUE, IoUtil.readBytes(inputStream));
            IoUtil.close(inputStream);
            zip.delete();
            FileUtil.del(rootFile);
        }
    }

    /**
     * @author CZJ[OKAY]
     * @description 设置头部导出信息
     **/
    private void setRepHeader() throws UnsupportedEncodingException {
        response.setContentType("application/zip");
        response.setCharacterEncoding("utf-8");
        String newFileName = URLEncoder.encode(fileName + ".zip", "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + newFileName + "");
        response.setHeader("filename", newFileName);
        response.setHeader("Access-Control-Expose-Headers", "FileName");
    }
}
