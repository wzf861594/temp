package com.okay.cp.controller;

import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.cp.entity.dto.CpAppraisalExpertDTO;
import com.okay.cp.service.CpAppraisalExpertService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author CZJ[OKAY]
 * @date 2021-12-14 20:07:31
 * @description 鉴定专家管理表Controller
 **/
@RestController
@AllArgsConstructor
@Api(tags = "鉴定专家管理表")
@RequestMapping(value = "/appraisalExpert")
public class CpAppraisalExpertController {

    private final CpAppraisalExpertService appraisalExpertService;

    /**
     * 新增
     *
     * @param dto 记录数据
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/insert")
    @ApiOperation(value = "新增")
    public R insert(@Validated CpAppraisalExpertDTO dto) {
        return R.ok(appraisalExpertService.insert(dto));
    }

    /**
     * 根据ID修改
     *
     * @param dto 记录数据
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/updateById")
    @ApiOperation(value = "根据ID修改")
    public R updateById(@Validated CpAppraisalExpertDTO dto) {
        return R.ok(appraisalExpertService.updateById(dto));
    }

    /**
     * 根据ID删除
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/deleteById")
    @ApiOperation(value = "根据ID删除")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R deleteById(@RequestParam(value = "id") String id) {
        return R.ok(appraisalExpertService.deleteById(id));
    }

    /**
     * 根据ID获取记录基本信息
     *
     * @param id 主键
     * @return R
     * @author CZJ[OKAY]
     **/
    @GetMapping(value = "/getById")
    @ApiOperation(value = "根据ID获取记录基本信息")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "主键", required = true)})
    public R getById(@RequestParam(value = "id") String id) {
        return R.ok(appraisalExpertService.getById(id)).setMsg("");
    }

    /**
     * 获取记录列表
     *
     * @param dto  查询条件
     * @param page 分页信息
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/listAll")
    @ApiOperation(value = "获取记录列表")
    public R listAll(Page page, CpAppraisalExpertDTO dto) {
        return R.ok(appraisalExpertService.listAll(page, dto)).setMsg("");
    }
}