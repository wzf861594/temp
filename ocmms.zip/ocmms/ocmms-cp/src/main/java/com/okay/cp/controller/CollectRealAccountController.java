package com.okay.cp.controller;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.okay.cp.baseBusiness.CollectInfoBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectInfo;
import com.okay.cp.entity.CollectRelocation;
import com.okay.cp.entity.PublishRecord;
import com.okay.cp.entity.vo.CollectRealAccountExportVO;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.CollectInfoService;
import com.okay.cp.service.PublishRecordService;
import com.okay.cp.utils.ExcelWriterUtil;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.SequenceService;
import com.okay.framework.utils.ComUtils;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 藏品正式账控制层
 *
 * @author zhangyx
 * @since 2019/9/18 14:50
 */
@RestController
@RequestMapping(value = "/realAccount")
public class CollectRealAccountController extends CollectInfoBaseBusiness {

    @Autowired
    private CollectInfoService collectInfoService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private PublishRecordService publishRecordService;
    @Autowired
    private SequenceService sequenceService;

    /**
     * 初始化查询表单
     *
     * @return
     */
    @RequestMapping(value = "/query", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject initForm() {
        JSONObject jsonObject = new JSONObject();
        try {
            //获取藏品类别
            JSONArray typeArray = collectCommonCodeService.selectCollectType();
            jsonObject.put("collectType", typeArray);

            //获取级别
            JSONArray levelOptions = collectCommonCodeService.selectCollectLev();
            jsonObject.put("cpLevel", levelOptions);

            //获取完残程度
            JSONArray degreeOptions = collectCommonCodeService.completeDegreeOptions();
            jsonObject.put("completeDegree", degreeOptions);

            //库房树形结构
            JSONArray storehouseTree = collectCommonCodeService.selectCollectStorehouseTree();
            jsonObject.put("storehouseTree", storehouseTree);

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 加载数据列表
     *
     * @return JSONObject
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        JSONObject jsonObject = new JSONObject();
        try {
            selectParam(page);
            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);

            JSONArray dataList = new JSONArray();
            for (int i = 0; i < collectInfoList.size(); i++) {
                CollectInfo collectInfo = collectInfoList.get(i);
                String jsonString = JSONObject.toJSONString(collectInfo);
                JSONObject collectInfoJson = JSONObject.parseObject(jsonString);

                //小图
//                JSONObject jsonObject1 = collectCommonBusinessService.getMainBodyRes("90", collectInfo.getCollectId());
//                collectInfoJson.put("image", jsonObject1.getString("coverUrl"));
                String imgBase64 = collectCommonBusinessService.getCoverImg("90", collectInfo.getCollectId());
                collectInfoJson.put("image", imgBase64);

                //藏品类别
                String collectType_t = collectCommonCodeService.collectType_t(collectInfo.getCollectType());
                collectInfoJson.put("collectType", collectType_t);

                //完残程度
                String completeDegree_t = collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree());
                collectInfoJson.put("completeDegree", completeDegree_t);

                //级别
                String cpLev_t = collectCommonCodeService.cpLev_t(collectInfo.getCpLevel());
                collectInfoJson.put("cpLevel", cpLev_t);

                //来源方式
                String source_t = collectCommonCodeService.source_t(collectInfo.getSource());
                collectInfoJson.put("source", source_t);

                //库房
                String storehouse_t = collectCommonCodeService.storehouse_t(collectInfo.getStorehouse());
                collectInfoJson.put("storehouse", storehouse_t);

                dataList.add(collectInfoJson);
            }
            jsonObject.put("data", dataList);
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 发布
     *
     * @return
     */
    @SysLog("正式帐-发布")
    @PreAuthorize("@pms.hasPermission('RA_PUBLICATION')")
    @RequestMapping(value = "/pub", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject pubControl(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            User user = ComUtils.getLoginUser();
            String userId = user.getUserId();

            String collectIds = json.getString("collectIds");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            String confirmFlg = json.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_PUBLIC);
            }

            List<String> list = Arrays.asList(collectIds.split(","));
            List<CollectInfo> collectInfoList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                CollectInfo collectInfo = new CollectInfo();
                collectInfo.setCollectId(list.get(i));
                collectInfo.setStatus("4");
                collectInfo.setPubUserId(userId);
                collectInfo.setPubDate(new Date());

                collectInfoList.add(collectInfo);
            }
            collectInfoService.batchUpdate(collectInfoList);

            // 添加发布记录
            addPubRecord(collectIds, "1");

            throw new BaseRuntimeException(CollectErrorDefine.PUBLIC_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 再发布
     *
     * @return
     */
    @SysLog("正式帐-重新发布")
    @PreAuthorize("@pms.hasPermission('RA_RELOADSUBMIT')")
    @RequestMapping(value = "/againPub", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject againPubControl(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            User user = ComUtils.getLoginUser();
            String userId = user.getUserId();

            String collectIds = json.getString("collectIds");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            String confirmFlg = json.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_PUBLIC);
            }

            List<String> list = Arrays.asList(collectIds.split(","));
            List<CollectInfo> collectInfoList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                CollectInfo collectInfo = new CollectInfo();
                collectInfo.setCollectId(list.get(i));
                collectInfo.setStatus("4");
                collectInfo.setPubUserId(userId);
                collectInfo.setPubDate(new Date());
                collectInfoList.add(collectInfo);
            }
            collectInfoService.batchUpdate(collectInfoList);

            // 添加发布记录
            addPubRecord(collectIds, "1");

            throw new BaseRuntimeException(CollectErrorDefine.PUBLIC_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 撤销发布
     *
     * @return
     */
    @SysLog("正式帐-撤销发布")
    @PreAuthorize("@pms.hasPermission('RA_REVOCATION')")
    @RequestMapping(value = "/revoke", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject revokeControl(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            User user = ComUtils.getLoginUser();
            String userId = user.getUserId();

            String collectIds = json.getString("collectIds");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            String confirmFlg = json.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_CANCEL);
            }

            List<String> list = Arrays.asList(collectIds.split(","));
            List<CollectInfo> collectInfoList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                CollectInfo collectInfo = new CollectInfo();
                collectInfo.setCollectId(list.get(i));
                collectInfo.setStatus("5");
                collectInfo.setPubUserId(userId);
                collectInfo.setPubDate(new Date());
                collectInfoList.add(collectInfo);
            }
            collectInfoService.batchUpdate(collectInfoList);

            // 添加发布记录
            addPubRecord(collectIds, "2");

            throw new BaseRuntimeException(CollectErrorDefine.CANCEL_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 重编目
     *
     * @return
     */
    @SysLog("正式帐-重编目")
    @PreAuthorize("@pms.hasPermission('RA_RELOAD')")
    @RequestMapping(value = "/againEdit", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject againEditControl(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            User user = ComUtils.getLoginUser();
            String userId = user.getUserId();

            String collectIds = json.getString("collectIds");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            JSONObject againEditObj = json.getJSONObject("againEditObj");
            String againEditReason = againEditObj.getString("againEditReason");
            if (DataUtil.isEmpty(againEditReason)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOTNULL_CHECK, "重编目原因"));
            }

            String confirmFlg = json.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_AGAIN_EDIT);
            }

            List<String> list = Arrays.asList(collectIds.split(","));
            List<CollectInfo> collectInfoList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                CollectInfo collectInfo = new CollectInfo();
                collectInfo.setCollectId(list.get(i));
                collectInfo.setStatus("6");
                collectInfo.setAgainEditOperator(userId);
                collectInfo.setAgainEditDate(new Date());
                collectInfo.setAgainEditReason(againEditReason);
                collectInfoList.add(collectInfo);
            }
            collectInfoService.batchUpdate(collectInfoList);

            //添加重编目历史记录
            collectInfoService.insertAgainEditRecord(collectInfoList);

            throw new BaseRuntimeException(CollectErrorDefine.AGAIN_EDIT_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 撤回重编目
     *
     * @return
     */
    @SysLog("正式帐-撤回重编目")
    @PreAuthorize("@pms.hasPermission('RA_WITHDRAW')")
    @RequestMapping(value = "/revokeAgainEdit", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject revokeAgainEdit(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            User user = ComUtils.getLoginUser();
            String userId = user.getUserId();

            String collectIds = json.getString("collectIds");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }


            String confirmFlg = json.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_AGAIN_AGAIN_EDIT);
            }

            List<String> list = Arrays.asList(collectIds.split(","));
            List<CollectInfo> collectInfoList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                CollectInfo collectInfo = new CollectInfo();
                collectInfo.setCollectId(list.get(i));
                collectInfo.setStatus("5");
                collectInfo.setAgainEditOperator("");
                collectInfo.setAgainEditDate(null);
                collectInfo.setAgainEditReason("");
                collectInfoList.add(collectInfo);
            }
            collectInfoService.batchUpdate(collectInfoList);

            //删除重编目最新的历史记录
            collectInfoService.delAgainEditRecord(collectInfoList);

            throw new BaseRuntimeException(CollectErrorDefine.AGAIN_EDIT_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }


    /**
     * 注销
     *
     * @return
     */
    @SysLog("正式帐-注销")
    @PreAuthorize("@pms.hasPermission('RA_CANCELLATION')")
    @RequestMapping(value = "/cancel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject cancelControl(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {

            String collectIds = json.getString("collectIds");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_SELECT_CANCEL_DATA);
            }

            JSONObject cancelInfo = json.getJSONObject("cancelInfo");
            //注销登记号
            String cancelNum = cancelInfo.getString("cancelNum");
            if (DataUtil.isEmpty(cancelNum)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_INPUT_CANCEL_NUM);
            }
            //注销批准文号
            String cancelApproveNum = cancelInfo.getString("cancelApproveNum");
            if (DataUtil.isEmpty(cancelApproveNum)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_INPUT_CANCEL_APPROVE_NUM);
            }
            //注销去向
            String cancelWhere = cancelInfo.getString("cancelWhere");
            if (DataUtil.isEmpty(cancelWhere)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_INPUT_CANCEL_WHERE);
            }
            //注销批准人
            String cancelApproveUser = cancelInfo.getString("cancelApproveUser");
            if (DataUtil.isEmpty(cancelApproveUser)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_INPUT_CANCEL_APPROVE_USER);
            }
            //注销单位
            String cancelApproveUnit = cancelInfo.getString("cancelApproveUnit");
            if (DataUtil.isEmpty(cancelApproveUnit)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_INPUT_CANCEL_UNIT);
            }
            //注销日期
            String cancelDate = cancelInfo.getString("cancelDate");
            if (DataUtil.isEmpty(cancelDate)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_INPUT_CANCEL_DATE);
            }

            String confirmFlg = json.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.SURE_CANCEL_COLLECT);
            }

            User user = ComUtils.getLoginUser();
            String userId = user.getUserId();

            List list = Arrays.asList(collectIds.split(","));
            List<CollectInfo> collectInfoList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                String collectId = list.get(i).toString();
                CollectInfo collectInfo = new CollectInfo();
                collectInfo.setCollectId(collectId);
                collectInfo.setStatus("7");
                collectInfo.setCancelNum(cancelNum);
                collectInfo.setCancelApproveNum(cancelApproveNum);
                collectInfo.setCancelWhere(cancelWhere);
                collectInfo.setCancelApproveUser(cancelApproveUser);
                collectInfo.setCancelApproveUnit(cancelApproveUnit);
                collectInfo.setCancelDate(DateUtil.convertStringToDate(cancelDate));
                collectInfo.setCancelRemark(cancelInfo.getString("cancelRemark"));
                collectInfo.setCancelHandelUser(userId);
                collectInfo.setCancelHandelDate(new Date());

                collectInfoList.add(collectInfo);
            }
            collectInfoService.batchUpdate(collectInfoList);

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 藏品重拨库.
     *
     * @param jsonParam
     * @return
     */
    @SysLog("正式帐-藏品重拨库")
    @PreAuthorize("@pms.hasPermission('RA_REDIALLIBRARY')")
    @RequestMapping(value = "/relocation", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject relocation(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();

        try {
            String id = jsonParam.getString("id");
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            JSONObject relocationObj = jsonParam.getJSONObject("relocationObj");
            List list = relocationObj.getJSONArray("relocationAfterList");
            if (null == list || list.size() == 0) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_DATA_ERROR, "库房位置"));
            } else {
                relocationObj.put("relocationAfter", StringUtils.join(list.toArray(), ","));
            }

            if (DataUtil.isEmpty(relocationObj.getString("relocationReason"))) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR, "重拨库原因"));
            }

            CollectRelocation collectRelocation = relocationObj.toJavaObject(CollectRelocation.class);

            String confirmFlg = jsonParam.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.SURE_CHANGE_STORE_CLASS);
            }

            collectInfoService.collectRelocation(id, collectRelocation);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 选择导出的表头
     *
     * @return
     */
    @RequestMapping(value = "/exportHeaderOptions", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeaderOptions() {
        JSONObject jsonObject = new JSONObject();
        try {

            List headers = new ArrayList();
            JSONObject headerJson = new JSONObject();
            headerJson.put("label", "藏品名称");
            headerJson.put("key", "collectName");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品原名");
            headerJson.put("key", "collectNameOld");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "普查名称");
            headerJson.put("key", "censusName");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "总登记号");
            headerJson.put("key", "totalNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "分类号");
            headerJson.put("key", "classNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品编号");
            headerJson.put("key", "collectCode");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "收入号");
            headerJson.put("key", "incomeNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "年代");
            headerJson.put("key", "years");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体年代");
            headerJson.put("key", "specificAge");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "级别");
            headerJson.put("key", "cpLevel");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "藏品类别");
            headerJson.put("key", "collectType");
            headers.add(headerJson);

//            headerJson = new JSONObject();
//            headerJson.put("label", "质地类别");
//            headerJson.put("key", "textureType");
//            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体质地");
            headerJson.put("key", "texture");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "质量范围");
            headerJson.put("key", "massRange");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "质量单位");
            headerJson.put("key", "massUnit");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体质量");
            headerJson.put("key", "specificMass");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "数量");
            headerJson.put("key", "quantity");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "实际数量");
            headerJson.put("key", "realNum");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "长(cm)");
            headerJson.put("key", "length");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "宽(cm)");
            headerJson.put("key", "width");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "高(cm)");
            headerJson.put("key", "height");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "口径(cm)");
            headerJson.put("key", "bore");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "底径(cm)");
            headerJson.put("key", "bottomDiameter");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "腹经(cm)");
            headerJson.put("key", "abdominal");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "直径(cm)");
            headerJson.put("key", "diameter");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体尺寸");
            headerJson.put("key", "specificSize");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "完残程度");
            headerJson.put("key", "completeDegree");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "保存状态");
            headerJson.put("key", "keepState");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "完残状况");
            headerJson.put("key", "completeDesc");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "包装情况");
            headerJson.put("key", "packCondition");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "来源方式");
            headerJson.put("key", "source");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "产地");
            headerJson.put("key", "productPlace");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "入馆时间");
            headerJson.put("key", "inMsDt");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "入藏时间");
            headerJson.put("key", "collectTimeRange");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "在库位置");
            headerJson.put("key", "storehouse");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "具体方位");
            headerJson.put("key", "specificPosition");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "在库状态");
            headerJson.put("key", "outState");
            headers.add(headerJson);

            headerJson = new JSONObject();
            headerJson.put("label", "在库数量");
            headerJson.put("key", "inStoreNum");
            headers.add(headerJson);

            jsonObject.put("headerOptions", headers);
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 数据导出
     *
     * @return
     */
    @SysLog("正式帐-导出")
    @RequestMapping(value = "/dataExport", method = RequestMethod.POST, produces = "application/json")
    public void dataExport(@RequestBody JSONObject json, HttpServletRequest request, HttpServletResponse response) {
        try {
            //查询数据 转换查询条件
            JSONObject pageJson = json.getJSONObject("page");
            Page page = pageJson.toJavaObject(Page.class);

            selectParam(page);

            //导出类型
            String exportType = json.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }

            if (exportType.equals("0")) {
                //导出查询的全部数据
                page.setPageSize(0);
                page.getConditionMap().put("orderBy", "pubDate desc");
            } else if (exportType.equals("1")) {
                //导出当前页的数据
                page.setOrderBy("pubDate desc");
            } else if (exportType.equals("2")) {
                page.setOrderBy("pubDate desc");
                //2：选择的数据
                String collectIds = json.getString("collectIds");
                page.getConditionMap().put("collectIds", Arrays.asList(collectIds.split(",")));
            }

            //获取选择的头部
            List headerNameList = new ArrayList(10);
            List headerKeyList = new ArrayList(10);
            JSONArray exportColumn = json.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            //封装实体数据
            List dataList = new ArrayList(10);
            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);
            for (int i = 0; i < collectInfoList.size(); i++) {
                CollectInfo collectInfo = collectInfoList.get(i);
                //实体类转换成 json对象
                JSONObject collectInfo_inObject = JSONObject.parseObject(JSONObject.toJSONString(collectInfo, SerializerFeature.WriteNullStringAsEmpty));
                //获取选择的列数据
                boolean calcInStoreNum = false;//是否已经计算过在库数量
                int inStoreNum = 0;//在库数量
                List obj = new ArrayList();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = headerKeyList.get(j).toString();
                    String value = collectInfo_inObject.getString(key);

                    //---------------------获取翻译值---------------------------------
                    if (key.equals("years")) {
                        //年代
                        value = collectCommonCodeService.collectAge_t(collectInfo.getYears());
                    } else if (key.equals("cpLevel")) {
                        //级别
                        value = collectCommonCodeService.cpLev_t(collectInfo.getCpLevel());
                    } else if (key.equals("collectType")) {
                        //藏品类别;
                        value = collectCommonCodeService.collectType_t(collectInfo.getCollectType());
                    } else if (key.equals("textureType")) {
                        //质地类别;
                        value = collectCommonCodeService.textureType_t(collectInfo.getTextureType());
                    } else if (key.equals("texture")) {
                        // 质地;
                        //value = collectCommonCodeService.texture_t(collectInfo.getTexture());
                    } else if (key.equals("massRange")) {
                        // 质量范围;
                        value = collectCommonCodeService.massRange_t(collectInfo.getMassRange());
                    } else if (key.equals("massUnit")) {
                        // 质量单位;
                        value = collectCommonCodeService.massUnit_t(collectInfo.getMassUnit());
                    } else if (key.equals("quantity")) {
                        // 数量;
                        if (collectInfo.getNumUnit() != null && collectInfo.getNumUnit() != "") {
                            value = collectInfo.getQuantity() + collectCommonCodeService.numUnit_t(collectInfo.getNumUnit());
                        } else {
                            value = collectInfo.getQuantity();
                        }
                    } else if (key.equals("completeDegree")) {
                        // 完残程度;
                        value = collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree());
                    } else if (key.equals("keepState")) {
                        // 保存状态;
                        value = collectCommonCodeService.keepState_t(collectInfo.getKeepState());
                    } else if (key.equals("source")) {
                        // 来源方式;
                        value = collectCommonCodeService.source_t(collectInfo.getSource());
                    } else if (key.equals("storehouse")) {
                        // 在库位置;
                        value = collectCommonCodeService.storehouse_t(collectInfo.getStorehouse());
                    } else if (key.equals("outState")) {
                        // 在库状态;
                        inStoreNum = getCollectInStoreNum(collectInfo.getCollectId());
                        if (key.equals("outState")) {
                            if (inStoreNum == Integer.valueOf(collectInfo.getRealNum())) {
                                value = "在库";
                            } else if (inStoreNum == 0) {
                                value = "出库";
                            } else {
                                value = "部分在库";
                            }
                        }

                        calcInStoreNum = true;
                    } else if (key.equals("inStoreNum")) {
                        if (!calcInStoreNum) {
                            inStoreNum = getCollectInStoreNum(collectInfo.getCollectId());
                        }
                        value = String.valueOf(inStoreNum);
                    }
                    obj.add(value);
                }
                dataList.add(obj);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, dataList);
            DataExportUtils.setResponseHeader(response, wb, "藏品正式账");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 数据导出
     *
     * @return
     */
    @SysLog("正式帐-导出")
    @RequestMapping(value = "/collectDataExport", method = RequestMethod.POST, produces = "application/json")
    public void collectDataExport(@RequestBody JSONObject json, HttpServletRequest request, HttpServletResponse response) {
        try {
            //查询数据 转换查询条件
            JSONObject pageJson = json.getJSONObject("page");
            Page page = pageJson.toJavaObject(Page.class);

            selectParam(page);

            //导出类型
            String exportType = json.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }

            if (exportType.equals("0")) {
                //导出查询的全部数据
                page.setPageSize(0);
                page.getConditionMap().put("orderBy", "pubDate desc");
            } else if (exportType.equals("1")) {
                //导出当前页的数据
                page.setOrderBy("pubDate desc");
            } else if (exportType.equals("2")) {
                page.setOrderBy("pubDate desc");
                //2：选择的数据
                String collectIds = json.getString("collectIds");
                page.getConditionMap().put("collectIds", Arrays.asList(collectIds.split(",")));
            }

            //封装实体数据
            List<CollectRealAccountExportVO> exportVOList = new ArrayList<>();
            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);
            for (int i = 0; i < collectInfoList.size(); i++) {
                CollectInfo collectInfo = collectInfoList.get(i);

                CollectRealAccountExportVO exportVO = new CollectRealAccountExportVO();
                exportVO.setSeqNo(i + 1);
                exportVO.setNumType("藏品总登记号");
                exportVO.setTotalNum(collectInfo.getTotalNum());
                exportVO.setClassNum(collectInfo.getClassNum());
                exportVO.setCollectName(collectInfo.getCollectName());
                exportVO.setCollectNameOld(collectInfo.getCollectNameOld());
                String years = collectInfo.getYears();
                if (StrUtil.isNotBlank(years)) {
                    List<String> ageList = StrUtil.split(collectCommonCodeService.collectAge_t(collectInfo.getYears()), "/");
                    int ageSize = ageList.size();
                    if (ageSize >= 1) {
                        exportVO.setYear1(ageList.get(0));
                    }
                    if (ageSize >= 2) {
                        exportVO.setYear2(ageList.get(1));
                    }
                    if (ageSize >= 3) {
                        exportVO.setYear3(ageList.get(2));
                    }
                    if (ageSize >= 4) {
                        exportVO.setYear4(ageList.get(3));
                    }
                }
                exportVO.setSpecificAge(collectInfo.getSpecificAge());
                if (StrUtil.isNotBlank(collectInfo.getCollectType())) {
                    exportVO.setCollectType(collectCommonCodeService.collectType_t(collectInfo.getCollectType()));
                }
                if (StrUtil.isNotBlank(collectInfo.getTextureType())) {
                    //
                    List<String> textureTypeList = StrUtil.split(collectCommonCodeService.textureType_t(collectInfo.getTextureType()), '/');
                    int textureTypeSize = textureTypeList.size();
                    if (textureTypeSize >= 1) {
                        exportVO.setTextureType1(textureTypeList.get(0));
                    }
                    if (textureTypeSize >= 2) {
                        exportVO.setTextureType2(textureTypeList.get(1));
                    }
                }
                exportVO.setTexture(collectInfo.getTexture());
                exportVO.setRealNum(collectInfo.getRealNum());
                exportVO.setLength(collectInfo.getLength());
                exportVO.setWidth(collectInfo.getWidth());
                exportVO.setHeight(collectInfo.getHeight());
                exportVO.setSpecificSize(collectInfo.getSpecificSize());
                if (StrUtil.isNotBlank(collectInfo.getMassRange())) {
                    // 质量范围
                    exportVO.setMassRange(collectCommonCodeService.massRange_t(collectInfo.getMassRange()));
                }
                exportVO.setSpecificMass(collectInfo.getSpecificMass());
                if (StrUtil.isNotBlank(collectInfo.getMassUnit())) {
                    // 质量单位
                    exportVO.setMassUnit(collectCommonCodeService.massUnit_t(collectInfo.getMassUnit()));
                }
                if (StrUtil.isNotBlank(collectInfo.getCpLevel())) {
                    // 文物级别
                    exportVO.setCpLevel(collectCommonCodeService.cpLev_t(collectInfo.getCpLevel()));
                }
                if (StrUtil.isNotBlank(collectInfo.getSource())) {
                    // 文物来源
                    exportVO.setSource(collectCommonCodeService.source_t(collectInfo.getSource()));
                }
                if (StrUtil.isNotBlank(collectInfo.getCompleteDegree())) {
                    // 完残程度
                    exportVO.setCompleteDegree(collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree()));
                }
                exportVO.setCompleteDesc(collectInfo.getCompleteDesc());
                if (StrUtil.isNotBlank(collectInfo.getKeepState())) {
                    // 保存状态
                    exportVO.setKeepState(collectCommonCodeService.keepState_t(collectInfo.getKeepState()));
                }
                // 存放位置(库房：*库*柜*层；展厅：*楼*柜
                if (StrUtil.isNotBlank(collectInfo.getStorehouse())) {
                    exportVO.setPosition(collectCommonCodeService.storehouse_t(collectInfo.getStorehouse()));
                }

                exportVO.setCollectTimeRange(collectInfo.getCollectTimeRange());
                exportVO.setCollectYear(collectInfo.getCollectYear());
                exportVOList.add(exportVO);
            }
            ExcelWriterUtil.builder().fileName("华侨博物院文物藏品分类账（电子）").sheetName("文物信息采集表").response(response).build()
                    .write(exportVOList, CollectRealAccountExportVO.class);
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 通用查询条件
     *
     * @return
     */
    private static void selectParam(Page page) {
        Object obj = page.getConditionMap().get("status");
        if (obj.toString().equals("0")) {
            String status = "4,3,5";
            List statusList = Arrays.asList(status.split(","));
            page.getConditionMap().put("status", "");
            page.getConditionMap().put("statusList", statusList);
        }

//        page.setOrderBy("pubDate desc");
    }

    // 添加发布记录
    private void addPubRecord(String collectIds, String pubState) {
        if (StringUtils.isNotEmpty(collectIds)) {
            User user = ComUtils.getLoginUser();
            List<String> collectIdList = Arrays.asList(collectIds.split(","));
            for (int i = 0; i < collectIdList.size(); i++) {
                PublishRecord publishRecord = new PublishRecord();
                publishRecord.setPubState(pubState);
                publishRecord.setPublishTime(new Date());
                publishRecord.setPublishUser(user.getUserId());
                publishRecord.setPubCollectId(collectIdList.get(i));
                publishRecord.setRecordId(sequenceService.getSequence());

                publishRecordService.insert(publishRecord);
            }
        }
    }

    /**
     * 藏品编目卡下载
     *
     * @param collectId 藏品ID
     * @author CZJ[OKAY]
     **/
     @GetMapping(value = "/catalogCardDownload")
    public void catalogCardDownload(@RequestParam(value = "collectId") String collectId, HttpServletResponse response) {
        collectInfoService.catalogCardDownload(collectId, response);
    }

    /**
     * 藏品编目卡下载
     * @param collectId
     * @param response
     */
    @GetMapping(value = "/catalogCardDownloadNew")
    public void catalogCardDownloadNew(@RequestParam(value = "collectId") String collectId, HttpServletResponse response) {
        collectInfoService.catalogCardDownloadNew(collectId, response);
    }

    /**
     * 馆藏文物年度核查统计报表
     * @param response
     */
    @GetMapping(value = "/collectStatisticsForm")
    public void collectStatisticsFormDownload(HttpServletResponse response) {
        collectInfoService.collectStatisticsFormDownload(response);
    }

}
