package com.okay.cp.baseBusiness;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.*;
import com.okay.cp.outside.clients.ResServerInterface;
import com.okay.cp.service.*;
import com.okay.cp.utils.CollectUtils;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.SequenceService;
import com.okay.framework.utils.ComUtils;
import com.okay.framework.utils.DataUtil;
import org.springframework.beans.factory.annotation.Autowired;
import com.okay.framework.service.CustomPropertyService;
import com.okay.framework.entity.CustomProperty;

import java.util.*;

/**
 * 藏品公共业务处理
 *
 * @author zhangyx
 * @since 2019/9/26 10:10
 */
public class CollectHandleBaseBusiness {
    @Autowired
    private ResServerInterface resServerInterface;
    @Autowired
    private CollectInfoService collectInfoService;
    @Autowired
    private GroupService groupService;
    @Autowired
    private CpLabelService cpLabelService;
    @Autowired
    private SequenceService sequenceService;
    @Autowired
    private CatalogZjAppraisalService catalogZjAppraisalService;//征集鉴定信息服务
    @Autowired
    private GradingService gradingService;//定级鉴定信息服务
    @Autowired
    private CirculateLiveService circulateLiveService;//流传信息服务
    @Autowired
    private BreakDownService breakDownService;//损坏记录查询
    @Autowired
    private BookmakingService bookmakingService;//著录记录查询
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private CustomPropertyService customPropertyService;

    /**
     * 设置封面
     *
     * @param json
     * @return
     */
    public JSONObject setCover(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = resServerInterface.setCover(json);
            if (jsonObject.getString("code").equals("0")) {
                throw new BaseRuntimeException(jsonObject.getString("msg"));
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 查询关联藏品 默认显示前10条
     */
    public JSONObject searchLinkCollect(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String queryNum = json.getString("queryNum");

            if ("1".equals(queryNum)) {// 未分组

                // 搜索藏品参数设置
                Page page = new Page();
                page.setPageSize(10);
                page.setOrderBy("createTime desc");

                Map<String, Object> conditionMap = new HashMap<>();
                conditionMap.put("collectName", json.getString("collectName"));
                conditionMap.put("collectId", json.getString("collectId"));//关联藏品不包含自己
                page.setConditionMap(conditionMap);

                List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);

                JSONArray array = new JSONArray();
                for (int i = 0; i < collectInfoList.size(); i++) {
                    CollectInfo collectInfo = collectInfoList.get(i);
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("label", collectInfo.getCollectName());
                    jsonObject1.put("value", collectInfo.getCollectId());

                    Group group = groupService.selectGroupByCollectId(collectInfo.getCollectId());
                    if (group != null) {
                        jsonObject1.put("label", collectInfo.getCollectName());
                        jsonObject1.put("disabled", true);
                    }
                    array.add(jsonObject1);
                }
                jsonObject.put("collectInfoList", array);

            } else if ("2".equals(queryNum)) { // 分组数据查询

                Map<String, Object> query = new HashMap<>();
                query.put("collectName", json.getString("collectName"));
                query.put("excludeCollectId", json.getString("collectId"));
                List<Map<String, String>> groupLinkDataList = groupService.findLinkDataByQuery(query);

                JSONArray resultArray = new JSONArray();
                for (int i = 0; i < groupLinkDataList.size(); i++) {
                    Map<String, String> dataMap = groupLinkDataList.get(i);
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("label", dataMap.get("collectName"));
                    jsonObject1.put("value", dataMap.get("collectId"));
                    resultArray.add(jsonObject1);
                    if (i == 9) {
                        break;
                    }
                }
                jsonObject.put("collectInfoList", resultArray);
            }

            jsonObject.put("code", "1");

        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 添加关联藏品
     */
    public JSONObject addLinkCollect(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //关联藏品
            List collectIds = json.getJSONArray("collectIds");
            if (collectIds.size() == 0) {
                throw new BaseRuntimeException(CollectErrorDefine.GROUP_NOT_DATA);
            }

            //主要藏品
            String collectId = json.getString("curCollectId");
            CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(collectId);
            if (collectInfo == null) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_SAVE_DATA);
            }

            //保存关联藏品
            try {
                List<Group> groupList = groupService.updateGroupData(collectId, collectIds);
                jsonObject.put("groupList", groupList);
            } catch (Exception e) {
                throw new BaseRuntimeException(CollectErrorDefine.GROUP_ERR);
            }

            jsonObject.put("code", "1");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BaseRuntimeException(e.getMessage());
        }
        return jsonObject;
    }

    /**
     * 删除关联藏品
     */
    public JSONObject delLinkCollect(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //关联藏品
            String collectId = json.getString("collectId");
            if (DataUtil.isEmpty(collectId)) {
                throw new BaseRuntimeException(CollectErrorDefine.GROUP_NOT_DATA);
            }

            String confirmFlg = json.getString("confirmFlg");
            if (confirmFlg == null || confirmFlg.trim().equals("") || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL, ""));
            }

            try {
                groupService.delLinkCollect(collectId);
            } catch (Exception e) {
                throw new BaseRuntimeException(e.getMessage());
            }
            throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }


    /**
     * 单个藏品贴标签
     *
     * @return
     */
    public JSONObject addLabel(JSONObject json) {
        JSONObject jsonObject = new JSONObject();

        //获取在线登录用户
        User user = ComUtils.getLoginUser();
        String userId = user.getUserId();
        try {
            String labelString = json.getString("lableName");
            if (DataUtil.isEmpty(labelString)) {
                throw new BaseRuntimeException(CollectErrorDefine.LABELLING_CHECK);
            }
            String collectId = json.getString("collectId");
            if (DataUtil.isEmpty(collectId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "藏品主键"));
            }
            //用“，”号隔开。默认贴多个标签
            labelString = DataUtil.charToDBC(labelString);
            String[] labelList = labelString.split(",");

            List<CpLabel> labels = new ArrayList<>();
            for (int i = 0; i < labelList.length; i++) {
                CpLabel label = new CpLabel();
                label.setLabId(sequenceService.getSequence());
                if (DataUtil.isEmpty(labelList[i].trim())) {
                    continue;
                }
                label.setLabName(labelList[i].trim());
                label.setCollectId(collectId);
                label.setDelFlg("0");
                label.setCreatUser(userId);
                labels.add(label);
            }
            List<CpLabel> insertSuccessLabel = cpLabelService.batchInsertSelective(labels);
            JSONArray jsonArray = new JSONArray();
            if (null != insertSuccessLabel && insertSuccessLabel.size() > 0) {
                //插入成功后 返回插入成功的数据结果
                for (int i = 0; i < insertSuccessLabel.size(); i++) {
                    JSONObject jsonObject1 = new JSONObject(true);
                    jsonObject1.put("labId", insertSuccessLabel.get(i).getLabId());
                    jsonObject1.put("labName", insertSuccessLabel.get(i).getLabName());
                    jsonObject1.put("delFlg", insertSuccessLabel.get(i).getDelFlg());
                    jsonArray.add(jsonObject1);
                }
            }
            jsonObject.put("code", "1");
            jsonObject.put("data", jsonArray);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 单个资源标签删除
     *
     * @return
     */
    public JSONObject delLabel(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String labId = json.getString("labId");
            if (DataUtil.isEmpty(labId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "标签主键"));
            }
            cpLabelService.deleteByPrimaryKey(labId);
            throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 批量标签删除
     *
     * @return
     */
    public JSONObject batchDelLabel(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            List collectIdList = json.getJSONArray("collectIds");
            String labName = json.getString("labName");
            if (null == collectIdList || collectIdList.size() == 0) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "藏品主键"));
            }

            if (DataUtil.isEmpty(labName)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "标签"));
            }

            String confirmFlg = json.getString("confirmFlg");
            if (confirmFlg == null || confirmFlg.trim().equals("") || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL, ""));
            }

            cpLabelService.batchDelCpLabel(collectIdList, labName);
            throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 批量贴标签
     *
     * @return
     */
    public JSONObject batchAddLabel(JSONObject json) {
        JSONObject jsonObject = new JSONObject();

        //获取在线登录用户
        User user = ComUtils.getLoginUser();
        String userId = user.getUserId();
        try {
            JSONArray CollectIds = json.getJSONArray("collectIds");
            if (CollectIds.size() == 0) {
                throw new BaseRuntimeException(CollectErrorDefine.HANDLE_DATA_NULL);
            }
            String labelName = json.getString("labelName");
            if (DataUtil.isEmpty(labelName)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "标签名称"));
            }

            labelName = DataUtil.charToDBC(labelName);
            String[] labelNameList = labelName.split(",");
            List<CpLabel> labels = new ArrayList<>();
            for (int i = 0; i < CollectIds.size(); i++) {
                String infoId = (String) CollectIds.get(i);
                for (int j = 0; j < labelNameList.length; j++) {
                    CpLabel label = new CpLabel();
                    label.setLabId(sequenceService.getSequence());
                    label.setLabName(labelNameList[j].trim());
                    label.setCollectId(infoId);
                    label.setCreatUser(userId);
                    labels.add(label);
                }
            }
            List<CpLabel> successLabel = cpLabelService.batchInsertSelective(labels);
            jsonObject.put("successData", successLabel);//返回成功后的标签对象

            //过滤重复的标签名称
            Map<String, String> map = new HashMap<String, String>();
            JSONArray labelArray = new JSONArray();
            for (int j = 0; j < labelNameList.length; j++) {
                String current_labelName = labelNameList[j].trim();
                if (!map.containsKey(current_labelName)) {
                    map.put(current_labelName, current_labelName);

                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("labName", current_labelName);
                    jsonObject1.put("delFlg", "0");

                    labelArray.add(jsonObject1);
                }
            }
            jsonObject.put("labelList", labelArray);

            throw new BaseRuntimeException(CollectErrorDefine.ADD_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 添加扩展属性
     *
     * @return
     */
    public JSONObject addExpand(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String type = json.getString("recordType");
            String collectId = json.getString("collectId");
            if (DataUtil.isEmpty(collectId)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "藏品主键"));
            }

            if (type.equals("1")) {
                //新增一条征集鉴定记录
                CatalogZjAppraisal catalogZjAppraisal = new CatalogZjAppraisal();
                catalogZjAppraisal.setIdeaId(sequenceService.getSequence());
                catalogZjAppraisal.setCollectId(collectId);
                catalogZjAppraisalService.insertSelective(catalogZjAppraisal);

                String jsonString = JSONObject.toJSONString(catalogZjAppraisal, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject catalogZjAppraisalJson = JSONObject.parseObject(jsonString);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "91");
                mainBody.put("mainBodyId", catalogZjAppraisal.getIdeaId());
                catalogZjAppraisalJson.put("mainBody", mainBody);

                jsonObject.put("record", catalogZjAppraisalJson);

            } else if (type.equals("2")) {
                //新增一条定级鉴定信息
                Grading grading = new Grading();
                grading.setGradingId(sequenceService.getSequence());
                grading.setCollectId(collectId);
                gradingService.insertSelective(grading);

                String jsonString = JSONObject.toJSONString(grading, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject gradingJson = JSONObject.parseObject(jsonString);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "92");
                mainBody.put("mainBodyId", grading.getGradingId());
                gradingJson.put("mainBody", mainBody);

                jsonObject.put("record", gradingJson);
            } else if (type.equals("3")) {
                //新增一条流传记录
                CirculateLive circulateLive = new CirculateLive();
                circulateLive.setLiveId(sequenceService.getSequence());
                circulateLive.setCollectId(collectId);
                circulateLiveService.insertSelective(circulateLive);

                String jsonString = JSONObject.toJSONString(circulateLive, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject circulateLiveJson = JSONObject.parseObject(jsonString);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "93");
                mainBody.put("mainBodyId", circulateLive.getLiveId());
                circulateLiveJson.put("mainBody", mainBody);

                jsonObject.put("record", circulateLiveJson);
            } else if (type.equals("4")) {
                //新增条损坏记录
                BreakDown breakDown = new BreakDown();
                breakDown.setBreakId(sequenceService.getSequence());
                breakDown.setCollectId(collectId);
                breakDownService.insertSelective(breakDown);

                String jsonString = JSONObject.toJSONString(breakDown, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject breakDownJson = JSONObject.parseObject(jsonString);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "94");
                mainBody.put("mainBodyId", breakDown.getBreakId());
                breakDownJson.put("mainBody", mainBody);

                jsonObject.put("record", breakDownJson);
            } else if (type.equals("5")) {
                //新增一条著录记录
                Bookmaking bookmaking = new Bookmaking();
                bookmaking.setBookId(sequenceService.getSequence());
                bookmaking.setCollectId(collectId);
                bookmakingService.insertSelective(bookmaking);

                String jsonString = JSONObject.toJSONString(bookmaking, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject bookmakingJson = JSONObject.parseObject(jsonString);

                JSONObject mainBody = new JSONObject();
                mainBody.put("mainBodyObj", "95");
                mainBody.put("mainBodyId", bookmaking.getBookId());
                bookmakingJson.put("mainBody", mainBody);

                jsonObject.put("record", bookmakingJson);
            }
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 删除扩展属性
     *
     * @return
     */
    public JSONObject delExpand(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String type = json.getString("recordType");
            String key = json.getString("key");
            if (DataUtil.isEmpty(key)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.PARAMETER_NOTNULL, "主键"));
            }

            //删除询问
            String confirmFlg = json.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL, ""));
            }

            if (type.equals("1")) {
                //删除一条征集鉴定记录
                catalogZjAppraisalService.deleteByPrimaryKey(key);
            } else if (type.equals("2")) {
                //删除一条定级鉴定信息
                gradingService.deleteByPrimaryKey(key);
            } else if (type.equals("3")) {
                //删除一条流传记录
                circulateLiveService.deleteByPrimaryKey(key);
            } else if (type.equals("4")) {
                //删除一条损坏记录
                breakDownService.deleteByPrimaryKey(key);
            } else if (type.equals("5")) {
                //删除一条著录记录
                bookmakingService.deleteByPrimaryKey(key);
            }
            throw new BaseRuntimeException(CollectErrorDefine.DELETE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 藏品数据保存 提交 和 暂存
     */
    public JSONObject saveOrCommit(JSONObject json) {

        JSONObject jsonObject = new JSONObject();
        try {
            //------------藏品信息 保存
            JSONObject collectInfoJson = json.getJSONObject("collectInfo");
            CollectInfo collectInfo = collectInfoJson.toJavaObject(CollectInfo.class);

            //必填项校验
            String mes = checkCollectInfo(collectInfo);
            if (!DataUtil.isEmpty(mes)) {
                throw new BaseRuntimeException(mes);
            }

            String saveOrCommit = json.getString("saveOrCommit");
            if (("1").equals(saveOrCommit)) {
                //提交
                String confirmFlg = json.getString("confirmFlg");
                if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                    throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_COMMIT, ""));
                }

                if (DataUtil.isEmpty(collectInfo.getStatus())) {
                    //审核中
                    collectInfo.setStatus("2");
                }

                //提交审核时间
                collectInfo.setCommitDate(new Date());
            }

            //年代 转换成 id串
            collectInfo.setYears(CollectUtils.arrayChangeIds(collectInfo.getYears()));
            //质地类别 转换成 id串
            collectInfo.setTextureType(CollectUtils.arrayChangeIds(collectInfo.getTextureType()));
            //质地 转换成 id串
            collectInfo.setTexture(CollectUtils.arrayChangeIds(collectInfo.getTexture()));
            //在库位置 转换成 id串
            collectInfo.setStorehouse(CollectUtils.arrayChangeIds(collectInfo.getStorehouse()));

            try {
                if (saveOrCommit.equals("0")) {
                    if (DataUtil.isEmpty(collectInfo.getStatus())) {
                        collectInfo.setStatus("0");
                    }
                }
                collectInfoService.updateByPrimaryKeySelective(collectInfo);
            } catch (Exception e) {
                throw new BaseRuntimeException(CollectErrorDefine.COLLECT_INFO_SAVE_ERR);
            }

            //保存自定义属性
            JSONArray userDefinedFieldList = json.getJSONArray("userDefinedFieldList");
            List<UserDefined> userDefinedList = new ArrayList<>();
            if (null != userDefinedFieldList) {
                for (int i = 0; i < userDefinedFieldList.size(); i++) {
                    JSONObject userDefinedJson = (JSONObject) userDefinedFieldList.get(i);
                    UserDefined userDefined = userDefinedJson.toJavaObject(UserDefined.class);
                    userDefinedList.add(userDefined);
                }
                collectCommonBusinessService.updateUserDefinedField(userDefinedList);
            }

            //保存征集鉴定意见
            JSONArray catalogZjAppraisalList = json.getJSONArray("zjList");
            List<CatalogZjAppraisal> catalogZjAppraisals = new ArrayList<>();
            if (null != catalogZjAppraisalList) {
                for (int i = 0; i < catalogZjAppraisalList.size(); i++) {
                    JSONObject catalogZjAppraisalJson = (JSONObject) catalogZjAppraisalList.get(i);
                    CatalogZjAppraisal catalogZjAppraisal = catalogZjAppraisalJson.toJavaObject(CatalogZjAppraisal.class);
                    catalogZjAppraisals.add(catalogZjAppraisal);
                }
                try {
                    catalogZjAppraisalService.updateManySelective(catalogZjAppraisals);
                } catch (Exception e) {
                    throw new BaseRuntimeException(CollectErrorDefine.ZJ_INFO_SAVE_ERR);
                }
            }

            //保存定级鉴定信息
            JSONArray gradingList = json.getJSONArray("djList");
            List<Grading> gradings = new ArrayList<>();
            if (null != gradingList) {
                for (int i = 0; i < gradingList.size(); i++) {
                    JSONObject gradingJson = (JSONObject) gradingList.get(i);
                    Grading grading = gradingJson.toJavaObject(Grading.class);
                    gradings.add(grading);
                }
                try {
                    gradingService.updateManySelective(gradings);
                } catch (Exception e) {
                    throw new BaseRuntimeException(CollectErrorDefine.DJ_INFO_SAVE_ERR);
                }
            }

            //保存流传信息
            JSONArray lcList = json.getJSONArray("lcList");
            List<CirculateLive> circulateLives = new ArrayList<>();
            if (null != lcList) {
                for (int i = 0; i < lcList.size(); i++) {
                    JSONObject circulateLiveJson = (JSONObject) lcList.get(i);
                    CirculateLive circulateLive = circulateLiveJson.toJavaObject(CirculateLive.class);
                    circulateLives.add(circulateLive);
                }
                try {
                    circulateLiveService.updateManySelective(circulateLives);
                } catch (Exception e) {
                    throw new BaseRuntimeException(CollectErrorDefine.LC_INFO_SAVE_ERR);
                }
            }

            //保存损坏记录
            JSONArray shList = json.getJSONArray("shList");
            List<BreakDown> breakDownList = new ArrayList<>();
            if (null != shList) {
                for (int i = 0; i < shList.size(); i++) {
                    JSONObject breakDownJson = (JSONObject) shList.get(i);
                    BreakDown breakDown = breakDownJson.toJavaObject(BreakDown.class);
                    breakDownList.add(breakDown);
                }
                try {
                    breakDownService.updateManySelective(breakDownList);
                } catch (Exception e) {
                    throw new BaseRuntimeException(CollectErrorDefine.SH_INFO_SAVE_ERR);
                }
            }

            //保存著录
            JSONArray zlList = json.getJSONArray("zlList");
            List<Bookmaking> bookmakingList = new ArrayList<>();
            if (null != zlList) {
                for (int i = 0; i < zlList.size(); i++) {
                    JSONObject bookmakingJson = (JSONObject) zlList.get(i);
                    Bookmaking bookmaking = bookmakingJson.toJavaObject(Bookmaking.class);
                    bookmakingList.add(bookmaking);
                }
                try {
                    bookmakingService.updateManySelective(bookmakingList);
                } catch (Exception e) {
                    throw new BaseRuntimeException(CollectErrorDefine.ZL_INFO_SAVE_ERR);
                }
            }

            // 自定义字段属性保存
            JSONObject collectCustomObj = json.getJSONObject("collectCustomObj");
            if (collectCustomObj != null) {
                CustomProperty customProperty = json.getJSONObject("collectCustomObj").toJavaObject(CustomProperty.class);
                customPropertyService.saveData(customProperty);
            }

            if (("1").equals(saveOrCommit)) {
                throw new BaseRuntimeException(CollectErrorDefine.COMMIT_SUCCESS);
            } else {
                throw new BaseRuntimeException(CollectErrorDefine.SAVE_SUCCESS);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    /**
     * 藏品信息必填项校验
     */
    public String checkCollectInfo(CollectInfo collectInfo) {
        String mes = "";

        if (DataUtil.isEmpty(collectInfo.getCollectName())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "藏品名称");
            return mes;
        }

        if (DataUtil.isEmpty(collectInfo.getTotalNum())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "总登记号");
            return mes;
        }

//        String years = collectInfo.getYears().replace("\"","").replace("[]", "");
//        if (DataUtil.isEmpty(years)) {
//            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "年代");
//            return mes;
//        }

        if (DataUtil.isEmpty(collectInfo.getCpLevel())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "藏品级别");
            return mes;
        }

        if (DataUtil.isEmpty(collectInfo.getCollectType())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "藏品类别");
            return mes;
        }

//        String textureType = collectInfo.getTextureType().replace("\"","").replace("[]", "");
//        if (DataUtil.isEmpty(textureType)) {
//            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "质地类别");
//            return mes;
//        }

        if (DataUtil.isEmpty(collectInfo.getSpecificAge())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "具体年代");
            return mes;
        }

        String texture = collectInfo.getTexture().replace("\"", "");
        if (DataUtil.isEmpty(texture)) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "具体质地");
            return mes;
        }

        if (DataUtil.isEmpty(collectInfo.getMassRange())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "质量范围");
            return mes;
        }

        // 选择质量范围未选择质量单位时提示
        if (!DataUtil.isEmpty(collectInfo.getMassRange()) && DataUtil.isEmpty(collectInfo.getMassUnit())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "质量范围单位");
            return mes;
        }

        //在库位置
        String storehouse = collectInfo.getStorehouse().replace("\"", "").replace("[]", "");
        if (DataUtil.isEmpty(storehouse)) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "在库位置");
            return mes;
        }

        if (DataUtil.isEmpty(collectInfo.getOutState())) {
            mes = String.format(CollectErrorDefine.NOTNULL_CHECK, "在库状态");
            return mes;
        }

        return mes;
    }
}
