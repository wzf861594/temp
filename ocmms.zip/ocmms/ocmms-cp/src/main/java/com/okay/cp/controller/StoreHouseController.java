package com.okay.cp.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.cp.entity.StoreHouseTree;
import com.okay.cp.service.StoreHouseService;
import com.okay.framework.controller.BaseController;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @ClassName: StoreHouseController
 * @Description: 库房管理
 * @author: HQ.ZHU
 * @date: 2019-09-23 14:55
 * @version: V1.0
 */
@RestController
@RequestMapping("/storeHouse")
public class StoreHouseController extends BaseController {

    @Autowired
    private StoreHouseService storeHouseService;

    /**
     * 库房左树及方位级联下拉数据
     * @return
     */
    @GetMapping("/dataTree")
    public JSONObject getStoreHouse(){
        JSONObject jsonObject = new JSONObject();
        try{
            List<Map> storeHouseTree = storeHouseService.getStoreHouseDataTree();
            Map<String, Object> orientationList = storeHouseService.getOrientationSelect();

            jsonObject.put("data", storeHouseTree);
            jsonObject.put("orientationList", orientationList);//用于更新方位下拉
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 方位级联下拉数据
     * @return
     */
    @GetMapping("/orientationSelect")
    public JSONObject getOrientationSelect(){
        JSONObject jsonObject = new JSONObject();
        try{
            Map<String, Object> orientationList = storeHouseService.getOrientationSelect();
            jsonObject.put("data", orientationList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 增加节点
     * @param storeHouseTree
     * @return
     */
    @SysLog("库房信息-增加库房")
    @PostMapping("/addTreeNode")
    public JSONObject addTreeNode(@RequestBody StoreHouseTree storeHouseTree){
        JSONObject jsonObject = new JSONObject();
        try{
            storeHouseTree.setId(getSequence());
            storeHouseService.addTreeNode(storeHouseTree);
            Map<String, Object> orientationList = storeHouseService.getOrientationSelect();

            jsonObject.put("orientationList", orientationList);//用于更新方位下拉
            jsonObject.put("data", storeHouseTree);
            jsonObject.put("code", 1);
            jsonObject.put("msg", "添加成功");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 删除节点
     * @param storeHouseTree
     * @return
     */
    @SysLog("库房信息-删除库房")
    @PostMapping("/removeTreeNode")
    public JSONObject removeTreeNode(@RequestBody StoreHouseTree storeHouseTree){
        JSONObject jsonObject = new JSONObject();
        try{
            storeHouseService.removeTreeNode(storeHouseTree);
            Map<String, Object> orientationList = storeHouseService.getOrientationSelect();
            jsonObject.put("orientationList", orientationList);//用于更新方位下拉
            jsonObject.put("code", 1);
            jsonObject.put("msg", "删除成功");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 修改节点
     * @param storeHouseTree
     * @return
     */
    @SysLog("库房信息-修改库房")
    @PostMapping("/modifyTreeNode")
    public JSONObject modifyTreeNode(@RequestBody StoreHouseTree storeHouseTree){
        JSONObject jsonObject = new JSONObject();
        try{
            storeHouseService.modifyTreeNode(storeHouseTree);
            Map<String, Object> orientationList = storeHouseService.getOrientationSelect();
            jsonObject.put("orientationList", orientationList);//用于更新方位下拉
            jsonObject.put("code", 1);
            jsonObject.put("msg", "修改成功");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }
}
