package com.okay.cp.entity;

import java.util.Date;

public class BrowseRecord {
    private String browseId;

    private String collectId;

    private String browseUser;

    private Date browseTime;

    public String getBrowseId() {
        return browseId;
    }

    public void setBrowseId(String browseId) {
        this.browseId = browseId;
    }

    public String getCollectId() {
        return collectId;
    }

    public void setCollectId(String collectId) {
        this.collectId = collectId;
    }

    public String getBrowseUser() {
        return browseUser;
    }

    public void setBrowseUser(String browseUser) {
        this.browseUser = browseUser;
    }

    public Date getBrowseTime() {
        return browseTime;
    }

    public void setBrowseTime(Date browseTime) {
        this.browseTime = browseTime;
    }
}