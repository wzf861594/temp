package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.github.pagehelper.PageHelper;
import com.okay.cp.baseBusiness.SolictBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.SolicClues;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.SolicClueService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.DataExportUtils;
import com.okay.framework.utils.DataUtil;
import com.okay.framework.utils.DateUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/9/18 15:54
 * @Version: 1.0
 * @Description: 征集线索控制类.
 */

@RestController
@RequestMapping(value = "/clue")
public class SolicCluesController extends SolictBaseBusiness {

    @Autowired
    private SolicClueService solicClueService;
    @Autowired
    private UserService userService;
    @Autowired
    private CollectCommonCodeService collectCommonService;

    /**
     * 查询列表初始化.
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initForm(){
        JSONObject jsonObject = new JSONObject();
        JSONArray sourceOptions = collectCommonService.sourceOptions();
        jsonObject.put("sourceOptions",sourceOptions);
        jsonObject.put("code",1);
        return jsonObject;
    }

    /**
     * 线索页面初始化.
     * @return
     */
    @RequestMapping(value = "/initPage", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initPage(){
        String cluesCode = "XS_" + DateUtil.getNextTime();
        JSONObject jsonObject = this.getOptions();
        jsonObject.put("cluesCode",cluesCode);
        jsonObject.put("code",1);
        return jsonObject;
    }

    /**
     * 线索列表数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        // 查询及结果处理
        com.github.pagehelper.Page pageResult = getDataByPage(page);
        List<Map<String,Object>> dataMapList = resultHandle(pageResult);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data",dataMapList);
        jsonObject.put("pages",pageResult.getPages());
        jsonObject.put("total",pageResult.getTotal());
        jsonObject.put("pageSize",page.getPageSize());
        jsonObject.put("code",1);

        return jsonObject;
    }

    /**
     * 线索新增.
     * @param solicClues
     * @return
     */
    @SysLog("线索录入新增")
    @RequestMapping(value="/insert", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
//    @PreAuthorize("@pms.hasPermission('LS_ADD')")
    public JSONObject addClues(@RequestBody @Valid SolicClues solicClues) {

        JSONObject jsonObject = new JSONObject();
        try{
            SolicClues newSolicClues = solicClueService.add(solicClues);
            jsonObject.put("data",newSolicClues);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.ADD_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取线索信息.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value="/getById", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getClue(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        try{
            String id = jsonParam.getString("clueId");
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            Map<String,Object> solicClues = solicClueService.findByClueIdForMap(id);

            // 去掉创建时间
            solicClues.put("creatTime",null);
            // 年代处理
            String yearId = String.valueOf(solicClues.get("culturalAge"));
            String yearName = getYearName(yearId);
            solicClues.put("culturalAgeName",yearName);
            solicClues.put("culturalAgeList",yearId.split(","));

            jsonObject.put("data",solicClues);
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 线索修改.
     * @param solicClues
     * @return
     */
    @SysLog("线索录入修改")
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject update(@RequestBody @Valid SolicClues solicClues){
        JSONObject jsonObject = new JSONObject();
        try{
            if (DataUtil.isEmpty(solicClues.getCluesId())) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.CHOOSE_HANDLE_DATA));
            }
            solicClueService.modify(solicClues);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.UPDATE_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 线索删除.
     * @param jsonParam
     * @return
     */
    @SysLog("线索录入废弃")
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @PreAuthorize("@pms.hasPermission('LS_ABANDONMENT')")
    public JSONObject delete(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();

        String id = jsonParam.getString("clueId");
        String reason = jsonParam.getString("reason");
        Boolean confirmFlg = jsonParam.getBooleanValue("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(reason)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.NOT_DATA_ERROR,"作废原因"));
            }
            if (!confirmFlg) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_ABANDON);
            }
            List<String> idList = new ArrayList<>(Arrays.asList(id.split(",")));
            for (int i = 0; i < idList.size(); i++) {
                SolicClues solicClues = new SolicClues();
                solicClues.setCluesId(idList.get(i));
                solicClues.setAssignState(2);
                solicClues.setAbandonTime(new Date());
                solicClues.setAbandonReason(reason);
                solicClues.setAbandonUser(userService.getLoginUser().getUserId());
                solicClueService.modify(solicClues);
            }
            throw new BaseRuntimeException(String.format(CollectErrorDefine.ABANDON_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 保存并指派.
     * @param solicClues
     * @return
     */
    @SysLog("綫索录入保存并指派")
    @RequestMapping(value = "/saveAndAssign", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject saveAndAssign(@RequestBody @Valid SolicClues solicClues){
        JSONObject jsonObject = new JSONObject();
        try{
            if (DataUtil.isEmpty(solicClues.getAssignUser())) {
                throw new BaseRuntimeException(CollectErrorDefine.ONE_NOT_USER_ERROR);
            }
            if (DataUtil.isEmpty(solicClues.getCluesId())) {
                solicClueService.add(solicClues);
            }else {
                solicClueService.modify(solicClues);
            }
            solicClueService.assign(solicClues.getCluesId());
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.ASSIGN_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 批量指派.
     * @param jsonParam
     * @return
     */
    @SysLog("线索录入批量指派")
    @RequestMapping(value = "/batchAssign", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @PreAuthorize("@pms.hasPermission('LS_ASSIGN')")
    public JSONObject batchAssign(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try{
            String cluesId = jsonParam.getString("cluesId");
            Boolean confirmFlg = jsonParam.getBooleanValue("confirmFlg");
            if (DataUtil.isEmpty(cluesId)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (!confirmFlg) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_ASSIGN);
            }
            solicClueService.assign(cluesId);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.ASSIGN_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }
    /**
     * 导出选择列.（未指派）
     * @return
     */
    @RequestMapping(value = "/exportHeaderNotAssigned", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeaderNotAssigned() {

        String headerArray = "[" +
                "{'label':'线索名称','key':'cluesName'}," +
                "{'label':'线索编码','key':'cluesCode'}," +
                "{'label':'线索来源','key':'cluesSource_t'}," +
                "{'label':'文物类别','key':'culturalType_t'}," +
                "{'label':'文物年代','key':'culturalAge_t'}," +
                "{'label':'联系人','key':'linkPeople'}," +
                "{'label':'联系电话','key':'linkTel'}," +
                "{'label':'创建人员','key':'creatUser_t'}," +
                "{'label':'创建时间','key':'creatTime'}," +
                "{'label':'指派人','key':'assignUser_t'}," +
                "{'label':'具体年代','key':'specificAge'}" +
                "]";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("exportHeaderList", JSONArray.parseArray(headerArray));
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {

        String headerArray = "[" +
                "{'label':'线索名称','key':'cluesName'}," +
                "{'label':'线索编码','key':'cluesCode'}," +
                "{'label':'线索来源','key':'cluesSource_t'}," +
                "{'label':'文物类别','key':'culturalType_t'}," +
                "{'label':'文物年代','key':'culturalAge_t'}," +
                "{'label':'联系人','key':'linkPeople'}," +
                "{'label':'联系电话','key':'linkTel'}," +
                "{'label':'创建人员','key':'creatUser_t'}," +
                "{'label':'创建时间','key':'creatTime'}," +
                "{'label':'指派人','key':'assignUser_t'}," +
                "{'label':'指派时间','key':'assignTime'}," +
                "{'label':'具体年代','key':'specificAge'}" +
                "]";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("exportHeaderList", JSONArray.parseArray(headerArray));
        jsonObject.put("code", "1");
        return jsonObject;
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("线索录入导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {

        try{
            Page page = jsonParam.getJSONObject("page").toJavaObject(Page.class);

            //导出类型 0:导出查询的全部数据 1: 当前页数据 2：选择的数据
            String exportType = jsonParam.getString("exportType");
            if (DataUtil.isEmpty(exportType)) {
                exportType = "0";
            }
            if (exportType.equals("0")) {
                page.setPageSize(0);
                page.setPageNum(0);
            } else  if (exportType.equals("2")) {
                String cluesId = String.valueOf(page.getConditionMap().get("cluesId"));
                page.getConditionMap().put("cluesIdList",Arrays.asList(cluesId.split(",")));
            }

            //导出文件名
            String fileName = jsonParam.getString("exportFileName");
            if (DataUtil.isEmpty(fileName)) {
                fileName = "线索信息导出";
            }

            // 获取选择导出的列数据
            List headerNameList = new ArrayList();
            List headerKeyList = new ArrayList();
            JSONArray exportColumn = jsonParam.getJSONArray("exportColumn");
            for (int i = 0; i < exportColumn.size(); i++) {
                JSONObject jsonObject = (JSONObject) exportColumn.get(i);
                headerNameList.add(jsonObject.getString("label"));//表头
                headerKeyList.add(jsonObject.getString("key"));//取出的key值
            }

            // 查询数据及结果处理
            com.github.pagehelper.Page pageResult = getDataByPage(page);
            List<Map<String,Object>> dataMapList = resultHandle(pageResult);

            // 根据选择导出列封装导出数据
            List<Object> exportDataList = new ArrayList<Object>();
            for (Map<String,Object> dataMap : dataMapList) {
                List<String> stringDataList = new ArrayList<String>();
                for (int j = 0; j < headerKeyList.size(); j++) {
                    String key = headerKeyList.get(j).toString();
                    String value = dataMap.get(key) == null ? "" : String.valueOf(dataMap.get(key));
                    stringDataList.add(value);
                }
                exportDataList.add(stringDataList);
            }

            HSSFWorkbook wb = DataExportUtils.creakWorkBook(headerNameList, exportDataList);
            DataExportUtils.setResponseHeader(response, wb, fileName);
        }catch (Exception e){
            e.printStackTrace();
            response.setStatus(201);
        }
    }

    /**
     * 查询数据.
     * @param page
     * @return
     */
    public com.github.pagehelper.Page getDataByPage(Page page){
        com.github.pagehelper.Page pageResult = null;
        Map<String,Object> conditionMap = new HashMap<String,Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state","0");
                }
                // 查询时间
                Object object = conditionMap.get("creatTime");
                if (object != null && !"".equals(object)) {
                    ArrayList<String> creatTime = (ArrayList)object;
                    if (null != creatTime && !"".equals(creatTime)) {
                        if (creatTime.size() == 2) {
                            if ("0".equals(conditionMap.get("state"))) {
                                conditionMap.put("startCreatTime", creatTime.get(0));
                                conditionMap.put("endCreatTime", creatTime.get(1));
                            }else if ("1".equals(conditionMap.get("state"))) {
                                conditionMap.put("startAssignTime", creatTime.get(0));
                                conditionMap.put("endAssignTime", creatTime.get(1));
                            }else {
                                conditionMap.put("startAbandonTime", creatTime.get(0));
                                conditionMap.put("endAbandonTime", creatTime.get(1));
                            }
                        }
                    }
                }

                // 排序
                if("1".equals(conditionMap.get("state"))) {
                    conditionMap.put("orderBy", "assignTime desc");
                }else if ("2".equals(conditionMap.get("state"))) {
                    conditionMap.put("orderBy", "abandonTime desc");
                }
            }
            // 查询
            try(com.github.pagehelper.Page pages = PageHelper.startPage(page.getPageNum(), page.getPageSize(), true)) {
                pageResult = pages;
                solicClueService.findDataList(conditionMap);
            }
        }
        return pageResult;
    }

    /**
     * 查询结果处理.
     * @param pageResult
     * @return
     */
    public List<Map<String,Object>> resultHandle(com.github.pagehelper.Page pageResult){
        List<Map<String,Object>> dataMapList = new ArrayList<Map<String,Object>>();
        for (int i = 0; i < pageResult.size(); i++) {
            SolicClues solicClues = (SolicClues)pageResult.get(i);
            String jsonString = JSONObject.toJSONString(solicClues, SerializerFeature.WriteNullStringAsEmpty);
            Map<String,Object> dataMap = JSONObject.parseObject(jsonString);

            if (solicClues != null) {
                // 创建时间
                SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                if (solicClues.getCreatTime() != null) {
                    dataMap.put("creatTime", sDateFormat.format(solicClues.getCreatTime()));
                }

                // 年代处理
                String yearId = String.valueOf(solicClues.getCulturalAge());
                String yearName = getYearName(yearId);
                dataMap.put("culturalAge_t",yearName);

                // 跟踪人员处理
                String userId = String.valueOf(solicClues.getAssignUser());
                dataMap.put("assignUser_t", getUserName(userId));

                // 来源方式
                String name = collectCommonService.source_t(String.valueOf(solicClues.getCluesSource()));
                dataMap.put("cluesSource_t",name);

                // 文物类别
                name = collectCommonService.collectType_t(String.valueOf(solicClues.getCulturalType()));
                dataMap.put("culturalType_t",name);

                // 创建人
                if (solicClues.getCreatUser() != null){
                    dataMap.put("creatUser_t", getUserName(solicClues.getCreatUser()));
                }

                // 指派时间
                if (solicClues.getAssignTime() != null){
                    dataMap.put("assignTime", sDateFormat.format(solicClues.getAssignTime()));
                }

                dataMapList.add(dataMap);
            }
            nullToEmpty(dataMapList);
        }
        return dataMapList;
    }

    public List<Map<String, Object>> nullToEmpty(List<Map<String, Object>> mapList) {
        for (int i = 0; i < mapList.size(); i++) {
            Map<String,Object> map = mapList.get(i);
            Set<String> set = map.keySet();
            if (set != null && !set.isEmpty()) {
                for (String key : set) {
                    if (map.get(key) == null) {
                        map.put(key, "");
                    }
                }
            }
        }
        return mapList;
    }
}
