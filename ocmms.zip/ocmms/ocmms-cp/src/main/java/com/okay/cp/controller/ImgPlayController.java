package com.okay.cp.controller;


import com.alibaba.fastjson.JSONObject;
import com.okay.common.constants.ServiceNameConstants;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.ImgPlay;
import com.okay.cp.service.ImgPlayService;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.util.*;

/**
 * 轮播图控制器.
 * @author wenlh
 */
@RestController
@RequestMapping(value = "/imgPlay")
public class ImgPlayController {

    @Autowired
    protected ImgPlayService imgPlayService;

    /**
     * 取得使用的轮播图片.
     * @return
     */
    @RequestMapping(value = "/list/use", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public JSONObject getUseImgPlayList(){
        JSONObject result = new JSONObject();
        try {
            Map<String,Object> query = new HashMap<String,Object>();
            query.put("isUse",1);
            List<ImgPlay> list = imgPlayService.getImgPlayList(query);

            List<Map<String,Object>> dataResult = new ArrayList<Map<String,Object>>();
            Iterator<ImgPlay> iterator = list.iterator();
            while(iterator.hasNext()) {
                ImgPlay obj = iterator.next();
                // 需要解析为网络路径.
                String imageUrl = getImageUrl(obj.getImgId());
                Map<String,Object> data = new HashMap<String,Object>();
                data.put("img", imageUrl);
                data.put("imageName", obj.getImgName());
                data.put("linkPath", obj.getLinkPath());
                data.put("introduction", obj.getIntroduction());
                dataResult.add(data);
            }
            result.put("data", dataResult);
            result.put("code", 1);
        }catch (Exception e) {
            result.put("code", -1);
        }
        return result;
    }

    /**
     * 图片输出流
     * @param response
     * @param id
     */
    @RequestMapping(value = "/image/{id}", method = RequestMethod.GET)
    public void getImageIo(HttpServletResponse response, @PathVariable String id) {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        byte[] data = null;

        try {
            // 创建图片输出流
            response.setContentType("image/jpeg");
            response.setCharacterEncoding("UTF-8");

            ImgPlay imgPlay = imgPlayService.getImgPlay(id);

            if (imgPlay != null) {
                String fileName = imgPlay.getImgPath();
                if(fileName != null && !"".equals(fileName)) {
                    // 获取保存路劲图片的图片流
                    //String filePath = Constant.OS_PATH + Constant.FILE_PATH.get("potalImgPlay") + File.separator + fileName;
                    String filePath = "";
                    File ioFile = new File(filePath);
                    if(ioFile.exists()) {
                        inputStream = new BufferedInputStream(new FileInputStream(ioFile));
                        data = new byte[(int) inputStream.available()];
                        inputStream.read(data);
                        inputStream.close();
                    }
                }
                if (data == null) {
                    data = imgPlay.getBytes();
                }
            }
            if (data == null) {
                if (inputStream != null) {
                    inputStream.close();
                }

                URL resource = this.getClass().getClassLoader().getResource("icons/unfind.jpg");
                if (resource != null) {
                    inputStream = new BufferedInputStream(resource.openStream());
                    data = new byte[inputStream.available()];
                    inputStream.read(data);
                    inputStream.close();
                }
            }

            if (data != null) {
                outputStream = response.getOutputStream();
                outputStream.write(data);
                outputStream.flush();
            }
        } catch (Exception e) {
            throw new RuntimeException("图片获取失败");
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                }
            }
        }
    }

    /**
     *  图片上传.
     * @param request
     * @param uploadFile
     * @return
     */
    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public JSONObject upload(HttpServletRequest request, @RequestParam("file") MultipartFile uploadFile) {
        JSONObject jsonObject = new JSONObject();

        try {
            String fileName = uploadFile.getOriginalFilename();
            byte[] imageByte = uploadFile.getBytes();
            ImgPlay imgPlay = imgPlayService.upload(fileName, imageByte);
            jsonObject.put("data",imgPlay);
            jsonObject.put("code","1");
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.UPLOAD_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject,e);
        }
        return jsonObject;
    }

    /**
     * 获取已上传的轮播信息.
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getUploadList(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        try {
            String useFlag = jsonParam.getString("useFlag");
            Map<String,Object> queryMap = new HashMap<String,Object>();
            if ("0".equals(useFlag)){
                queryMap.put("isDelete",null);
                queryMap.put("useFlag",useFlag);
                queryMap.put("orderBy","sortTime desc");
            }else {
                queryMap.put("isDelete",3);
                queryMap.put("orderBy","modifyTime desc");
            }

            List<ImgPlay> list = imgPlayService.getImgPlayList(queryMap);
            list = imgConversion(list);
            jsonObject.put("data", list);
            jsonObject.put("code", "1");
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息保存.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/updateList", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject updateList(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        try {
            List<ImgPlay> list = jsonParam.getJSONArray("imgPlay").toJavaList(ImgPlay.class);
            for (int i = 0; i < list.size(); i++) {
                ImgPlay imgPlay = list.get(i);
                if (imgPlay.getUseFlag() != 1) {
                    ImgPlay newImgPlay = new ImgPlay();
                    newImgPlay.setImgId(imgPlay.getImgId());
                    newImgPlay.setLinkPath(imgPlay.getLinkPath());
                    newImgPlay.setIntroduction(imgPlay.getIntroduction());
                    imgPlayService.saveInfo(newImgPlay);
                }
            }
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.UPDATE_SUCCESS);
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息发布
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/publish", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject publish(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        try {
            ImgPlay imgPlay = jsonParam.getJSONObject("imagePlay").toJavaObject(ImgPlay.class);
            imgPlayService.saveInfo(imgPlay);
            imgPlayService.publish(imgPlay.getImgId());
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.PUBLIC_SUCCESS);
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 发布撤销.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/repeal", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject repeal(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        try {
            String imgId = jsonParam.getString("imgId");
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_CANCEL);
            }
            imgPlayService.repeal(imgId);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.CANCEL_SUCCESS);
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 删除
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject delete(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        try {
            ImgPlay imgPlay = jsonParam.getJSONObject("imagePlay").toJavaObject(ImgPlay.class);
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                if (imgPlay.getUseFlag()== 0 || imgPlay.getUseFlag()== 2 || imgPlay.getUseFlag() == 3) {
                    throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
                }else if (imgPlay.getUseFlag() == 1) {
                    throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,"已发布，"));
                }
            }
            imgPlayService.delete(imgPlay);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.DELETE_SUCCESS);
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 恢复已删除数据.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/recover", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject recover(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        try {
            String imgId = jsonParam.getString("imgId");
            String confirmFlg = jsonParam.getString("confirmFlg");
            // 是否允许历史数据回撤
            Map<String,Object> queryMap = new HashMap<String,Object>();
            queryMap.put("useFlag",1);
            List<ImgPlay> imgPlayList = imgPlayService.getImgPlayList(queryMap);
            if (imgPlayList.size() < 6) {
                if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                    throw new BaseRuntimeException(CollectErrorDefine.ASK_RECOVER_DELETE);
                }
                imgPlayService.recover(imgId);
                throw new BaseRuntimeException(CollectErrorDefine.RECOVER_DELETE_SUCCESS);
            }else {
                throw new BaseRuntimeException(CollectErrorDefine.RECOVER_ERROR);
            }
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    public List<ImgPlay> imgConversion(List<ImgPlay> list){
        List<ImgPlay> imgList = new ArrayList<ImgPlay>();
        for (int i = 0; i < list.size(); i++) {
            ImgPlay imgPlay = list.get(i);
            String imageUrl = getImageUrl(imgPlay.getImgId());
            imgPlay.setImageUrl(imageUrl);
            imgList.add(imgPlay);
        }
        return imgList;
    }

    public String getImageUrl(String imgId){
        String imageUrl = "";
        if (!DataUtil.isEmpty(imgId)) {
            // 获取项目名称
            String proName = ServiceNameConstants.CP_PREFIX;
            // 需要解析为网络路径.
            imageUrl = proName + "/imgPlay/image/" + imgId;
        }
        return imageUrl;
    }

}
