package com.okay.cp.controller;

import com.baomidou.mybatisplus.extension.api.R;
import com.okay.cp.entity.dto.InWarehouseDTO;
import com.okay.cp.entity.dto.ReferAccountAuditDTO;
import com.okay.cp.service.CollectInfoService;
import io.swagger.annotations.Api;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author CZJ[OKAY]
 * @date 2021/12/2 16:51
 * @description 藏品信息Controller
 **/
@RestController
@AllArgsConstructor
@Api(tags = "藏品信息Controller")
@RequestMapping(value = "/collect")
public class CollectInfoController {

    private final CollectInfoService collectInfoService;

    /**
     * 流水账入库
     *
     * @param collectIds 藏品ID
     * @param type       流水账入库类型
     * @return
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/runAccountInWarehouse")
    public R runAccountInWarehouse(@RequestParam(value = "collectIds") List<String> collectIds,
                                   @RequestParam(value = "type") Integer type) {
        return R.ok(collectInfoService.runAccountInWarehouse(collectIds, type));
    }

    /**
     * 参考账审核
     *
     * @param dto 审核意见信息
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/referAccountAudit")
    public R referAccountAudit(ReferAccountAuditDTO dto) {
        return R.ok(collectInfoService.referAccountAudit(dto));
    }

    /**
     * 藏品入库
     *
     * @param dto 入库信息
     * @return R
     * @author CZJ[OKAY]
     **/
    @PostMapping(value = "/inWarehouse")
    public R inWarehouse(InWarehouseDTO dto) {
        return R.ok(collectInfoService.inWarehouse(dto));
    }

}
