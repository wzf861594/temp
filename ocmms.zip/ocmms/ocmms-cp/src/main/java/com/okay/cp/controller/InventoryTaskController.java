package com.okay.cp.controller;


import com.alibaba.fastjson.JSONObject;
import com.okay.cp.baseBusiness.InventoryBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.CollectInfo;
import com.okay.cp.entity.Inventory;
import com.okay.cp.service.CollectCommonBusinessService;
import com.okay.cp.service.CollectCommonCodeService;
import com.okay.cp.service.CollectInfoService;
import com.okay.cp.service.InventoryService;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.DataUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.*;

/**
 * @Author: xdn
 * @CreateDate: 2019/10/9 16:52
 * @Version: 1.0
 * @Description: 藏品盘点任务控制器.
 */

@RestController
@RequestMapping(value = "/task")
public class InventoryTaskController  extends InventoryBaseBusiness {

    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private CollectInfoService collectInfoService;


    /**
     * 查询列表初始化.
     * @return
     */
    @RequestMapping(value = "/initForm", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initList(){
        return initData();
    }

    /**
     * 信息页面初始化.
     * @return
     */
    @RequestMapping(value = "/initPage", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject initPage(){
        return initData();
    }

    /**
     * 列表数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject dataList(@RequestBody Page page) {

        Map<String,Object> conditionMap = new HashMap<String,Object>();
        if (page != null) {
            conditionMap = page.getConditionMap();
            if (conditionMap != null) {
                // 查询状态
                String state = String.valueOf(conditionMap.get("state"));
                if (DataUtil.isEmpty(state) || "null".equals(state)) {
                    conditionMap.put("state","0");
                }
            }
        }
        // 在线用户
//        User user = ComUtils.getLoginUser();
//        conditionMap.put("createUser", user.getUserId());

        return getDataList(page);
    }

    /**
     * 获取数据.
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam){
        return getDataById(jsonParam);
    }

    /**
     * 获取盘点明细数据.
     * @param page
     * @return
     */
    @RequestMapping(value = "/getByQuery", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getByQuery(@RequestBody Page page){
        return getInventoryListByQuery(page);
    }

    /**
     * 信息新增.
     * @param inventory
     * @return
     */
    @SysLog("盘点任务-新增")
    @RequestMapping(value="/insert", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject insert(@RequestBody @Valid Inventory inventory) {

        JSONObject jsonObject = new JSONObject();
        try{
            Inventory newInventory = inventoryService.addMainInfoAndAssociInfo(inventory);
            jsonObject.put("singleData",newInventory);
            throw new BaseRuntimeException(String.format(CollectErrorDefine.ADD_SUCCESS));
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息修改.
     * @param inventory
     * @return
     */
    @SysLog("盘点任务-修改")
    @RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject update(@RequestBody @Valid Inventory inventory){
        JSONObject jsonObject = new JSONObject();
        try {
            inventoryService.updateMainInfoAndAssociaInfo(inventory);
            ExceptionUtil.formatResultJsonObject(jsonObject, CollectErrorDefine.SAVE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 批量信息删除.
     * @param jsonParam
     * @return
     */
    @SysLog("盘点任务-删除")
    @PreAuthorize("@pms.hasPermission('IT_DEL')")
    @RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject delete(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();

        String id = jsonParam.getString("inventoryId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.ASK_HANDLE_DEL,""));
            }
            int handleNum = inventoryService.remove(id);
            if (handleNum == Arrays.asList(id.split(",")).size()) {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_SUCCESS));
            }else {
                throw new BaseRuntimeException(String.format(CollectErrorDefine.DELETE_ERR));
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 信息提交 =》 现场盘点.
     * @param jsonParam
     * @return
     */
    @SysLog("盘点任务-提交现场盘点")
    @PreAuthorize("@pms.hasPermission('IT_SUBMITSCENE')")
    @RequestMapping(value = "/submit", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject submit(@RequestBody JSONObject jsonParam){

        JSONObject jsonObject = new JSONObject();
        String id = jsonParam.getString("inventoryId");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try{
            if (DataUtil.isEmpty(id)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            if (DataUtil.isEmpty(confirmFlg) || "0".equals(confirmFlg)) {
                throw new BaseRuntimeException(CollectErrorDefine.ASK_HANDLE_COMMIT);
            }
            int handleNum = updateState("1",id);
            if (handleNum != Arrays.asList(id.split(",")).size()) {
                throw new BaseRuntimeException(CollectErrorDefine.COMMIT_ERR);
            }else {
                throw new BaseRuntimeException(CollectErrorDefine.COMMIT_SUCCESS);
            }
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 根据选择库房位置查询藏品.
     * @param page
     * @return
     */
    @RequestMapping(value = "/getByStore", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getByStore(@RequestBody Page page){

        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
        JSONObject jsonObject = new JSONObject();
        try{
            List<CollectInfo> collectInfoList = collectInfoService.selectByParameter(page);
            for (CollectInfo collectInfo : collectInfoList) {
                // 实体转Map
                String jsonString = JSONObject.toJSONString(collectInfo);
                Map<String, Object> dataMap = JSONObject.parseObject(jsonString);

                // 保存状态
                dataMap.put("keepState_t",collectCommonCodeService.keepState_t(collectInfo.getKeepState()));
                // 库房位置
                dataMap.put("storehouse_t",collectCommonCodeService.storehouse_t(collectInfo.getStorehouse()));
                // 完成程度
                dataMap.put("completeDegree_t",collectCommonCodeService.completeDegree_t(collectInfo.getCompleteDegree()));
                // 数量单位
                dataMap.put("numUnit_t",collectCommonCodeService.numUnit_t(collectInfo.getNumUnit()));
                // 具体方位
                dataMap.put("specificPosition",collectInfo.getSpecificPosition());
                // 在库数量
                int inStoreNum = getCollectInStoreNum(collectInfo.getCollectId());
                dataMap.put("inStoreNum",inStoreNum);
                // 在库状态
                String outState = "在库";
                String realNum = collectInfo.getRealNum();
                if (inStoreNum == 0) {
                    outState = "出库";
                } else if (inStoreNum < Integer.parseInt(realNum)) {
                    outState = "部分出库";
                }
                dataMap.put("outState_t",outState);
                // 获取对应的封面
                String collectId = String.valueOf(collectInfo.getCollectId());
                dataMap.put("image",collectCommonBusinessService.getCoverImg("90", collectId));

                dataList.add(dataMap);
            }

            jsonObject.put("singleList",dataList);
            jsonObject.put("pages",page.getPages());
            jsonObject.put("total",page.getTotal());
            jsonObject.put("pageSize",page.getPageSize());
            jsonObject.put("code",1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 导出选择列.
     * @return
     */
    @RequestMapping(value = "/exportHeader", method = RequestMethod.POST, produces = "application/json")
    public JSONObject exportHeader() {
        return initExportHeader();
    }

    /**
     * 数据导出.
     * @param jsonParam
     * @param request
     * @param response
     */
    @SysLog("盘点任务-导出")
    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = "application/json")
    public void export(@RequestBody JSONObject jsonParam, HttpServletRequest request, HttpServletResponse response) {
        exportHandle(jsonParam,request,response);
    }
}
