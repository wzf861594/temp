package com.okay.cp.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.Indicators;
import com.okay.cp.entity.TextureType;
import com.okay.cp.service.IndicatorsService;
import com.okay.framework.controller.BaseController;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: IndicatorsController
 * @Description: 环境指标管理
 * @author: HQ.ZHU
 * @date: 2019-09-29 11:36
 * @version: V1.0
 */
@RestController
@RequestMapping("/indicators")
public class IndicatorsController extends BaseController {

    @Autowired
    private IndicatorsService indicatorsService;

    @RequestMapping(value = "/dataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject getDataList(@RequestBody Page page){
        JSONObject jsonObject = new JSONObject();
        try{
            List<Map> list = indicatorsService.findDataList(page);
            jsonObject.put("code", 1);
            jsonObject.put("data",list);
            jsonObject.put("pages",page.getPages());
            jsonObject.put("total",page.getTotal());
            jsonObject.put("pageNum",page.getPageNum());
            jsonObject.put("pageSize",page.getPageSize());
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @PostMapping("/getById")
    public JSONObject getById(@RequestBody TextureType textureType){
        JSONObject jsonObject = new JSONObject();
        try{
            Indicators indicators = indicatorsService.findDataByTextureType(textureType);
            if(indicators == null) {
                indicators = new Indicators();
            }
            jsonObject.put("code", 1);
            jsonObject.put("data",indicators);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @SysLog("保管指标-新增")
    @PostMapping("/add")
    public JSONObject add(@RequestBody @Valid Indicators indicators){
        JSONObject jsonObject = new JSONObject();
        try{
            indicators.setIndicatorsId(getSequence());
            int rows = indicatorsService.addData(indicators);
            if(rows != 1)
                throw new BaseRuntimeException(CollectErrorDefine.ADD_ERR);
            jsonObject.put("code", 1);
            jsonObject.put("data",indicators);
            jsonObject.put("msg", "添加成功");
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @SysLog("保管指标-修改")
    @PostMapping("/modify")
    public JSONObject modify(@RequestBody @Valid Indicators indicators){
        JSONObject jsonObject = new JSONObject();
        try{
            int rows = indicatorsService.modifyData(indicators);
            if(rows != 1)
                throw new BaseRuntimeException(CollectErrorDefine.UPDATE_ERR);
            jsonObject.put("code", 1);
            jsonObject.put("data",indicators);
            jsonObject.put("msg", "修改成功");
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }
}
