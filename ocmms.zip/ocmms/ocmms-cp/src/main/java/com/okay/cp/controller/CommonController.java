package com.okay.cp.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.okay.cp.baseBusiness.CollectInfoBaseBusiness;
import com.okay.cp.constant.CollectErrorDefine;
import com.okay.cp.entity.*;
import com.okay.cp.outside.clients.ResServerInterface;
import com.okay.cp.service.*;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.utils.ComUtils;
import com.okay.framework.utils.DataUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import sun.misc.BASE64Decoder;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.util.*;

/**
 * 藏品系统公共控制层
 *
 * @author zhangyx
 * @since 2019/9/29 10:09
 */
@RestController
@RequestMapping(value = "/common")
public class CommonController extends CollectInfoBaseBusiness {

    @Autowired
    private CollectCommonCodeService collectCommonCodeService;
    @Autowired
    private CollectCommonBusinessService collectCommonBusinessService;
    @Autowired
    private ResServerInterface resServerInterface;
    @Autowired
    private CollectInfoService collectInfoService;
    @Autowired
    private CollectInfoHistoryService collectInfoHistoryService;
    @Autowired
    private IndicatorsService indicatorsService;

    /**
     * 附件上传
     *
     * @param map
     * @param file
     * @return
     */
    @RequestMapping(value = "/fileUpload", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject upload(@RequestParam Map<String, String> map, @RequestParam("file") MultipartFile file) {
        return resServerInterface.fileUpload(map, file);
    }

    /**
     * 删除附件
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/fileDel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject commonFileDel(@RequestBody JSONObject json) {
        return collectCommonBusinessService.cpSysFileDel(json);
    }

    /**
     * 藏品编目预览初始化页面
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/initPage", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject initPage(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //藏品基础信息
            JSONObject baseInfo = null;
            try {
                baseInfo = getCollectBaseInfo(json);
            } catch (Exception e) {
                throw new BaseRuntimeException(e.getMessage());
            }

            String collectId = json.getString("collectId");

            //获取自定义属性
            List<UserDefined> userDefinedList = collectCommonBusinessService.findUserDefinedList(collectId);
            baseInfo.put("userDefinedFieldList", userDefinedList);

            //注销，显示注销信息
            String status = baseInfo.getString("status");
            if (status.equals("7")) {
                baseInfo.put("showZxInfo", "1");
            }

            //年代
            String years = baseInfo.getString("years");
            baseInfo.put("years", Arrays.asList(years.split(",")));

            //质地类别
            String textureType = baseInfo.getString("textureType");
            baseInfo.put("textureType", Arrays.asList(textureType.split(",")));
            //质地
            String texture = baseInfo.getString("texture");
            baseInfo.put("texture", Arrays.asList(texture.split(",")));
            //在库位置
            String storehouse = baseInfo.getString("storehouse");
            List storehouseList = Arrays.asList(storehouse.split(","));
            baseInfo.put("storehouse", storehouseList);

            jsonObject.put("baseInfo", baseInfo);

            // 获取库房管理员
            String storeHouseId = storehouseList.get(0).toString();
            StoreHouse storeHouse = collectCommonBusinessService.selectStoreHouseByPrimaryKey(storeHouseId);
            List userNameList = new ArrayList();
            if (storeHouse != null) {
                String manager = storeHouse.getManager();
                String useName = collectCommonBusinessService.getUserNames(manager);
                userNameList = Arrays.asList(useName.split(","));
            }
            jsonObject.put("userNameList", userNameList);

            //-------------------下面是初始化下拉选项
            //年代树
            JSONArray ageTree = collectCommonCodeService.selectCollectAgeTree();
            jsonObject.put("ageTree", ageTree);

            //质地类别树
            JSONArray textureTypeTree = collectCommonCodeService.selectTextureTypeTree();
            jsonObject.put("textureTypeTree", textureTypeTree);

            //质地
            JSONArray textureList = collectCommonCodeService.selectTexture();
            jsonObject.put("textureList", textureList);

            //级别
            JSONArray cpLevOptions = collectCommonCodeService.selectCollectLev();
            jsonObject.put("cpLevOptions", cpLevOptions);

            //藏品类别
            JSONArray typeOptions = collectCommonCodeService.selectCollectType();
            jsonObject.put("typeOptions", typeOptions);

            //质量范围
            JSONArray massRangeOptions = collectCommonCodeService.massRangeOptions();
            jsonObject.put("massRangeOptions", massRangeOptions);

            //质量单位
            JSONArray massUnitOptions = collectCommonCodeService.massUnitOptions();
            jsonObject.put("massUnitOptions", massUnitOptions);

            //完残程度
            JSONArray completeDegreeOptions = collectCommonCodeService.completeDegreeOptions();
            jsonObject.put("completeDegreeOptions", completeDegreeOptions);

            //保存状态
            JSONArray keepStateOptions = collectCommonCodeService.keepStateOptions();
            jsonObject.put("keepStateOptions", keepStateOptions);

            //来源方式
            JSONArray sourceOptions = collectCommonCodeService.sourceOptions();
            jsonObject.put("sourceOptions", sourceOptions);

            //库房位置
            JSONArray storehouseOptions = collectCommonCodeService.selectCollectStorehouseTree();
            jsonObject.put("storehouseOptions", storehouseOptions);

            //在库状态
            JSONArray outStateOptions = collectCommonCodeService.outStateOptions();
            jsonObject.put("outStateOptions", outStateOptions);

            //数量单位
            JSONArray numUnitOptions = collectCommonCodeService.numUnitOptions();
            jsonObject.put("numUnitOptions", numUnitOptions);

            //藏品分类
            JSONArray collectClassOptions = collectCommonCodeService.collectClassOptions();
            jsonObject.put("collectClassOptions", collectClassOptions);

            //关联藏品
            jsonObject.put("groupCollect", getGroupCollect(collectId,false));

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品基本信息详情
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/baseInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject baseInfo(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            //藏品基础信息
            JSONObject baseInfo = null;
            try {
                baseInfo = getCollectBaseInfo(json);
            } catch (Exception e) {
                throw new BaseRuntimeException(e.getMessage());
            }

            //藏品类别
            String collectType = baseInfo.getString("collectType");
            String collectType_t = collectCommonCodeService.collectType_t(collectType);
            baseInfo.put("collectType_t", collectType_t);

            //级别
            String cpLevel = baseInfo.getString("cpLevel");
            String cpLevel_t = collectCommonCodeService.cpLev_t(cpLevel);
            baseInfo.put("cpLevel_t", cpLevel_t);

            //来源方式
            String source = baseInfo.getString("source");
            String source_t = collectCommonCodeService.source_t(source);
            baseInfo.put("source_t", source_t);

            //年代
            String years = baseInfo.getString("years");
            String years_t = collectCommonCodeService.collectAge_t(years);
            baseInfo.put("years_t", years_t);

            //藏品分类
            String collectClass = baseInfo.getString("collectClass");
            String collectClass_t = collectCommonCodeService.collectClass_t(collectClass);
            baseInfo.put("collectClass_t", collectClass_t);

            //质地类别
//            String textureType = baseInfo.getString("textureType");
//            String textureType_t = collectCommonCodeService.textureType_t(textureType);
//            baseInfo.put("textureType_t", textureType_t);

            //质地
//            String texture = baseInfo.getString("texture");
//            String texture_t = collectCommonCodeService.texture_t(texture);
//            baseInfo.put("texture_t", texture_t);

            //完残程度
            String completeDegree = baseInfo.getString("completeDegree");
            String completeDegree_t = collectCommonCodeService.completeDegree_t(completeDegree);
            baseInfo.put("completeDegree_t", completeDegree_t);

            //保存状态
            String keepState = baseInfo.getString("keepState");
            String keepState_t = collectCommonCodeService.keepState_t(keepState);
            baseInfo.put("keepState_t", keepState_t);

            //质量范围
            String massRange = baseInfo.getString("massRange");
            String massRange_t = collectCommonCodeService.massRange_t(massRange);
            baseInfo.put("massRange_t", massRange_t);

            //质量单位
            String massUnit = baseInfo.getString("massUnit");
            String massUnit_t = collectCommonCodeService.massUnit_t(massUnit);
            baseInfo.put("massUnit_t", massUnit_t);

            //生成相应的封面大图url
            JSONArray array = baseInfo.getJSONArray("imgList");
            JSONArray imgList_maxList = new JSONArray();
            for (int i = 0; i < array.size(); i++) {
                JSONObject object = (JSONObject) array.get(i);
                String str = object.toJSONString();
                JSONObject obj = JSONObject.parseObject(str);
                obj.put("url", obj.getString("url") + "&v=4");
                imgList_maxList.add(obj);
            }
            baseInfo.put("imgList_maxList", imgList_maxList);

            jsonObject.put("baseInfo", baseInfo);


            //除图片外，其他附件 默认取一条
            //视频
            String url = "";
            jsonObject.put("videoUrl", "");
            jsonObject.put("audioUrl", "");
            jsonObject.put("modelUrl", "");
            JSONArray videoList = baseInfo.getJSONArray("videoList");
            if (videoList.size() > 0) {
                JSONObject jsonObject1 = (JSONObject) videoList.get(0);
                JSONObject jsonObject11 = resServerInterface.vrUrl(jsonObject1);
                if (jsonObject11.getString("code").equals("1")) {
                    url = jsonObject11.getString("url");
                    jsonObject.put("videoUrl", url);
                } else {
                    throw new BaseRuntimeException(jsonObject11.getString("msg"));
                }
            }
            //音频
            JSONArray audioList = baseInfo.getJSONArray("audioList");
            if (audioList.size() > 0) {
                JSONObject jsonObject1 = (JSONObject) audioList.get(0);
                JSONObject jsonObject11 = resServerInterface.vrUrl(jsonObject1);
                if (jsonObject11.getString("code").equals("1")) {
                    url = jsonObject11.getString("url");
                    jsonObject.put("audioUrl", url);
                } else {
                    throw new BaseRuntimeException(jsonObject11.getString("msg"));
                }
            }
            //三维
            JSONArray modelList = baseInfo.getJSONArray("modelList");
            if (modelList.size() > 0) {
                JSONObject jsonObject1 = (JSONObject) modelList.get(0);
                JSONObject jsonObject11 = resServerInterface.vrUrl(jsonObject1);
                if (jsonObject11.getString("code").equals("1")) {
                    url = jsonObject11.getString("url");
                    jsonObject.put("modelUrl", url);
                } else {
                    throw new BaseRuntimeException(jsonObject11.getString("msg"));
                }
            }
            jsonObject.put("url", url);

            // 对浏览量、下载量、收藏量1000以上用万做单位
            Integer browseCount = Integer.valueOf(String.valueOf(baseInfo.get("browseCount")));
            Integer downLoadCount = Integer.valueOf(String.valueOf(baseInfo.get("collectCount")));
            if (browseCount > 1000){
                BigDecimal bigDecimal = new BigDecimal((double)browseCount/10000);
                double result = bigDecimal.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue(); // 四舍五入后保留两位小数
                baseInfo.put("browseCount", result + "万");
            }
            if (downLoadCount > 1000){
                BigDecimal bigDecimal = new BigDecimal((double)downLoadCount/10000);
                double result = bigDecimal.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue(); // 四舍五入后保留两位小数
                baseInfo.put("collectCount", result + "万");
            }

            jsonObject.put("code", "1");

        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }


    /**
     * 获取藏品的扩展属性
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/extendedAttribute", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject extendedAttribute(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");

            //获取征集鉴定信息
            jsonObject.put("zjList", getCatalogZjAppraisalList(collectId));

            //获取定级鉴定信息
            jsonObject.put("djList", getGradingList(collectId));

            //获取流传经历信息
            jsonObject.put("lcList", getCirculateLive(collectId));

            //获取损坏记录
            jsonObject.put("shList", getBreakDownList(collectId));

            //获取著录信息
            jsonObject.put("zlList", getBookRecodeInfo(collectId));

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品的关联藏品
     * @param json
     * @return
     */
    @RequestMapping(value = "/groupCollect", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject groupCollect(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");
            Boolean isSearch = json.getBooleanValue("isSearch");
            jsonObject.put("groupCollect", getGroupCollect(collectId,isSearch));
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品的审核记录
     * @param json
     * @return
     */
    @RequestMapping(value = "/examineRecords", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject examineRecords(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");

            //获取审核记录信息
            jsonObject.put("examineRecords", getExamineRecords(collectId));

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品的重编目记录
     * @param json
     * @return
     */
    @RequestMapping(value = "/againEditRecords", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject againEditRecords(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");


            //获取重编目记录信息
            jsonObject.put("againEditRecords", getAgainEditRecords(collectId));

            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 根据id查询 多个藏品信息
     *
     * @param json
     * @return
     */
    @RequestMapping(value = "/manyInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject manyInfo(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectIds = json.getString("collectIds");
            if (DataUtil.isEmpty(collectIds)) {
                throw new BaseRuntimeException(CollectErrorDefine.PLEASE_SELECT_CANCEL_DATA);
            }
            List list = Arrays.asList(collectIds.split(","));

            JSONArray infoArray = new JSONArray();
            for (int i = 0; i < list.size(); i++) {
                String collectId = list.get(i).toString();

                //藏品基础信息
                CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(collectId);
                String jsonString = JSONObject.toJSONString(collectInfo, SerializerFeature.WriteNullStringAsEmpty);
                JSONObject baseInfo = JSONObject.parseObject(jsonString);

                //藏品类别
                String collectType = baseInfo.getString("collectType");
                String collectType_t = collectCommonCodeService.collectType_t(collectType);
                baseInfo.put("collectType_t", collectType_t);

                //级别
                String cpLevel = baseInfo.getString("cpLevel");
                String cpLevel_t = collectCommonCodeService.cpLev_t(cpLevel);
                baseInfo.put("cpLevel_t", cpLevel_t);

                //来源方式
                String source = baseInfo.getString("source");
                String source_t = collectCommonCodeService.source_t(source);
                baseInfo.put("source_t", source_t);

                //年代
                String years = baseInfo.getString("years");
                String years_t = collectCommonCodeService.collectAge_t(years);
                baseInfo.put("years_t", years_t);

                //质地类别
//                String textureType = baseInfo.getString("textureType");
//                String textureType_t = collectCommonCodeService.textureType_t(textureType);
//                baseInfo.put("textureType_t", textureType_t);

                //质地
//                String texture = baseInfo.getString("texture");
//                String texture_t = collectCommonCodeService.texture_t(texture);
//                baseInfo.put("texture_t", texture_t);

                //完残程度
                String completeDegree = baseInfo.getString("completeDegree");
                String completeDegree_t = collectCommonCodeService.completeDegree_t(completeDegree);
                baseInfo.put("completeDegree_t", completeDegree_t);

                //保存状态
                String keepState = baseInfo.getString("keepState");
                String keepState_t = collectCommonCodeService.keepState_t(keepState);
                baseInfo.put("keepState_t", keepState_t);

                //质量范围
                String massRange = baseInfo.getString("massRange");
                String massRange_t = collectCommonCodeService.massRange_t(massRange);
                baseInfo.put("massRange_t", massRange_t);

                //质量单位
                String massUnit = baseInfo.getString("massUnit");
                String massUnit_t = collectCommonCodeService.massUnit_t(massUnit);
                baseInfo.put("massUnit_t", massUnit_t);

                JSONObject resObj = collectCommonBusinessService.getMainBodyRes("90", collectId);
                baseInfo.put("imgUrl", resObj.getString("coverUrl"));

                infoArray.add(baseInfo);
            }

            jsonObject.put("baseInfoList", infoArray);

            User user = ComUtils.getLoginUser();
            String userName = user.getUserName();
            jsonObject.put("userName", userName);
            jsonObject.put("date", new Date());

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取保管事件
     *
     * @return
     */
    @RequestMapping(value = "/keepRecords", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject keepRecords(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");
            if (DataUtil.isEmpty(collectId)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }
            JSONArray jsonArray = getKeepingEvents(collectId);
            jsonObject.put("keepRecords", jsonArray);

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品的修改痕迹
     *
     * @return
     */
    @RequestMapping(value = "/infoModifyRecord", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject infoModifyRecord(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");
            String pages = json.getString("pages");

            if (DataUtil.isEmpty(collectId)) {
                throw new BaseRuntimeException(CollectErrorDefine.CHOOSE_HANDLE_DATA);
            }

            CollectInfo collectInfo = collectInfoService.selectByPrimaryKey(collectId);
            JSONObject new_info = JSONObject.parseObject(JSONObject.toJSONString(collectInfo, SerializerFeature.WriteNullStringAsEmpty));

            List list = new ArrayList();
            //基本信息的修改痕迹
            String moreFlg = "0";
            List<CollectInfoHistory> collectInfoHistoryList = collectInfoHistoryService.selectByCollectId(collectId);
            for (int i = 0; i < collectInfoHistoryList.size(); i++) {
                CollectInfoHistory collectInfoHistory = collectInfoHistoryList.get(i);
                JSONObject old_info = JSONObject.parseObject(JSONObject.toJSONString(collectInfoHistory, SerializerFeature.WriteNullStringAsEmpty));

                //后面的修改痕迹 需要和上一条数据作比较
                if (i > 0) {
                    new_info = JSONObject.parseObject(JSONObject.toJSONString(collectInfoHistoryList.get(i - 1), SerializerFeature.WriteNullStringAsEmpty));
                }

                Set<String> stringSet = old_info.keySet();
                Iterator iterator = stringSet.iterator();

                JSONArray attributeList = new JSONArray();
                while (iterator.hasNext()) {
                    String key = iterator.next().toString();

                    String value_old = old_info.getString(key);
                    String value_new = new_info.getString(key);

                    if (null == value_old) {
                        value_old = "";
                    }

                    if (null == value_new) {
                        value_new = "";
                    }
                    if (!value_old.equals(value_new)) {
                        String labelName = "";
                        if (key.equals("collectName")) {
                            labelName = "藏品名称";
                        } else if (key.equals("censusName")) {
                            labelName = "普查名称";
                        } else if (key.equals("collectNameOld")) {
                            labelName = "藏品原名";
                        } else if (key.equals("totalNum")) {
                            labelName = "总登记号";
                        } else if (key.equals("classNum")) {
                            labelName = "分类号";
                        } else if (key.equals("collectCode")) {
                            labelName = "藏品编号";
                        } else if (key.equals("incomeNum")) {
                            labelName = "收入号";
                        } else if (key.equals("years")) {
                            labelName = "年代";
                            value_old = collectCommonCodeService.collectAge_t(value_old);
                            value_new = collectCommonCodeService.collectAge_t(value_new);
                        } else if (key.equals("specificAge")) {
                            labelName = "具体年代";
                        } else if (key.equals("cpLevel")) {
                            labelName = "级别";
                            value_old = collectCommonCodeService.cpLev_t(value_old);
                            value_new = collectCommonCodeService.cpLev_t(value_new);
                        } else if (key.equals("collectType")) {
                            labelName = "藏品类别";
                            value_old = collectCommonCodeService.collectType_t(value_old);
                            value_new = collectCommonCodeService.collectType_t(value_new);
                        } else if (key.equals("textureType")) {
                            labelName = "质地类别";
                            value_old = collectCommonCodeService.textureType_t(value_old);
                            value_new = collectCommonCodeService.textureType_t(value_new);
                        } else if (key.equals("texture")) {
                            labelName = "质地";
                            //value_old = collectCommonCodeService.texture_t(value_old);
                            //value_new = collectCommonCodeService.texture_t(value_new);
                        } else if (key.equals("massRange")) {
                            labelName = "质量范围";
                            value_old = collectCommonCodeService.massRange_t(value_old);
                            value_new = collectCommonCodeService.massRange_t(value_new);
                        } else if (key.equals("massUnit")) {
                            labelName = "质量单位";
                            value_old = collectCommonCodeService.massUnit_t(value_old);
                            value_new = collectCommonCodeService.massUnit_t(value_new);
                        } else if (key.equals("specificMass")) {
                            labelName = "具体质量";
                        } else if (key.equals("quantity")) {
                            labelName = "数量";
                        } else if (key.equals("numUnit")) {
                            labelName = "数量单位";
                            value_old = collectCommonCodeService.numUnit_t(value_old);
                            value_new = collectCommonCodeService.numUnit_t(value_new);
                        } else if (key.equals("realNum")) {
                            labelName = "实际数量";
                        } else if (key.equals("length")) {
                            labelName = "尺寸（长）";
                        } else if (key.equals("width")) {
                            labelName = "尺寸（宽）";
                        } else if (key.equals("height")) {
                            labelName = "尺寸（高）";
                        } else if (key.equals("bore")) {
                            labelName = "尺寸（口径）";
                        } else if (key.equals("bottomDiameter")) {
                            labelName = "尺寸（底径）";
                        } else if (key.equals("abdominal")) {
                            labelName = "尺寸（腹经）";
                        } else if (key.equals("diameter")) {
                            labelName = "尺寸（直径）";
                        } else if (key.equals("specificSize")) {
                            labelName = "具体尺寸";
                        } else if (key.equals("completeDegree")) {
                            labelName = "完残程度";
                            value_old = collectCommonCodeService.completeDegree_t(value_old);
                            value_new = collectCommonCodeService.completeDegree_t(value_new);
                        } else if (key.equals("keepState")) {
                            labelName = "保存状态";
                            value_old = collectCommonCodeService.keepState_t(value_old);
                            value_new = collectCommonCodeService.keepState_t(value_new);
                        } else if (key.equals("completeDesc")) {
                            labelName = "完残状况";
                        } else if (key.equals("packCondition")) {
                            labelName = "包装情况";
                        } else if (key.equals("source")) {
                            labelName = "来源方式";
                            value_old = collectCommonCodeService.source_t(value_old);
                            value_new = collectCommonCodeService.source_t(value_new);
                        } else if (key.equals("productPlace")) {
                            labelName = "产地";
                        } else if (key.equals("inMsDt")) {
                            labelName = "入馆时间";
                        } else if (key.equals("collectTimeRange")) {
                            labelName = "入藏时间";
                        } else if (key.equals("formProperty")) {
                            labelName = "形态特征";
                        } else if (key.equals("introduction")) {
                            labelName = "藏品简介";
                        } else if (key.equals("remark")) {
                            labelName = "藏品信息备注";
                        } else if (key.equals("storehouse")) {
                            labelName = "在库位置";
                            value_old = collectCommonCodeService.storehouse_t(value_old);
                            value_new = collectCommonCodeService.storehouse_t(value_new);
                        } else if (key.equals("specificPosition")) {
                            labelName = "具体方位";
                        } else if (key.equals("safeAssess")) {
                            labelName = "保险估价（万元）";
                        } else if (key.equals("offer")) {
                            labelName = "征集报价（万元）";
                        } else if (key.equals("strikePrice")) {
                            labelName = "征集成交价（万元）";
                        } else if (key.equals("collectClass")) {
                            labelName = "藏品分类";
                            value_old = collectCommonCodeService.collectClass_t(value_old);
                            value_new = collectCommonCodeService.collectClass_t(value_new);
                        } else {
                            continue;
                        }
                        JSONObject updateObj = new JSONObject();
                        updateObj.put("labelName", labelName);
                        updateObj.put("old_value", value_old);
                        updateObj.put("new_value", value_new);
                        attributeList.add(updateObj);
                    }
                }

                JSONObject jsonObject1 = new JSONObject();
                if (attributeList.size() > 0) {
                    String updateUser = collectInfoHistory.getUpdateuser();
                    updateUser = collectCommonBusinessService.getUserNames(updateUser);
                    jsonObject1.put("updateUser", updateUser);
                    jsonObject1.put("updateTime", old_info.getString("updateDt"));
                    jsonObject1.put("attributeList", attributeList);

                    list.add(jsonObject1);
                }

                //默认加载5条数据
                if (DataUtil.isEmpty(pages)) {
                    if (list.size() == 5) {
                        if ((i + 1) < collectInfoHistoryList.size()) {
                            moreFlg = "1";
                        }
                        break;
                    }
                }
            }
            jsonObject.put("moreFlg", moreFlg);
            jsonObject.put("updateRecordList", list);
            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取藏品的环境参照指标
     *
     * @return
     */
    @RequestMapping(value = "/environmentPointer", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject environmentPointer(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            List textureList = json.getJSONArray("texture");

            List environmentPointerList = new ArrayList();
            if (textureList.size() > 0) {
                for (int i = 0; i < textureList.size(); i++) {
                    String textureId = textureList.get(i).toString();
                    String texture_t = collectCommonCodeService.texture_t(textureId);
                    Indicators indicators = indicatorsService.selectDataByTexture(textureId);
                    if (indicators == null) {
                        indicators = new Indicators();
                    }
                    String string = JSONObject.toJSONString(indicators, SerializerFeature.WriteNullStringAsEmpty);
                    JSONObject jsonObject1 = JSONObject.parseObject(string);
                    jsonObject1.put("texture_t", texture_t);

                    jsonObject1.remove("indicatorsId");
                    jsonObject1.remove("textureType");
                    jsonObject1.remove("texture");

                    Set<String> stringSet = jsonObject1.keySet();
                    Iterator it = stringSet.iterator();
                    while (it.hasNext()) {
                        String key = it.next().toString();
                        if (DataUtil.isEmpty(jsonObject1.getString(key))) {
                            jsonObject1.put(key, "--");
                        }
                    }
                    environmentPointerList.add(jsonObject1);
                }
            }
            jsonObject.put("environmentPointer", environmentPointerList);

            jsonObject.put("code", "1");
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }


    /**
      *@Author : xdn
      *@Description : 获取藏品的重拨库记录
      *@Return :
      **/
    @RequestMapping(value = "/relocationRecord", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject relocationRecord(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");
            List<Map<String,Object>> dataMapList = getRelocationRecord(collectId);
            jsonObject.put("relocationRecordList", dataMapList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 获取藏品的发布记录
      *@Return :
      **/
    @RequestMapping(value = "/publishRecord", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject publishRecord(@RequestBody JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
            String collectId = json.getString("collectId");
            List<Map<String,Object>> dataMapList = getPublislhRecord(collectId);
            jsonObject.put("publishRecordList", dataMapList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    //单个资源删除标签
    @RequestMapping(value = "/singleResDelLabel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject singleResDelLabel(@RequestBody JSONObject json) {
        JSONObject jsonObject = delLabel(json);
        return jsonObject;
    }

    //批量查询标签
    @RequestMapping(value = "/batchSearchLabel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject batchSearchLabel(@RequestBody JSONObject json) {
        JSONObject jsonObject = batchSelectLabel(json);
        return jsonObject;
    }

    //批量贴标签
    @RequestMapping(value = "/batchResAddLabel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject batchResAddLabel(@RequestBody JSONObject json) {
        JSONObject jsonObject = batchAddLabel(json);
        return jsonObject;
    }

    //批量删除贴
    @RequestMapping(value = "/batchResDelLabel", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject batchResDelLabel(@RequestBody JSONObject json) {
        JSONObject jsonObject = batchDelLabel(json);
        return jsonObject;
    }

    /**
     * 获取藏品缩略图片输出流
     * @author: xdn
     * @time: 2020/7/7 17:42
     * @param id
     */
    @RequestMapping(value = "/imageIo/{id}", method = RequestMethod.GET)
    public void getImageIo(HttpServletResponse response, @PathVariable String id) {

        OutputStream outputStream = null;
        byte[] imageByte = null;

        try {
            // 创建图片输出流
            response.setContentType("image/jpeg");
            response.setCharacterEncoding("UTF-8");

            // 获取藏品封面图
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("mainBodyObj", "90");//主体对象
            jsonObject.put("mainBodyId", id);//主体Id
            JSONObject resObj = resServerInterface.getAppCoverImg(jsonObject);

            String imgBase64 = resObj.getString("imageToBase64");

            if (StringUtils.isNotEmpty(imgBase64)) {
                String base64Code = imgBase64.indexOf(",") != -1 ? imgBase64.split(",")[1] : imgBase64;//去掉头部
                imageByte = new BASE64Decoder().decodeBuffer(base64Code);
            }

            if (imageByte != null) {
                outputStream = response.getOutputStream();
                outputStream.write(imageByte);
                outputStream.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("图片获取失败");
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                }
            }
        }
    }
}
