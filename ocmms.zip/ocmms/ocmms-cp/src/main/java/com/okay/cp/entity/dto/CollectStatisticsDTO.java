package com.okay.cp.entity.dto;

import lombok.Data;

/**
 * @author CZJ[OKAY]
 * @date 2021/5/25 11:52
 * @description 藏品统计DTO
 **/
@Data
public class CollectStatisticsDTO {

    private Integer houseStatus;

    /**
     * 1、按类别 2、按级别 3、按来源方式
     */
    private Integer type;

    private String typeName;

    /**
     * 1、全部 2、按级别 3、按来源方式
     */
    private String status;

}
