package com.okay.cp.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 藏品发布官网(CollectPublish)实体类
 *
 * @author xiandn
 * @since 2020-08-26 09:14:07
 */
public class CollectPublish implements Serializable {
    private static final long serialVersionUID = 911319517549621733L;
    /**
     * 发布ID
     */
    private String publishId;
    /**
     * 发布藏品ID
     */
    private String publishCollectId;
    /**
     * 发布人
     */
    private String publishUser;
    /**
     * 发布时间
     */
    private Date publishTime;
    /**
     * 取消发布人
     */
    private String cancelPublishUser;
    /**
     * 发布时间
     */
    private Date cancelPublishTime;
    /**
     * 发布状态
     */
    private String publishState;


    public String getPublishId() {
        return publishId;
    }

    public void setPublishId(String publishId) {
        this.publishId = publishId;
    }

    public String getPublishCollectId() {
        return publishCollectId;
    }

    public void setPublishCollectId(String publishCollectId) {
        this.publishCollectId = publishCollectId;
    }

    public String getPublishUser() {
        return publishUser;
    }

    public void setPublishUser(String publishUser) {
        this.publishUser = publishUser;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getCancelPublishUser() {
        return cancelPublishUser;
    }

    public void setCancelPublishUser(String cancelPublishUser) {
        this.cancelPublishUser = cancelPublishUser;
    }

    public Date getCancelPublishTime() {
        return cancelPublishTime;
    }

    public void setCancelPublishTime(Date cancelPublishTime) {
        this.cancelPublishTime = cancelPublishTime;
    }

    public String getPublishState() {
        return publishState;
    }

    public void setPublishState(String publishState) {
        this.publishState = publishState;
    }
}