package com.okay.cp.entity;

import java.util.Date;

public class BreakDown {
    private String breakId;

    private String collectId;

    private String beakTime;

    private String beakPlace;

    private String beakSummary;

    private String creatUser;

    private Date creatTime;

    private String updateUser;

    private Date updateTime;

    public String getBreakId() {
        return breakId;
    }

    public void setBreakId(String breakId) {
        this.breakId = breakId;
    }

    public String getCollectId() {
        return collectId;
    }

    public void setCollectId(String collectId) {
        this.collectId = collectId;
    }

    public String getBeakTime() {
        return beakTime;
    }

    public void setBeakTime(String beakTime) {
        this.beakTime = beakTime;
    }

    public String getBeakPlace() {
        return beakPlace;
    }

    public void setBeakPlace(String beakPlace) {
        this.beakPlace = beakPlace;
    }

    public String getBeakSummary() {
        return beakSummary;
    }

    public void setBeakSummary(String beakSummary) {
        this.beakSummary = beakSummary;
    }

    public String getCreatUser() {
        return creatUser;
    }

    public void setCreatUser(String creatUser) {
        this.creatUser = creatUser;
    }

    public Date getCreatTime() {
        return creatTime;
    }

    public void setCreatTime(Date creatTime) {
        this.creatTime = creatTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}