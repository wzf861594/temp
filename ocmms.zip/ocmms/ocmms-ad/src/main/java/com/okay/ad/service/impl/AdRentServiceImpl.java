package com.okay.ad.service.impl;

import com.github.pagehelper.PageHelper;
import com.okay.ad.common.PageQueryBean;
import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.AdRent;
import com.okay.ad.exception.OkayException;
import com.okay.ad.mapper.AdRentMapper;
import com.okay.ad.service.AdRentService;
import com.okay.ad.utils.ExportUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.util.*;

@Service
@AllArgsConstructor
public class AdRentServiceImpl implements AdRentService {

    private AdRentMapper rentMapper;


    /**
     * Date 2018-09-29 9:59
     *
     * @Description 根据ID查找租用记录
     */
    @Override
    public HashMap queryLoanDataList(List idList) throws OkayException {
        HashMap<Object, Object> map = new HashMap<>();
        if (idList.size() > 0) {
            List<AdRent> dataList = rentMapper.queryDatafromIds(idList);
            map.put("dataList", dataList);
            return map;
        } else {
            throw new OkayException("没有得到ID");
        }
    }

    /**
     * Date 2018-09-29 10:00
     *
     * @Description 根据查询条件查询寄存记录显示列表
     */
    @Override
    public PageQueryBean quertAudienceRegisterList(QueryCondition condition) {
        PageQueryBean pageQueryBean = new PageQueryBean();
        int count = rentMapper.selectCount(condition);
        if (count > 0) {
            pageQueryBean.setTotalRows(count);
            pageQueryBean.setCurrentPage(condition.getCurrentPage());
            pageQueryBean.setPageSize(condition.getPageSize());
            PageHelper.startPage(condition.getCurrentPage(), condition.getPageSize());
            List<AdRent> list = rentMapper.selectAudiencdeRegisterList(condition);
            pageQueryBean.setItems(list);
        }
        return pageQueryBean;
    }

    /**
     * Date 2018-09-29 11:17
     *
     * @Description 单挑新增
     */
    @Override
    public void insertRent(AdRent adRent) {
        int i = rentMapper.insertSelective(adRent);
        if (i != 1) {
            throw new OkayException("添加失败");
        }
    }

    @Override
    public void updateRent(AdRent adRent) {
        int i = rentMapper.updateByPrimaryKeySelective(adRent);
        if (i != 1) {
            throw new OkayException("修改失败");
        }
    }

    /**
     * Date 2018-09-29 14:23
     *
     * @Description Excel表格上传观众租用信息
     */
    @Override
    public void insertForExcelList(List uploadList) {
        if (uploadList.size() > 0) {
            rentMapper.insertFroExcelList(uploadList);
        } else {
            throw new OkayException("没有读取到数据或表中数据为空");
        }
    }

    @Override
    public void deleteDatafromId(Integer id) {
        int i = rentMapper.deleteByPrimaryKey(id);
        if (i != 1) {
            throw new OkayException("删除失败");
        }
    }

    @Override
    public void deleteByBatch(String ids) {
        rentMapper.deleteByBatch(Arrays.asList(ids.split(",")));
    }

    @Override
    public void moveFinancial(AdRent rent) {
        if (rent.getAdRentId()!= null) {
            rent.setIsMoveFinancial(1);
            int i = rentMapper.updateByPrimaryKey(rent);
            if (i != 1) {
                throw new OkayException("更新失败");
            }
        } else {
            throw new OkayException("没有得到ID");
        }
    }

    @Override
    public AdRent selectById(Integer id) {
        return rentMapper.selectByPrimaryKey(id);
    }

    @Override
    public void rentExport(HttpServletResponse response, HashMap object) throws Exception {
        List<Map<String, Object>> bookingSingleList = rentMapper.rentExport();
        //头部-导出行
        List<String> titleCol = new ArrayList<>();
        titleCol.add("观众姓名");
        titleCol.add("身份证");
        titleCol.add("观众手机号");
        titleCol.add("租用内容");
        titleCol.add("租用数量");
        titleCol.add("押金");
        List<String> datavalue = new ArrayList<>();
        datavalue.add("adName");
        datavalue.add("adCardno");
        datavalue.add("adPhone");
        datavalue.add("rentContent");
        datavalue.add("rentNum");
        datavalue.add("deposit");
        String fileName = "租用行为列表";
        ExportUtil.exportInfo(response, fileName, titleCol, bookingSingleList, datavalue);
    }
}
