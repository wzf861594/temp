package com.okay.ad.common;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.entity.WxArticleSummary;
import com.okay.ad.entity.WxDatasynLog;
import com.okay.ad.entity.WxUserCumulate;
import com.okay.ad.entity.WxUserSummary;
import com.okay.ad.mapper.WxArticleSummaryMapper;
import com.okay.ad.mapper.WxUserCumulateMapper;
import com.okay.ad.mapper.WxUserSummaryMapper;
import com.okay.ad.service.WxsynService;
import com.okay.ad.task.DTO.BodyParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * @author tingjun
 */
@Component
public class WxdataSyn {
    private final Logger logger = LoggerFactory.getLogger(WxdataSyn.class);

    @Autowired
    private WxUserSummaryMapper wxUserSummaryMapper;

    @Autowired
    private WxUserCumulateMapper wxUserCumulateMapper;

    @Autowired
    private WxArticleSummaryMapper wxArticleSummaryMapper;
    @Autowired
    WxsynService wxsynService;

    // 获取用户增减数据
    public void getUserSumMary(String access_token, BodyParams params) {
        JSONObject userSumMary = new JSONObject();
        try {
            String url = "https://api.weixin.qq.com/datacube/getusersummary?access_token=" + access_token;
            RestTemplate restTemplate = new RestTemplate();
            userSumMary = restTemplate.postForObject(url, params, JSONObject.class);
            JSONArray jsonArray = userSumMary.getJSONArray("list");
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String ref_date = jsonObject.getString("ref_date");
                int user_source = jsonObject.getIntValue("user_source");
                int new_user = jsonObject.getIntValue("new_user");
                int cancel_user = jsonObject.getIntValue("cancel_user");
                int count = wxUserSummaryMapper.selectUserSummary(ref_date, user_source);
                if (count == 0) {
                    WxUserSummary wxUserSummary = new WxUserSummary();
                    wxUserSummary.setRefDate(ref_date);
                    wxUserSummary.setUserSource(user_source);
                    wxUserSummary.setNewUser(new_user);
                    wxUserSummary.setCancelUser(cancel_user);
                    wxUserSummaryMapper.insertUserSummary(wxUserSummary);
                }
            }
            WxDatasynLog wxDatasynLog = new WxDatasynLog();
            wxDatasynLog.setStartdate(params.getBegin_date());
            wxDatasynLog.setEnddate(params.getEnd_date());
            wxDatasynLog.setResponse(userSumMary.toJSONString());
            wxDatasynLog.setsucctype0();
            wxsynService.lnsertLog(wxDatasynLog);
        } catch (Exception e) {
            logger.error("微信用户增减数据同步error：", e);
            WxDatasynLog wxDatasynLog = new WxDatasynLog();
            wxDatasynLog.setfailuretype0();
            wxDatasynLog.setStartdate(params.getBegin_date());
            wxDatasynLog.setEnddate(params.getEnd_date());
            wxDatasynLog.setResponse("{error:" + e.getMessage() + "}————" + userSumMary.toJSONString());
            wxsynService.lnsertLog(wxDatasynLog);
        }
    }

    // 获取累计用户数据
    public void getUserCumulate(String access_token, BodyParams params) {
        JSONObject userCumulate = new JSONObject();
        try {
            String url = "https://api.weixin.qq.com/datacube/getusercumulate?access_token=" + access_token;
            RestTemplate restTemplate = new RestTemplate();
            userCumulate = restTemplate.postForObject(url, params, JSONObject.class);
            JSONArray jsonArray = userCumulate.getJSONArray("list");
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String ref_date = jsonObject.getString("ref_date");
                int cumulate_user = jsonObject.getIntValue("cumulate_user");
                int count = wxUserCumulateMapper.selectUserCumulate(ref_date);
                if (count == 0) {
                    WxUserCumulate wxUserCumulate = new WxUserCumulate();
                    wxUserCumulate.setRefDate(ref_date);
                    wxUserCumulate.setCumulateUser(cumulate_user);
                    wxUserCumulateMapper.insertUserCumulate(wxUserCumulate);
                }
            }
            WxDatasynLog wxDatasynLog = new WxDatasynLog();
            wxDatasynLog.setStartdate(params.getBegin_date());
            wxDatasynLog.setEnddate(params.getEnd_date());
            wxDatasynLog.setResponse(userCumulate.toJSONString());
            wxDatasynLog.setsucctype1();
            wxsynService.lnsertLog(wxDatasynLog);
        } catch (Exception e) {
            logger.error("同步微信累计用户数据error：", e);
            WxDatasynLog wxDatasynLog = new WxDatasynLog();
            wxDatasynLog.setfailuretype1();
            wxDatasynLog.setStartdate(params.getBegin_date());
            wxDatasynLog.setEnddate(params.getEnd_date());
            wxDatasynLog.setResponse("{error:" + e.getMessage() + "}————" + userCumulate.toJSONString());
            wxsynService.lnsertLog(wxDatasynLog);
        }
    }

    // 获取图文群发每日数据
    public void getArticleSummary(String access_token, BodyParams params) {
        JSONObject articleSummary = new JSONObject();
        try {
            String url = "https://api.weixin.qq.com/datacube/getarticlesummary?access_token=" + access_token;
            BodyParams bodyParams = new BodyParams();
            RestTemplate restTemplate = new RestTemplate();
            articleSummary = restTemplate.postForObject(url, params, JSONObject.class);
            articleSummary.toString();
            JSONArray jsonArray = articleSummary.getJSONArray("list");
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String ref_date = jsonObject.getString("ref_date");
                String msgid = jsonObject.getString("msgid");
                String title = jsonObject.getString("title");
                int int_page_read_user = jsonObject.getIntValue("int_page_read_user");
                int int_page_read_count = jsonObject.getIntValue("int_page_read_count");
                int ori_page_read_user = jsonObject.getIntValue("ori_page_read_user");
                int ori_page_read_count = jsonObject.getIntValue("ori_page_read_count");
                int share_user = jsonObject.getIntValue("share_user");
                int share_count = jsonObject.getIntValue("share_count");
                int add_to_fav_user = jsonObject.getIntValue("add_to_fav_user");
                int add_to_fav_count = jsonObject.getIntValue("add_to_fav_count");
                int count = wxArticleSummaryMapper.selectArticleSummary(ref_date, title);
                if (count == 0) {
                    WxArticleSummary wxArticleSummary = new WxArticleSummary();
                    wxArticleSummary.setRefDate(ref_date);
                    wxArticleSummary.setMsgid(msgid);
                    wxArticleSummary.setTitle(title);
                    wxArticleSummary.setIntPageReadUser(int_page_read_user);
                    wxArticleSummary.setIntPageReadCount(int_page_read_count);
                    wxArticleSummary.setOriPageReadUser(ori_page_read_user);
                    wxArticleSummary.setOriPageReadCount(ori_page_read_count);
                    wxArticleSummary.setShareUser(share_user);
                    wxArticleSummary.setShareCount(share_count);
                    wxArticleSummary.setAddToFavUser(add_to_fav_user);
                    wxArticleSummary.setAddToFavCount(add_to_fav_count);
                    wxArticleSummaryMapper.insertArticleSummary(wxArticleSummary);
                }
            }
            WxDatasynLog wxDatasynLog = new WxDatasynLog();
            wxDatasynLog.setStartdate(params.getBegin_date());
            wxDatasynLog.setEnddate(params.getEnd_date());
            wxDatasynLog.setResponse(articleSummary.toJSONString());
            wxDatasynLog.setsucctype2();
            wxsynService.lnsertLog(wxDatasynLog);
        } catch (Exception e) {
            logger.error("同步微信图文群发每日数据error：", e);
            WxDatasynLog wxDatasynLog = new WxDatasynLog();
            wxDatasynLog.setfailuretype2();
            wxDatasynLog.setStartdate(params.getBegin_date());
            wxDatasynLog.setEnddate(params.getEnd_date());
            wxDatasynLog.setResponse("{error:" + e.getMessage() + "}————" + articleSummary.toJSONString());
            wxsynService.lnsertLog(wxDatasynLog);
        }
    }
}