package com.okay.ad.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.okay.ad.entity.*;
import com.okay.ad.exception.OkayException;
import com.okay.ad.mapper.OptionMapper;
import com.okay.ad.mapper.QuestionMapper;
import com.okay.ad.mapper.QuestionNaireMapper;
import com.okay.ad.mapper.RecordMapper;
import com.okay.ad.service.IQuestionNaireService;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class QuestionNaireServiceImpl implements IQuestionNaireService {

    @Autowired
    SqlSessionTemplate sqlSessionTemplate;
    @Autowired
    private QuestionNaireMapper questionNaireMapper;
    @Autowired
    private QuestionMapper questionMapper;
    @Autowired
    private OptionMapper optionMapper;
    @Autowired
    private RecordMapper recordMapper;

    /**
     * 单个增加问卷调查
     * @param questionNaire 问卷调查
     * @param questionList  问题对象列表
     * @return
     */
    @Override
    @Transactional
    public boolean addQuestionNaire(QuestionNaire questionNaire, List<Question> questionList) {
        try {
            //PUBSTATUS '1-已发布  2-未发布'
            questionNaire.setPubstatus(questionNaire.getPubstatus() == null || "".equals(questionNaire.getPubstatus()) ? 2:questionNaire.getPubstatus());
            int qn_success = questionNaireMapper.insertSelective(questionNaire);
            if (qn_success == 1) {//新增问卷调查成功
                //新增多个关联问卷调查的问题
                for (int i = 0; i < questionList.size(); i++) {
                    Question question = questionList.get(i);
                    question.setNaireid(questionNaire.getNaireid());
                    int q_success = questionMapper.insertSelective(question);
                    if (q_success == 1) {//新增问题成功
                        List<Option> optionList = question.getOption();
                        //新增多个关联问题的选项
                        for (int j = 0; j < optionList.size(); j++) {
                            Option option = optionList.get(j);
                            option.setQuesid(question.getQuesid());
                            optionMapper.insertSelective(option);
                        }
                    }
                }
            }
            return true;
        } catch (Exception e) {
            throw new OkayException(e);
        }
    }


    /**
     * 单条删除问卷调查
     * @param naireId
     * @return
     */
    @Override
    @Transactional
    public boolean deleteQuestionNaire(int naireId) {
        try {
            int qn_success= questionNaireMapper.deleteByPrimaryKey(naireId);
            if (qn_success == 1) {
                //删除问卷调查
                List<Question> questionList = questionMapper.selectByNaireId(naireId);
                //questionList = null;
                //删除所属问题
                questionMapper.deleteByNaireId(naireId);
                for (int i = 0; i < questionList.size(); i++) {
                    int quesid = questionList.get(i).getQuesid();
                    //删除所属选项
                    optionMapper.deleteByQuesId(quesid);
                }
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            throw new OkayException(e);
        }
    }

    /**
     * 批量查询 分页
     * @param aMap
     * @param pageNum 页码
     * @param pageSize 分页大小
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getHashMapList(Map<String, Object> aMap,int pageNum,int pageSize){
        PageHelper.startPage(pageNum, pageSize);
        return questionNaireMapper.getHashMapList(aMap);
    }

    /**
     * 根据条件获取数据总量
     * @param aMap
     * @return int
     */
    @Override
    public int getCount(Map<String, Object> aMap){
        return questionNaireMapper.getCount(aMap);
    }

    /**
     * 更新数据
     * @param questionNaire
     * @return
     */
    @Override
    public int updateQuestionNaire(QuestionNaire questionNaire){
        return questionNaireMapper.updateByPrimaryKey(questionNaire);
    }

    /**
     * 根据问卷ID统计问卷答题结果
     * @param naireId
     * @return
     */
    @Override
    public List<QuestionOption> queryNaireResultStatisical(int naireId) {
        List<QuestionOption> questionOptionList = new ArrayList<>();
        if (naireId != 0) {
            /**查询问卷下的所有问题**/
            List<Question> questionList = questionMapper.selectByNaireId(naireId);
            if (questionList.size() > 0) {

            } else {
                throw new OkayException("没有查询到问卷的问题");
            }
            NumberFormat numberFormat = NumberFormat.getInstance();
            numberFormat.setMaximumFractionDigits(2);
            for (int i = 0; i < questionList.size(); i++) {
                QuestionOption questionOption = new QuestionOption();
                int quesid = questionList.get(i).getQuesid();
                int questCount = recordMapper.selectRecordCountByQuesId(quesid);
                List<Map<String,Object>> questionResultList = questionMapper.selectQuestionResultByQuesId(quesid);
                List<OptionStatistical> OptionStatisticalList = new ArrayList<>();
                for (int j = 0; j < questionResultList.size(); j++) {
                    String optionsTitle = questionResultList.get(j).get("OPTIONSTITLE").toString();
                    int answerCount = Integer.parseInt(questionResultList.get(j).get("ANSWERCOUNT").toString());
                    String percentAge = answerCount == 0 ? "0" : numberFormat.format((float) answerCount / (float) questCount * 100);
                    OptionStatistical optionStatistical = new OptionStatistical();
                    optionStatistical.setOptionName(optionsTitle);
                    optionStatistical.setCount(answerCount);
                    optionStatistical.setPercentage(percentAge + "%");
                    OptionStatisticalList.add(optionStatistical);
                }
                questionOption.setQuestionName(questionList.get(i).getQuestitle());
                questionOption.setOptionList(OptionStatisticalList);
                questionOptionList.add(questionOption);
            }
        }
        return questionOptionList;
    }

    /**
     * 问卷调查统计
     *
     * @param naireId
     * @return
     */
    @Override
    public List<QuestionOption> queryStatistical(int naireId) {
        List<QuestionOption> questionOptionList = new ArrayList<>();
        List<Map<String, Object>> optionList = null;
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.getDefault());
        numberFormat.setMaximumFractionDigits(2);
        if (naireId != 0) {
            /**查询问卷下的所有问题**/
            List<Question> questionList = questionMapper.selectByNaireId(naireId);
            if (questionList.size() > 0) {
                /**拿到每一个问题答题人数**/
                for (int i = 0; i < questionList.size(); i++) {
                    QuestionOption questionOption = new QuestionOption();
                    List<OptionStatistical> optionStatisticals = new ArrayList<>();
                    questionOption.setQuestionName(questionList.get(i).getQuestitle());
                    //获取该问题下回答总人数
                    int count = recordMapper.getcount(questionList.get(i));
                    //获取该问题下所有的选项
                    optionList = optionMapper.selectMapByQuesId(questionList.get(i).getQuesid());
                    for (int j = 0; j < optionList.size(); j++) {
                        //选项id
                        Object op = optionList.get(j).get("optionsid");
                        //选项标题
                        Object optitle = optionList.get(j).get("optionstitle");

                        String optionsid = op == null ? "0" : op.toString();
                        String optionstitle = optitle == null ? "" : optitle.toString();
                        //选项出现的次数
                        int optionCount = recordMapper.getoptionCount(Integer.parseInt(optionsid));
                        Float v = (float) optionCount / (float) count * 100;
                        if (v.isNaN()) {
                            v = 0f;
                        }
                        //获取百分比
                        String result = numberFormat.format(v)+"%";
                        //集合最里面数据
                        OptionStatistical optionStatistical = new OptionStatistical();
                        optionStatistical.setCount(optionCount);
                        optionStatistical.setOptionName(optionstitle);
                        optionStatistical.setPercentage(result);
                        //集合倒数第二层_选项层次数据添加
                        optionStatisticals.add(optionStatistical);
                    }
                    questionOption.setOptionList(optionStatisticals);
                    //添加到返回主数据
                    questionOptionList.add(questionOption);
                }
            } else {
                throw new OkayException("没有查询到问卷的问题");
            }
        }

        return questionOptionList;
    }

    /**
     * 查看问卷调查数据
     * @param naireId
     * @return
     */
    @Override
    public Map<String, Object> getQuestionNaire(int naireId) {
        try {
            Map<String, Object> questionNaire = questionNaireMapper.selectMapByPrimaryKey(naireId);
            if(questionNaire == null || questionNaire.size() ==0){
                throw new OkayException("未找到数据,请确认数据是否存在");
            }
            List<Map<String, Object>> questionList = questionMapper.selectMapByNaireId((Integer)questionNaire.get("naireid"));
            for (int i = 0; i < questionList.size(); i++) {
                List<Map<String, Object>> optionList = optionMapper.selectMapByQuesId((Integer)questionList.get(i).get("quesid"));
                questionList.get(i).put("option", optionList);
            }
            questionNaire.put("question", questionList);
            return questionNaire;
        } catch (Exception e) {
            throw new OkayException(e);
        }
    }

    /**
     * 修改问卷调查
     * @param questionNaire
     * @param questionList
     * @return
     */
    @Override
    @Transactional
    public boolean updateQuestionNaire(QuestionNaire questionNaire, List<Question> questionList) {
        try {
            int naireId = questionNaire.getNaireid();
            QuestionNaire oldQuestionNaire = questionNaireMapper.selectByPrimaryKey(naireId);
            questionNaire.setCreatuser(oldQuestionNaire.getCreatuser());
            questionNaire.setUpdatetime(oldQuestionNaire.getCreattime());
            deleteQuestionNaire(questionNaire.getNaireid());
            addQuestionNaire(questionNaire, questionList);
            return true;
        } catch (Exception e) {
            throw new OkayException(e);
        }
    }

    @Override
    public JSONArray getList(int naireid) {
        JSONArray results = new JSONArray();
        List<Question> questions = questionMapper.selectByNaireId(naireid);
        if (questions ==null || questions.size() == 0){
            throw new OkayException("未找到数据,请确认数据是否存在");
        }
        for (Question question :questions) {
            JSONObject result= new JSONObject();
            List<Map<String, Object>> maps = optionMapper.selectMapByQuesIdfromanswer(question.getQuesid());
            result.put("title",question.getQuestitle());
            result.put("datas",maps);
            results.add(result);
        }
        return results;
    }
}

