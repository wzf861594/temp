package com.okay.ad.mapper;

import java.util.List;
import com.okay.ad.entity.AdmsTrafficstatisticsWeek;

/**
* 通用 Mapper
*
* @author  zengxiaoquan
*/
public interface AdmsTrafficstatisticsWeekMapper {


    /**
     * 获取全部数据
     * @return List<AdmsTrafficstatisticsWeek>
     */
    List<AdmsTrafficstatisticsWeek> getAllData();

}




