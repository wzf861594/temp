package com.okay.ad.service;


import com.okay.ad.entity.Suggestion;

import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface SuggestService {

    /**
     * 单条数据新增
     *
     * @param suggestion
     * @return
     * @throws ParseException
     */
    boolean addSuggestion(Suggestion suggestion) throws ParseException;

    void batchInsert(List<Suggestion> list);

    /**
     * 单条数据删除
     *
     * @param recId
     * @return
     */
    boolean deleteSuggestion(int recId);

    void deleteByBatch(String ids);

    /**
     * 更新数据
     *
     * @param suggestion
     * @return
     */
    Suggestion updateSuggestion(Suggestion suggestion);


    /**
     * 批量查询
     *
     * @param aMap
     * @return
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize);

    /**
     * 根据条件查询总条数
     *
     * @param aMap
     * @return
     */
    int getCount(Map<String, Object> aMap);

    /**
     * 单条数据查看
     * @param recId
     * @return
     */
    Suggestion selectSuggestion(int recId);
    /**
     * 处理意见
     *
     * @param suggestion
     * @return
     */
    Suggestion dealSuggestion(Suggestion suggestion);

    /**
     * 创建题库
     * @param recId
     * @return
     */
    boolean createSuggestionPool(int recId);

    void suggestExport(HttpServletResponse response, HashMap object)throws Exception;

}
