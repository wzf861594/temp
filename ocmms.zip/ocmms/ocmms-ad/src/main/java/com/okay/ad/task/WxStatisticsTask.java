package com.okay.ad.task;

import com.okay.ad.common.WxdataSyn;
import com.okay.ad.task.DTO.BodyParams;
import com.okay.ad.utils.HttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * 获取每日微信数据_获取昨天
 *
 * @author tingjun
 */

@Component
@EnableScheduling
public class WxStatisticsTask {

    private final Logger logger = LoggerFactory.getLogger(WxStatisticsTask.class);
    @Autowired
    HttpClient httpClientUtil;

    @Autowired
    WxdataSyn wxdataSyn;

    /**
     * 每天早上八点半进行拉取数据,微信建议每天早上八点后 进行拉取数据
     */
    @Scheduled(cron = "0 30 8 * * ?")
    public void dowxStatisticsDataTask() {
        logger.info("-------每日同步微信数据开始------------------");
        long starttime = System.currentTimeMillis();
        try {
            String accessToken = httpClientUtil.httpUtil();
            logger.info("同步公众号：accessToken" + accessToken);
            LocalDate localDate = LocalDate.now().minusDays(1);
            BodyParams bodyParams = new BodyParams();
            bodyParams.setBegin_date(localDate.toString());
            bodyParams.setEnd_date(localDate.toString());
            // 获取用户增减数据
            wxdataSyn.getUserSumMary(accessToken, bodyParams);
            // 获取累计用户数据
            wxdataSyn.getUserCumulate(accessToken, bodyParams);
            // 获取图文群发每日数据
            wxdataSyn.getArticleSummary(accessToken, bodyParams);
            long endtime = System.currentTimeMillis();
            logger.info("-------每日同步微信数据结束------------------耗时：" + (endtime - starttime) + " ms");
        } catch (Exception e) {
            logger.error("每日同步微信数据error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
