package com.okay.ad.entity;

import lombok.Data;

import java.util.Date;

@Data
public class WxDatasynLog {
    private Integer id;

    private Integer type;

    private Integer status;

    private String response;

    private Date createtime;

    private String startdate;

    private String enddate;

    //success 用户增减
    public void setsucctype0() {
        this.createtime = new Date();
        this.status = (0);
        this.type = (0);
    }

    //failure 用户增减
    public void setfailuretype0() {
        this.createtime = new Date();
        this.status = (1);
        this.type = (0);
    }

    //success 用户增减
    public void setsucctype1() {
        this.createtime = new Date();
        this.status = (0);
        this.type = (1);
    }

    //failure 用户增减
    public void setfailuretype1() {
        this.createtime = new Date();
        this.status = (1);
        this.type = (1);
    }

    //success 用户增减
    public void setsucctype2() {
        this.createtime = new Date();
        this.status = (0);
        this.type = (2);
    }

    //failure 用户增减
    public void setfailuretype2() {
        this.createtime = new Date();
        this.status = (1);
        this.type = (2);
    }
}