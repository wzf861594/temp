package com.okay.ad.entity;

import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@Table(value = "ad_options")
@ApiModel(value = "选项表")
public class Option {

    @ApiModelProperty(value = "ID")
    private Integer optionsid;

    @ApiModelProperty(value = "所属问题")
    private Integer quesid;

    @ApiModelProperty(value = "选项标题")
    private String optionstitle;

    @ApiModelProperty(value = "描述")
    private String summary;

    @ApiModelProperty(value = "创建人")
    private String creatuser;

    @ApiModelProperty(value = "创建时间")
    private Date creattime;

    @ApiModelProperty(value = "更新人")
    private String updateuser;

    @ApiModelProperty(value = "更新时间")
    private Date updatetime;

}