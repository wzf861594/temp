package com.okay.ad.mapper;

import com.okay.ad.entity.BookingSingle;

import java.util.List;
import java.util.Map;

/**
* 通用 Mapper
*
* @author  zengxiaoquan
*/
public interface BookingSingleMapper {
    BookingSingle findById(String singleId);

    List<BookingSingle> selectInfo(Map<String, Object> aMap);

    int selectInfoCount(Map<String, Object> aMap);

    List<BookingSingle> getTicketList(Map<String, Object> aMap);

    int getTicketListCount(Map<String, Object> aMap);

    List<BookingSingle> getActTicketList(Map<String, Object> aMap);

    int getActTicketListCount(Map<String, Object> aMap);

    List<Map<String, Object>>  personExport();

    List<Map<String, Object>>  actExport();

}




