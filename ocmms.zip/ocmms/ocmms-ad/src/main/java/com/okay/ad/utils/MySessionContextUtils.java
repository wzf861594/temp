package com.okay.ad.utils;

import javax.servlet.http.HttpSession;
import java.util.HashMap;

/**   
 * @Title: AESUtils.java  
*/
public class MySessionContextUtils {
    private static MySessionContextUtils instance;
    private HashMap<String, HttpSession> sessionMap;

    private MySessionContextUtils() {
        sessionMap = new HashMap<String, HttpSession>();
    }

    public static MySessionContextUtils getInstance() {
        if (instance == null) {
            instance = new MySessionContextUtils();
        }
        return instance;
    }

    public synchronized void addSession(HttpSession session) {
        if (session != null) {
            sessionMap.put(session.getId(), session);
        }
    }

    public synchronized void delSession(HttpSession session) {
        if (session != null) {
            sessionMap.remove(session.getId());
        }
    }

    public synchronized HttpSession getSession(String sessionID) {
        if (sessionID == null) {
            return null;
        }
        return sessionMap.get(sessionID);
    }

}
