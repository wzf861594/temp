package com.okay.ad.entity;

import com.okay.ad.annotation.Column;
import com.okay.ad.annotation.Id;
import com.okay.ad.annotation.Table;

import java.util.Date;


@Table(value = "ad_group_rule")
public class Rule {
    // 主键
    private Integer GroupId;
    private String GroupName;
    private String Gender;
    private String ResidenceNation;
    private String ResidenceType;
    private String EducationLevel;
    private String Profession;
    private String InComeLevel;
    private String Interests;
    private String AudienceType;
    private String InfoResourc;
    private Integer AgeBegin;
    private Integer AgeEnd;
    private String RuleSql;
    private Date CreateDate;


//    @Id(value = "logId")
//    @Column(value = "logId")


    @Id(value = "GroupId")
    public Integer getGroupId() {
        return GroupId;
    }

    public void setGroupId(Integer groupId) {
        GroupId = groupId;
    }
    @Column(value = "GroupName")
    public String getGroupName() {
        return GroupName;
    }

    public void setGroupName(String groupName) {
        GroupName = groupName;
    }
    @Column(value = "Gender")
    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }
    @Column(value = "ResidenceNation")
    public String getResidenceNation() {
        return ResidenceNation;
    }

    public void setResidenceNation(String residenceNation) {
        ResidenceNation = residenceNation;
    }
    @Column(value = "ResidenceType")
    public String getResidenceType() {
        return ResidenceType;
    }

    public void setResidenceType(String residenceType) {
        ResidenceType = residenceType;
    }
    @Column(value = "EducationLevel")
    public String getEducationLevel() {
        return EducationLevel;
    }

    public void setEducationLevel(String educationLevel) {
        EducationLevel = educationLevel;
    }
    @Column(value = "Profession")
    public String getProfession() {
        return Profession;
    }

    public void setProfession(String profession) {
        Profession = profession;
    }
    @Column(value = "InComeLevel")
    public String getInComeLevel() {
        return InComeLevel;
    }

    public void setInComeLevel(String inComeLevel) {
        InComeLevel = inComeLevel;
    }
    @Column(value = "Interests")
    public String getInterests() {
        return Interests;
    }

    public void setInterests(String interests) {
        Interests = interests;
    }
    @Column(value = "AudienceType")
    public String getAudienceType() {
        return AudienceType;
    }

    public void setAudienceType(String audienceType) {
        AudienceType = audienceType;
    }
    @Column(value = "InfoResourc")
    public String getInfoResourc() {
        return InfoResourc;
    }

    public void setInfoResourc(String infoResourc) {
        InfoResourc = infoResourc;
    }
    @Column(value = "AgeBegin")
    public Integer getAgeBegin() {
        return AgeBegin;
    }

    public void setAgeBegin(Integer ageBegin) {
        AgeBegin = ageBegin;
    }
    @Column(value = "AgeEnd")
    public Integer getAgeEnd() {
        return AgeEnd;
    }

    public void setAgeEnd(Integer ageEnd) {
        AgeEnd = ageEnd;
    }
    @Column(value = "RuleSql")
    public String getRuleSql() {
        return RuleSql;
    }

    public void setRuleSql(String ruleSql) {
        RuleSql = ruleSql;
    }
    @Column(value = "CreateDate")
    public Date getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(Date createDate) {
        CreateDate = createDate;
    }
}
