package com.okay.ad.service.impl;

import java.util.List;
import java.util.Map;

import com.okay.ad.entity.AdmsPeopledatatrend;
import com.okay.ad.mapper.AdmsPeopledatatrendMapper;
import com.okay.ad.service.IAdmsPeopledatatrendService;

import org.springframework.stereotype.Service;


import javax.annotation.Resource;

/**
* 通用  serviceimpl
*
* @author  zengxiaoquan
*/
@Service(value = "aAdmsPeopledatatrendServiceImpl")
public  class AdmsPeopledatatrendServiceImpl implements IAdmsPeopledatatrendService {

	@Resource
    private AdmsPeopledatatrendMapper aAdmsPeopledatatrendMapper;


    @Override
    public List<AdmsPeopledatatrend> getAllData() {
        return aAdmsPeopledatatrendMapper.getAllData();
    }

    /**
     *获取全部方法_返回map集合
     * @return List<map>
     */
    @Override
    public List<Map> getmapData() {
        return aAdmsPeopledatatrendMapper.getmapData();
    }

}




