package com.okay.ad.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.entity.Record;
import com.okay.ad.mapper.OptionMapper;
import com.okay.ad.service.IRecordService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 问卷调查答案录入控制器
 * @author tingjun
 */
@CrossOrigin(allowCredentials = "true")
@Controller
@Api(tags = "问卷调查填写录入")
@RequestMapping("/record")
public class ReordController {


    @Autowired
    private IRecordService recordService;

    @Autowired
    OptionMapper optionMapper;

    @PostMapping("/addRecord")
    @ResponseBody
    public Result addRecord(@RequestBody JSONObject jsonObject,HttpServletRequest request) {

        Result result = new Result();
        JSONArray jsonArray = jsonObject.getJSONArray("record");
        if (jsonArray == null || jsonArray.isEmpty()) {
            result.setCode(TicketStatus.STATUS_NEW_FAIL);
            result.setMessage(TicketStatus.STATUS_EXCEPTION_MSG + ": 未获取到指定数据！");
            return result;
        }
        List<Record> records = new ArrayList<>();
        try {
            for (int i = 0; i < jsonArray.size(); i++) {
                Object o = jsonArray.get(i);
                Record record = optionMapper.selectIDbyoptionsid(Integer.parseInt(o.toString()));
                record.setRecordtime(new Date());
                records.add(record);
            }
            recordService.addRecord(records);
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
        } catch (Exception e) {
            result.setCode(TicketStatus.STATUS_NEW_FAIL);
            result.setMessage(TicketStatus.STATUS_EXCEPTION_MSG + ": 后台处理出错!请稍后再试！" );
            e.printStackTrace();
        }
        return result;
    }

    @GetMapping("/succes")
    public ModelAndView succes(HttpServletRequest request){
        ModelAndView modelAndView =new ModelAndView();
        String returnUrl = request.getHeader("referer");
        if (returnUrl !=null && returnUrl.contains("questionAnswer/paper")){
            modelAndView.setViewName("questionnaire_succes");
        }else{
            modelAndView.addObject("msg","非法访问请求！请正确操作");
            modelAndView.setViewName("questionnaire_error");
        }
        return modelAndView;
    }
}
