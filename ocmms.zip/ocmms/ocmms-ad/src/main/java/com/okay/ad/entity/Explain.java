package com.okay.ad.entity;

import com.okay.ad.annotation.Column;
import com.okay.ad.annotation.Id;
import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Table(value = "ad_service_explain")
@Data
public class Explain {
    private Integer explainid;

    private String name;

    private String idcard;

    private String explainname;

    private Double price;

    private String starttime;

    private String endtime;

    private Integer ischarge;

    private Integer type;

    private String content;

    private String remark;

    private String label;

    private String registrant;

    private String registrationtime;

    private Integer audiencesize;



    @Column(value = "audiencesize")
    public Integer getAudiencesize() {
        return audiencesize;
    }

    public void setAudiencesize(Integer audiencesize) {
        this.audiencesize = audiencesize;
    }

    @Id(value = "explainid")
    public Integer getExplainid() {
        return explainid;
    }
    public void setExplainid(Integer explainid) {
        this.explainid = explainid;
    }

    @Column(value = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(value = "idcard")
    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    @Column(value = "explainname")
    public String getExplainname() {
        return explainname;
    }

    public void setExplainname(String explainname) {
        this.explainname = explainname;
    }


    @Column(value = "price")
    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Column(value = "starttime")
    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    @Column(value = "endtime")
    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    @Column(value = "ischarge")
    public Integer getIscharge() {
        return ischarge;
    }

    public void setIscharge(Integer ischarge) {
        this.ischarge = ischarge;
    }






    @Column(value = "type")
    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
    @Column(value = "content")
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    @Column(value = "remark")
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    @Column(value = "label")
    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
    @Column(value = "registrant")
    public String getRegistrant() {
        return registrant;
    }

    public void setRegistrant(String registrant) {
        this.registrant = registrant;
    }
    @Column(value = "registrationtime")
    public String getRegistrationtime() {
        return registrationtime;
    }

    public void setRegistrationtime(String registrationtime) {
        this.registrationtime = registrationtime;
    }
}