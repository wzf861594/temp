package com.okay.ad.entity;

import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
@Table(value = "ad_question")
@ApiModel(value = "问题表")
public class Question {

    @ApiModelProperty(value = "ID")
    private Integer quesid;

    @ApiModelProperty(value = "所属问卷ID")
    private Integer naireid;

    @ApiModelProperty(value = "标题")
    private String questitle;

    @ApiModelProperty(value = "描述")
    private Integer pubstatus;

    @ApiModelProperty(value = "1-已发布 2-未发布")
    private String creatuser;

    @ApiModelProperty(value = "创建人")
    private Date creattime;

    @ApiModelProperty(value = "创建时间")
    private String updateuser;

    @ApiModelProperty(value = "更新人")
    private Date updatetime;

    @ApiModelProperty(value = "内容")
    private String summary;

    @ApiModelProperty(value = "选项")
    private List<Option> option;

    @ApiModelProperty(value = "1是单选，2是多选")
    private Integer isRadio;

}