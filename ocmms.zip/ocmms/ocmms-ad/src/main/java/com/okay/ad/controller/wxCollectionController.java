package com.okay.ad.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.entity.WxData;
import com.okay.ad.service.BaseServiceClient;
import com.okay.ad.utils.HttpClient;
import com.okay.ad.utils.HttpClientUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;


//日志
@CrossOrigin(allowCredentials = "true")
@RestController
@Api(tags = "微信收藏")
@RequestMapping("/auth/wx")
public class wxCollectionController {


    @Autowired
    HttpClient httpClientUtil;
    @Autowired
    private BaseServiceClient aBaseServiceClient;

//**************************************自定义注解测试

    @ApiOperation(value = "获取微信图文参数", notes = "/Collection")
    @RequestMapping(value = "/Collection", method = {RequestMethod.GET})
    @ResponseBody
    public JSONObject wx(String t) {

        JSONObject aJSONObject = new JSONObject();
        String token = null;
        try {
            token = httpClientUtil.httpUtil();
            String url = "https://api.weixin.qq.com/datacube/getarticlesummary?access_token=" + token;
            String userURL = "https://api.weixin.qq.com/datacube/getusersummary?access_token=" + token;

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -1);
            Date time = cal.getTime();
//            String t = new SimpleDateFormat("yyyy-MM-dd").format(time);
            String value = "{\"begin_date\":\"" + t + "\",\"end_date\":\"" + t + "\"}";

            // 图文信息
            String s = HttpClientUtil.doPost(url, value);
            JSONObject json = (JSONObject) JSONObject.parseObject(s, Object.class);
            JSONArray jsonArr = json.getJSONArray("list");

            // 用户信息
            String user = HttpClientUtil.doPost(userURL, value);
            JSONObject userjson = (JSONObject) JSONObject.parseObject(user, Object.class);
            JSONArray userjsonArr = json.getJSONArray("list");
            Integer userTotal = 0;
            if (userjsonArr.size() != 0)
                userTotal = userjsonArr.getJSONObject(0).getInteger("new_user");
//            StringBuffer stringB = new StringBuffer();
            System.out.println("AA");
            for (int i = 0; i < jsonArr.size(); i++) {
                JSONObject jsonObject = jsonArr.getJSONObject(i);
                WxData wx = new WxData();
                wx.setPagereadcount(jsonObject.getInteger("int_page_read_count"));
                wx.setAddtofavcount(jsonObject.getInteger("add_to_fav_count"));
                wx.setAddtofavuser(jsonObject.getInteger("add_to_fav_user"));
                wx.setSharecount(jsonObject.getInteger("share_count"));
                wx.setShareuser(jsonObject.getInteger("share_user"));
                wx.setTitle(jsonObject.getString("title"));
                wx.setWxrefdate(jsonObject.getString("ref_date"));
                wx.setMsgid(jsonObject.getString("msgid"));
                wx.setNewusers(userTotal);
                aBaseServiceClient.insert(wx);
            }
            aJSONObject.put("message", "成功");
            aJSONObject.put("status", 0);

        } catch (Exception e) {
            e.printStackTrace();
            aJSONObject.put("message", "失败");
            aJSONObject.put("status", 1);
        }
        return aJSONObject;
    }


    @ApiOperation(value = "查看指定文章的评论数据", notes = "/CommentList")
    @RequestMapping(value = "/CommentList", method = {RequestMethod.GET})
    @ResponseBody
    public String getCommentList(@RequestParam(name = "index", defaultValue = "0") int index,
                                 @RequestParam(name = "begin", defaultValue = "0") int begin,
                                 @RequestParam(name = "type", defaultValue = "0") int type) {
        JSONObject aJSONObject = new JSONObject();
        String token = null;

        try {
            token = httpClientUtil.httpUtil();
            String url = "https://api.weixin.qq.com/cgi-bin/comment/list?access_token=" + token;
            JSONObject pJSONObject = new JSONObject();
            pJSONObject.put("msg_data_id", "");//群发返回的msg_data_id
            pJSONObject.put("index", index);//非必填 多图文时，用来指定第几篇图文，从0开始，不带默认返回该msg_data_id的第一篇图文
            pJSONObject.put("begin", begin);//必填 起始位置
            pJSONObject.put("count", "49");//必填 获取数目（>=50会被拒绝）
            pJSONObject.put("type", type);//必填 type=0 普通评论&精选评论 type=1 普通评论 type=2 精选评论
            //查看指定文章的评论数据
            return HttpClientUtil.doPost(url, pJSONObject.toJSONString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "error";
        //return aJSONObject;

    }


}
