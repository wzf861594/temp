package com.okay.ad.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;

/**   
 * @Title: AESUtils.java  
*/
public class SessionUtils {

    public static HttpSession sessionToken(HttpServletRequest request){


        String ss=request.getHeader("token");
        MySessionContextUtils myc= MySessionContextUtils.getInstance();
        HttpSession sess = myc.getSession(ss);
        return sess;
    }

    public static void DeletesessionToken(HttpServletRequest request)throws Exception {


            String ss = request.getHeader("token");
            MySessionContextUtils myc = MySessionContextUtils.getInstance();
            HttpSession sess = myc.getSession(ss);
            myc.delSession(sess);
    }


    public static void isDeletesessionToken(HttpServletRequest request)throws Exception {


        String ss = request.getHeader("token");
        MySessionContextUtils myc = MySessionContextUtils.getInstance();
        HttpSession sess = myc.getSession(ss);
        if(sess!=null){
            //session里面的创建时间
            Date createDate = (Date) sess.getAttribute("createDate");
            long cDate=createDate.getTime();
            //当前时间戳
            long date = new Date().getTime();

            System.out.println(cDate);

            //证明是超级管理员
            long time=(long)date-cDate;
            if("www".equals(sess.getAttribute("userName"))){

                //超级管理源超过1小时没操作会要去从新登陆
                if(time>=(1000*60*60*1)){
                    myc.delSession(sess);
                }
            }else{

                //普通用户 超过 8小时需要从新登陆
                if(time>=(1000*60*60*8)){
                    myc.delSession(sess);
                }

            }

        }


    }

}
