package com.okay.ad.service.impl;

import java.io.IOException;
import java.util.*;

import com.github.pagehelper.PageHelper;
import com.okay.ad.entity.Explain;
import com.okay.ad.exception.OkayException;
import com.okay.ad.mapper.TicketServiceExplainMapper;
import com.okay.ad.service.BaseServiceClient;
import com.okay.ad.service.ITicketServiceExplainService;

import com.okay.ad.utils.ExportUtil;
import com.okay.ad.utils.ImprotDownLoadUtil;
import com.okay.ad.utils.POIUtils;
import lombok.AllArgsConstructor;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* 通用  serviceimpl
*
* @author  zengxiaoquan
*/
@Service(value = "aTicketServiceExplainServiceImpl")
public  class TicketServiceExplainServiceImpl implements ITicketServiceExplainService {

//    @Autowired
    @Resource
    private TicketServiceExplainMapper aTicketServiceExplainMapper;


    @Autowired
    private BaseServiceClient aBaseServiceClient;


    /**
     * 根据条件获取数据总量
     *
     * @param aMap
     * @return int
     */
    @Override
    public int getCount(Map<String, Object> aMap) {
        return aTicketServiceExplainMapper.getCount(aMap);
    }

    /**
     * 批量查询
     *
     * @param aMap
     * @return List<TicketServiceExplain>
     */
    @Override
    public List<Explain> getEntityList(Map<String, Object> aMap) {

        return aTicketServiceExplainMapper.getEntityList(aMap);

    }

    /**
     * 批量查询 分页
     *
     * @param aMap
     * @param pageNum  页码
     * @param pageSize 分页大小
     * @return List<TicketServiceExplain>
     */
    @Override
    public List<Explain> getEntityList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return aTicketServiceExplainMapper.getEntityList(aMap);

    }

    /**
     * 单条查询
     *
     * @param aKey
     * @return TicketServiceExplain
     */
    @Override
    public Explain getEntityByPrimaryKey(String aKey) {
        return aTicketServiceExplainMapper.getEntityByPrimaryKey(aKey);
    }


    /**
     * 批量查询
     *
     * @param aMap
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getHashMapList(Map<String, Object> aMap) {

        return aTicketServiceExplainMapper.getHashMapList(aMap);

    }

    /**
     * 批量查询 分页
     *
     * @param aMap
     * @param pageNum  页码
     * @param pageSize 分页大小
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return aTicketServiceExplainMapper.getHashMapList(aMap);

    }

    /**
     * 单条查询
     *
     * @param aKey
     * @return HashMap
     */
    @Override
    public HashMap getHashMapByPrimaryKey(String aKey) {
        return aTicketServiceExplainMapper.getHashMapByPrimaryKey(aKey);
    }

    /**
     * 添加
     *
     * @param aTicketServiceExplain
     * @return boolean
     */
    @Override
    public boolean addEntity(Explain aTicketServiceExplain) {
        if (1 == aBaseServiceClient.insert(aTicketServiceExplain)) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * 更新
     *
     * @param aTicketServiceExplain
     * @return boolean
     */
    @Override
    public boolean updateEntity(Explain aTicketServiceExplain) {
        if (1 == aBaseServiceClient.update(aTicketServiceExplain)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 物理删除
     *
     * @param aKey
     * @return boolean
     */
    @Override
    public boolean deleteEntity(String aKey) {
        if (1 == aBaseServiceClient.delete(aKey)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 批量增加
     *
     * @param sqlId
     * @param data
     * @return
     */
    @Override
    public boolean batchAddEntitys(String sqlId, List data) {
        if (1 == aBaseServiceClient.batchInsert(sqlId, data)) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * 批量查询 分页
     *
     * @param aMap
     * @param pageNum  页码
     * @param pageSize 分页大小
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getEXHashMapList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return aTicketServiceExplainMapper.getEXHashMapList(aMap);

    }

    @Override
    public List<Map<String, Object>> getEXHashMapList(Map<String, Object> aMap) {
        return aTicketServiceExplainMapper.getEXHashMapList(aMap);

    }

    @Override
    public void deleteByBatch(String ids) {
        int i = aTicketServiceExplainMapper.deleteByBatch(Arrays.asList(ids.split(",")));

    }

    /**
     * Date 2018-09-27 17:24
     *
     * @Description 下载模板
     */
    public  void downLoadExplainExcel(HttpServletRequest request,
                                      HttpServletResponse response, Integer type
            , List<Map<String, Object>> list) {
        // 在内存创建一个excle文件,并通过输出流写到客户端提供下载
        HSSFWorkbook workbook = new HSSFWorkbook();
        // 创建一个sheet分页
        HSSFSheet sheet = null;
        String filename ="";
        if(type==1) {
            sheet = workbook.createSheet("线下服务讲解数据");
            filename = "线下服务讲解数据.xls";
        }else if(type==2){
            sheet = workbook.createSheet("线下服务广播数据");
            filename = "线下服务广播数据.xls";
        }else if(type==3){
            sheet = workbook.createSheet("线下服务咨询数据");
            filename = "线下服务咨询数据.xls";
        }else if(type==4){
            sheet = workbook.createSheet("线下服务医疗数据");
            filename = "线下服务医疗数据.xls";
        }
        HSSFCellStyle textStyle = workbook.createCellStyle();
        HSSFDataFormat format = workbook.createDataFormat();
        textStyle.setDataFormat(format.getFormat("@"));

        //设置下标为二的单元默认样式为文本



//        ticketServiceExplainMapper.getexplaintypeList(map);



        // 创建标题行
        HSSFRow headRow = sheet.createRow(0);


        for (int i = 0; i < list.size(); i++) {
            headRow.createCell(i).setCellStyle(textStyle);
            //HSSFCell.CELL_TYPE_STRING
            headRow.createCell(i).setCellType(CellType.STRING);
            headRow.createCell(i).setCellValue(list.get(i).get("typename").toString());
            sheet.setDefaultColumnStyle(i, textStyle);
        }

       /* headRow.createCell(0).setCellStyle(textStyle);
        headRow.createCell(0).setCellType(HSSFCell.CELL_TYPE_STRING);
        headRow.createCell(0).setCellValue("姓名（必填）");

        headRow.createCell(1).setCellStyle(textStyle);
        headRow.createCell(1).setCellType(HSSFCell.CELL_TYPE_STRING);
        headRow.createCell(1).setCellValue("证件号（必填）");

        headRow.createCell(2).setCellValue("讲解员（必填）");
        headRow.createCell(3).setCellValue("押金（元）（必填）");
        headRow.createCell(4).setCellValue("服务开始时间（必填）");
        headRow.createCell(5).setCellValue("服务结束时间");*/



        // 给下面的表格写数据
//        String filename = "线下服务讲解数据.xls";
        String agent = request.getHeader("User-Agent");
        ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
    }


    /**
     * Date 2018-09-28 15:39
     *
     * @Description 上传Excel表格
     */
    public   List<Map<String,Object>> explainUpload(MultipartFile file, HttpServletRequest request, Integer type) throws IOException {
        HSSFWorkbook workbook = null;
        HSSFCell cell = null;
        HSSFCell cell2 = null;
        HSSFCell cell3 = null;
        HSSFCell cell4 = null;
        HSSFCell cell5 = null;
        HSSFCell cell6 = null;


        // 创建集合存储单元表格数据
        List<Object> list = new ArrayList();
        // 获取file文件
        workbook = new HSSFWorkbook(file.getInputStream());
        // 获取单元表格
        HSSFSheet sheet = workbook.getSheetAt(0);

        Row hssfRow = sheet.getRow(0);
        //总列数
        int cellCount= hssfRow.getPhysicalNumberOfCells();

        Map<Integer,String> m = new HashMap<>();
        for (int i = 0; i <cellCount ; i++) {
            //列名称
            String rowName=POIUtils.getValue(sheet.getRow(0).getCell(i));
//            if(rowName.indexOf("(必填)")!=-1){
                m.put(i,rowName) ;
//            }
        }
//        Integer a = Integer.parseInt("AAA");

        //返回的list  里面装这个要新增的map数据
        List<Map<String,Object>> returnlist = new ArrayList<>();

        // 循环遍历单元表格数据
        for (int i = 0; i <= sheet.getLastRowNum(); i++) {
//            AdRent audienceRegister = new AdRent();
            Explain explain = new Explain();
            HSSFRow row = sheet.getRow(i);
            // 不要第一行
            if (row.getRowNum() == 0) {
                continue;
            }

            Map<String,Object> map  =new HashMap<>();

            for (int j = 0; j <cellCount ; j++) {
                String value= POIUtils.getValue(sheet.getRow(i).getCell(j));
                if(m.get(j).indexOf("(必填)")!=-1){
                    if (value == null || value.trim().equals("")) {
                        throw new OkayException("第" + ++i + "行的"+m.get(j).substring(0,m.get(j).indexOf("(必填)"))+"为空");
                    }else {
                        Map<String,Object> map2 =new HashMap<>();
                        map2.put("tname",m.get(j));
                        List<Map<String, Object>> ww = aTicketServiceExplainMapper.getexplaintypeList(map2);
                        if(ww.size()!=0){
                            map.put(ww.get(0).get("name").toString(),value);
                        }
                    }
                }else{
                    Map<String,Object> map2 =new HashMap<>();
                    map2.put("tname",m.get(j));
                    List<Map<String, Object>> ww = aTicketServiceExplainMapper.getexplaintypeList(map2);

                    map.put(ww.get(0).get("name").toString(),value);

                }
            }

            map.put("type",type);
            System.out.println(map);

            returnlist.add(map);
//            Integer a = Integer.parseInt("AAA");
//            return map;
//            list.add(explain);
        }
        return returnlist;
    }



    /**
     *Date 2018-10-16 15:33
     *@Description 导出博物馆观众列表
     */
    public  void outPutAllExplain(List<Map<String, Object>> lists, String tableName, HttpServletRequest request, HttpServletResponse response, Integer type
    , List<Map<String, Object>> listDate) {
        if (lists.size() > 0) {
            /*ArrayList<String> list = new ArrayList<>();
            list.add("姓名");
            list.add("证件号");
            list.add("讲解员");
            list.add("金额");
            list.add("服务开始时间");
            list.add("服务结束时间");*/
            ArrayList<String> list = new ArrayList<>();
            for (int i = 0; i <listDate.size() ; i++) {
                list.add(listDate.get(i).get("typename").toString());
            }


            String Sname = "";
            if(type==1) {
                Sname = "线下服务讲解数据";
            }else if(type==2){
                Sname = "线下服务广播数据";
            }else if(type==3){
                Sname = "线下服务咨询数据";
            }else if(type==4){
                Sname = "线下服务医疗数据";
            }

            HashMap tableMap = template(Sname, list);
            HSSFSheet sheet = (HSSFSheet) tableMap.get("sheet");
            HSSFWorkbook workbook = (HSSFWorkbook) tableMap.get("workBook");
            //填写自己的信息
            HSSFCellStyle textStyle = workbook.createCellStyle();
            int b = 0;

            for (int i = 0; i < lists.size(); i++) {



                HSSFRow contentRow = sheet.createRow(++b);
                contentRow.createCell(i).setCellStyle(textStyle);
                contentRow.createCell(i).setCellType(CellType.STRING);
                for (int j = 0; j <listDate.size() ; j++) {


                    Object name = lists.get(i).get(listDate.get(j).get("name"));
                    if(name!=null){
                        contentRow.createCell(j).setCellValue(name.toString());
                    }else{
                        contentRow.createCell(j).setCellValue("");
                    }
                }

            }

            // 给下面的表格写数据
            String filename = tableName;
            String agent = request.getHeader("User-Agent");
            ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
        }
    }



    /**
     *@Author Ye
     *Date 2018-10-10 17:22
     *Param sheetName sheet分页名字
     *Param headNameList 标题头名称集合
     *@Description 模板下载部分通用代码
     */
    public static HashMap template(String sheetName, List<String> headNameList) {
        // 在内存创建一个excle文件,并通过输出流写到客户端提供下载
        HSSFWorkbook workbook = new HSSFWorkbook();
        // 创建一个sheet分页
        HSSFSheet sheet = workbook.createSheet(sheetName);

        HSSFCellStyle textStyle = workbook.createCellStyle();
        HSSFDataFormat format = workbook.createDataFormat();
        textStyle.setDataFormat(format.getFormat("@"));

        //设置下标为二的单元默认样式为文本


        // 创建标题行
        HSSFRow headRow = sheet.createRow(0);
        for (int i = 0; i < headNameList.size(); i++) {
            headRow.createCell(i).setCellStyle(textStyle);
            headRow.createCell(i).setCellType(CellType.STRING);
            headRow.createCell(i).setCellValue(headNameList.get(i));
            sheet.setDefaultColumnStyle(i, textStyle);
        }
        HashMap map = new HashMap();
        map.put("sheet", sheet);
        map.put("workBook", workbook);
        return map;

    }

    @Override
    public Explain selectByPrimaryKey(Integer explainid) {
        return aTicketServiceExplainMapper.selectByPrimaryKey(explainid);
    }

    @Override
    public void explainExport(HttpServletResponse response, HashMap object) throws Exception {
        List<Map<String, Object>> bookingSingleList = aTicketServiceExplainMapper.explainExport();
        //头部-导出行
        List<String> titleCol = new ArrayList<>();
        titleCol.add("游客姓名");
        titleCol.add("游客证件号");
        titleCol.add("类型");
        titleCol.add("讲解员");
        titleCol.add("金额");
        titleCol.add("服务开始时间");
        titleCol.add("服务结束时间");
        List<String> datavalue = new ArrayList<>();
        datavalue.add("name");
        datavalue.add("idcard");
        datavalue.add("typeStr");
        datavalue.add("explainname");
        datavalue.add("price");
        datavalue.add("starttime");
        datavalue.add("endtime");
        String fileName = "服务管理列表";
        ExportUtil.exportInfo(response, fileName, titleCol, bookingSingleList, datavalue);

    }
}

