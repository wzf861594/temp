package com.okay.ad.entity;

import com.okay.ad.annotation.Column;
import com.okay.ad.annotation.Id;
import com.okay.ad.annotation.Table;

@Table(value = "ad_region")
public class Region {
    private Integer RegionId;

    private String RegionCode;

    private String RegionName;

    private String RegionParentId;
    private Integer RegionLevel;
    private Integer RegionSort;

    public void setRegionId(Integer regionId) {
        RegionId = regionId;
    }

    @Id(value = "RegionId")
    public Integer getRegionId() {
        return RegionId;
    }

    @Column(value ="RegionCode")
    public String getRegionCode() {
        return RegionCode;
    }

    public void setRegionCode(String regionCode) {
        RegionCode = regionCode;
    }
    @Column(value ="RegionName")
    public String getRegionName() {
        return RegionName;
    }

    public void setRegionName(String regionName) {
        RegionName = regionName;
    }
    @Column(value ="RegionParentId")
    public String getRegionParentId() {
        return RegionParentId;
    }

    public void setRegionParentId(String regionParentId) {
        RegionParentId = regionParentId;
    }

    @Column(value ="RegionLevel")
    public Integer getRegionLevel() {
        return RegionLevel;
    }

    public void setRegionLevel(Integer regionLevel) {
        RegionLevel = regionLevel;
    }

    @Column(value ="RegionSort")
    public Integer getRegionSort() {
        return RegionSort;
    }

    public void setRegionSort(Integer regionSort) {
        RegionSort = regionSort;
    }
}