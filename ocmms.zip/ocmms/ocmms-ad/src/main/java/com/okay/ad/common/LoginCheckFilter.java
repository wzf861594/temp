package com.okay.ad.common;

import com.okay.ad.service.BaseServiceClient;
import com.okay.ad.utils.MySessionContextUtils;
import com.okay.ad.utils.SessionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;

public class LoginCheckFilter {


    @Autowired
    private BaseServiceClient aBaseServiceClient;



    protected boolean isAccessAllowed(ServletRequest servletRequest, ServletResponse servletResponse, Object o) throws Exception {





        //        String userName=servletRequest.getSession().getAttribute("userName").toString();
        try {
            HttpServletRequest request = (HttpServletRequest) servletRequest;
            HttpServletResponse response = (HttpServletResponse) servletResponse;

            //判断他是否需要清除session
            SessionUtils.isDeletesessionToken(request);


            String sessionToken = sessionToken(request);

            MySessionContextUtils myc = MySessionContextUtils.getInstance();
            HttpSession sess = myc.getSession(sessionToken);

            if(sess==null){
                return false;
            }
            sess.setAttribute("createDate",new Date());
        }catch(Exception e){
            return false;
        }
        //没有登陆


      return true;

    }


    protected boolean onAccessDenied(ServletRequest servletRequest, ServletResponse servletResponse) throws Exception {
        HttpServletRequest request =(HttpServletRequest) servletRequest;
        HttpServletResponse response =(HttpServletResponse) servletResponse;
        response.sendRedirect(request.getContextPath() + "/auth/login");

        return false;
    }


    public static String sessionToken(HttpServletRequest request){

        return request.getHeader("token");
    }


}


