package com.okay.ad.utils;

import com.okay.ad.entity.*;
import com.okay.ad.exception.OkayException;
import com.okay.ad.mapper.TicketServiceExplainMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class ImprotDownLoadUtil {

    @Autowired
    private TicketServiceExplainMapper ticketServiceExplainMapper;


    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    //校验是否为数字
    private static Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
    //校验是否为浮点数
    private static Pattern patternFloat = Pattern.compile("^[-\\+]?[.\\d]*$");
    //校验手机号
    private static Pattern patternPhone = Pattern.compile("^1[3|4|5|7|8][0-9]\\d{4,8}$");
    //获取时间，用户校验Excel传入的时间转换
    private static Calendar c = new GregorianCalendar(1900,0,-1);

    /**
     *Date 2018-10-12 14:44
     *@Description 下载模板
     *Param tableName 表名需要带后缀
     *      sheetName 页名
     *      headRowList 首行名字集合
     */
    public static void templateDownLoad(String tableName, String sheetName, List<String> headRowList,
                                        HttpServletRequest request, HttpServletResponse response) {
        HashMap tableMap = template(sheetName, headRowList);
        HSSFWorkbook workbook = (HSSFWorkbook) tableMap.get("workBook");
        // 给下面的表格写数据
        String filename = tableName;
        String agent = request.getHeader("User-Agent");
        ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
    }


    /**
     * Date 2018-09-27 17:24
     *
     * @Description 下载模板
     */
    public static void downLoadExcel(HttpServletRequest request,
                                     HttpServletResponse response) {
        // 在内存创建一个excle文件,并通过输出流写到客户端提供下载
        HSSFWorkbook workbook = new HSSFWorkbook();
        // 创建一个sheet分页
        HSSFSheet sheet = workbook.createSheet("观众线下租用行为数据");

        HSSFCellStyle textStyle = workbook.createCellStyle();
        HSSFDataFormat format = workbook.createDataFormat();
        textStyle.setDataFormat(format.getFormat("@"));


        //设置下标为二的单元默认样式为文本
        sheet.setDefaultColumnStyle(2, textStyle);

        // 创建标题行
        HSSFRow headRow = sheet.createRow(0);


        headRow.createCell(0).setCellStyle(textStyle);
        //HSSFCell.CELL_TYPE_STRING
        headRow.createCell(0).setCellType(CellType.STRING);
        headRow.createCell(0).setCellValue("姓名（必填）");

        headRow.createCell(1).setCellStyle(textStyle);
        headRow.createCell(1).setCellType(CellType.STRING);
        headRow.createCell(1).setCellValue("手机");

        headRow.createCell(2).setCellValue("身份证（必填）");

        headRow.createCell(3).setCellValue("租用内容（必填）");
        headRow.createCell(4).setCellValue("租用数量（必填）");
        headRow.createCell(5).setCellValue("押金（元）（必填）");
        headRow.createCell(6).setCellValue("是否归还（必填）");
        headRow.createCell(7).setCellValue("是否已退押金（必填）");
        headRow.createCell(8).setCellValue("是否移交财务部（必填）");
        headRow.createCell(9).setCellValue("租借日期（必填）");

        // 给下面的表格写数据
        String filename = "观众租用明细.xls";
        String agent = request.getHeader("User-Agent");
        ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
    }


    public static void outputLoanData(HttpServletRequest request, HttpServletResponse response, HashMap map) throws Exception {
        if (map.get("dataList") != null) {
            List<AdRent> dataList = (List<AdRent>) map.get("dataList");
            // 在内存创建一个excle文件,并通过输出流写到客户端提供下载
            HSSFWorkbook workbook = new HSSFWorkbook();
            // 创建一个sheet分页
            HSSFSheet sheet = workbook.createSheet("观众线下租用行为数据");

            HSSFCellStyle textStyle = workbook.createCellStyle();
            HSSFDataFormat format = workbook.createDataFormat();
            textStyle.setDataFormat(format.getFormat("@"));


            //设置下标为二的单元默认样式为文本
            sheet.setDefaultColumnStyle(2, textStyle);

            // 创建标题行
            HSSFRow headRow = sheet.createRow(0);
            headRow.createCell(0).setCellStyle(textStyle);
            headRow.createCell(0).setCellType(CellType.STRING);
            headRow.createCell(0).setCellValue("姓名（必填）");

            headRow.createCell(1).setCellStyle(textStyle);
            headRow.createCell(1).setCellType(CellType.STRING);
            headRow.createCell(1).setCellValue("手机");

            headRow.createCell(2).setCellValue("身份证（必填）");

            headRow.createCell(3).setCellValue("租用内容（必填）");
            headRow.createCell(4).setCellValue("租用数量（必填）");
            headRow.createCell(5).setCellValue("押金（元）（必填）");
            headRow.createCell(6).setCellValue("是否归还（必填）");
            headRow.createCell(7).setCellValue("是否已退押金（必填）");
            headRow.createCell(8).setCellValue("是否移交财务部（必填）");

            int b = 0;
            for (int i = 0; i < dataList.size(); i++) {
                HSSFRow contentRow = sheet.createRow(++b);
                contentRow.createCell(0).setCellStyle(textStyle);
                contentRow.createCell(0).setCellType(CellType.STRING);
                contentRow.createCell(0).setCellValue(dataList.get(i).getAdName());
                contentRow.createCell(1).setCellStyle(textStyle);
                contentRow.createCell(1).setCellType(CellType.STRING);
                contentRow.createCell(1).setCellValue(dataList.get(i).getAdPhone());
            }
            // 给下面的表格写数据
            String filename = "观众寄存明细.xls";
            String agent = request.getHeader("User-Agent");
            ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
        }
    }

    public static void writeFile(String filename, String agent, Workbook workbook,
                                 HttpServletRequest request, HttpServletResponse response) {
        try {
            filename = FileUtils.encodeDownloadFilename(filename, agent);
            ServletOutputStream outputStream = response.getOutputStream();
            String contnenType = request.getSession().getServletContext().getMimeType(filename);
            // 一个流两个头
            response.setContentType(contnenType);
            response.setHeader("content-disposition", "attchment;filename=" + filename);
            workbook.write(outputStream);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (workbook != null) {
                //关闭
            }
        }
    }

    /**
     * Date 2018-09-28 15:39
     *
     * @Description 上传Excel表格
     */
    public static List upload(MultipartFile file, HttpServletRequest request, ModelMap model) throws IOException {
        HSSFWorkbook workbook = null;
        HSSFCell cell = null;
        HSSFCell cell2 = null;
        HSSFCell cell3 = null;
        HSSFCell cell4 = null;
        HSSFCell cell5 = null;
        HSSFCell cell6 = null;
        HSSFCell cell7 = null;
        HSSFCell cell8 = null;
        HSSFCell cell9 = null;


        // 创建集合存储单元表格数据
        List<Object> list = new ArrayList();
        // 获取file文件
        workbook = new HSSFWorkbook(file.getInputStream());
        // 获取单元表格
        HSSFSheet sheet = workbook.getSheetAt(0);
        // 循环遍历单元表格数据
        for (int i = 0; i <= sheet.getLastRowNum(); i++) {
            AdRent audienceRegister = new AdRent();
            HSSFRow row = sheet.getRow(i);
            // 不要第一行
            if (row.getRowNum() == 0) {
                continue;
            }
            String personnel_name = POIUtils.getValue(row.getCell(0));
            if (personnel_name == null || personnel_name.trim().equals("")) {
                throw new OkayException("第" + ++i + "行的人员名称为空");
            }
            audienceRegister.setAdName(personnel_name);

            cell = row.getCell(1);
            cell.setCellType(CellType.STRING);
            String phone = cell.getStringCellValue();//此时content的数值为12345678910123
            audienceRegister.setAdPhone(phone);

            cell2 = row.getCell(2);
            if (cell2 == null) {
                throw new OkayException("请检查第" + ++i + "行是否有填写身份证信息");
            }
            cell2.setCellType(CellType.STRING);
            String personnel_papersNo = cell2.getStringCellValue();//此时content的数值为12345678910123

            if (personnel_papersNo == null || personnel_papersNo.trim().equals("")) {
                throw new OkayException("第" + ++i + "行的身份证号码为空");
            }
            if (!IDCardUtils.validateCard(personnel_papersNo)) {
                throw new OkayException("第" + ++i + "行的身份证号码错误");
            }
            audienceRegister.setAdCardno(personnel_papersNo);

            cell3 = row.getCell(3);
            if (cell3 == null) {
                throw new OkayException("请填写租用内容");
            }
            cell3.setCellType(CellType.STRING);
            String content = cell3.getStringCellValue();
            audienceRegister.setRentContent(content);

            cell4 = row.getCell(4);
            if (cell4 == null) {
                throw new OkayException("请填写租用数量");
            }
            cell4.setCellType(CellType.STRING);
            String number = cell4.getStringCellValue();
            if (pattern.matcher(number).matches()) {
                audienceRegister.setRentNum(Integer.parseInt(number));
            } else {
                throw new OkayException("租用数量必须为整数");
            }

            cell5 = row.getCell(5);
            if (cell5 == null) {
                throw new OkayException("请填写押金");
            }
            cell5.setCellType(CellType.STRING);
            String price = cell5.getStringCellValue();
            if (patternFloat.matcher(price).matches() || pattern.matcher(price).matches()) {
                audienceRegister.setDeposit(Long.parseLong(price));
            } else {
                throw new OkayException("押金应为数字");
            }


            cell6 = row.getCell(6);
            if (cell6 == null) {
                throw new OkayException("请填写是否归还,请填写规范是或否");
            }
            cell6.setCellType(CellType.STRING);
            String isReturn = cell6.getStringCellValue();
            isReturn = "是".equals(isReturn) ? "1" : "2";
            audienceRegister.setIsReturn(Integer.parseInt(isReturn));

            cell7 = row.getCell(7);
            if (cell7 == null) {
                throw new OkayException("请填写是否已退押金,请填写规范是或否");
            }
            cell7.setCellType(CellType.STRING);
            String isReturnPrice = cell7.getStringCellValue();
            isReturnPrice = "是".equals(isReturnPrice) ? "1" : "2";
            audienceRegister.setIsReturnDeposit(Integer.parseInt(isReturnPrice));

            cell8 = row.getCell(8);
            if (cell8 == null) {
                throw new OkayException("请填写是否移交财务,请填写规范是或否");
            }
            cell8.setCellType(CellType.STRING);
            String isMove = cell8.getStringCellValue();
            isMove = "是".equals(isMove) ? "1" : "2";
            audienceRegister.setIsMoveFinancial(Integer.parseInt(isMove));


            cell9 = row.getCell(9);
            if (cell9 == null) {
                throw new OkayException("请填写租借时间,请填写规范2018-01-01");
            }
            cell9.setCellType(CellType.NUMERIC);
            Date date = cell9.getDateCellValue();
//            audienceRegister.setIsMoveFinancial(Byte.parseByte(LeaseTime));
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
           try {
               String LeaseTime = sdf.format(date);       //将Date类型转换成String类型
//               audienceRegister.setLeaseTime(LeaseTime);
           }catch (Exception e){
               throw new OkayException("请填写租借时间,请填写规范2018/1/1");
           }
            // 新增
            list.add(audienceRegister);
        }
        return list;
    }

    /**
     *@Author Ye
     *Date 2018-10-10 17:22
     *Param sheetName sheet分页名字
     *Param headNameList 标题头名称集合
     *@Description 模板下载部分通用代码
     */
    public static HashMap template(String sheetName, List<String> headNameList) {
        // 在内存创建一个excle文件,并通过输出流写到客户端提供下载
        HSSFWorkbook workbook = new HSSFWorkbook();
        // 创建一个sheet分页
        HSSFSheet sheet = workbook.createSheet(sheetName);

        HSSFCellStyle textStyle = workbook.createCellStyle();
        HSSFDataFormat format = workbook.createDataFormat();
        textStyle.setDataFormat(format.getFormat("@"));

        //设置下标为二的单元默认样式为文本
        sheet.setDefaultColumnStyle(2, textStyle);

        // 创建标题行
        HSSFRow headRow = sheet.createRow(0);
        for (int i = 0; i < headNameList.size(); i++) {
            headRow.createCell(i).setCellStyle(textStyle);
            headRow.createCell(i).setCellType(CellType.STRING);
            headRow.createCell(i).setCellValue(headNameList.get(i));
        }
        HashMap map = new HashMap();
        map.put("sheet", sheet);
        map.put("workBook", workbook);
        return map;

    }


    /**
     *Date 2018-10-10 17:24
     *@Description 问卷调查导出数据
     */
    public static void TemplateoutputQuestionNaire(String tableName, HashMap map, HttpServletRequest request, HttpServletResponse response) {
        List<QuestionNaire> dataList = (List<QuestionNaire>) map.get("dataList");
        if (dataList.size() > 0) {
            ArrayList<String> list = new ArrayList<>();
            list.add("问卷名称");
            list.add("问卷调查时间");
            list.add("问卷状态");
            list.add("问卷报告上传时间");
            list.add("报告数量");
            HashMap tableMap = template("调查报告", list);
            HSSFSheet sheet = (HSSFSheet) tableMap.get("sheet");
            HSSFWorkbook workbook = (HSSFWorkbook) tableMap.get("workBook");
            //填写自己的信息
            HSSFCellStyle textStyle = workbook.createCellStyle();
            int b = 0;
            for (int i = 0; i < dataList.size(); i++) {
                HSSFRow contentRow = sheet.createRow(++b);
                contentRow.createCell(0).setCellStyle(textStyle);
                contentRow.createCell(0).setCellType(CellType.STRING);
                if (dataList.get(i).getNairetitle() != null) {
                    contentRow.createCell(0).setCellValue(dataList.get(i).getNairetitle());
                } else {
                    contentRow.createCell(0).setCellValue("");
                }
                contentRow.createCell(1).setCellStyle(textStyle);
                contentRow.createCell(1).setCellType(CellType.STRING);
                if (dataList.get(i).getQuestionNaireStartTime() != null && dataList.get(i).getQuestionNaireEndTime() != null) {
                    contentRow.createCell(1).setCellValue(dataList.get(i).getQuestionNaireStartTime() + "-" + dataList.get(i).getQuestionNaireEndTime());
                } else {
                    contentRow.createCell(1).setCellValue("");
                }
                if (dataList.get(i).getPubstatus() != null) {
                    contentRow.createCell(2).setCellValue(dataList.get(i).getPubstatus());
                } else {
                    contentRow.createCell(2).setCellValue("");
                }

                if (dataList.get(i).getQuestionNaireUploadTime() != null) {
                    contentRow.createCell(3).setCellValue(dataList.get(i).getQuestionNaireUploadTime());
                } else {
                    contentRow.createCell(3).setCellValue("");
                }
                if(dataList.get(i).getQuestionNaireCount()!=null) {
                    contentRow.createCell(4).setCellValue(dataList.get(i).getQuestionNaireCount());
                } else {
                    contentRow.createCell(4).setCellValue("");
                }
            }
            // 给下面的表格写数据
            String filename = tableName;
            String agent = request.getHeader("User-Agent");
            ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
        }
    }


    public static List<Suggestion> uploadSuggestion(MultipartFile file, HttpServletRequest request, ModelMap model) throws IOException {
        HSSFWorkbook workbook = null;
        HSSFCell cell = null;
        HSSFCell cell2 = null;
        HSSFCell cell3 = null;
        HSSFCell cell4 = null;
        HSSFCell cell5 = null;
        HSSFCell cell6 = null;
        HSSFCell cell7 = null;
        HSSFCell cell8 = null;
        HSSFCell cell9 = null;
        HSSFCell cell10 = null;
        HSSFCell cell11 = null;
        HSSFCell cell12 = null;
        HSSFCell cell13 = null;
        HSSFCell cell14 = null;
        HSSFCell cell15 = null;
        HSSFCell cell16 = null;
        //校验是否为数字
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        //校验是否为浮点数
        Pattern patternFloat = Pattern.compile("^[-\\+]?[.\\d]*$");
        //校验邮箱
        Pattern patternEmail = Pattern.compile("^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*\\.[a-zA-Z0-9]{2,6}$");

        // 创建集合存储单元表格数据
        List<Suggestion> list = new ArrayList();
        // 获取file文件
        workbook = new HSSFWorkbook(file.getInputStream());
        // 获取单元表格
        HSSFSheet sheet = workbook.getSheetAt(0);
        // 循环遍历单元表格数据
        for (int i = 0; i <= sheet.getLastRowNum(); i++) {
            Suggestion suggestion = new Suggestion();
            HSSFRow row = sheet.getRow(i);
            // 不要第一行
            if (row.getRowNum() == 0) {
                continue;
            }
            String personnel_name = POIUtils.getValue(row.getCell(0));
            if (StringUtils.isBlank(personnel_name)) {
                //throw new OkayException("第" + ++i + "行的人员名称为空");
                personnel_name="";
            }
            suggestion.setAudiencename(personnel_name);

            //观众来源
            cell = row.getCell(1);
            cell.setCellType(CellType.STRING);
            String source = cell.getStringCellValue();
            if(StringUtils.isBlank(source) || !pattern.matcher(source).matches()) {
                source="0";
            }
            suggestion.setSuggestionresource(Integer.parseInt(source));

            //意见类型
            cell2 = row.getCell(2);
            if (cell2 == null) {
                throw new OkayException("请检查第" + ++i + "行是否有填写意见类型");
            }
            cell2.setCellType(CellType.STRING);
            String type = cell2.getStringCellValue();//此时content的数值为12345678910123
            if (StringUtils.isBlank(type)) {
                throw new OkayException("第" + ++i + "行的意见类型为空");
            }
            suggestion.setSuggestiontype(Integer.parseInt(type));

            //意见提交时间
            cell3 = row.getCell(3);
            if (cell3 != null) {
                cell3.setCellType(CellType.STRING);
                String dateTime = cell3.getStringCellValue();
                try {
                    Date date= DateUtils.addDays(c.getTime(),Integer.parseInt(dateTime));
                    suggestion.setSubmitdate(date);
                } catch (Exception e) {
                    throw new OkayException("日期格式填写错误");
                }
            }

            //手机号
            cell4 = row.getCell(4);
            if (cell4 != null) {
                cell4.setCellType(CellType.STRING);
                String phone = cell4.getStringCellValue();
                if (pattern.matcher(phone).matches()) {
                    suggestion.setMobilephone(phone);
                } else {
                    throw new OkayException("手机号应格式错误");
                }
            }


            cell5 = row.getCell(5);
            if (cell5 != null) {
                cell5.setCellType(CellType.STRING);
                String qq = cell5.getStringCellValue();
                if (!StringUtils.isBlank(qq) && pattern.matcher(qq).matches()) {
                    suggestion.setQqnumber(qq);
                } else {
                    throw new OkayException("QQ格式不正确");
                }
            }


            cell6 = row.getCell(6);
            if (cell6 != null) {
                cell6.setCellType(CellType.STRING);
                String telephone = cell6.getStringCellValue();
                if(!StringUtils.isBlank(telephone) && pattern.matcher(telephone).matches()) {
                    suggestion.setTelephone(telephone);
                } else {
                    throw new OkayException("电话格式不正确");
                }
            }


            cell7 = row.getCell(7);
            if (cell7 != null) {
                cell7.setCellType(CellType.STRING);
                String wechat = cell7.getStringCellValue();
                if(!StringUtils.isBlank(wechat)) {
                    suggestion.setWeixinnumber(wechat);
                } else {
                    throw new OkayException("没有得到微信号");
                }
            }


            //邮箱
            cell8 = row.getCell(8);
            if (cell8 != null) {
                cell8.setCellType(CellType.STRING);
                String email = cell8.getStringCellValue();
                if(!StringUtils.isBlank(email) && patternEmail.matcher(email).matches()) {
                    suggestion.setEmail(email);
                } else {
                    throw new OkayException("邮箱格式不正确");
                }
            }

            //年龄
            cell9 = row.getCell(9);
            if (cell9 != null) {
                cell9.setCellType(CellType.STRING);
                String age = cell9.getStringCellValue();
                if(!StringUtils.isBlank(age) && pattern.matcher(age).matches()) {
                    suggestion.setAge(Integer.parseInt(age));
                } else {
                    throw new OkayException("年龄应不包含其他字符");
                }
            }

            //职业 1在校学生,2事业单位人员,3企业单位人员,4公务员,5军人/警察,6文教卫,7农业生产者,8个体户/自由职业者,9待业,10离退休,11其他)
            cell10 = row.getCell(10);
            if (cell10 != null) {
                cell10.setCellType(CellType.STRING);
                String job = cell10.getStringCellValue();
                if(!StringUtils.isBlank(job)) {
                    switch (job) {
                        case "在校学生":
                            job = "1";
                            break;
                        case  "事业单位人员":
                            job ="2";
                            break;
                        case  "企业单位人员":
                            job ="3";
                            break;
                        case  "公务员":
                            job ="4";
                            break;
                        case  "军人/警察":
                            job ="5";
                            break;
                        case  "文教卫":
                            job ="6";
                            break;
                        case  "农业生产者":
                            job ="7";
                            break;
                        case  "个体户/自由职业者":
                            job ="8";
                            break;
                        case  "待业":
                            job ="9";
                            break;
                        case  "离退休":
                            job ="10";
                            break;
                        case  "其他":
                            job ="11";
                            break;
                            default:
                             job = "11";
                    }
                    suggestion.setProfession(Integer.parseInt(job));
                } else {
                    throw new OkayException("没有得到职位");
                }
            }

            //教育程度 1小学或以下,2初中高中/中专/技校大专,3本科,4研究生及以上,5海外留学生,6其他)
            cell11 = row.getCell(11);
            if (cell11 != null) {
                cell11.setCellType(CellType.STRING);
                String education = cell11.getStringCellValue();
                if(!StringUtils.isBlank(education)) {
                    if("小学或以下".equals(education)) {
                        education = "1";
                    } else if("初中高中/中专/技校大专".equals(education)) {
                        education = "2";
                    } else if("本科".equals(education)) {
                        education = "3";
                    } else if("研究生及以上".equals(education)) {
                        education = "4";
                    } else if("海外留学生".equals(education)) {
                        education = "5";
                    } else {
                        education = "6";
                    }
                    suggestion.setEducationlevel(Integer.parseInt(education));
                } else {
                    throw new OkayException("没有得到教育级别");
                }
            }

            //观众类型
            //(1内宾,2外宾,3儿童,4青少年,5中年,6老人,7孕妇,8残疾人,9嘉宾,10其他)
            cell12 = row.getCell(12);
            if (cell12 != null) {
                cell12.setCellType(CellType.STRING);
                String audienceType = cell12.getStringCellValue();
                if(!StringUtils.isBlank(audienceType)) {
                    audienceType="10";
                    suggestion.setAudiencetype(Integer.parseInt(audienceType));
                } else {
                    throw new OkayException("没有得到观众类型");
                }
            }

            //意见反馈渠道 (1手机,2电话,3QQ,4微信,5邮箱)
            cell13 = row.getCell(13);
            if (cell13 != null) {
                cell12.setCellType(CellType.STRING);
                String feedbackChannel = cell13.getStringCellValue();
                if(!StringUtils.isBlank(feedbackChannel)) {
                    if("手机".equals(feedbackChannel)) {
                        feedbackChannel = "1";
                    } else if("电话".equals(feedbackChannel)) {
                        feedbackChannel = "2";
                    } else if("QQ".equals(feedbackChannel)) {
                        feedbackChannel = "3";
                    } else if("微信".equals(feedbackChannel)) {
                        feedbackChannel = "4";
                    } else if("邮箱".equals(feedbackChannel)) {
                        feedbackChannel = "5";
                    } else {
                        throw new OkayException("请填写正确的意见返回渠道");
                    }
                    suggestion.setFeedbackchannel(Integer.parseInt(feedbackChannel));
                } else {
                    throw new OkayException("没有得到意见反馈渠道");
                }
            }

            //意见内容
            cell14 = row.getCell(14);
            if (cell14 == null) {
               throw new OkayException("请填写意见内容");
            } else {
                cell14.setCellType(CellType.STRING);
                String content = cell14.getStringCellValue();
                if(!StringUtils.isBlank(content)) {
                    suggestion.setSuggestioncontent(content);
                } else {
                    throw new OkayException("请填写意见内容");
                }
            }

            //处理意见
//            cell15 = row.getCell(15);
//            if (cell15 != null) {
//                cell15.setCellType(CellType.STRING);
//                String result = cell15.getStringCellValue();
//                if(!StringUtils.isBlank(result)) {
//                    suggestion.setSuggestionresult(result);
//                } else {
//                    throw new OkayException("没有得到处理意见");
//                }
//            }
            // 新增
            list.add(suggestion);
        }
        return list;
    }


    //-------------------------------------------导出Ex表 观众数据


    /**
     *Date 2018-10-16 15:33
     *@Description 导出博物馆观众列表
     */
    public static void outPutAll(List<Map<String, Object>> lists, String tableName, HttpServletRequest request, HttpServletResponse response) {
//        List<TicketSingle> dataList = (List<TicketSingle>) map.get("dataList");
        if (lists.size() > 0) {
            ArrayList<String> list = new ArrayList<>();
            list.add("观众名称");
            list.add("观众来源");
            list.add("性别");
            list.add("年龄");
            list.add("手机");
            list.add("最新预约");
            list.add("历史预约次数");
            HashMap tableMap = template("观众信息列表", list);
            HSSFSheet sheet = (HSSFSheet) tableMap.get("sheet");
            HSSFWorkbook workbook = (HSSFWorkbook) tableMap.get("workBook");
            //填写自己的信息
            HSSFCellStyle textStyle = workbook.createCellStyle();
            int b = 0;
            for (int i = 0; i < lists.size(); i++) {
                HSSFRow contentRow = sheet.createRow(++b);
                contentRow.createCell(0).setCellStyle(textStyle);
                contentRow.createCell(0).setCellType(CellType.STRING);
                if (lists.get(i).get("AUDIENCENAME") != null) {
                    contentRow.createCell(0).setCellValue(lists.get(i).get("AUDIENCENAME").toString());
                } else {
                    contentRow.createCell(0).setCellValue("");
                }

                //观众来源
                contentRow.createCell(1).setCellStyle(textStyle);
                contentRow.createCell(1).setCellType(CellType.STRING);
                if (lists.get(i).get("INFOMATIONNAME") != null) {
                    contentRow.createCell(1).setCellValue(lists.get(i).get("INFOMATIONNAME").toString());
                } else {
                    contentRow.createCell(1).setCellValue("");
                }



                //性别
                contentRow.createCell(2).setCellStyle(textStyle);
                contentRow.createCell(2).setCellType(CellType.STRING);
                if (lists.get(i).get("GENDERNAME") != null) {
                    contentRow.createCell(2).setCellValue(lists.get(i).get("GENDERNAME").toString());
                } else {
                    contentRow.createCell(2).setCellValue("");
                }


                //年龄
                contentRow.createCell(3).setCellStyle(textStyle);
                contentRow.createCell(3).setCellType(CellType.STRING);
                if (lists.get(i).get("AGE") != null) {
                    contentRow.createCell(3).setCellValue(lists.get(i).get("AGE").toString());
                } else {
                    contentRow.createCell(3).setCellValue("");
                }

                //手机
                contentRow.createCell(4).setCellStyle(textStyle);
                contentRow.createCell(4).setCellType(CellType.STRING);
                if (lists.get(i).get("TELEPHONE") != null) {
                    contentRow.createCell(4).setCellValue(lists.get(i).get("TELEPHONE").toString());
                } else {
                    contentRow.createCell(3).setCellValue("");
                }


                //最新预约
                contentRow.createCell(5).setCellStyle(textStyle);
                contentRow.createCell(5).setCellType(CellType.STRING);
                if (lists.get(i).get("LASTVISITDATE") != null) {
                    contentRow.createCell(5).setCellValue(lists.get(i).get("LASTVISITDATE").toString());
                } else {
                    contentRow.createCell(5).setCellValue("");
                }


                //历史预约次数
                contentRow.createCell(6).setCellStyle(textStyle);
                contentRow.createCell(6).setCellType(CellType.NUMERIC);
                if (lists.get(i).get("VISITTIMES") != null) {
                    contentRow.createCell(6).setCellValue(lists.get(i).get("LASTVISITDATE").toString());
                } else {
                    contentRow.createCell(6).setCellValue(0);
                }
            }
            // 给下面的表格写数据
            String filename = tableName;
            String agent = request.getHeader("User-Agent");
            ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
        }
    }



    //-------------------------------------------导出Ex表 观众数据







    //-------------------------------------------线下讲解人员

    /**
     * Date 2018-09-27 17:24
     *
     * @Description 下载模板
     */
    public static void downLoadExplainExcel(HttpServletRequest request,
                                            HttpServletResponse response, Integer type
    , List<Map<String, Object>> list) {
        // 在内存创建一个excle文件,并通过输出流写到客户端提供下载
        HSSFWorkbook workbook = new HSSFWorkbook();
        // 创建一个sheet分页
        HSSFSheet sheet = null;
        String filename ="";
        if(type==1) {
             sheet = workbook.createSheet("线下服务讲解数据");
             filename = "线下服务讲解数据.xls";
        }else if(type==2){
             sheet = workbook.createSheet("线下服务广播数据");
            filename = "线下服务广播数据.xls";
        }else if(type==3){
             sheet = workbook.createSheet("线下服务咨询数据");
            filename = "线下服务咨询数据.xls";
        }else if(type==4){
             sheet = workbook.createSheet("线下服务医疗数据");
            filename = "线下服务医疗数据.xls";
        }
        HSSFCellStyle textStyle = workbook.createCellStyle();
        HSSFDataFormat format = workbook.createDataFormat();
        textStyle.setDataFormat(format.getFormat("@"));


        //设置下标为二的单元默认样式为文本


//        ticketServiceExplainMapper.getexplaintypeList(map);



        // 创建标题行
        HSSFRow headRow = sheet.createRow(0);


        for (int i = 0; i < list.size(); i++) {
            headRow.createCell(i).setCellStyle(textStyle);
            headRow.createCell(i).setCellType(CellType.STRING);
            headRow.createCell(i).setCellValue(list.get(i).get("typename").toString());
        }

       /* headRow.createCell(0).setCellStyle(textStyle);
        headRow.createCell(0).setCellType(CellType.STRING);
        headRow.createCell(0).setCellValue("姓名（必填）");

        headRow.createCell(1).setCellStyle(textStyle);
        headRow.createCell(1).setCellType(CellType.STRING);
        headRow.createCell(1).setCellValue("证件号（必填）");

        headRow.createCell(2).setCellValue("讲解员（必填）");
        headRow.createCell(3).setCellValue("押金（元）（必填）");
        headRow.createCell(4).setCellValue("服务开始时间（必填）");
        headRow.createCell(5).setCellValue("服务结束时间");*/



        // 给下面的表格写数据
//        String filename = "线下服务讲解数据.xls";
        String agent = request.getHeader("User-Agent");
        ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
    }




    /**
     * Date 2018-09-28 15:39
     *
     * @Description 上传Excel表格
     */
    public static List explainUpload(MultipartFile file, HttpServletRequest request, ModelMap model) throws IOException {
        HSSFWorkbook workbook = null;
        HSSFCell cell = null;
        HSSFCell cell2 = null;
        HSSFCell cell3 = null;
        HSSFCell cell4 = null;
        HSSFCell cell5 = null;
        HSSFCell cell6 = null;


        // 创建集合存储单元表格数据
        List<Object> list = new ArrayList();
        // 获取file文件
        workbook = new HSSFWorkbook(file.getInputStream());
        // 获取单元表格
        HSSFSheet sheet = workbook.getSheetAt(0);

        Row hssfRow = sheet.getRow(0);
        //总列数
        int cellCount= hssfRow.getPhysicalNumberOfCells();

        Map<Integer,String> m = new HashMap<>();
        for (int i = 0; i <cellCount ; i++) {
            //列名称
           String rowName=POIUtils.getValue(sheet.getRow(0).getCell(i));
           if(rowName.indexOf("(必填)")!=-1){
               m.put(i,rowName) ;
           }
        }
//        Integer a = Integer.parseInt("AAA");

        // 循环遍历单元表格数据
        for (int i = 0; i <= sheet.getLastRowNum(); i++) {
//            AdRent audienceRegister = new AdRent();
            Explain explain = new Explain();
            HSSFRow row = sheet.getRow(i);
            // 不要第一行
            if (row.getRowNum() == 0) {
                continue;
            }

            Map<String,String> map  =new HashMap<>();

            for (int j = 0; j <cellCount ; j++) {
                if(m.get(j)!=null){
                    String value=POIUtils.getValue(sheet.getRow(i).getCell(j));
                    if (value == null || value.trim().equals("")) {
                        throw new OkayException("第" + ++i + "行的"+m.get(j).substring(0,m.get(j).indexOf("(必填)"))+"为空");
                    }else {
//                        ticketServiceExplainMapper.
//                        map.
                    }
                }
            }

           /* String personnel_name = POIUtils.getValue(row.getCell(0));
            if (personnel_name == null || personnel_name.trim().equals("")) {
                throw new OkayException("第" + ++i + "行的姓名为空");
            }
            explain.setName(personnel_name);


            cell2 = row.getCell(1);
            if (cell2 == null) {
                throw new OkayException("请检查第" + ++i + "行是否有填写证件号信息");
            }
            cell2.setCellType(CellType.STRING);
            String personnel_papersNo = cell2.getStringCellValue();//此时content的数值为12345678910123

            if (personnel_papersNo == null || personnel_papersNo.trim().equals("")) {
                throw new OkayException("第" + ++i + "行的身份证号码为空");
            }
            if (!IDCardUtils.validateCard(personnel_papersNo)) {
                throw new OkayException("第" + ++i + "行的身份证号码错误");
            }
//            audienceRegister.setAudienceCardno(personnel_papersNo);
            explain.setIdcard(personnel_papersNo);

            cell3 = row.getCell(2);
            if (cell3 == null) {
                throw new OkayException("请填写讲解员姓名");
            }
            cell3.setCellType(CellType.STRING);
            String content = cell3.getStringCellValue();
            explain.setExplainname(content);

            cell4 = row.getCell(3);
            if (cell4 == null) {
                throw new OkayException("请填写押金");
            }
            cell4.setCellType(CellType.STRING);
            String price = cell4.getStringCellValue();
            if (patternFloat.matcher(price).matches() || pattern.matcher(price).matches()) {
//                audienceRegister.setDeposit(Long.parseLong(price));
                explain.setPrice(Double.parseDouble(price));
            } else {
                throw new OkayException("押金应为数字");
            }




            cell5 = row.getCell(4);
            if (cell5 == null) {
                throw new OkayException("请填写租借时间,请填写规范2018-01-01");
            }
            cell5.setCellType(HSSFCell.CELL_TYPE_NUMERIC );
            Date startTime = cell5.getDateCellValue();
//            audienceRegister.setIsMoveFinancial(Byte.parseByte(LeaseTime));
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                String start = sdf.format(startTime);       //将Date类型转换成String类型
//                audienceRegister.setLeaseTime(start);
                explain.setStarttime(start);
            }catch (Exception e){
                throw new OkayException("请填写开始时间,请填写规范2018/1/1");
            }



            cell6 = row.getCell(5);
            if (cell6 != null) {
//                throw new OkayException("请填写租借时间,请填写规范2018-01-01");

            cell6.setCellType(HSSFCell.CELL_TYPE_NUMERIC );
            Date endTime = cell6.getDateCellValue();
                try {
                    String end = sdf.format(endTime);       //将Date类型转换成String类型
//                audienceRegister.setLeaseTime(end);
                    explain.setEndtime(end);
                }catch (Exception e){
                    throw new OkayException("请填写结束时间,请填写规范2018/1/1");
                }
            }else{
                explain.setEndtime(null);
            }*/
//            audienceRegister.setIsMoveFinancial(Byte.parseByte(LeaseTime));
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            // 新增
            list.add(explain);
        }
        return list;
    }



    //---------------------------------------------导出讲解数据



    /**
     *Date 2018-10-16 15:33
     *@Description 导出博物馆观众列表
     */
    public static void outPutAllExplain(List<Map<String, Object>> lists, String tableName, HttpServletRequest request, HttpServletResponse response) {
        if (lists.size() > 0) {
            ArrayList<String> list = new ArrayList<>();
            list.add("姓名");
            list.add("证件号");
            list.add("讲解员");
            list.add("金额");
            list.add("服务开始时间");
            list.add("服务结束时间");
            HashMap tableMap = template("讲解信息列表", list);
            HSSFSheet sheet = (HSSFSheet) tableMap.get("sheet");
            HSSFWorkbook workbook = (HSSFWorkbook) tableMap.get("workBook");
            //填写自己的信息
            HSSFCellStyle textStyle = workbook.createCellStyle();
            int b = 0;
            for (int i = 0; i < lists.size(); i++) {
                HSSFRow contentRow = sheet.createRow(++b);
                contentRow.createCell(0).setCellStyle(textStyle);
                contentRow.createCell(0).setCellType(CellType.STRING);
                if (lists.get(i).get("name") != null) {
                    contentRow.createCell(0).setCellValue(lists.get(i).get("name").toString());
                } else {
                    contentRow.createCell(0).setCellValue("");
                }

                //观众来源
                contentRow.createCell(1).setCellStyle(textStyle);
                contentRow.createCell(1).setCellType(CellType.STRING);
                if (lists.get(i).get("idcard") != null) {
                    contentRow.createCell(1).setCellValue(lists.get(i).get("idcard").toString());
                } else {
                    contentRow.createCell(1).setCellValue("");
                }



                //性别
                contentRow.createCell(2).setCellStyle(textStyle);
                contentRow.createCell(2).setCellType(CellType.STRING);
                if (lists.get(i).get("explainname") != null) {
                    contentRow.createCell(2).setCellValue(lists.get(i).get("explainname").toString());
                } else {
                    contentRow.createCell(2).setCellValue("");
                }


                //年龄
                contentRow.createCell(3).setCellStyle(textStyle);
                contentRow.createCell(3).setCellType(CellType.STRING);
                if (lists.get(i).get("price") != null) {
                    contentRow.createCell(3).setCellValue(lists.get(i).get("price").toString());
                } else {
                    contentRow.createCell(3).setCellValue("");
                }

                //手机
                contentRow.createCell(4).setCellStyle(textStyle);
                contentRow.createCell(4).setCellType(CellType.NUMERIC);
                if (lists.get(i).get("starttime") != null) {
                    contentRow.createCell(4).setCellValue(lists.get(i).get("starttime").toString());
                } else {
                    contentRow.createCell(3).setCellValue("");
                }


                //最新预约
                contentRow.createCell(5).setCellStyle(textStyle);
                contentRow.createCell(5).setCellType(CellType.NUMERIC);
                if (lists.get(i).get("endtime") != null) {
                    contentRow.createCell(5).setCellValue(lists.get(i).get("endtime").toString());
                } else {
                    contentRow.createCell(5).setCellValue("");
                }


            }
            // 给下面的表格写数据
            String filename = tableName;
            String agent = request.getHeader("User-Agent");
            ImprotDownLoadUtil.writeFile(filename, agent, workbook, request, response);
        }
    }




    //---------------------------------------------导出讲解数据


    //-------------------------------------------线下讲解人员
}
