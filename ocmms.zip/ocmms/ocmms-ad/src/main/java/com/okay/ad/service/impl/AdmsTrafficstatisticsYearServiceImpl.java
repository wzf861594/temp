package com.okay.ad.service.impl;

import java.util.List;

import com.okay.ad.entity.AdmsTrafficstatisticsYear;
import com.okay.ad.mapper.AdmsTrafficstatisticsYearMapper;
import com.okay.ad.service.IAdmsTrafficstatisticsYearService;

import org.springframework.stereotype.Service;


import javax.annotation.Resource;

/**
* 通用  serviceimpl
*
* @author  zengxiaoquan
*/
@Service(value = "aAdmsTrafficstatisticsYearServiceImpl")
public  class AdmsTrafficstatisticsYearServiceImpl implements IAdmsTrafficstatisticsYearService {


	@Resource
    private AdmsTrafficstatisticsYearMapper aAdmsTrafficstatisticsYearMapper;

    @Override
    public List<AdmsTrafficstatisticsYear> getAllData() {
        return aAdmsTrafficstatisticsYearMapper.getAllData();
    }



}




