package com.okay.ad.service;

import java.util.List;
import java.util.Map;

/**
* 通用  service
*
* @author zengxiaoquan
*/
public interface ITicketTeamService {


    /**
     * 获取个人门票预约列表
     *
     * @param aMap
     * @return
     */
    List<Map<String, Object>> getTeamTicketList(Map<String, Object> aMap, int pageNum, int pageSize);

    /**
     * 根据条件获取个人门票数据总量
     *
     * @param aMap
     * @return
     */
    int getTeamTicketCount(Map<String, Object> aMap);

    List<Map<String, Object>>  teamExport();


}




