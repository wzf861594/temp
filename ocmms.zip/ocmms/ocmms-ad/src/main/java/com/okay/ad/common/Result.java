package com.okay.ad.common;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 *Date 2018-09-28 14:44
 *@Description 响应数据
 */
@Data
public class Result<T> {
    @ApiModelProperty(value = "返回状态码")
    private int code;

    @ApiModelProperty(value = "描述信息")
    private String message;

    @ApiModelProperty(value = "总数")
    private int total;

    /**
     * 返回成功_success
     * @param ob
     * @param total
     */
    public void success(T ob,int total){
        setCode(1);
        setMessage("成功");
        setData(ob);
        setTotal(total);
    }

    //返回的数据
    private T data;

    public void setCode(int code) {
        this.code = code;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public void setData(T data) {
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public int getTotal() {
        return total;
    }

    public T getData() {
        return data;
    }
}
