package com.okay.ad.service.impl;

import com.github.pagehelper.PageHelper;
import com.okay.ad.entity.SuggestionAnswer;
import com.okay.ad.mapper.SuggestionAnswerMapper;
import com.okay.ad.service.ISuggestionAnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class SuggestionAnswerServiceImpl implements ISuggestionAnswerService {

    @Autowired
    SuggestionAnswerMapper suggestionAnswerMapper;

    /**
     * 批量查询 分页
     *
     * @param aMap
     * @param pageNum  页码
     * @param pageSize 分页大小
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return suggestionAnswerMapper.getHashMapList(aMap);
    }

    /**
     * 根据条件获取数据总量
     *
     * @param aMap
     * @return int
     */
    @Override
    public int getCount(Map<String, Object> aMap) {
        return suggestionAnswerMapper.getCount(aMap);
    }

    /**
     * 更新数据
     *
     * @param suggestionAnswer
     * @return
     */
    @Override
    public int updateQuestionAnswer(SuggestionAnswer suggestionAnswer) {
       // Date createDate = suggestionAnswerMapper.selectByPrimaryKey(suggestionAnswer.getRecid()).getCreatedate();
        //suggestionAnswer.setCreatedate(createDate);
        suggestionAnswer.setUpdatedate(new Date());
        return suggestionAnswerMapper.updateByPrimaryKeySelective(suggestionAnswer);
    }

    /**
     * 单条数据删除
     * @param recId
     * @return
     */
    @Override
    public  boolean deleteSuggestionAnswer(int recId){
        if (suggestionAnswerMapper.deleteByPrimaryKey(recId) == 1) {
            return true;
        }else {
            return false;
        }
    }

    @Override
    public void deleteByBatch(String ids) {
        suggestionAnswerMapper.deleteByBatch(Arrays.asList(ids.split(",")));
    }

    /**
     * 单条数据新增
     * @param suggestionAnswer
     * @return
     * @throws ParseException
     */
    @Override
    public boolean addSuggestionAnswer(SuggestionAnswer suggestionAnswer) throws ParseException {
        if(suggestionAnswerMapper.insertSelective(suggestionAnswer) == 1) {
            return true;
        }else {
            return false;
        }
    }

    /**
     * 单条数据查看
     * @param recId
     * @return
     */
    @Override
    public  SuggestionAnswer selectSuggestionAnswer(int recId){
        return  suggestionAnswerMapper.selectByPrimaryKey(recId);
    }
}

