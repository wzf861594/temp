package com.okay.ad.service;


import com.okay.ad.entity.SuggestionAnswer;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

public interface ISuggestionAnswerService {

    /**
     * 单条数据新增
     * @param suggestionAnswer
     * @return
     * @throws ParseException
     */
    boolean addSuggestionAnswer(SuggestionAnswer suggestionAnswer) throws ParseException;

    /**
     * 单条数据删除
     * @param recId
     * @return
     */
    boolean deleteSuggestionAnswer(int recId);

    void deleteByBatch(String ids);


    /**
     * 更新数据
     * @param suggestionAnswer
     * @return
     */
    int updateQuestionAnswer(SuggestionAnswer suggestionAnswer);


    /**
     * 批量查询
     * @param aMap
     * @return
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize);

    /**
     * 根据条件查询总条数
     * @param aMap
     * @return
     */
    int getCount(Map<String, Object> aMap);

    /**
     * 单条数据查看
     * @param recId
     * @return
     */
    SuggestionAnswer selectSuggestionAnswer(int recId);

}
