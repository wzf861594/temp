package com.okay.ad.service;

import java.util.List;
import java.util.Map;

/**
 * @author tingjun
 *
 * 观众数字化_通用查询模块——用于报表
 */
public interface Adgeneralquery {


    List<Map<String, Object>> getPassengerflowinrealtime();

}
