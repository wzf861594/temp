package com.okay.ad.common;

public class TicketStatus {

	public static final int STATUS_AUTH_ERROR = 10000;// 无权限访问
	public static final String STATUS_AUTH_ERROR_MSG = "无权限访问";//无权限访问

	public static final int STATUS_SUCCESS = 1;// 成功
	public static final String STATUS_SUCCESS_MSG = "成功";// 成功
	
	public static final int STATUS_FAIL = 20001;// 失败
	public static final String STATUS_FAIL_MSG = "失败";// 失败
	
	public static final int STATUS_ERROE = 20002;// 错误
	public static final String STATUS_ERROE_MSG = "错误";// 错误
	
	
	public static final int STATUS_VALID = 30000;// 有效
	public static final String STATUS_VALID_MSG = "有效";// 有效
	
	public static final int STATUS_INVALID = 30001;// 无效
	public static final String STATUS_INVALID_MSG = "无效";// 无效
	
	
	public static final int STATUS_UPDATE_ERROR = 30002;// 更新失败
	public static final String STATUS_UPDATE_ERROR_MSG = "无效";// 更新失败
	
	
	public static final int STATUS_RESULT_EMPTY = 40000;// 记录为空
	public static final String STATUS_RESULT_EMPTY_MSG = "记录为空";// 记录为空
	
	
	public static final int STATUS_SIGN_ERROR = 50000;// 签名无效
	public static final String STATUS_SIGN_ERROR_MSG = "签名无效";// 签名无效
	
	
	public static final int STATUS_EXCEPTION = 60000;// 异常
	public static final String STATUS_EXCEPTION_MSG = "异常";// 异常
	
	
	public static final int NETWORK_STATUS_SUCCESS = 90000;// 网络成功
	public static final String NETWORK_STATUS_SUCCESS_MSG = "网络成功";// 网络成功
	
	
	public static final int NETWORK_STATUS_ERROR = 90001;// 网络错误
	public static final String NETWORK_STATUS_ERROR_MSG = "网络错误";//网络错误

    public static  final  int STATUS_NEW_FAIL=4;    // 失败
    public static final String STATUS__NEW_FAIL_MSG = "错误";//错误

}
