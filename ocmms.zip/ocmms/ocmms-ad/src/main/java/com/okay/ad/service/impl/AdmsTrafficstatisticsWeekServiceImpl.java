package com.okay.ad.service.impl;

import java.util.List;
import com.okay.ad.entity.AdmsTrafficstatisticsWeek;
import com.okay.ad.mapper.AdmsTrafficstatisticsWeekMapper;
import com.okay.ad.service.IAdmsTrafficstatisticsWeekService;

import org.springframework.stereotype.Service;


import javax.annotation.Resource;

/**
* 通用  serviceimpl
*
* @author  zengxiaoquan
*/
@Service(value = "aAdmsTrafficstatisticsWeekServiceImpl")
public  class AdmsTrafficstatisticsWeekServiceImpl implements IAdmsTrafficstatisticsWeekService {

	@Resource
    private AdmsTrafficstatisticsWeekMapper aAdmsTrafficstatisticsWeekMapper;

    @Override
    public List<AdmsTrafficstatisticsWeek> getAllData() {
        return aAdmsTrafficstatisticsWeekMapper.getAllData();
    }


}




