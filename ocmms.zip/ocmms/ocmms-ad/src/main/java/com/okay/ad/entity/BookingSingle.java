package com.okay.ad.entity;

import lombok.Data;

import java.util.Date;

/**
 * @auther: xiazhili
 * @date: 2020-08-17 14:17
 */
@Data
public class BookingSingle {
    private String id;
    private String ticketNo;//预约票流水号
    private String visitName;//参观人
    private String certificateType;//证件类型
    private String certificateNo;//证件号码
    private String province;//省份
    private String city;//城市
    private String mobile;//手机号码
    private Integer status;//1-未参观，2-已参观，3-取消（超时未参观为爽约）
    private String ticketChecking;//检票时间
    private String ticketMachine;//检票机器
    private String temperature;//参观者体温
    private Integer childrens;//携带儿童数量
    private String bookingId;//预约表主键
    private Integer sort;//排序
    private Date cancelTime;//记录预约票的取消时间
    private Date createTime;//创建时间
    private String checkingType;//检票类型（1闸机;2手持检票机;3人工检票）
    private String cancelType;//取消方式（1人工；2网站；3微信公共号）
    private String outStatus;//出票状态（1已出票;0未出票）
    private Date outTime;//出票时间
    private String bid;
    private String orderNo;//如多张票的总单号
    private String ticketCode;//取票码
    private Integer ticketType;//票种类（1-门票，2-展览票，3-活动票）
    private Integer ticketWay;//订票方式（1-微信预约，2-网站预约，3-自助机取票，4-人工取票）
    private Date visitDate;//参观日期
    private String visitPeriod;//参观时段
    private Integer bookingStatus;//订单状态（1-正常，0-取消（预留：讨论一下有没有必要）默认1）
    private Integer bookingSort;//排序（默认1）
    private Date bookingCancelTime;//记录预约票的取消时间
    private Integer bookingType;//预约类（1-个人，2-团体）（默认1）
    private String bookingPerson;//预约人
    private String bookingMobile;//手机号码
    private Integer isCharge;//是否收费（1-收费，0-不收费）（默认0）
    private Integer age;
    private String sex;
    private String visitDateStr;
    private String ticketWayStr;
    private String statusStr;
    private String certificateTypeStr;
    private String isChargeStr;
    private Integer visittimes;// 历史参观次数
}
