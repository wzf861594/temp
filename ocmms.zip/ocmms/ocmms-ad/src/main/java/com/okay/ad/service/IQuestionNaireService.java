package com.okay.ad.service;


import com.alibaba.fastjson.JSONArray;
import com.okay.ad.common.PageQueryBean;
import com.okay.ad.entity.Option;
import com.okay.ad.entity.Question;
import com.okay.ad.entity.QuestionNaire;
import com.okay.ad.entity.QuestionOption;

import java.util.Map;

import java.util.List;

public interface IQuestionNaireService {

    /**
     * 新增问卷调查
     * @param questionNaire
     * @param questionList
     * @return
     */
    boolean addQuestionNaire(QuestionNaire questionNaire, List<Question> questionList);

    /**
     * 单条数据删除
     * @param naireId
     * @return
     */
    boolean deleteQuestionNaire(int naireId);

    /**
     * 批量查询
     * @param aMap
     * @return
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize);

    /**
     * 根据条件查询总条数
     * @param aMap
     * @return
     */
    int getCount(Map<String, Object> aMap);

    /**
     * 更新数据
     * @param questionNaire
     * @return
     */
    int updateQuestionNaire(QuestionNaire questionNaire);

    /** 问卷调查统计 */
    List<QuestionOption> queryNaireResultStatisical(int naireId);

    /**
     * 问卷调查统计
     * @param naireId
     * @return
     */
    List<QuestionOption> queryStatistical(int naireId);

    /**
     * 问卷调查查看
     * @param naireId
     * @return
     */
    Map<String, Object>  getQuestionNaire(int naireId);

    /**
     * 更新问卷调查
     * @param questionNaire
     * @param questionList
     * @return
     */
    boolean updateQuestionNaire(QuestionNaire questionNaire, List<Question> questionList);

    //List<Question> getQuestionList(int naireId);

    // HashMap queryQuestionListForIds(List<Integer> idsList);

    //List<QuestionOption> queryStatistical(String ids);

    //问卷调查_答题_列表渲染
    JSONArray getList(int naireid);

}
