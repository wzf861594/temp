package com.okay.ad.entity;

import com.okay.ad.annotation.Column;
import com.okay.ad.annotation.Id;
import com.okay.ad.annotation.Table;

/**
  *
  * 
  * 模板：entity.ftl
  * 模板定制：zengxiaoquan
 */

@Table(value = "ad_jiankong")
public class AdJiankong {

   	// 设备id 
    private Integer recordid;
   	// IP地址 
    private String ipaddress;
   	// mac地址 
    private String macaddress;
   	// 频道编号 
    private String channelid;
   	// 摄像头设定的箭头方向的值 
    private String penter;
   	// 摄像头设定的出口方向的值 
    private String pexit;
   	// 通过人数的值 
    private String ppass;
   	// 摄像头时间段-开始 
    private String starttime;
   	// 摄像头结束时间 
    private String endtime;
   	// 记录创建时间 
    private String createdate;

       
     /**
     * 获取 设备id
     *
     * @return recordid - 设备id
     */
    @Id(value = "recordid")
      public Integer getRecordid() {
        return recordid;
    }

     /**
     * 设置 设备id
     *
     * @param recordid 设备id
     */
    public void setRecordid(Integer recordid) {
        this.recordid = recordid;
    }
    



        
     /**
     * 获取 IP地址
     *
     * @return ipaddress - IP地址
     */
    @Column(value = "ipaddress")
    public String getIpaddress() {
        return ipaddress;
    }

     /**
     * 设置 IP地址
     *
     * @param ipaddress IP地址
     */
    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }
    
        
     /**
     * 获取 mac地址
     *
     * @return macaddress - mac地址
     */
    @Column(value = "macaddress")
    public String getMacaddress() {
        return macaddress;
    }

     /**
     * 设置 mac地址
     *
     * @param macaddress mac地址
     */
    public void setMacaddress(String macaddress) {
        this.macaddress = macaddress;
    }
    
        
     /**
     * 获取 频道编号
     *
     * @return channelid - 频道编号
     */
    @Column(value = "channelid")
    public String getChannelid() {
        return channelid;
    }

     /**
     * 设置 频道编号
     *
     * @param channelid 频道编号
     */
    public void setChannelid(String channelid) {
        this.channelid = channelid;
    }
    
        
     /**
     * 获取 摄像头设定的箭头方向的值
     *
     * @return penter - 摄像头设定的箭头方向的值
     */
    @Column(value = "penter")
    public String getPenter() {
        return penter;
    }

     /**
     * 设置 摄像头设定的箭头方向的值
     *
     * @param penter 摄像头设定的箭头方向的值
     */
    public void setPenter(String penter) {
        this.penter = penter;
    }
    
        
     /**
     * 获取 摄像头设定的出口方向的值
     *
     * @return pexit - 摄像头设定的出口方向的值
     */
    @Column(value = "pexit")
    public String getPexit() {
        return pexit;
    }

     /**
     * 设置 摄像头设定的出口方向的值
     *
     * @param pexit 摄像头设定的出口方向的值
     */
    public void setPexit(String pexit) {
        this.pexit = pexit;
    }
    
        
     /**
     * 获取 通过人数的值
     *
     * @return ppass - 通过人数的值
     */
    @Column(value = "ppass")
    public String getPpass() {
        return ppass;
    }

     /**
     * 设置 通过人数的值
     *
     * @param ppass 通过人数的值
     */
    public void setPpass(String ppass) {
        this.ppass = ppass;
    }
    
        
     /**
     * 获取 摄像头时间段-开始
     *
     * @return starttime - 摄像头时间段-开始
     */
    @Column(value = "starttime")
    public String getStarttime() {
        return starttime;
    }

     /**
     * 设置 摄像头时间段-开始
     *
     * @param starttime 摄像头时间段-开始
     */
    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }
    
        
     /**
     * 获取 摄像头结束时间
     *
     * @return endtime - 摄像头结束时间
     */
    @Column(value = "endtime")
    public String getEndtime() {
        return endtime;
    }

     /**
     * 设置 摄像头结束时间
     *
     * @param endtime 摄像头结束时间
     */
    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }
    
        
     /**
     * 获取 记录创建时间
     *
     * @return createdate - 记录创建时间
     */
    @Column(value = "createdate")
    public String getCreatedate() {
        return createdate;
    }

     /**
     * 设置 记录创建时间
     *
     * @param createdate 记录创建时间
     */
    public void setCreatedate(String createdate) {
        this.createdate = createdate;
    }
    


}

