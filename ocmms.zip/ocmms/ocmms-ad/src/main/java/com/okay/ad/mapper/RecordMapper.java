package com.okay.ad.mapper;

import com.okay.ad.entity.Option;
import com.okay.ad.entity.Question;
import com.okay.ad.entity.Record;

import java.util.List;

public interface RecordMapper {
    int deleteByPrimaryKey(Integer recordid);

    int insert(Record record);

    int insertSelective(Record record);

    Record selectByPrimaryKey(Integer recordid);

    int updateByPrimaryKeySelective(Record record);

    int updateByPrimaryKey(Record record);

    List<Integer> count(List<Question> questionList);

    List<Integer> optionCount(List<Option> optionList);

    int insertRecordBatch(List<Record> recordList);

    int selectRecordCountByQuesId(Integer quesid);

    int getcount(Question question);

    int getoptionCount(int optionsid);
}