package com.okay.ad.mapper;

import java.util.List;
import java.util.Map;
import com.okay.ad.entity.AdmsPeopledatatrend;

/**
* 通用 Mapper
*
* @author  zengxiaoquan
*/
public interface AdmsPeopledatatrendMapper {

    /**
     * 获取全部数据
     * @return int
     */
    List<AdmsPeopledatatrend> getAllData();

    List<Map> getmapData();


}




