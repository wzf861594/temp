package com.okay.ad.entity;

import lombok.Data;

import java.math.BigDecimal;

/**
  *
  * 
  * 模板：entity.ftl
  * 模板定制：zengxiaoquan
 */

@Data
public class AdmsTrafficstatisticsWeek {

   	//  
    private String orderdate;
   	//  
    private BigDecimal acount;



}

