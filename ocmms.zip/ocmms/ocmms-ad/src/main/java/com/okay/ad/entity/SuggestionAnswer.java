package com.okay.ad.entity;

import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@Table(value = "ad_suggestion_answer")
@ApiModel(value = "意见答库")
public class SuggestionAnswer {

    @ApiModelProperty(value = "ID")
    private Integer recid;

    @ApiModelProperty(value = "意见内容描述")
    private String suggestioncontent;

    @ApiModelProperty(value = "意见答案")
    private String suggestionanswer;

    @ApiModelProperty(value = "意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)")
    private Integer suggestiontype;

    @ApiModelProperty(value = "是否删除(0否,1是)")
    private Integer isdelete;

    @ApiModelProperty(value = "记录创建时间")
    private Date createdate;

    @ApiModelProperty(value = "记录更新时间")
    private Date updatedate;
}