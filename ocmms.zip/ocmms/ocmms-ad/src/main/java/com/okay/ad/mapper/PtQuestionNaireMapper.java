package com.okay.ad.mapper;

import com.okay.ad.entity.PtQuestionNaire;

public interface PtQuestionNaireMapper {
    int deleteByPrimaryKey(Integer naireid);

    int insert(PtQuestionNaire record);

    int insertSelective(PtQuestionNaire record);

    PtQuestionNaire selectByPrimaryKey(Integer naireid);

    int updateByPrimaryKeySelective(PtQuestionNaire record);

    int updateByPrimaryKeyWithBLOBs(PtQuestionNaire record);

    int updateByPrimaryKey(PtQuestionNaire record);
}