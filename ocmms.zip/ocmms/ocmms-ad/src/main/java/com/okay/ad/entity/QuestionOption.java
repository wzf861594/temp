package com.okay.ad.entity;

import lombok.Data;

import java.util.List;

@Data
public class QuestionOption {
    private String questionName;

    private List<OptionStatistical> optionList;
}
