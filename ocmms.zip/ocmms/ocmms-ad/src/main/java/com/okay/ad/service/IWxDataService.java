package com.okay.ad.service;

import com.okay.ad.entity.WxArticleSummary;
import com.okay.ad.entity.WxData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface IWxDataService {

     /**
     * 根据条件获取数据总量 
     * @param aMap 
     * @return int
     */
    int getCount(Map<String, Object> aMap);
    /**
     * 批量查询
     * @param aMap
     * @return List<WxData>
     */
    List<WxData> getEntityList(Map<String, Object> aMap);

     /**
     * 批量查询 分页
     * @param aMap 
     * @param pageNum 页码
     * @param pageSize 分页大小
     * @return List<WxData>
     */
    List<WxData> getEntityList(Map<String, Object> aMap, int pageNum, int pageSize);
    
     /**
     * 单条查询
     * @param aKey
     * @return WxData
     */
    WxData getEntityByPrimaryKey(String aKey);
    
    
    
     /**
     * 批量查询
     * @param aMap
     * @return  List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap);

     /**
     * 批量查询 分页
     * @param aMap 
     * @param pageNum 页码
     * @param pageSize 分页大小
     * @return  List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize);
    
     /**
     * 单条查询
     * @param aKey
     * @return HashMap
     */
     HashMap getHashMapByPrimaryKey(String aKey);

     /**
     * 添加
     * @param aWxData
     * @return boolean
     */
	public boolean addEntity(WxData aWxData);

	/**
     * 更新
     * @param aWxData
     * @return boolean
     */
	public boolean updateEntity(WxData aWxData);
	
	/**
     * 物理删除
     * @param  aKey
     * @return boolean
     */
	public boolean deleteEntity(String aKey);
	 /**
     * 通用批量添加
     *
     * @param sqlId
     * @param data
     * @return
     */
    public boolean batchAddEntitys(String sqlId, List data);

    List<Map<String, Object>> getWxListByPrimaryKey(Map<String, Object> aMap, int pageNum, int pageSize);

    int getWxCountByPrimaryKey(Map<String, Object> aMap);
}




