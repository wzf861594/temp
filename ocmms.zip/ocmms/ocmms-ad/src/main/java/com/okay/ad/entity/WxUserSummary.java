package com.okay.ad.entity;



import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.Date;

// 用户增减数据
@Data
@Table(value = "wx_usersummary")
@ApiModel(value = "用户增减数据")
public class WxUserSummary {

    private int id;
    // 日期
    private String refDate;
    // 用户的渠道
    private int userSource;
    // 新增的用户数量
    private int newUser;
    // 取消关注的用户数量
    private int cancelUser;
    // 创建时间
    private Date createdate;
}
