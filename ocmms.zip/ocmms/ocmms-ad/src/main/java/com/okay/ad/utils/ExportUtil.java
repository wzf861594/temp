package com.okay.ad.utils;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @auther: xiazhili
 * @date: 2020-12-22 15:33
 */
public class ExportUtil {

    public static void exportInfo(HttpServletResponse response, String filename,  List<String> titleCol, List<Map<String, Object>>  datas, List<String> datavalues) throws Exception {
        HSSFWorkbook sheets = new HSSFWorkbook();
        HSSFSheet sheet = sheets.createSheet("数据导出");

        int n = titleCol.size();
        //全局统一字体
        String fontCNType = "宋体";
        //设置n列，各自的列宽 = 3000毫米
        int width = 5000;
        int widthTitle = 8000;
        int height = 2500;
        for (int i = 0; i < n; i++) {
            if (i == 0) {
                sheet.setColumnWidth(i, widthTitle);
            } else {
                sheet.setColumnWidth(i, width);
            }
        }
        //head样式
        CellStyle headCellStyle = sheets.createCellStyle();
        Font headFont = sheets.createFont();
        headCellStyle.setAlignment(HorizontalAlignment.CENTER);
        headCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        headFont.setBold(true);
        headCellStyle.setFont(headFont);

        //data 样式
        CellStyle dataStyle = sheets.createCellStyle();
        dataStyle.setAlignment(HorizontalAlignment.CENTER);
        dataStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        //头行
        HSSFRow rowHead2 = sheet.createRow(0);
        rowHead2.setHeight((short) 500);
        for (int d = 0; d < titleCol.size(); d++) {
            HSSFCell datecell = rowHead2.createCell(d);
            datecell.setCellStyle(headCellStyle);
            datecell.setCellValue(titleCol.get(d));
        }
        //数据行
        int i = 1;
        for (int data = 0; data < datas.size(); data++) {
            HSSFRow dataRow = sheet.createRow(i);
            for (int dataL = 0; dataL < n; dataL++) {
                HSSFCell datecell = dataRow.createCell(dataL);
                datecell.setCellStyle(dataStyle);
                datecell.setCellValue(Objects.toString(datas.get(data).get(datavalues.get(dataL)), ""));
            }
            i++;
        }
        response.reset();
        response.setContentType("application/x-download");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(filename, "UTF-8") + ".xls");
        response.addHeader("filename", URLEncoder.encode(filename, "UTF-8") + ".xls");
        sheets.write(response.getOutputStream());

    }
}
