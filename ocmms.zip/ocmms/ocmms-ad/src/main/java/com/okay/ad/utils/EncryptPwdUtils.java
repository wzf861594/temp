package com.okay.ad.utils;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class EncryptPwdUtils {
    public static String encryptPassword(String paramString) {
        Object localObject = new byte[]{-61, 12, 53, -37, 126, 57, -21, -65, 61, -45, 28, 113};
        try {
            return AESEncrypt(paramString, Base64Encode((byte[]) localObject), true);
        } catch (Exception e) {
            return "";
        }
    }

    public static String AESEncrypt(String paramString1, String paramString2, boolean paramBoolean) throws Exception {
        String base64Encode = Base64Encode(new byte[]{0, 68, -65, 16, 32, 127, 60, -96, -110, -28, -10, -99, 118, 41, -32});
        Cipher cipher = Cipher.getInstance(base64Encode);
        cipher.init(1, new SecretKeySpec(paramString2.getBytes("utf-8"), "AES"));
        byte[] paramString1Byte = paramString1.getBytes("UTF-8");
        return Base64Encode(cipher.doFinal(paramString1Byte));
    }

    public static String Base64Encode(byte[] byteArray) {
        return new String((new Base64()).encode(byteArray));
    }
}
