package com.okay.ad.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.PageQueryBean;
import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.*;
import com.okay.ad.exception.OkayException;
import com.okay.ad.mapper.OptionMapper;
import com.okay.ad.mapper.QuestionMapper;
import com.okay.ad.mapper.QuestionNaireMapper;
import com.okay.ad.mapper.RecordMapper;
import com.okay.ad.service.QuestionService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    private QuestionNaireMapper questionNaireMapper;

    @Autowired
    private QuestionMapper questionMapper;

    @Autowired
    private OptionMapper optionMapper;

    @Autowired
    private RecordMapper recordMapper;


    @Override
    public PageQueryBean queryQuestionList(QueryCondition condition) {
        PageQueryBean pageQueryBean = new PageQueryBean();
        if (!StringUtils.isBlank(condition.getRangeDate())) {
            String rangeDate = condition.getRangeDate();
            String[] split = rangeDate.split("/");
            condition.setStartDate(split[0]);
            condition.setEndDate(split[1]);
        }
        int count = questionNaireMapper.count(condition);
        if (count > 0) {
            pageQueryBean.setTotalRows(count);
            pageQueryBean.setCurrentPage(condition.getCurrentPage());
            pageQueryBean.setPageSize(condition.getPageSize());
            List<QuestionNaire> list = questionNaireMapper.selectQuestionList(condition);
            pageQueryBean.setItems(list);
        }
        return pageQueryBean;
    }

    @Override
    public HashMap queryQuestionListForIds(List<Integer> idsList) {
        HashMap map = new HashMap();
        if (idsList.size() > 0) {
            List<QuestionNaire> list = questionNaireMapper.selectQuestionListForIds(idsList);
            map.put("dataList", list);
        } else {
            throw new OkayException("没有得到ID");
        }
        return map;
    }

    @Override
    @Transactional
    public int addQuestion(String obj) throws ParseException {
        JSONObject jsonObject = JSONObject.parseObject(obj);
        String bigTitle = (String) jsonObject.get("bigTitle");
        String naireStartTime = (String) jsonObject.get("naireStartTime");
        String naireEndTime = (String) jsonObject.get("naireEndTime");
        if (StringUtils.isBlank(bigTitle)) {
            throw new OkayException("没有的到问卷标题");
        }
        JSONArray idsJsonList = (JSONArray) jsonObject.get("questionList");
        QuestionNaire questionNaire = new QuestionNaire();
        questionNaire.setNairetitle(bigTitle);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            if(!StringUtils.isBlank(naireStartTime)&&!StringUtils.isBlank(naireEndTime)) {
                questionNaire.setQuestionNaireStartTime(simpleDateFormat.parse(naireStartTime));
                questionNaire.setQuestionNaireEndTime(simpleDateFormat.parse(naireEndTime));
            }
        } catch (Exception e) {
            throw new OkayException("日期转换异常");
        }
        int questionNaireResp = questionNaireMapper.insertSelective(questionNaire);
        if (questionNaireResp != 1) {
            throw new OkayException("插入问卷失败");
        }
        List<Option> optionList = new ArrayList<>();
        for (int i = 0; i < idsJsonList.size(); i++) {
            Question question = new Question();
            JSONObject map = (JSONObject) idsJsonList.get(i);
            String title = (String) map.get("title");
            if (StringUtils.isBlank(title)) {
                throw new OkayException("没有得到问题标题");
            }
            question.setQuestitle(title);
            question.setNaireid(questionNaire.getNaireid());
            int questionResp = questionMapper.insertSelective(question);
            if (questionResp != 1) {
                throw new OkayException("插入问题失败");
            }
            List<String> allList = (List<String>) map.get("option");
            for (int b = 0; b < allList.size(); b++) {
                Option option = new Option();
                option.setOptionstitle(allList.get(b));
                option.setQuesid(question.getQuesid());
                optionList.add(option);
            }
        }
        //批量插入OPTION
        optionMapper.batchInsert(optionList);
        return 0;
    }

    @Override
    public List<QuestionOption> queryStatistical(String ids) {
        List<QuestionOption> questionOptionList = new ArrayList<>();
        List<Integer> count = null;
        List<Option> optionList = null;
        NumberFormat numberFormat = NumberFormat.getInstance();
        numberFormat.setMaximumFractionDigits(2);
        JSONObject jsonObject = JSONObject.parseObject(ids);
        int id = (int) jsonObject.get("ids");
        if (id != 0) {
            /**查询问卷下的所有问题**/
            List<Question> questionList = questionMapper.selectByNaireId(id);
            if (questionList.size() > 0) {
                /**拿到每一个问题答题人数**/
                count = recordMapper.count(questionList);

                /**拿到所有问题下的所有选项**/
                optionList = optionMapper.selectByQuestionId(questionList);
            } else {
                throw new OkayException("没有查询到问卷的问题");
            }
            /**每一个选项出现的次数**/
            List<Integer> optionCount = recordMapper.optionCount(optionList);
            /**遍历每一个问题下的所有选项**/
            for (int i = 0; i < questionList.size(); i++) {
                QuestionOption questionOption = new QuestionOption();
                List<OptionStatistical> optionNameList = new ArrayList<>();
                for (int b = 0; b < optionList.size(); b++) {
                    /**校验选项所属哪个问题**/
                    if (questionList.get(i).getQuesid() == optionList.get(b).getQuesid()) {
                        OptionStatistical optionStatistical = new OptionStatistical();
                        questionOption.setQuestionName(questionList.get(i).getQuestitle());
                        optionStatistical.setOptionName(optionList.get(b).getOptionstitle());
                        optionStatistical.setCount(optionCount.get(b));
                        /**计算百分比**/
                        String result = numberFormat.format((float) optionCount.get(b) / (float) count.get(i) * 100);
                        optionStatistical.setPercentage(result + "%");
                        optionNameList.add(optionStatistical);
                        questionOption.setOptionList(optionNameList);
                    }
                }
                questionOptionList.add(questionOption);
            }
        } else {
            throw new OkayException("没有得到id");
        }
        return questionOptionList;
    }
}
