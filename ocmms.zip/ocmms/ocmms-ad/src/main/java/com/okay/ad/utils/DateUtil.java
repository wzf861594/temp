package com.okay.ad.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
    public static final String DateTime24h = "yyyy-MM-dd HH:mm:ss";
    public static final String DateTime12h = "yyyy-MM-dd hh:mm:ss";
    public static final String dateFormat = "yyyy-MM-dd";
    public static final String timeFormat = "HH:mm:ss";

    /**
     * 获取系统时间（yyyy_MM_dd_HH_mm_ss）
     *
     * @return String
     */
    public static String dateFormat_yyyy_MM_dd_HH_mm_ss() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return dateFormat.format(date);
    }

    /**
     * 格式化Date to yyyy-MM-dd HH:mm:ss
     * @return String
     */
    public static String dateTimeToString(Date dateTime) throws Exception{
        DateFormat df = new SimpleDateFormat(DateTime24h);
        return df.format(dateTime);
    }

    /**
     * 格式化yyyy-MM-dd HH:mm:ss to Date
     * @return Date
     */
    public static Date stringToDateTime(String dateTime) throws Exception{
        DateFormat df = new SimpleDateFormat(DateTime24h);
        return df.parse(dateTime);
    }

    public static int getAgeByBirth(String birthday) throws Exception {
        // 格式化传入的时间
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        Date parse = format.parse(birthday);
        int age = 0;
        try {
            Calendar now = Calendar.getInstance();
            now.setTime(new Date()); // 当前时间

            Calendar birth = Calendar.getInstance();
            birth.setTime(parse); // 传入的时间

            //如果传入的时间，在当前时间的后面，返回0岁
            if (birth.after(now)) {
                age = 0;
            } else {
                age = now.get(Calendar.YEAR) - birth.get(Calendar.YEAR);
                if (now.get(Calendar.DAY_OF_YEAR) > birth.get(Calendar.DAY_OF_YEAR)) {
                    age += 1;
                }
            }
            return age;
        } catch (Exception e) {
            return 0;
        }
    }

    public static boolean compare_date(Date DATE1, int second) {
        try {
            Date flockDate = new Date(DATE1.getTime() + second);
            Date nowDate = new Date();
            if (flockDate.getTime() >= nowDate.getTime()) {
                return true;
            } else if (flockDate.getTime() < nowDate.getTime()) {
                return false;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }
}
