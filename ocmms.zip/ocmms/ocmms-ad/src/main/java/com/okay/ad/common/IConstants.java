package com.okay.ad.common;


public class IConstants {
    // 返回码,成功
    public static final int RESULT_INT_SUCCESS = 0;

    // 返回码,失败
    public static final int RESULT_INT_ERROR = 1;


    //默认数据分页大小
    public static final int DEFULAT_PAGER_SIZE = 20;
}

