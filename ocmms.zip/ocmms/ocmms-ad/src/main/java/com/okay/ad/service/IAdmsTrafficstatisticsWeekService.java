package com.okay.ad.service;

import java.util.List;
import com.okay.ad.entity.AdmsTrafficstatisticsWeek;

/**
* 通用  service
*
* @author zengxiaoquan
*/
public interface IAdmsTrafficstatisticsWeekService {

    /**
     * 批量查询
     * @return List<AdmsTrafficstatisticsWeek>
     */
    List<AdmsTrafficstatisticsWeek> getAllData();

}




