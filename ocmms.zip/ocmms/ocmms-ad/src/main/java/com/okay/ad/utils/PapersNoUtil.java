package com.okay.ad.utils;

import java.security.MessageDigest;
import java.util.Map;
import java.util.TreeMap;

public class PapersNoUtil {
    /**
     * 加密
     *
     * @param str 需要加密的字符串
     * @return 加密后的字符串
     */
    public static String encryption(String str,String AEStoken,String MD5token){
        String result = "";
        AESUtils aesUtil = new AESUtils();
        String AESstr = aesUtil.AESEncode(str,AEStoken);
        TreeMap<String, Object> reqArgs = new TreeMap<>();
        reqArgs.put("ID_CARD",AESstr);
        result = sign(reqArgs,MD5token);
        return result;
    }
    /**
     * <b>计算字符串的MD5码值</b>
     *
     * @param str 需要计算的字符串
     * @return 计算得到的MD5字符串, 字母为大写
     */
    public static String md5(String str, boolean upper) {
        StringBuilder buff = new StringBuilder();
        try {
            // 计算字符串的MD5值
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(str.getBytes("utf-8"));

            // 16进制对应字符，此处使用的是大写字母
            final char[] HEX_DIGITS = {
                    '0', '1', '2', '3',
                    '4', '5', '6', '7',
                    '8', '9', 'A', 'B',
                    'C', 'D', 'E', 'F',
            };
            // 将结果转换为16进制字符串形式
            for (byte b : bytes) {
                buff.append(HEX_DIGITS[(b >> 4) & 0x0f]);
                buff.append(HEX_DIGITS[b & 0x0f]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!upper) {
            return buff.toString().toLowerCase();
        } else {
            return buff.toString();
        }
    }

    /**
     * <b>生成签名参数</b>
     * <p>
     * 对应文档中"2.3.2 签名参数"一节，需要使用签名参数验证请求的合法性。<br>
     * 其中第一次计算出来的请求参数的MD5码(与"pass"参数结合的那个)是小写的，否则计算签名会出错。<br>
     * 生成签名参数需要用到其它的参数和值，因此需要在为其它参数赋值后调用。即使参数值为空，也需要赋予空值。<br>
     * 生成签名参数需要用到用户密码。
     *
     * @param args 请求参数Map
     * @param MD5token MD5密钥
     * @return 签名参数的值(MD5字符串)
     */
    public static String sign(TreeMap<String, Object> args,String MD5token) {
        PapersNoUtil tu = new PapersNoUtil();
        return md5(md5(argsStr(args), false) + MD5token, true);
    }
    /**
     * <b>将请求参数Map转换为字符串形式</b>
     * <p>
     * 转换后的字符串即可拼接至URL后作为参数。<br>
     * 当传入参数Map为null或为空时，会返回空字符串。
     *
     * @param args 请求参数Map
     * @return 请求参数字符串
     */
    public static String argsStr(Map<String, Object> args) {
        StringBuilder buff = new StringBuilder();
        if (args != null) {
            // 遍历参数Map，依次将其内容拼接至字符串中
            for (String key : args.keySet()) {
                buff.append(key).append("=").append(args.get(key)).append("&");
            }
            // 删除最后的一个"&"
            buff.deleteCharAt(buff.length() - 1);
        }
        return buff.toString();
    }
}
