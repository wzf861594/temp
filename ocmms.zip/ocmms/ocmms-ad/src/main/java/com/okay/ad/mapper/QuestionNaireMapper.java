package com.okay.ad.mapper;

import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.QuestionNaire;

import java.util.List;
import java.util.Map;

public interface QuestionNaireMapper {

    int insert(QuestionNaire record);

    QuestionNaire selectByPrimaryKey(Integer naireid);

    int updateByPrimaryKeySelective(QuestionNaire record);

    int updateByPrimaryKeyWithBLOBs(QuestionNaire record);

    int count(QueryCondition condition);

    List<QuestionNaire> selectQuestionList(QueryCondition condition);

    List<QuestionNaire> selectQuestionListForIds(List<Integer> idsList);

    /**
     * 新增数据
     * @param record
     * @return
     */
    int insertSelective(QuestionNaire record);

    /**
     * 根据主键id,删除数据
     * @param naireid
     * @return
     */
    int deleteByPrimaryKey(Integer naireid);


    /**
     * 更新数据
     * @param questionNaire
     * @return
     */
    int updateByPrimaryKey(QuestionNaire questionNaire);

    /**
     * 查询问卷调查的数量条数
     * @param questionNaire
     * @return
     */
    int count(QuestionNaire questionNaire);

    /**
     * 问卷调查的列表的查询
     * @param questionNaire
     * @return
     */
    List<QuestionNaire> selectQuestionList(QuestionNaire questionNaire);


    /**
     * 批量查询
     * @param aMap
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap);


    /**
     * 根据条件获取数据总量
     * @param aMap
     * @return int
     */
    int getCount(Map<String, Object> aMap);

    /**
     * 根据主键id获取调查问卷的数据(Map形式返回)
     * @param naireid
     * @return
     */
    Map<String, Object> selectMapByPrimaryKey(Integer naireid);


    /**
     * 根据主键ID 获取发布状态
     */
    Map<String, Object> selectMapByPrimaryKeygetstatus(int naireid);
}