package com.okay.ad.service.impl;

import com.okay.ad.mapper.WxArticleSummaryMapper;
import com.okay.ad.service.WxStatisicsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class WxStatisicsServiceImpl implements WxStatisicsService {

    @Autowired
    private WxArticleSummaryMapper wxArticleSummaryMapper;

    @Override
    public int countArticleSummary(String title, String startDate, String endDate) {
        return wxArticleSummaryMapper.countArticleSummary(title, startDate, endDate);
    }

    @Override
    public List<Map<String, Object>> listArticleSummary(String title, String startDate, String endDate, int pageNo, int pageSize) {
        return wxArticleSummaryMapper.listArticleSummary(title, startDate, endDate, pageNo, pageSize);
    }
}
