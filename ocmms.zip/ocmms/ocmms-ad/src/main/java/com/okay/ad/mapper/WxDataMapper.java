package com.okay.ad.mapper;

import com.okay.ad.entity.WxData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public interface WxDataMapper {



     /**
     * 根据条件获取数据总量 
     * @param aMap 
     * @return int
     */
    int getCount(Map<String, Object> aMap);

    /**
     * 批量查询
     * @param aMap
     * @return List<WxData>
     */
    List<WxData> getEntityList(Map<String, Object> aMap);
    
     /**
     * 单条查询
     * @param aKey
     * @return WxData
     */
     WxData getEntityByPrimaryKey(String aKey);

	 
	 
	 
	 /**
     * 批量查询
     * @param aMap
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap);
    
     /**
     * 单条查询
     * @param aKey
     * @return HashMap
     */
    HashMap getHashMapByPrimaryKey(String aKey);

    List<Map<String, Object>> getWxListByPrimaryKey(Map<String, Object> aMap);

    int getWxCountByPrimaryKey(Map<String, Object> aMap);

}




