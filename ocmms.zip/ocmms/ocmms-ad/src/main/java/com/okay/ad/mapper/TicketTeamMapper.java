package com.okay.ad.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TicketTeamMapper {


    /**
     * 获取团体门票预约列表
     * @param aMap
     * @return
     */
    List<Map<String, Object>> getTeamTicketList(Map<String, Object> aMap);


    /**
     * 根据条件获取团体门票数据总量
     * @param aMap
     * @return int
     */
    int getTeamTicketCount(Map<String, Object> aMap);

    /**
     * 团体数据展示
     * @param map
     * @return
     */
    List<Map<String, Object>> getlist(Map<String, Object> map);

    Map<String, Object> view(String id);

    List<Map<String, Object>>  teamExport();
}




