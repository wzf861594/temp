package com.okay.ad.entity;

import com.okay.ad.annotation.Column;
import com.okay.ad.annotation.Id;
import com.okay.ad.annotation.Table;


@Table(value = "sys_log")
public class Log {
    // 主键
    private String log_Id;
    private String log_Name;
    private String log_ip;
    private String log_url;
    private String log_function;
    private String userId;
    private Integer LogType;
    private String VisitDate;


//    @Id(value = "logId")
    @Column(value = "logId")
    public String getLog_Id() {
        return log_Id;
    }

    public void setLog_Id(String log_Id) {
        this.log_Id = log_Id;
    }
    @Column(value = "log_Name")
    public String getLog_Name() {
        return log_Name;
    }

    public void setLog_Name(String log_Name) {
        this.log_Name = log_Name;
    }
    @Column(value = "log_ip")
    public String getLog_ip() {
        return log_ip;
    }

    public void setLog_ip(String log_ip) {
        this.log_ip = log_ip;
    }
    @Column(value = "log_url")
    public String getLog_url() {
        return log_url;
    }

    public void setLog_url(String log_url) {
        this.log_url = log_url;
    }
    @Column(value = "log_function")
    public String getLog_function() {
        return log_function;
    }

    public void setLog_function(String log_function) {
        this.log_function = log_function;
    }

    @Column(value = "userId")
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Column(value = "LogType")
    public Integer getLogType() {
        return LogType;
    }

    public void setLogType(Integer logType) {
        LogType = logType;
    }

    @Column(value = "VisitDate")
    public String getVisitDate() {
        return VisitDate;
    }

    public void setVisitDate(String visitDate) {
        VisitDate = visitDate;
    }
}
