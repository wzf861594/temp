package com.okay.ad.entity;

import java.util.Date;

public class PtQuestionNaire {
    private Integer naireid;

    private String nairetitle;

    private Integer pubstatus;

    private String creatuser;

    private Date creattime;

    private String updateuser;

    private Date updatetime;

    private String summary;

    public Integer getNaireid() {
        return naireid;
    }

    public void setNaireid(Integer naireid) {
        this.naireid = naireid;
    }

    public String getNairetitle() {
        return nairetitle;
    }

    public void setNairetitle(String nairetitle) {
        this.nairetitle = nairetitle == null ? null : nairetitle.trim();
    }

    public Integer getPubstatus() {
        return pubstatus;
    }

    public void setPubstatus(Integer pubstatus) {
        this.pubstatus = pubstatus;
    }

    public String getCreatuser() {
        return creatuser;
    }

    public void setCreatuser(String creatuser) {
        this.creatuser = creatuser == null ? null : creatuser.trim();
    }

    public Date getCreattime() {
        return creattime;
    }

    public void setCreattime(Date creattime) {
        this.creattime = creattime;
    }

    public String getUpdateuser() {
        return updateuser;
    }

    public void setUpdateuser(String updateuser) {
        this.updateuser = updateuser == null ? null : updateuser.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary == null ? null : summary.trim();
    }
}