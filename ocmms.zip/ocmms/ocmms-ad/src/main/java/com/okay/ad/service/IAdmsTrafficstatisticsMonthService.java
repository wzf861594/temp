package com.okay.ad.service;

import java.util.List;
import com.okay.ad.entity.AdmsTrafficstatisticsMonth;

/**
* 通用  service
*
* @author zengxiaoquan
*/
public interface IAdmsTrafficstatisticsMonthService {

    /**
     * 获取全部数据
     * @return List<AdmsTrafficstatisticsMonth>
     */
    List<AdmsTrafficstatisticsMonth> getAllData();


}




