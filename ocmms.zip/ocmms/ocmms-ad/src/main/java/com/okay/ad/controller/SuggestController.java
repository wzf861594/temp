package com.okay.ad.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.entity.Suggestion;
import com.okay.ad.exception.OkayException;
import com.okay.ad.service.SuggestService;
import com.okay.ad.utils.ImprotDownLoadUtil;
import com.okay.okay.common.log.annotation.SysLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "意见管理")
@RequestMapping("/suggest")
public class SuggestController {

    @Autowired
    private SuggestService suggestService;

    /**
     * 意见录入
     * @param json
     * @return
     */
    @SysLog("观众数字化意见管理新增")
    @ApiOperation(value = "意见录入")
    @ApiImplicitParams({
            @ApiImplicitParam(name="audiencename" ,value="名字",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="suggestionresource" ,value="意见来源(1留言区,2展厅现场,3内部,4电话,5其他)",dataType = "int"),
            @ApiImplicitParam(name="suggestiontype" ,value="意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)",dataType = "int", required = true),
            @ApiImplicitParam(name = "submitdate",value = "意见提交时间",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "mobilephone",value = "手机",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "qqnumber",value = "QQ号",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "telephone",value = "电话",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "weixinnumber",value = "微信号",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="email" ,value="邮箱",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="age" ,value="年龄",dataType = "int"),
            @ApiImplicitParam(name="profession" ,value="职业(1在校学生,2事业单位人员,3企业单位人员,4公务员,5军人/警察,6文教卫,7农业生产者,8个体户/自由职业者,9待业,10离退休,11其他)",dataType = "int"),
            @ApiImplicitParam(name="audiencetype" ,value="观众类型(1内宾,2外宾,3儿童,4青少年,5中年,6老人,7孕妇,8残疾人,9嘉宾,10其他)",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="educationlevel" ,value="教育程度(1小学或以下,2初中高中/中专/技校大专,3本科,4研究生及以上,5海外留学生,6其他)",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="feedbackchannel" ,value="意见反馈渠道(1手机,2电话,3QQ,4微信,5邮箱)",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="suggestioncontent" ,value="意见内容",dataType = "String",paramType = "query",required = true)
    })
    //SuggestionResult
    @PostMapping(value = "/insert")
    public Result insertSuggestion(@RequestBody JSONObject json) {
        String suggstionStr = JSONObject.toJSONString(json);
        Suggestion suggstion = JSON.parseObject(suggstionStr,Suggestion.class);
        Result resp = new Result();
        try {
            suggestService.addSuggestion(suggstion);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("保存成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_FAIL);
            resp.setMessage("系统错误");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

    /**
     * 单条删除
     * @param json
     * @return
     */
    @ApiOperation(value="单条意见删除")
    @ApiImplicitParam(name = "id" ,value = "ID",dataType = "int")
    @DeleteMapping(value = "/delete")
    public Result deleteSuggestion(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            suggestService.deleteSuggestion(json.getInteger("recid"));
            resp.setMessage("删除成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

    /**
     * 多条意见删除
     * @param ids
     * @return
     */
    @ApiOperation(value="多条意见删除")
    @ApiImplicitParam(name = "ids" ,value = "ID",dataType = "String")
    @SysLog("观众数字化意见管理删除")
    @PreAuthorize("@pms.hasPermission('opinion_del')")
    @DeleteMapping(value = "/deleteByBatch")
    public Result deleteByBatch(@RequestParam(value = "ids",required = true) String ids){
        Result result = new Result();
        try {
            suggestService.deleteByBatch(ids);
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setMessage("删除成功！");
        } catch (OkayException e) {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            result.setMessage("内部错误");
            result.setCode(TicketStatus.STATUS_ERROE);
        }
        return  result;
    }

    /**
     * 意见数据列表
     * @param json
     * @return
     */
    @ApiOperation(value = "意见数据列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int"),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name="suggestionresource" ,value="意见来源(1留言区,2展厅现场,3内部,4电话,5其他)",dataType = "int"),
            @ApiImplicitParam(name="suggestiontype" ,value="意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)",dataType = "int"),
            @ApiImplicitParam(name="suggestionstate" ,value="意见处理状态(0待处理,1已处理)",dataType = "int"),
            @ApiImplicitParam(name = "startDate" ,value = "意见提交开始时间",dataType = "String",paramType = "query",required = false),
            @ApiImplicitParam(name = "endDate" ,value = "意见提交结束时间",dataType = "String",paramType = "query",required = false),
            @ApiImplicitParam(name="audiencename" ,value="观众名字",dataType = "String"),
    })
    @PostMapping(value = "/query")
    public Result querySuggestionAnswer(@RequestBody JSONObject json) {
       Result resp = new Result();
        try {
            Map<String, Object> aMap = new HashMap<>();
            aMap.put("suggestionresource",json.getInteger("suggestionresource"));
            aMap.put("suggestiontype",json.getInteger("suggestiontype"));
            aMap.put("suggestionstate",json.getInteger("suggestionstate"));
            aMap.put("startDate",json.getString("startDate"));
            aMap.put("endDate",json.getString("endDate"));
            aMap.put("audiencename",json.getString("audiencename"));
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setData(suggestService.getHashMapList(aMap, json.getInteger("currentPage"), json.getInteger("pageSize")));
            resp.setTotal(suggestService.getCount(aMap));
        }catch (Exception ex){
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            resp.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return resp;
    }


    /**
     * 单条数据编辑
     * @param json
     * @return
     */
    @SysLog("观众数字化意见管理编辑")
    @ApiOperation(value="单条数据编辑")
    @ApiImplicitParams({
            @ApiImplicitParam(name="recid" ,value="ID",dataType = "int",paramType = "query", required = true),
            @ApiImplicitParam(name="suggestionresource" ,value="意见来源(1留言区,2展厅现场,3内部,4电话,5其他)",dataType = "int"),
            @ApiImplicitParam(name="audiencename" ,value="名字",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="suggestionresource" ,value="意见来源(1留言区,2展厅现场,3内部,4电话,5其他)",dataType = "int"),
            @ApiImplicitParam(name="suggestiontype" ,value="意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)",dataType = "int"),
            @ApiImplicitParam(name = "submitdate",value = "意见提交时间",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "mobilephone",value = "手机",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "qqnumber",value = "QQ号",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "telephone",value = "电话",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "weixinnumber",value = "微信号",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="email" ,value="邮箱",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="age" ,value="年龄",dataType = "int"),
            @ApiImplicitParam(name="profession" ,value="职业(1在校学生,2事业单位人员,3企业单位人员,4公务员,5军人/警察,6文教卫,7农业生产者,8个体户/自由职业者,9待业,10离退休,11其他)",dataType = "int"),
            @ApiImplicitParam(name="audiencetype" ,value="观众类型(1内宾,2外宾,3儿童,4青少年,5中年,6老人,7孕妇,8残疾人,9嘉宾,10其他)",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="educationlevel" ,value="教育程度(1小学或以下,2初中高中/中专/技校大专,3本科,4研究生及以上,5海外留学生,6其他)",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="feedbackchannel" ,value="意见反馈渠道(1手机,2电话,3QQ,4微信,5邮箱)",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="suggestioncontent" ,value="意见内容",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="suggestionresult" ,value="意见处理结果",dataType = "String",paramType = "query")
    })
    @PostMapping(value = "/update")
    public Result updateSuggestion(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            String suggstionStr = JSONObject.toJSONString(json);
            Suggestion suggstion = JSON.parseObject(suggstionStr,Suggestion.class);
            resp.setData(suggestService.updateSuggestion(suggstion));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("修改成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

    /**
     * 单条数据查看
     * @param recid
     * @return
     */
    @ApiOperation(value="单条数据查看")
    @ApiImplicitParam(name = "recid" ,value = "ID",dataType = "int")
    @GetMapping(value = "/selectById")
    public Result selectSuggestion(@RequestParam(value = "recid", required = true) String recid) {
        Result resp = new Result();
        try {
            resp.setData(suggestService.selectSuggestion(Integer.parseInt(recid)));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

    /**
     * 意见处理
     * @param json
     * @return
     */
    @ApiOperation(value="意见处理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "recid" ,value = "ID",dataType = "int"),
            @ApiImplicitParam(name="suggestionresult" ,value="意见处理结果",dataType = "String",paramType = "query")
    })
    @PostMapping(value = "/dealSuggestion")
    public Result dealSuggestion(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            String suggstionStr = JSONObject.toJSONString(json);
            Suggestion suggstion = JSON.parseObject(suggstionStr,Suggestion.class);
            resp.setData(suggestService.dealSuggestion(suggstion));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("处理成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
    /**
     *@Description 生成题库
     */
    @ApiOperation(value="生成题库")
    @ApiImplicitParam(name = "id" ,value = "ID",dataType = "int")
    @RequestMapping(value = "/createSuggestionPool",method = RequestMethod.POST)
    public Result createSuggestionPool(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            boolean i = suggestService.createSuggestionPool(json.getInteger("recid"));
            resp.setData(i);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
    /**
     * 导出意见管理信息
     * @param response
     * @param map
     * @throws Exception
     */
    @ApiOperation(value = "意见管理-导出")
    @PreAuthorize("@pms.hasPermission('suggest_exp')")
    @PostMapping("/suggestExport")
    public void suggestExport(HttpServletResponse response, @RequestBody HashMap map) throws Exception{
        suggestService.suggestExport(response,map);
    }
    /**
     *Date 2018-10-12 14:32
     *@Description 观众意见模板下载
     */
    @ApiOperation(value = "观众意见模板下载")
    @GetMapping(value = "/templateDownLoad")
    public void download(HttpServletRequest request, HttpServletResponse response) {
        Result resp = new Result();
        try {
            String tableName = "观众意见.xls";
            String sheetName = "观众意见录入";
            List<String> headRowList = new ArrayList<>();
            headRowList.add("观众姓名");
            headRowList.add("意见来源");
            headRowList.add("意见类型");
            headRowList.add("意见提交时间");
            headRowList.add("手机");
            headRowList.add("QQ");
            headRowList.add("电话");
            headRowList.add("微信号");
            headRowList.add("电子邮箱");
            headRowList.add("年龄");
            headRowList.add("职业");
            headRowList.add("教育程度");
            headRowList.add("观众类型");
            headRowList.add("意见反馈渠道");
            headRowList.add("意见内容");
//            headRowList.add("处理意见");
            ImprotDownLoadUtil.templateDownLoad(tableName,sheetName,
                    headRowList,request,response);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_ERROE);
            resp.setMessage("内部错误");
        }
        return ;
    }


    /**
     *Date 2018-10-12 14:51
     *@Description 导入观众意见
     */
    @ApiOperation(value = "导入观众意见")
    @ApiImplicitParam(name="file" ,value="Excel文件",dataType = "file",required = true)
    @PostMapping(value = "/upload")
    public Result upload(@RequestBody MultipartFile file , HttpServletRequest request, ModelMap model) {
        Result resp = new Result();
        try {
            List<Suggestion> list = ImprotDownLoadUtil.uploadSuggestion(file,request,model);
            suggestService.batchInsert(list);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_ERROE);
            resp.setMessage("内部错误");
        }
        return resp;
    }

}
