package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.service.ITicketTeamService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "线上行为")
@RequestMapping("/ticketTeam")
public class TicketTeamController {

    @Autowired
    private ITicketTeamService ticketTeamService;

    /**
     *@Description 团体门票预约列表
     *
     */
    @ApiOperation(value = "团体门票预约列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int"),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name="ticketNo" ,value="订单标识",dataType = "String"),
            @ApiImplicitParam(name="bookingPerson" ,value="预约人",dataType = "String"),
            @ApiImplicitParam(name="startVisitDate" ,value="参观开始时间",dataType = "String"),
            @ApiImplicitParam(name="endVisitDate" ,value="参观结束时间",dataType = "String")
    })
    @PostMapping(value = "/queryTeamTicketList")
    public Result queryTeamTicketList(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            Map<String, Object> aMap = new HashMap<>();
            aMap.put("ticketNo",json.getString("ticketNo"));
            aMap.put("bookingPerson",json.getString("bookingPerson"));
            aMap.put("startVisitDate",json.getString("startVisitDate"));
            aMap.put("endVisitDate",json.getString("endVisitDate"));
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setData(ticketTeamService.getTeamTicketList(aMap, json.getInteger("currentPage"), json.getInteger("pageSize")));
            resp.setTotal(ticketTeamService.getTeamTicketCount(aMap));
        }catch (Exception ex){
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            resp.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return resp;
    }

}
