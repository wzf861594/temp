package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.service.impl.ADMSStatisticalServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author zengxiaoquan
 */

@CrossOrigin(allowCredentials = "true")
@Controller
@Api(tags = "到访观众分析")
@RequestMapping(value = "/adms/udience/")
public class AudienceAnalysisController {

    private static final Logger log = LoggerFactory.getLogger(AudienceAnalysisController.class);

    @Autowired
    ADMSStatisticalServiceImpl aADMSStatisticalServiceImpl;

    /**
     * 馆内实时流量--导出
     */
    @PostMapping("/exportPassengerFlow")
    public void exportPassengerFlow(HttpServletResponse response, @RequestBody HashMap Map) throws Exception {
        aADMSStatisticalServiceImpl.exportPassengerFlow(response, Map);
    }


    /**
     * 观众类型到访统计--导出
     */
    @PostMapping("/exportAudienceType")
    public void exportAudienceType(HttpServletRequest httpServletRequest, HttpServletResponse response, @RequestBody HashMap map) throws Exception {
        aADMSStatisticalServiceImpl.exportAudienceType(response, map);
    }

    /**
     * 观众到访记录--导出
     */
    @PostMapping("/export")
    public void export(HttpServletRequest request, HttpServletResponse response, @RequestBody HashMap map) throws
            Exception {
        aADMSStatisticalServiceImpl.export(response, map);
    }

    /**
     * 到访观众统计——
     *
     * @param jsonObject
     * @return
     */
    @PostMapping("/getListAudiencevisit")
    @ResponseBody
    @ApiOperation(value = "到访观众统计__v1.0")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "beginDate", value = "开始时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "endDate", value = "结束时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "type", value = "类型（day,week,month,year）", dataType = "String", paramType = "query", defaultValue = "day", required = true)
    })
    public Result getVisitingstatistics(@RequestBody JSONObject jsonObject) {
        Result result = new Result();
        String beginDate = jsonObject.getString("beginDate");
        String endDate = jsonObject.getString("endDate");

        HashMap aMap = new HashMap<>(5);
        aMap.put("beginDate", beginDate);
        aMap.put("endDate", endDate);
        aMap.put("type", jsonObject.get("type"));
        List<Map<String, Object>> listAdventist = aADMSStatisticalServiceImpl.getListAudiencevisit(aMap);
        result.setTotal(listAdventist.size());
        result.setData(listAdventist);
        result.setCode(TicketStatus.STATUS_SUCCESS);
        result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
        return result;
    }

    /**
     * 到访观众类型统计（团体、成人、儿童）
     *
     * @param jsonObject
     * @return
     */
    @PostMapping("/getListAudienceTypeVisit")
    @ResponseBody
    @ApiOperation(value = "到访观众类型统计__v1.0")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "beginDate", value = "开始时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "endDate", value = "结束时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "type", value = "类型（day,week,month,year）", dataType = "String", paramType = "query", defaultValue = "day", required = true)
    })
    public Result getListAudienceTypeVisit(@RequestBody JSONObject jsonObject) {
        Result result = new Result();
        String beginDate = jsonObject.getString("beginDate");
        String endDate = jsonObject.getString("endDate");

        HashMap aMap = new HashMap<>();
        aMap.put("beginDate", beginDate);
        aMap.put("endDate", endDate);
        aMap.put("type", jsonObject.get("type"));
        Map<String, Object> adventist = aADMSStatisticalServiceImpl.getListAudienceTypeVisit(aMap);
        result.setData(adventist);
        result.setCode(TicketStatus.STATUS_SUCCESS);
        result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
        return result;
    }
}




