package com.okay.ad.service.impl;

import com.okay.ad.mapper.AdgeneralqueryMapper;
import com.okay.ad.service.Adgeneralquery;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AdgeneralqueryImpl implements Adgeneralquery {

    @Resource
    AdgeneralqueryMapper adgeneralqueryMapper;

    @Override
    public List<Map<String, Object>> getPassengerflowinrealtime() {
        //获取当前时间
        int hour = LocalDateTime.now().getHour();
        //返回结果集
        List<Map<String, Object>> mapList = new ArrayList<>();
        for (int i =9; i<18; i++){
            Map<String, Object> map =new HashMap<>();
            if (i>hour){
                map.put("x",i);
                map.put("y",0);
            }else if(i<=hour){
                int j = adgeneralqueryMapper.getPassengerflowinrealtime(i);
                int l =adgeneralqueryMapper.getpassengerflowinrealtimeCg(i);
                int r = j-l;
                map.put("x",i);
                map.put("y",r);
            }else{
                map.put("x",i);
                map.put("y",0);
            }
            mapList.add(map);
        }

        return mapList;
    }
}