package com.okay.ad.service.impl;

import com.okay.ad.entity.BookingSingle;
import com.okay.ad.mapper.BookingSingleMapper;
import com.okay.ad.service.BookingSingleService;
import com.okay.ad.service.ITicketTeamService;
import com.okay.ad.utils.ExportUtil;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @auther: xiazhili
 * @date: 2020-08-27 10:31
 */
@Service
@AllArgsConstructor
public class BookingSingleServiceImpl implements BookingSingleService {

     private BookingSingleMapper bookingSingleMapper;
    @Autowired
    private ITicketTeamService ticketTeamService;

    @Override
    public BookingSingle findById(String singleId) {
        return bookingSingleMapper.findById(singleId);
    }

    @Override
    public List<BookingSingle> selectInfo(Map<String, Object> aMap) {
        List<BookingSingle> list = new ArrayList<>();
        List<BookingSingle> bookingSingleList = bookingSingleMapper.selectInfo(aMap);
        if(bookingSingleList != null){
            for(BookingSingle b:bookingSingleList){
                BookingSingle bookingSingle = new BookingSingle();
                BeanUtils.copyProperties(b,bookingSingle);
                String certificate_no = b.getCertificateNo();
                if("0".equals(b.getCertificateType()) && certificate_no != null && (certificate_no.length() ==15 || certificate_no.length() == 18)){
                    Map<String, Object> value = getCarInfo(certificate_no);
                    bookingSingle.setAge((Integer) value.get("age"));
                    bookingSingle.setSex((String) value.get("sex"));
                }
                list.add(bookingSingle);
            }
        }
        return list;
    }

    @Override
    public int selectInfoCount(Map<String, Object> aMap) {
        return bookingSingleMapper.selectInfoCount(aMap);
    }

    @Override
    public List<BookingSingle> getTicketList(Map<String, Object> aMap) {
        List<BookingSingle> bookingSingles = bookingSingleMapper.getTicketList(aMap);
        return bookingSingles;
    }

    @Override
    public int getTicketListCount(Map<String, Object> aMap) {
        return bookingSingleMapper.getTicketListCount(aMap);
    }

    @Override
    public List<BookingSingle> getActTicketList(Map<String, Object> aMap) {
        return bookingSingleMapper.getActTicketList(aMap);
    }

    @Override
    public int getActTicketListCount(Map<String, Object> aMap) {
        return bookingSingleMapper.getActTicketListCount(aMap);
    }

    /**
     * 根据身份证的号码算出当前身份证持有者的性别和年龄 18位身份证
     *
     * @return
     * @throws Exception
     */
    public static Map<String, Object> getCarInfo(String CardCode) {
        Map<String, Object> map = new HashMap<String, Object>();
        String year = CardCode.substring(6).substring(0, 4);// 得到年份
        String yue = CardCode.substring(10).substring(0, 2);// 得到月份
        // String day=CardCode.substring(12).substring(0,2);//得到日
        String sex;
        if (Integer.parseInt(CardCode.substring(16).substring(0, 1)) % 2 == 0) {// 判断性别
            sex = "女";
        } else {
            sex = "男";
        }
        Date date = new Date();// 得到当前的系统时间
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String fyear = format.format(date).substring(0, 4);// 当前年份
        String fyue = format.format(date).substring(5, 7);// 月份
        // String fday=format.format(date).substring(8,10);
        int age = 0;
        if (Integer.parseInt(yue) <= Integer.parseInt(fyue)) { // 当前月份大于用户出身的月份表示已过生
            age = Integer.parseInt(fyear) - Integer.parseInt(year) + 1;
        } else {// 当前用户还没过生
            age = Integer.parseInt(fyear) - Integer.parseInt(year);
        }
        map.put("sex", sex);
        map.put("age", age);
        return map;
    }

    @Override
    public void personExport(HttpServletResponse response, HashMap object) throws Exception {
        List<Map<String, Object>> bookingSingleList = bookingSingleMapper.personExport();

        //头部-导出行
        List<String> titleCol = new ArrayList<>();
        titleCol.add("订单标识");
        titleCol.add("姓名");
        titleCol.add("证件类型");
        titleCol.add("证件号码");
        titleCol.add("手机号");
        titleCol.add("是否参观");
        titleCol.add("参观时间");
        List<String> datavalu = new ArrayList<>();
        datavalu.add("ticketNo");
        datavalu.add("visitName");
        datavalu.add("certificateTypeStr");
        datavalu.add("certificateNo");
        datavalu.add("mobile");
        datavalu.add("statusStr");
        datavalu.add("visitDateStr");
        String fileName = "个人门票列表";
        ExportUtil.exportInfo(response, fileName, titleCol, bookingSingleList, datavalu);
    }
    @Override
    public void teamExport(HttpServletResponse response, HashMap object) throws Exception {
        List<Map<String, Object>> bookingSingleList = ticketTeamService.teamExport();

        //头部-导出行
        List<String> titleCol = new ArrayList<>();
        titleCol.add("订单标识");
        titleCol.add("预约人");
        titleCol.add("参观时间");
        titleCol.add("参观团体");
        titleCol.add("团体履约人数");
        titleCol.add("是否参观");
        List<String> datavalu = new ArrayList<>();
        datavalu.add("ticketNo");
        datavalu.add("bookingPerson");
        datavalu.add("visitDateStr");
        datavalu.add("memberName");
        datavalu.add("visitingCount");
        datavalu.add("statusStr");
        String fileName = "团体预约信息列表";
        ExportUtil.exportInfo(response, fileName, titleCol, bookingSingleList, datavalu);
    }
    @Override
    public void actExport(HttpServletResponse response, HashMap object) throws Exception {
        List<Map<String, Object>> bookingSingleList = bookingSingleMapper.actExport();

        //头部-导出行
        List<String> titleCol = new ArrayList<>();
        titleCol.add("订单标识");
        titleCol.add("姓名");
        titleCol.add("证件类型");
        titleCol.add("证件号码");
        titleCol.add("手机号");
        titleCol.add("是否参观");
        titleCol.add("参观时间");
        titleCol.add("是否收费");
        List<String> datavalu = new ArrayList<>();
        datavalu.add("ticketNo");
        datavalu.add("visitName");
        datavalu.add("certificateTypeStr");
        datavalu.add("certificateNo");
        datavalu.add("mobile");
        datavalu.add("statusStr");
        datavalu.add("visitDateStr");
        datavalu.add("isChargeStr");
        String fileName = "活动讲座预约信息列表";
        ExportUtil.exportInfo(response, fileName, titleCol, bookingSingleList, datavalu);
    }
}
