package com.okay.ad.mapper;

import java.util.List;
import com.okay.ad.entity.AdmsTrafficstatisticsMonth;

/**
* 通用 Mapper
*
* @author  zengxiaoquan
*/
public interface AdmsTrafficstatisticsMonthMapper {

    /**
     * 获取全部数据
     * @return List<AdmsTrafficstatisticsMonth>
     */
    List<AdmsTrafficstatisticsMonth> getAllData();

}




