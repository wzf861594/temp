package com.okay.ad.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageHelper;
import com.okay.ad.entity.WxData;
import com.okay.ad.mapper.WxDataMapper;
import com.okay.ad.service.BaseServiceClient;
import com.okay.ad.service.IWxDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service(value = "aWxDataServiceImpl")
public class WxDataServiceImpl implements IWxDataService {


    @Autowired
    private WxDataMapper wxDataMapper;


    @Autowired
    private BaseServiceClient aBaseServiceClient;

    /**
     * 根据条件获取数据总量
     *
     * @param aMap
     * @return int
     */
    @Override
    public int getCount(Map<String, Object> aMap) {
        return wxDataMapper.getCount(aMap);
    }

    /**
     * 批量查询
     *
     * @param aMap
     * @return List<WxData>
     */
    @Override
    public List<WxData> getEntityList(Map<String, Object> aMap) {

        return wxDataMapper.getEntityList(aMap);

    }

    /**
     * 批量查询 分页
     *
     * @param aMap
     * @param pageNum  页码
     * @param pageSize 分页大小
     * @return List<WxData>
     */
    @Override
    public List<WxData> getEntityList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return wxDataMapper.getEntityList(aMap);

    }

    /**
     * 单条查询
     *
     * @param aKey
     * @return WxData
     */
    @Override
    public WxData getEntityByPrimaryKey(String aKey) {
        return wxDataMapper.getEntityByPrimaryKey(aKey);
    }


    /**
     * 批量查询
     *
     * @param aMap
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getHashMapList(Map<String, Object> aMap) {

        return wxDataMapper.getHashMapList(aMap);

    }

    /**
     * 批量查询 分页
     *
     * @param aMap
     * @param pageNum  页码
     * @param pageSize 分页大小
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return wxDataMapper.getHashMapList(aMap);

    }

    /**
     * 单条查询
     *
     * @param aKey
     * @return HashMap
     */
    @Override
    public HashMap getHashMapByPrimaryKey(String aKey) {
        return wxDataMapper.getHashMapByPrimaryKey(aKey);
    }

    /**
     * 添加
     *
     * @param aWxData
     * @return boolean
     */
    @Override
    public boolean addEntity(WxData aWxData) {
        if (1 == aBaseServiceClient.insert(aWxData)) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * 更新
     *
     * @param aWxData
     * @return boolean
     */
    @Override
    public boolean updateEntity(WxData aWxData) {
        if (1 == aBaseServiceClient.update(aWxData)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 物理删除
     *
     * @param aKey
     * @return boolean
     */
    @Override
    public boolean deleteEntity(String aKey) {
        if (1 == aBaseServiceClient.delete(aKey)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 批量增加
     *
     * @param sqlId
     * @param data
     * @return
     */
    @Override
    public boolean batchAddEntitys(String sqlId, List data) {
        if (1 == aBaseServiceClient.batchInsert(sqlId, data)) {
            return true;
        } else {
            return false;
        }
    }


    @Override
    public List<Map<String, Object>> getWxListByPrimaryKey(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return wxDataMapper.getWxListByPrimaryKey(aMap);

    }

    @Override
    public int getWxCountByPrimaryKey(Map<String, Object> aMap) {
        return wxDataMapper.getWxCountByPrimaryKey(aMap);
    }

}




