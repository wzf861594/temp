package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.WxdataSyn;
import com.okay.ad.service.WxsynService;
import com.okay.ad.utils.HttpClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/wxsyn")
@Api(tags="手动同步微信数据接口")
public class WXsynControllen {


    @Autowired
    HttpClient httpClientUtil;

    @Autowired
    WxdataSyn wxdataSyn;
    @Autowired
    WxsynService wxsynService;

    @PostMapping("/synBydate")
    @ApiOperation(value = "同步数据",httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(name="startDate", dataType = "string", value = "开始日期",paramType="body"),
            @ApiImplicitParam(name="endDate", dataType = "string", value = "结束日期日期",paramType="body"),
            @ApiImplicitParam(name="type", dataType = "string", value = "类型:ALL 所有类型,RY 用户相关,TW 图文相关",paramType="body")
    })
    public JSONObject gettoken(@RequestBody Map<String, String> map) {
        return wxsynService.wxsynbydate(map);

    }
}