package com.okay.ad.entity;

public class StaticConstant {
    private static String aeskey;

    public static String getAeskey() {
        return aeskey;
    }

    public static void setAeskey(String key) {
        aeskey = key;
    }
}
