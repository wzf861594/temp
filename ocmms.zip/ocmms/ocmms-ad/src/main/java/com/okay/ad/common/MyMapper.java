package com.okay.ad.common;


public interface MyMapper<T>  {
	

}
