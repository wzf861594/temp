package com.okay.ad.service;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.entity.WxDatasynLog;

import java.util.Map;

/**
 * @author tingjun
 */
public interface WxsynService {
    JSONObject wxsynbydate(Map<String, String> map);

    void lnsertLog(WxDatasynLog wxDatasynLog);
}
