package com.okay.ad.entity;

import com.okay.ad.annotation.Column;

import java.math.BigDecimal;

/**
  *
  * 
  * 模板：entity.ftl
  * 模板定制：zengxiaoquan
 */

public class AdmsPeopledatatrend {

   	//  
    private Long dayhour;
   	//  
    private BigDecimal acount;


     /**
     * 获取 
     *
     * @return dayhour - 
     */
    @Column(value = "dayhour")
    public Long getDayhour() {
        return dayhour;
    }

     /**
     * 设置 
     *
     * @param dayhour 
     */
    public void setDayhour(Long dayhour) {
        this.dayhour = dayhour;
    }
    
        
     /**
     * 获取 
     *
     * @return acount - 
     */
    @Column(value = "acount")
    public BigDecimal getAcount() {
        return acount;
    }

     /**
     * 设置 
     *
     * @param acount 
     */
    public void setacount(BigDecimal acount) {
        this.acount = acount;
    }
    


}

