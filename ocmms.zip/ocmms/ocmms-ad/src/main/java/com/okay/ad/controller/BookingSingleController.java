package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.exception.OkayException;
import com.okay.ad.service.BookingSingleService;
import com.okay.okay.common.log.annotation.SysLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;


/**
 * Demo TicketArchivesSingle Controller
 *
 * @author  zengxiaoquan
 */
@RestController
@Api(tags = "线上行为")
@RequestMapping(value = "/ticketSingle")
@AllArgsConstructor
public class BookingSingleController {

    private BookingSingleService bookingSingleService;


    //获取数据列表
    @ApiOperation(value = "获取个人观众档案列表")
    @PostMapping(value = "/list")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page" ,value = "页数",dataType = "int",required = true,defaultValue = "1"),
            @ApiImplicitParam(name = "limit" ,value = "页长",dataType = "int",required = true,defaultValue = "1"),
            @ApiImplicitParam(name="visitName",value = "参观人姓名",dataType = "String"),
            @ApiImplicitParam(name="ticketWay",value = "订票方式（1-微信预约，2-网站预约，3-自助机取票，4-人工取票）",dataType = "int"),
            @ApiImplicitParam(name="startVisitDate",value = "参观开始日期",dataType = "String"),
            @ApiImplicitParam(name="endVisitDate",value = "参观结束日期",dataType = "String")
    })
    public Result list(@RequestBody JSONObject json) {
        Result re = new Result();
        try {
            Map<String, Object> aMap = new HashMap<>();
            Integer PageLimit = json.getInteger("pageSize");
            aMap.put("PageNo",  (json.getInteger("currentPage")-1)*PageLimit);
            System.out.println((json.getInteger("currentPage")-1)*PageLimit);
            aMap.put("PageLimit", PageLimit);
            aMap.put("visitName",json.getString("visitName")); //参观人姓名
            aMap.put("ticketWay",json.getInteger("ticketWay")); //订票方式（1-t微信预约，2-网站预约，3-自助机取票，4-人工取票）
            aMap.put("startVisitDate",json.getString("startVisitDate")); //参观日期
            aMap.put("endVisitDate",json.getString("endVisitDate"));
            re.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            re.setCode(TicketStatus.STATUS_SUCCESS);
            re.setData(bookingSingleService.selectInfo(aMap));
            re.setTotal(bookingSingleService.selectInfoCount(aMap));
        }catch (Exception ex){
            ex.printStackTrace();
            re.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            re.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return re;
    }
    //根据id获取个人档案数据
    @ApiOperation(value = "根据id获取个人档案数据")
    @GetMapping(value = "/findById")
    @ApiImplicitParam(name = "singleId" ,value = "singleId",dataType = "int",required = true)
    public Result findById(@RequestParam(value = "singleId",required = true) String singleId) {
        Result resp = new Result();
        try {
            resp.setData(bookingSingleService.findById(singleId));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
    /**
     *@Description 个人门票预约列表
     */
    @ApiOperation(value = "个人门票预约列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int"),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name="ticketNo" ,value="订单标识",dataType = "String"),
            @ApiImplicitParam(name="visitName" ,value="名字",dataType = "String"),
            @ApiImplicitParam(name="startVisitDate" ,value="参观开始时间",dataType = "Date"),
            @ApiImplicitParam(name="endVisitDate" ,value="参观结束时间",dataType = "Date")
    })
    @PostMapping(value = "/queryTicketList")
    public Result queryTicketList(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {

            Map<String, Object> aMap = new HashMap<>();
            aMap.put("ticketNo",json.getString("ticketNo"));
            aMap.put("visitName",json.getString("visitName"));
            aMap.put("startVisitDate",json.getDate("startVisitDate"));
            aMap.put("endVisitDate",json.getDate("endVisitDate"));
            int currentPage = json.getInteger("currentPage");
            int pageSize = json.getInteger("pageSize");
            int pageNo = (currentPage - 1) * pageSize;
            aMap.put("pageNo", pageNo);
            aMap.put("pageSize", pageSize);
            resp.setData(bookingSingleService.getTicketList(aMap));
            resp.setTotal(bookingSingleService.getTicketListCount(aMap));
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        } catch (Exception ex) {
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            resp.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return resp;
    }

    /**
     *@Description 活动讲座预约列表
     */
    @ApiOperation(value = "活动讲座预约列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int"),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name="ticketNo" ,value="订单标识",dataType = "String"),
            @ApiImplicitParam(name="visitName" ,value="名字",dataType = "String"),
            @ApiImplicitParam(name="startVisitDate" ,value="参观开始时间",dataType = "Date"),
            @ApiImplicitParam(name="endVisitDate" ,value="参观结束时间",dataType = "Date")
    })
    @PostMapping(value = "/queryActTicketList")
    public Result queryActTicketList(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {

            Map<String, Object> aMap = new HashMap<>();
            aMap.put("ticketNo",json.getString("ticketNo"));
            aMap.put("visitName",json.getString("visitName"));
            aMap.put("startVisitDate",json.getDate("startVisitDate"));
            aMap.put("endVisitDate",json.getDate("endVisitDate"));
            int currentPage = json.getInteger("currentPage");
            int pageSize = json.getInteger("pageSize");
            int pageNo = (currentPage - 1) * pageSize;
            aMap.put("pageNo", pageNo);
            aMap.put("pageSize", pageSize);
            resp.setData(bookingSingleService.getActTicketList(aMap));
            resp.setTotal(bookingSingleService.getActTicketListCount(aMap));
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        } catch (Exception ex) {
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            resp.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return resp;
    }

    /**
     * 导出个人预约信息
     * @param response
     * @param map
     * @throws Exception
     */
    @ApiOperation(value = "个人会员-导出")
    @PreAuthorize("@pms.hasPermission('online_exp')")
    @PostMapping("/personExport")
    public void personExport(HttpServletResponse response, @RequestBody HashMap map) throws Exception{
        bookingSingleService.personExport(response,map);
    }

    /**
     * 导出团体预约信息
     * @param response
     * @param map
     * @throws Exception
     */
    @ApiOperation(value = "团体-导出")
    @PreAuthorize("@pms.hasPermission('online_exp')")
    @PostMapping("/teamExport")
    public void teamExport(HttpServletResponse response, @RequestBody HashMap map) throws Exception{
        bookingSingleService.teamExport(response,map);
    }

    /**
     * 导出活动讲座信息
     * @param response
     * @param map
     * @throws Exception
     */
    @ApiOperation(value = "活动讲座-导出")
    @PreAuthorize("@pms.hasPermission('online_exp')")
    @PostMapping("/actExport")
    public void actExport(HttpServletResponse response, @RequestBody HashMap map) throws Exception{
        bookingSingleService.actExport(response,map);
    }
}




