package com.okay.ad.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.okay.ad.entity.Explain;
import org.apache.ibatis.annotations.Param;

import javax.servlet.http.HttpServletResponse;

/**
* 通用 Mapper
*
* @author  zengxiaoquan
*/
public interface TicketServiceExplainMapper {



     /**
     * 根据条件获取数据总量 
     * @param aMap 
     * @return int
     */
    int getCount(Map<String, Object> aMap);

    /**
     * 批量查询
     * @param aMap
     * @return List<TicketServiceExplain>
     */
    List<Explain> getEntityList(Map<String, Object> aMap);
    
     /**
     * 单条查询
     * @param aKey
     * @return TicketServiceExplain
     */
     Explain getEntityByPrimaryKey(String aKey);

	 
	 
	 
	 /**
     * 批量查询
     * @param aMap
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap);
    
     /**
     * 单条查询
     * @param aKey
     * @return HashMap
     */
     HashMap getHashMapByPrimaryKey(String aKey);

    /**
     * 批量删除
     * @param ids
     * @return
     */
    int deleteByBatch(@Param(value = "ids") List<String> ids);

    /**
     * 批量查询
     * @param aMap
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getEXHashMapList(Map<String, Object> aMap);

    /**
     * 根据type查询 有什么字段
     * @param aMap
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getexplaintypeList(Map<String, Object> aMap);
    /**
     * 新增 explain表(导入数据)
     * @return List<Map<String, Object>>
     */
    void InsertExplain(Map<String, Object> map);

    HashMap<String,Object> selectExplainListById(Map<String, Object> map);

    Explain selectByPrimaryKey(Integer explainid);

    List<Map<String, Object>>  explainExport();


}




