package com.okay.ad.service.impl;

import com.okay.ad.entity.*;
import com.okay.ad.mapper.RecordMapper;
import com.okay.ad.service.IRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecordServiceImpl implements IRecordService {

    @Autowired
    private RecordMapper recordMapper;

    /**
     * 问卷调查填写录入
     * @param recordList
     * @return
     */
    public int addRecord(List<Record> recordList){
        return recordMapper.insertRecordBatch(recordList);
    }

}
