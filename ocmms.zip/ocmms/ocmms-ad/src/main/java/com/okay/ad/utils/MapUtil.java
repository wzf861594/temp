package com.okay.ad.utils;

import java.util.Iterator;
import java.util.Map;

public class MapUtil {

    /**
     * 打印Map的K-V*/
    public static void logOutMap(Map aMap){
        Iterator aIterator = aMap.entrySet().iterator();
        while (aIterator.hasNext()) {
            Map.Entry entry = (Map.Entry) aIterator.next();
            Object key = entry.getKey();
            Object value = entry.getValue();
            if(value instanceof Map){
                System.out.println(key + ":" + value);
            }else if(value instanceof String[]){
                String[] values = (String[])value;
                System.out.println(key + ":" + values[0]);
            }else{
                System.out.println(key + ":" + value.toString());
            }
        }
    }
}
