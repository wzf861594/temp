package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.service.Adgeneralquery;
import com.okay.ad.service.impl.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@CrossOrigin(allowCredentials ="true")
@Controller
@Api(tags = "观众流量监控管理")
@RequestMapping(value = "/adms/homepage/")
public  class MonitoringController {

	private static final Logger log = LoggerFactory.getLogger(MonitoringController.class);


    @Autowired
    AdmsTrafficstatisticsWeekServiceImpl aAdmsTrafficstatisticsWeekServiceImpl;

    @Autowired
    AdmsTrafficstatisticsMonthServiceImpl aAdmsTrafficstatisticsMonthServiceImpl;

    @Autowired
    AdmsTrafficstatisticsYearServiceImpl aAdmsTrafficstatisticsYearServiceImpl;

    @Autowired
    ADMSStatisticalServiceImpl aADMSStatisticalServiceImpl;

    @Autowired
    AdmsPeopledatatrendServiceImpl aAdmsPeopledatatrendServiceImpl;

    @Autowired
   Adgeneralquery  adgeneralquery;

    @ApiOperation(value = "观众流量监控 - 门禁人流统计")
    @RequestMapping(value = "/SluiceStatistics", method = {RequestMethod.POST})
    @ApiImplicitParam(name = "type", value = "类型（day,week,month,year）", dataType = "String", paramType = "query", defaultValue = "day", required = true)
    @ResponseBody
    public Result sluiceStatistics(@RequestBody JSONObject jsonObject) {
        Result result = new Result();
        String type = jsonObject.getString("type");
        if (StringUtils.isBlank(type)) {
            type = "day";
        }
        try {
            switch (type) {
                case "day":
                    result.setData(aAdmsPeopledatatrendServiceImpl.getmapData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                case "week":
                    result.setData(aAdmsTrafficstatisticsWeekServiceImpl.getAllData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                case "month":
                    result.setData(aAdmsTrafficstatisticsMonthServiceImpl.getAllData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                case "year":
                    result.setData(aAdmsTrafficstatisticsYearServiceImpl.getAllData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                default:
                    break;
            }
        } catch (Exception ex) {
            result.setCode(TicketStatus.STATUS_NEW_FAIL);
            result.setMessage(TicketStatus.STATUS_FAIL_MSG + " :" + ex.getMessage());
            log.error("观众流量监控管理error: 门禁统计-type: " + type + " " + ex.getMessage());
        }
        return result;
    }

    @ApiOperation(value = "观众流量监控 - 观众人流分析")
    @RequestMapping(value = "/AudienceFlowAnalysis", method = {RequestMethod.POST})
    @ApiImplicitParam(name = "type" ,value = "类型（day,week,month,year）",dataType = "String",paramType = "query",defaultValue = "day",required = true)
    @ResponseBody
    public Result audienceFlowAnalysis(@RequestParam(value = "type",defaultValue = "day",required = true)String type) {
        Result result = new Result();
        try{
            switch (type){
                case "day":
                    result.setData(aAdmsPeopledatatrendServiceImpl.getAllData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                case "week":
                    result.setData(aAdmsTrafficstatisticsWeekServiceImpl.getAllData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                case "month":
                    result.setData(aAdmsTrafficstatisticsMonthServiceImpl.getAllData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                case "year":
                    result.setData(aAdmsTrafficstatisticsYearServiceImpl.getAllData());
                    result.setCode(TicketStatus.STATUS_SUCCESS);
                    result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
                    break;
                default:
                    result.setCode(TicketStatus.STATUS_INVALID);
                    result.setMessage(TicketStatus.STATUS_INVALID_MSG);
                    break;
            }
        }catch (Exception ex){
            result.setCode(TicketStatus.STATUS_EXCEPTION);
            result.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
        }
        return result;
    }

    /**
     * 观众流量监控-管内实时人流分析第一版,初版逻辑_可优化
     * @auto tingjun
     * @return
     */
    @ApiOperation(value = "观众流量监控 - 馆内实时人流分析")
    @RequestMapping(value = "/RealTimeFlowAnalysis", method = {RequestMethod.POST})
    @ResponseBody
    public Result realTimeFlowAnalysis() {
        Result result =new Result();
        List<Map<String, Object>> passengerflowinrealtime = adgeneralquery.getPassengerflowinrealtime();
        result.setData(passengerflowinrealtime);
        result.setCode(TicketStatus.STATUS_SUCCESS);
        result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
        return result;
    }
}




