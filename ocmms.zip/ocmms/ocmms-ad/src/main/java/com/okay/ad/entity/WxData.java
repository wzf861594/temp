package com.okay.ad.entity;

import com.okay.ad.annotation.Column;
import com.okay.ad.annotation.Id;
import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@Table(value = "wx_data")
@ApiModel(value = "浏览点赞表")
public class WxData {

    @ApiModelProperty(value = "id")
    private Integer wxid;

    @ApiModelProperty(value = "数据的日期")
   	// 数据的日期 
    private String wxrefdate;

    @ApiModelProperty(value = "12003_3， 其中12003是msgid，即一次群发的消息的id； 3为index")
    private String msgid;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "分享次数")
    private Integer sharecount;

    @ApiModelProperty(value = "收藏次数")
    private Integer addtofavcount;

    @ApiModelProperty(value = "分享人数")
    private Integer shareuser;

    @ApiModelProperty(value = "收藏的人数")
    private Integer addtofavuser;

    @ApiModelProperty(value = "图文阅读数")
    private Integer pagereadcount;
    private Integer newusers;

    @Column(value="newusers")
    public Integer getNewusers() {
        return newusers;
    }

    public void setNewusers(Integer newusers) {
        this.newusers = newusers;
    }

    @Column(value="pagereadcount")
    public Integer getPagereadcount() {
        return pagereadcount;
    }

    public void setPagereadcount(Integer pagereadcount) {
        this.pagereadcount = pagereadcount;
    }

    @Id(value="wxid")
    public Integer getWxid() {
        return wxid;
    }

    public void setWxid(Integer wxid) {
        this.wxid = wxid;
    }

    @Column(value="wxrefdate")
    public String getWxrefdate() {
        return wxrefdate;
    }

    public void setWxrefdate(String wxrefdate) {
        this.wxrefdate = wxrefdate;
    }
    @Column(value="msgid")
    public String getMsgid() {
        return msgid;
    }

    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    @Column(value="title")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    @Column(value="sharecount")
    public Integer getSharecount() {
        return sharecount;
    }

    public void setSharecount(Integer sharecount) {
        this.sharecount = sharecount;
    }
    @Column(value="addtofavcount")
    public Integer getAddtofavcount() {
        return addtofavcount;
    }

    public void setAddtofavcount(Integer addtofavcount) {
        this.addtofavcount = addtofavcount;
    }
    @Column(value="shareuser")
    public Integer getShareuser() {
        return shareuser;
    }

    public void setShareuser(Integer shareuser) {
        this.shareuser = shareuser;
    }
    @Column(value="addtofavuser")
    public Integer getAddtofavuser() {
        return addtofavuser;
    }

    public void setAddtofavuser(Integer addtofavuser) {
        this.addtofavuser = addtofavuser;
    }
}

