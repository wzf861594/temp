package com.okay.ad.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface MultimediaMapper {

    // 文章热度
    List<Map<String, Object>> articleHotWeek(HashMap<String, Object> map);
    List<Map<String, Object>> articleHotMonth(HashMap<String, Object> map);
    List<Map<String, Object>> articleHotYear(HashMap<String, Object> map);

    // 新增用户关注
    List<Map<String, Object>> userSummaryWeek(HashMap<String, Object> map);
    List<Map<String, Object>> userSummaryMonth(HashMap<String, Object> map);
    List<Map<String, Object>> userSummaryYear(HashMap<String, Object> map);

    // 用户关注数
    List<Map<String, Object>> userCumulateWeek(HashMap<String, Object> map);
    List<Map<String, Object>> userCumulateMonth(HashMap<String, Object> map);
    List<Map<String, Object>> userCumulateYear(HashMap<String, Object> map);


    List<Map<String,Object>> selectweek();
    List<Map<String,Object>> selectmonth(HashMap<String, Object> map);
    List<Map<String,Object>> selectyear();

    List<Map<String,Object>> selectVisitweek();
    List<Map<String,Object>> selectVisitmonth(HashMap<String, Object> map);
    List<Map<String,Object>> selectVisityear();


    List<Map<String,Object>> selectCommentweek();
    List<Map<String,Object>> selectCommentmonth(HashMap<String, Object> map);
    List<Map<String,Object>> selectCommentyear();
}