package com.okay.ad.utils;

import java.io.UnsupportedEncodingException;

public class StringUtil {


    public static String Base64DataToString(String base64data) throws UnsupportedEncodingException {
        base64data = base64data.replaceAll("\\r\\n", "<br/>");
        byte[] decode_bytes= org.apache.commons.codec.binary.Base64.decodeBase64(base64data);
        String str=new String(decode_bytes,"GBK");
        return  str;
    }
}
