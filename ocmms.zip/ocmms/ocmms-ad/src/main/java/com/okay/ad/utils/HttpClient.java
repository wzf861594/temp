package com.okay.ad.utils;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.entity.WxDatasynLog;
import com.okay.ad.service.WxsynService;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;


@Component
public class HttpClient {
    private final Logger logger = LoggerFactory.getLogger(HttpClient.class);

    @Value("${wx.appID}")
    String APPID;
    @Value("${wx.appSecret}")
    String SECRET;

    @Autowired
    WxsynService wxsynService;


    public String httpUtil() {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        String access_token = "";
        JSONObject returnTonKen = new JSONObject();
        //1--失败，0--成功
        int status = 1;
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + APPID + "&secret=" + SECRET;
        try {
            HttpGet httpGet = new HttpGet(url);
            CloseableHttpResponse response = httpclient.execute(httpGet);
            String result = EntityUtils.toString(response.getEntity(), "utf-8");
            returnTonKen = JSONObject.parseObject(result);
            if (returnTonKen.getString("errcode") != null) {
                status = 1;
                logger.info("获取微信：access_token失败:" + returnTonKen);
            } else {
                status = 0;
                access_token = returnTonKen.getString("access_token");
                return access_token;
            }
        } catch (Exception e) {
            logger.error("获取微信：access_token ERROR:", e);
        } finally {
            try {
                WxDatasynLog wxDatasynLog = new WxDatasynLog();
                wxDatasynLog.setStartdate(LocalDate.now().toString());
                wxDatasynLog.setEnddate(LocalDate.now().toString());
                wxDatasynLog.setResponse(url + "----" + returnTonKen.toString());
                wxDatasynLog.setType(3);
                wxDatasynLog.setCreatetime(new Date());
                wxDatasynLog.setStatus(status);
                wxsynService.lnsertLog(wxDatasynLog);
                httpclient.close();
            } catch (IOException e) {
                logger.error("获取微信执行关流ERROR：", e);
            }
        }
        return access_token;
    }
}