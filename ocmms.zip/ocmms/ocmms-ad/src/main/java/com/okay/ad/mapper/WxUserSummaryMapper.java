package com.okay.ad.mapper;

import com.okay.ad.entity.WxUserSummary;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface WxUserSummaryMapper {

    @Select("select count(1) from wx_usersummary where ref_date = #{ref_date} and user_source = #{user_source}")
    int selectUserSummary(@Param("ref_date") String ref_date, @Param("user_source") int user_source);

    @Insert("insert into wx_usersummary(ref_date,user_source,new_user,cancel_user) values(#{wxUserSummary.refDate},#{wxUserSummary.userSource},#{wxUserSummary.newUser},#{wxUserSummary.cancelUser})")
    void insertUserSummary(@Param("wxUserSummary") WxUserSummary wxUserSummary);
}
