package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.service.WxStatisicsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "微信统计分析数据")
@RequestMapping("/adms/wxData")
public class WxStatisicsController {

    @Autowired
    private WxStatisicsService wxStatisicsService;

    @ApiOperation(value = "微信浏览行为")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int"),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name="title" ,value="标题",dataType = "String"),
            @ApiImplicitParam(name = "startDate" ,value = "开始时间",dataType = "String",paramType = "query",required = false),
            @ApiImplicitParam(name = "endDate" ,value = "结束时间",dataType = "String",paramType = "query",required = false)
    })
    @RequestMapping(value = "/queryWxArticleSummary",method = {RequestMethod.POST})
    public Result queryWxDataList(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            String title = json.getString("title");
            String startDate = json.getString("startDate");
            String endDate = json.getString("endDate");
            int currentPage = json.getInteger("currentPage");
            int pageSize = json.getInteger("pageSize");
            int pageNo = (currentPage - 1) * pageSize;
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setData(wxStatisicsService.listArticleSummary(title, startDate, endDate, pageNo, pageSize));
            resp.setTotal(wxStatisicsService.countArticleSummary(title, startDate, endDate));
        }catch (Exception ex){
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            resp.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return resp;
    }
}
