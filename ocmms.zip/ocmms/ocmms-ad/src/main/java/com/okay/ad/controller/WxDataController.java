package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.service.IWxDataService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "线上行为")
@RequestMapping("/adms/wxData")
public class WxDataController {

    @Autowired
    private IWxDataService wxDataService;

    /**
     *@Description 浏览点赞列表
     *
     */
    @ApiOperation(value = "浏览点赞列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int"),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name="title" ,value="标题",dataType = "String"),
            @ApiImplicitParam(name = "startDate" ,value = "开始时间",dataType = "String",paramType = "query",required = false),
            @ApiImplicitParam(name = "endDate" ,value = "结束时间",dataType = "String",paramType = "query",required = false)
    })
    @RequestMapping(value = "/queryWxDataList",method = {RequestMethod.POST})
    public Result queryWxDataList(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            Map<String, Object> aMap = new HashMap<>();;
            aMap.put("title","%"+json.getString("title")+"%");
            aMap.put("startDate",json.getDate("startDate"));
            aMap.put("endDate",json.getDate("endDate"));
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setData(wxDataService.getWxListByPrimaryKey(aMap, json.getInteger("currentPage"), json.getInteger("pageSize")));
            resp.setTotal(wxDataService.getWxCountByPrimaryKey(aMap));
        }catch (Exception ex){
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            resp.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return resp;
    }

}
