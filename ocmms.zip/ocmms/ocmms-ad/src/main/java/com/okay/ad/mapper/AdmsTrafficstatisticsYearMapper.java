package com.okay.ad.mapper;

import java.util.List;
import com.okay.ad.entity.AdmsTrafficstatisticsYear;

/**
* 通用 Mapper
*
* @author  zengxiaoquan
*/
public interface AdmsTrafficstatisticsYearMapper {

    /**
     * 获取全部数据
     * @return List<AdmsTrafficstatisticsYear>
     */
    List<AdmsTrafficstatisticsYear> getAllData();

}




