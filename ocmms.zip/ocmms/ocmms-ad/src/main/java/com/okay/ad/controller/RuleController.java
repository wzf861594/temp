package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.okay.ad.mapper.RuleMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


//观众分组
@CrossOrigin(allowCredentials ="true")
@RestController
@RequestMapping("/adms/rule")
@Api(tags = "观众分组")
public class RuleController {

    @Autowired
    private RuleMapper ruleMapper;


    //查询观众分组
    @ApiOperation(value = "查询观众分组列表", notes = "InsterRule")
    @RequestMapping(value = "/selectRule", method = {RequestMethod.GET})
    @ResponseBody
    public JSONObject selectRule(@RequestParam(value="page",defaultValue = "1") Integer page , @RequestParam(value="size",defaultValue = "5") Integer size , @RequestParam(value="GroupName",defaultValue = "",required = false) String GroupName) {
        JSONObject aJSONObject = new JSONObject();
        try {

           /* if(page!=0){
                page=page-1;
            }*/

            Map<Object ,Object> map=new HashMap <>();
            /*map.put("page",page);
            map.put("size",size);*/
            map.put("groupname",GroupName);
            PageHelper.startPage(page, size);
            List<Map<Object, Object>> ruleMap = ruleMapper.selectRule(map);
            map.put("page",null);
            map.put("size",null);
            Integer ruleSize = 0;
            if(ruleMap!=null){
                ruleSize=ruleMapper.selectRule(map).size();
            }

//            Map<Object, Object> ruleMap = ruleMapper.selectRule(page , size ,GroupName);
//            Integer ruleSize=ruleMapper.selectRule(null, null, GroupName).size();


            aJSONObject.put("data", ruleMap);
            aJSONObject.put("Total", ruleSize);
            aJSONObject.put("message", "成功");
            aJSONObject.put("status", 0);
        }catch(Exception e){
            e.printStackTrace();
            aJSONObject.put("message", "失败");
            aJSONObject.put("status", 1);
        }

        return aJSONObject;
    }

}
