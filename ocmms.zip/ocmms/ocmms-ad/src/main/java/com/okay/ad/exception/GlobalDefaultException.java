package com.okay.ad.exception;

import com.okay.ad.common.ResponseCode;
import com.okay.ad.common.ResponseResult;
import com.okay.ad.common.Result;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice(basePackages = {"com.okay.ticket.adms"})
public class GlobalDefaultException {

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ResponseResult requestExceptionHandler(Exception e){
        e.printStackTrace();
        return ResponseResult.builder().msg(ResponseCode.FAIL.msg).status(ResponseCode.FAIL.code).build();
    }
}
