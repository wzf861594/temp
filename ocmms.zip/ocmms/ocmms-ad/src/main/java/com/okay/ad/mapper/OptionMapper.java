package com.okay.ad.mapper;

import com.okay.ad.entity.Option;
import com.okay.ad.entity.Question;
import com.okay.ad.entity.Record;

import java.util.List;
import java.util.Map;

public interface OptionMapper {
    int deleteByPrimaryKey(Integer optionsid);

    int insert(Option record);

    int insertSelective(Option record);

    Option selectByPrimaryKey(Integer optionsid);

    int updateByPrimaryKeySelective(Option record);

    int updateByPrimaryKeyWithBLOBs(Option record);

    int updateByPrimaryKey(Option record);

    void batchInsert(List<Option> optionList);

    List<Option> selectByQuestionId(List<Question> questionList);

    /**
     * 根据所属问题删除相关选项
     * @param quesid
     * @return
     */
    int deleteByQuesId(int quesid);

    /**
     * 根据问题ID获取所属选项
     * @param quesid
     * @return
     */
    List<Option> selectByQuesId(int quesid);

    /**
     * 根据问题ID获取所属选项，Map形式返回
     * @param quesid
     * @return
     */
    List<Map<String, Object>> selectMapByQuesId(int quesid);

    /**
     * 根据问题ID 获取所属选项 用于答题列表渲染
     */
    List<Map<String, Object>> selectMapByQuesIdfromanswer(int quesid);

    /**
     * 根据选项 获取子问题ID
     */
    Record selectIDbyoptionsid(int optionsid);
}