package com.okay.ad.entity;

import lombok.Data;

import java.util.Date;

@Data
public class AdRent {
    private Integer adRentId;//id

    private String adName;//观众姓名

    private String adCardno;//身份证

    private String adPhone;//观众手机号

    private String rentContent;//租用内容

    private Integer rentNum;//租用数量

    private Long deposit;//押金

    private Integer isReturn;//是否归还 1.是,0.否

    private Integer isReturnDeposit;//是否已退押金 1,是，0,否

    private Integer isMoveFinancial;//是否移交财务 1,是,0,否

    private Date createdate;//记录创建时间

    private Integer receiveStatus;//领取状态 0未领取 1已领取

    private String registerNumber;//寄存牌号

    private Date leaseTime;//租借时间

    private Date returnTime;//归还时间

    private String agent; //经办人

}