package com.okay.ad.mapper;

import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.AdRent;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface AdRentMapper {
    int deleteByPrimaryKey(Integer audienceRegisterId);

    int deleteByBatch(@Param(value = "ids") List<String> ids);

    int insert(AdRent record);

    int insertSelective(AdRent record);

    AdRent selectByPrimaryKey(Integer audienceRegisterId);

    int updateByPrimaryKeySelective(AdRent record);

    int updateByPrimaryKey(AdRent record);

    List<AdRent> queryDatafromIds(List idList);

    int selectCount(QueryCondition condition);

    List<AdRent> selectAudiencdeRegisterList(QueryCondition condition);

    void insertFroExcelList(List uploadList);

    List<Map<String, Object>>  rentExport();
}