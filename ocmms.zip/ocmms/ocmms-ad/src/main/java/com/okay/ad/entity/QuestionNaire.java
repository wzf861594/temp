package com.okay.ad.entity;

import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@Table(value = "ad_questionnaire")
@ApiModel(value = "问卷调查表")
public class QuestionNaire{

    @ApiModelProperty(value = "ID")
    private Integer naireid;

    @ApiModelProperty(value = "问卷标题")
    private String nairetitle;

    @ApiModelProperty(value = "问卷内容")
    private String summary;

    @ApiModelProperty(value = "1-已发布  2-未发布")
    private Integer pubstatus;

    @ApiModelProperty(value = "创建人")
    private String creatuser;

    @ApiModelProperty(value = "创建时间")
    private Date creattime;

    @ApiModelProperty(value = "更新人")
    private String updateuser;

    @ApiModelProperty(value = "更新时间")
    private Date updatetime;

    @ApiModelProperty(value = "问卷报告开始时间")
    private Date questionNaireStartTime;

    @ApiModelProperty(value = "问卷报告结束时间")
    private Date questionNaireEndTime;

    @ApiModelProperty(value = "问卷报告上传时间")
    private Date questionNaireUploadTime;

    @ApiModelProperty(value = "报告数量")
    private Integer questionNaireCount;

    public Integer getNaireid() {
        return naireid;
    }

    public void setNaireid(Integer naireid) {
        this.naireid = naireid;
    }

    public String getNairetitle() {
        return nairetitle;
    }

    public void setNairetitle(String nairetitle) {
        this.nairetitle = nairetitle;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Integer getPubstatus() {
        return pubstatus;
    }

    public void setPubstatus(Integer pubstatus) {
        this.pubstatus = pubstatus;
    }

    public String getCreatuser() {
        return creatuser;
    }

    public void setCreatuser(String creatuser) {
        this.creatuser = creatuser;
    }

    public Date getCreattime() {
        return creattime;
    }

    public void setCreattime(Date creattime) {
        this.creattime = creattime;
    }

    public String getUpdateuser() {
        return updateuser;
    }

    public void setUpdateuser(String updateuser) {
        this.updateuser = updateuser;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Date getQuestionNaireStartTime() {
        return questionNaireStartTime;
    }

    public void setQuestionNaireStartTime(Date questionNaireStartTime) {
        this.questionNaireStartTime = questionNaireStartTime;
    }

    public Date getQuestionNaireEndTime() {
        return questionNaireEndTime;
    }

    public void setQuestionNaireEndTime(Date questionNaireEndTime) {
        this.questionNaireEndTime = questionNaireEndTime;
    }

    public Date getQuestionNaireUploadTime() {
        return questionNaireUploadTime;
    }

    public void setQuestionNaireUploadTime(Date questionNaireUploadTime) {
        this.questionNaireUploadTime = questionNaireUploadTime;
    }

    public Integer getQuestionNaireCount() {
        return questionNaireCount;
    }

    public void setQuestionNaireCount(Integer questionNaireCount) {
        this.questionNaireCount = questionNaireCount;
    }

    public Integer getQuestionNairePlatefrom() {
        return questionNairePlatefrom;
    }

    public void setQuestionNairePlatefrom(Integer questionNairePlatefrom) {
        this.questionNairePlatefrom = questionNairePlatefrom;
    }

    @ApiModelProperty(value = "问卷来源 1微信")
    private Integer questionNairePlatefrom;

}