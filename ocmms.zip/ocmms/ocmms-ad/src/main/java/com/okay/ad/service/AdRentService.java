package com.okay.ad.service;

import com.okay.ad.common.PageQueryBean;
import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.AdRent;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;

public interface AdRentService {
//    HashMap queryLoanDataList(Integer[] ids) throws Exception;

    //查询寄存列表数据
    PageQueryBean quertAudienceRegisterList(QueryCondition condition);


    HashMap queryLoanDataList(List<Integer> idsList);

    void insertRent(AdRent adRent);

    void updateRent(AdRent adRent);

    void insertForExcelList(List uploadList);

    void deleteDatafromId(Integer id);

    void deleteByBatch(String ids);

    void moveFinancial(AdRent rent);

    AdRent selectById(Integer id);

    void rentExport(HttpServletResponse response, HashMap object)throws Exception;
}
