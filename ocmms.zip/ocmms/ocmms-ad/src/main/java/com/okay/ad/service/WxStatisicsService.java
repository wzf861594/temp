package com.okay.ad.service;


import java.util.List;
import java.util.Map;

public interface WxStatisicsService {

    // 获取微信图文浏览行为的数量
    int countArticleSummary(String title, String startDate, String endDate);

    // 获取微信图文浏览行为数据
    List<Map<String, Object>> listArticleSummary(String title, String startDate, String endDate, int pageNo, int pageSize);

}
