package com.okay.ad.entity;

import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@Table(value = "ad_suggestion")
@ApiModel(value = "意见管理")
public class Suggestion {

    @ApiModelProperty(value = "ID")
    private Integer recid;

    @ApiModelProperty(value = "观众姓名")
    private String audiencename;

    @ApiModelProperty(value = "意见来源(1留言区,2展厅现场,3内部,4电话,5其他)")
    private Integer suggestionresource;

    @ApiModelProperty(value = "意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)")
    private Integer suggestiontype;

    @ApiModelProperty(value = "意见提交时间")
    private Date submitdate;

    @ApiModelProperty(value = "手机")
    private String mobilephone;

    @ApiModelProperty(value = "QQ号码")
    private String qqnumber;

    @ApiModelProperty(value = "电话")
    private String telephone;

    @ApiModelProperty(value = "微信号")
    private String weixinnumber;

    @ApiModelProperty(value = "电子邮箱")
    private String email;

    @ApiModelProperty(value = "年龄")
    private Integer age;

    @ApiModelProperty(value = "职业(1在校学生,2事业单位人员,3企业单位人员,4公务员,5军人/警察,6文教卫,7农业生产者,8个体户/自由职业者,9待业,10离退休,11其他)")
    private Integer profession;

    @ApiModelProperty(value = "观众类型(1内宾,2外宾,3儿童,4青少年,5中年,6老人,7孕妇,8残疾人,9嘉宾,10其他)")
    private Integer audiencetype;

    @ApiModelProperty(value = "教育程度(1小学或以下,2初中高中/中专/技校大专,3本科,4研究生及以上,5海外留学生,6其他)")
    private Integer educationlevel;

    @ApiModelProperty(value = "意见反馈渠道(1手机,2电话,3QQ,4微信,5邮箱)")
    private Integer feedbackchannel;

    @ApiModelProperty(value = "意见内容")
    private String suggestioncontent;

    @ApiModelProperty(value = "意见处理结果")
    private String suggestionresult;

    @ApiModelProperty(value = "意见处理状态(0待处理,1已处理)")
    private Integer suggestionstate;

    @ApiModelProperty(value = "是否生成题库(0否,1是)")
    private Integer iscreateanswer;

    @ApiModelProperty(value = "记录创建时间")
    private Date createdate;

    @ApiModelProperty(value = "记录修改时间")
    private Date updatedate;

    @ApiModelProperty(value = "意见处理渠道(1直接处理,2OA处理)")
    private Integer operatechannel;

    private String SuggestionResourceStr;
    private String SuggestionTypeStr;
}