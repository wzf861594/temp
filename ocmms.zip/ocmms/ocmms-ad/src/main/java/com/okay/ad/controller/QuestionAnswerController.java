package com.okay.ad.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.mapper.QuestionNaireMapper;
import com.okay.ad.service.IQuestionNaireService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import java.util.Map;

/**
 * @author ZHU.HQ
 * @date 2020/8/31 10:06
 */
@Api(tags = "问卷调查-答卷")
@Controller
@RequestMapping("/questionAnswer")
public class QuestionAnswerController {

    @Autowired
    IQuestionNaireService iQuestionNaireService;
    @Autowired
    QuestionNaireMapper questionNaireMapper;

    @GetMapping("/paper/{questionId}")
    public ModelAndView paper(@PathVariable String questionId, ModelAndView modelMap) {
        Map<String, Object> stringObjectMap = questionNaireMapper.selectMapByPrimaryKeygetstatus(Integer.valueOf(questionId));
        if (stringObjectMap == null ){
            modelMap.setViewName("questionnaire_error");
            modelMap.addObject("msg","未找到该调查问卷!");
            return modelMap;
        }
        // 1 - 发布   2--未发布
        String status = stringObjectMap.get("pubstatus") == null ? "2" : stringObjectMap.get("pubstatus").toString();
        if ("2".equals(status)) {
            modelMap.setViewName("questionnaire_error");
            modelMap.addObject("msg","当前调查问卷未发布!");
            return modelMap;
        }
        modelMap.setViewName("questionnaire");
        modelMap.addObject("data",stringObjectMap);
        return modelMap;
    }

    @GetMapping("/getList")
    @ResponseBody
    public JSONObject getList(@RequestParam("id") int narid) {
        JSONObject result = new JSONObject();
        try {
            JSONArray list1 = iQuestionNaireService.getList(narid);
            result.put("list", list1);
            result.put("code", "1");
            result.put("message", "成功");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("code", "500");
            result.put("message", "失败: " + e.getMessage());
        }
        return result;
    }
}
