package com.okay.ad.utils;


import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.MessageDigest;

/**
 * 签名工具类
 * MD5加密
 * HMAC加密
 * 本加密用于签名使用和js需要联合使用
 */
public class SignUtil {
    private static final Logger log = LoggerFactory.getLogger(SignUtil.class);
    private static final String KEY_MD5 = "MD5";
    // 全局数组
    private static final String[] strDigits = { "0", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

    // 返回形式为数字跟字符串
    private static String byteToArrayString(byte bByte) {
        int iRet = bByte;
        if (iRet < 0) {
            iRet += 256;
        }
        int iD1 = iRet / 16;
        int iD2 = iRet % 16;
        return strDigits[iD1] + strDigits[iD2];
    }

    // 转换字节数组为16进制字串
    private static String byteToString(byte[] bByte) {
        StringBuffer sBuffer = new StringBuffer();
        for (int i = 0; i < bByte.length; i++) {
            sBuffer.append(byteToArrayString(bByte[i]));
        }
        return sBuffer.toString();
    }
    /**
     * MD5加密
     * @param aString
     * @return
     * @throws Exception
     */
    public static String GetMD5Code(String aString) throws Exception{
        MessageDigest md = MessageDigest.getInstance(KEY_MD5);
        // md.digest() 该函数返回值为存放哈希值结果的byte数组
        return byteToString(md.digest(aString.getBytes()));
    }
    public static boolean matchSign(String aSign,String aBody) {
        try {
            System.out.println("用于签名的数据: "+aBody);
            String bSign=GetMD5Code(aBody);
            System.out.println("aSign: "+aSign);
            System.out.println("bSign: "+bSign);
            if(bSign.equals(aSign)) { return true; }
        } catch (Exception e) {
            return false;
        }
        return false;
    }
    /**
     * 签名判断：签名正确返回数据主体，签名校验失败返回（待定）*/
    public static String matchSign(String aBody) {
        try {
            JSONObject aJSONObject= JSONObject.parseObject(aBody);

            String aData=aJSONObject.getString("Data");//数据主体
            String aSign=aJSONObject.getString("Sign");//签名

            String bSign=GetMD5Code(aData);//重新签名
            System.out.println("aSign: "+aSign);
            System.out.println("bSign: "+bSign);
            //匹配签名
            if(bSign.equals(aSign)) { return StringUtil.Base64DataToString(aData); }
        } catch (Exception e) {
            log.error("签名异常： ",e.getMessage());
        }
        return "{}";
    }
}
