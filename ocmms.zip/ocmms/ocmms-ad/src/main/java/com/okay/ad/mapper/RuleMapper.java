package com.okay.ad.mapper;

import com.okay.ad.entity.Rule;

import java.util.List;
import java.util.Map;

public interface RuleMapper {

    List<Map<Object,Object>> selectRule(Map<Object, Object> map);
    Map<Object,Object> selectRuleById(Integer id);

    void InsertRule(Rule rule);
}