package com.okay.ad.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.entity.Explain;
import com.okay.ad.exception.OkayException;
import com.okay.ad.mapper.TicketServiceExplainMapper;
import com.okay.ad.service.BaseServiceClient;
import com.okay.ad.service.ITicketServiceExplainService;
import com.okay.okay.common.log.annotation.SysLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//日志
@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "线下行为管理-服务管理")
@RequestMapping("/explain")
@AllArgsConstructor
public class ExplainController {

    private final BaseServiceClient aBaseServiceClient;
    private final ITicketServiceExplainService ticketServiceExplainService;
    private final TicketServiceExplainMapper ticketServiceExplainMapper;


    //新增服务管理
    @SysLog("观众数字化服务管理新增")
    @ApiOperation(value = "新增服务管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name",value = "姓名",dataType = "String",required = true),
            @ApiImplicitParam(name="type" ,value="类型(1：讲解 2：广播 3：资讯 4 ：医疗 )",dataType = "Integer"),
            @ApiImplicitParam(name="starttime" ,value="服务开始时间",dataType = "String"),
            @ApiImplicitParam(name="endtime" ,value="服务结束时间",dataType = "String"),
            @ApiImplicitParam(name = "idcard",value = "证件号",dataType = "String"),
            @ApiImplicitParam(name="explainname" ,value="讲解人",dataType = "String"),
            @ApiImplicitParam(name="price" ,value="金额",dataType = "Double"),
            @ApiImplicitParam(name="registrant" ,value="登记人",dataType = "String"),
            @ApiImplicitParam(name="audiencesize" ,value="观众人数",dataType = "Integer"),
            @ApiImplicitParam(name="content" ,value="内容",dataType = "String"),
            @ApiImplicitParam(name="ischarge" ,value="是否收费(0免费 1收费）",dataType = "Integer"),
            @ApiImplicitParam(name="label" ,value="标签",dataType = "String")
    })
    @PostMapping(value = "/add")
    @Transactional(propagation = Propagation.REQUIRED)
    public Result insertExplain(@RequestBody JSONObject jsonD) {
        Result result = new Result();
        try {
            String audienceName = jsonD.getString("name");
            if ("".equals(audienceName)) {
                result.setMessage("请输入游客姓名");
                result.setCode(TicketStatus.STATUS_FAIL);
            } else {
                Explain ex = new Explain();
                if(!("".equals(jsonD.getString("starttime")))){
                    ex.setStarttime(jsonD.getString("starttime"));
                }

                if(!("".equals(jsonD.getString("endtime")))){
                    ex.setEndtime(jsonD.getString("endtime"));
                }

                ex.setExplainname(jsonD.getString("explainname"));
                ex.setIdcard(jsonD.getString("idcard"));
                ex.setName(jsonD.getString("name"));
                ex.setPrice(jsonD.getDouble("price"));
                ex.setType(jsonD.getInteger("type"));
                ex.setContent(jsonD.getString("content"));
                ex.setIscharge(jsonD.getInteger("ischarge"));
                ex.setLabel(jsonD.getString("label"));
                ex.setRegistrant(jsonD.getString("registrant"));
                ex.setAudiencesize(jsonD.getInteger("audiencesize"));
                SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = sdf.format(new Date());
                ex.setRegistrationtime(format);

                aBaseServiceClient.insert(ex);

                result.setMessage("保存成功");
                result.setCode(TicketStatus.STATUS_SUCCESS);
            }
        }catch(Exception e){
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            e.printStackTrace();
            result.setCode(TicketStatus.STATUS_FAIL);
            result.setMessage("保存失败");
        }

        return result;
    }


    //修改服务管理
    @SysLog("观众数字化服务管理修改")
    @ApiOperation(value = "修改服务管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name="explainid",value = "id",dataType = "Integer",required = true),
            @ApiImplicitParam(name = "name",value = "姓名",dataType = "String",required = true),
            @ApiImplicitParam(name="type" ,value="类型(1：讲解 2：广播 3：资讯 4 ：医疗 )",dataType = "Integer"),
            @ApiImplicitParam(name="starttime" ,value="服务开始时间",dataType = "String"),
            @ApiImplicitParam(name="endtime" ,value="服务结束时间",dataType = "String"),
            @ApiImplicitParam(name = "idcard",value = "证件号",dataType = "String"),
            @ApiImplicitParam(name="explainname" ,value="讲解人",dataType = "String"),
            @ApiImplicitParam(name="price" ,value="金额",dataType = "Double"),
            @ApiImplicitParam(name="registrant" ,value="登记人",dataType = "String"),
            @ApiImplicitParam(name="audiencesize" ,value="观众人数",dataType = "Integer"),
            @ApiImplicitParam(name="content" ,value="内容",dataType = "String"),
            @ApiImplicitParam(name="ischarge" ,value="是否收费(0免费 1收费）",dataType = "Integer"),
            @ApiImplicitParam(name="label" ,value="标签",dataType = "String")
    })
    @PostMapping(value = "/update")
    @Transactional(propagation = Propagation.REQUIRED)
    public Result updateExplainById(@RequestBody JSONObject jsonD) {
        Result result = new Result();
        try {
            int explainid = jsonD.getInteger("explainid");
            if (explainid == 0 || "".equals(explainid)) {
                result.setMessage("缺少主记录信息");
                result.setCode(TicketStatus.STATUS_FAIL);
            } else {
                Explain ex = new Explain();
                if(!("".equals(jsonD.getString("starttime")))){
                    ex.setStarttime(jsonD.getString("starttime"));
                }
                if(!("".equals(jsonD.getString("endtime")))){
                    ex.setEndtime(jsonD.getString("endtime"));
                }
                ex.setExplainid(jsonD.getInteger("explainid"));
                ex.setExplainname(jsonD.getString("explainname"));
                ex.setIdcard(jsonD.getString("idcard"));
                ex.setName(jsonD.getString("name"));
                ex.setPrice(jsonD.getDouble("price"));
                ex.setType(jsonD.getInteger("type"));
                ex.setContent(jsonD.getString("content"));
                ex.setIscharge(jsonD.getInteger("ischarge"));
                ex.setLabel(jsonD.getString("label"));
                ex.setRegistrant(jsonD.getString("registrant"));
                ex.setAudiencesize(jsonD.getInteger("audiencesize"));
                SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
                String format = sdf.format(new Date());
                ex.setRegistrationtime(format);
                aBaseServiceClient.update(ex);
                result.setMessage("修改成功");
                result.setCode(TicketStatus.STATUS_SUCCESS);
            }
        }catch(Exception e){
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            e.printStackTrace();
            result.setCode(TicketStatus.STATUS_FAIL);
            result.setMessage("修改失败");
        }
        return result;
    }

    //删除服务管理
    @ApiOperation(value = "单条删除服务管理")
    @DeleteMapping(value = "/delete")
    @Transactional(propagation = Propagation.REQUIRED)
    public JSONObject deleteExplainById(@RequestBody JSONObject jsonD) {
        JSONObject aJSONObject = new JSONObject();
        try {
            JSONArray jsonArr=jsonD.getJSONArray("explanid");
            for (int i = 0; i < jsonArr.size() ; i++) {
                Explain ex = new Explain();
                ex.setExplainid((Integer) jsonArr.get(i));
                aBaseServiceClient.delete(ex);
            }
            aJSONObject.put("message", "成功");
            aJSONObject.put("code", 1);
        }catch(Exception e){
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            aJSONObject.put("message", "失败");
            aJSONObject.put("code", 2);
        }
        return aJSONObject;
    }
    //删除服务管理
    @ApiOperation(value = "多条删除服务管理")
    @ApiImplicitParam(name = "ids" ,value = "ID",dataType = "int")
    @SysLog("观众数字化服务管理删除")
    @PreAuthorize("@pms.hasPermission('offline_audience_service_del')")
    @DeleteMapping(value = "/deleteByBatch")
    public Result deleteByBatch(@RequestParam(value = "ids",required = true) String ids) {
        Result result = new Result();
        try {
            ticketServiceExplainService.deleteByBatch(ids);
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setMessage("删除成功！");
        } catch (OkayException e) {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            result.setMessage("内部错误");
            result.setCode(TicketStatus.STATUS_ERROE);
        }
        return result;
    }


    //查询服务管理列表
    @ApiOperation(value = "查询服务管理列表")
    @PostMapping(value = "/list")
    public Result ExplainList(@RequestBody JSONObject json) {
        Result result = new Result();
        try {

            Map<String,Object> map =new HashMap<>();
            map.put("name",json.getString("name"));
            map.put("type",json.getInteger("type"));
            map.put("startTime",json.getString("startTime"));
            map.put("endTime",json.getString("endTime"));

            List<Map<String, Object>> exHashMapList = ticketServiceExplainService.getEXHashMapList(map, json.getInteger("currentPage"), json.getInteger("pageSize"));

            Integer size = 0;

            if(ticketServiceExplainService.getEXHashMapList(map)!= null){
                size=ticketServiceExplainService.getEXHashMapList(map).size();
            }

            result.setData(exHashMapList);
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setTotal(size);
            result.setMessage("成功");
        }catch(Exception e){
            e.printStackTrace();
            result.setMessage("失败");
            result.setCode(TicketStatus.STATUS_FAIL);

        }

        return result;
    }
    //根据id获取服务管理
    @ApiOperation(value = "根据id获取服务管理")
    @PostMapping(value = "/selectById")
    public Result selectById(@RequestBody JSONObject json ) {
        Result result = new Result();
        try {
            result.setData(ticketServiceExplainService.selectByPrimaryKey(json.getInteger("explainid")));
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setMessage("成功");
        }catch(Exception e){
            e.printStackTrace();
            result.setCode(TicketStatus.STATUS_FAIL);
            result.setMessage("失败");
        }
        return result;
    }

    //查询服务管理详情
    @ApiOperation(value = "查询服务管理详情")
    @GetMapping(value = "/listById")
    @ResponseBody
    public Result ExplainListById(Integer id ) {
        Result result = new Result();
        try {
            HashMap<String,Object> m = new HashMap<String,Object>();
            m.put("id",id);
            HashMap<String,Object> map=ticketServiceExplainMapper.selectExplainListById(m);
            result.setData(map);
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setMessage("成功");
        }catch(Exception e){
            e.printStackTrace();
            result.setCode(TicketStatus.STATUS_FAIL);
            result.setMessage("失败");
        }
        return result;
    }

    /**
     * 导出服务管理信息
     * @param response
     * @param map
     * @throws Exception
     */
    @ApiOperation(value = "服务管理-导出")
    @PreAuthorize("@pms.hasPermission('explain_exp')")
    @PostMapping("/explainExport")
    public void explainExport(HttpServletResponse response, @RequestBody HashMap map) throws Exception{
        ticketServiceExplainService.explainExport(response,map);
    }


}
