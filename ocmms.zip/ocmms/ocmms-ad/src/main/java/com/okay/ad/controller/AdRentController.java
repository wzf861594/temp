package com.okay.ad.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.PageQueryBean;
import com.okay.ad.common.QueryCondition;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.entity.AdRent;
import com.okay.ad.entity.Suggestion;
import com.okay.ad.exception.OkayException;
import com.okay.ad.service.AdRentService;
import com.okay.ad.utils.ImprotDownLoadUtil;
import com.okay.okay.common.log.annotation.SysLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

/**
 *Date 2018-10-15 15:15
 *@Description 寄存/租用
 */
@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "线下行为管理-租用行为")
@AllArgsConstructor
@RequestMapping("/rent")
public class AdRentController {

    private final AdRentService audienceRegisterService;

    /**
     *Date 2018-09-28 17:32
     *@Description 观众寄存列表
     *Param {"currentPage":1,"pageSize":10,"rangeDate":"2018-01-01/2018-10-10","name(观众姓名)":"asda","isReturnStatus(是否归还)":"1,是,2否","receiveStatus(领取状态)":"0未1已","registerNumber(寄存牌号)":"asdas"}
     */
    @ApiOperation(value = "观众寄存列表",httpMethod = "POST",notes = "根据各种条件查询列表数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "currentPage",value = "当前页",required = true,dataType = "int"),
            @ApiImplicitParam(name = "pageSize",value = "分页数",dataType = "int"),
            @ApiImplicitParam(name = "rangeDate",value = "起止日期2018-01-01/2018-10-10",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "name",value = "观众姓名",required = false,dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "isReturnStatus",value = "是否归还1,是,2否",dataType = "int"),
            @ApiImplicitParam(name = "receiveStatus",value = "领取状态未1已",dataType = "int"),
            @ApiImplicitParam(name = "registerNumber",value = "寄存牌号",dataType = "String",paramType = "query")

    })
    @PostMapping(value = "query")
    public Result queryAudienceRegister(@RequestBody QueryCondition condition) {
        Result resp = new Result();
        try {
            PageQueryBean pageList = audienceRegisterService.quertAudienceRegisterList(condition);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setData(pageList);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_ERROE);
            resp.setMessage("查询成功");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_ERROE);
            resp.setMessage("内部错误");
        }
        return resp;
    }

    /**
     *Date 2018-09-29 11:13
     *@Description 单条新增租用行为记录
     */
    @SysLog("观众数字化租用行为新增")
    @ApiOperation(value="单条新增租用行为记录")
    @PostMapping(value = "/addRent")
    public Result insertRent(@RequestBody JSONObject json) {
        Result resp = new Result();
        try{
            String adRentStr = JSONObject.toJSONString(json);
            AdRent adRent = JSON.parseObject(adRentStr,AdRent.class);
            audienceRegisterService.insertRent(adRent);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("保存成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage(e.getMessage());
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_ERROE);
            resp.setMessage("网络错误");
        }
        return resp;
    }
    /**
     *Date 2018-09-29 11:13
     *@Description 单条修改租用行为记录
     */
    @SysLog("观众数字化租用行为修改")
    @ApiOperation(value="单条修改租用行为记录")
    @PostMapping(value = "/updateRent")
    public Result updateRent(@RequestBody JSONObject json) {
        Result resp = new Result();
        try{
            String adRentStr = JSONObject.toJSONString(json);
            AdRent adRent = JSON.parseObject(adRentStr,AdRent.class);
            audienceRegisterService.updateRent(adRent);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("修改成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage(e.getMessage());
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_ERROE);
            resp.setMessage("网络错误");
        }
        return resp;
    }


    /**
     *Date 2018-09-29 16:44
     *@Description 单条删除
     */
    @ApiOperation(value="单条寄存删除")
    @ApiImplicitParam(name = "id" ,value = "ID",dataType = "int")
    @DeleteMapping(value = "/delete")
    public Result deleteData(@RequestParam(value = "id",required = true) Integer id) {
        Result resp = new Result();
        try {
            audienceRegisterService.deleteDatafromId(id);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("删除成功！");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage(e.getMessage());
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
    @ApiOperation(value="多条租用行为删除")
    @ApiImplicitParam(name = "ids" ,value = "ID",dataType = "int")
    @SysLog("观众数字化租用行为删除")
    @PreAuthorize("@pms.hasPermission('offline_audience_rent_del')")
    @DeleteMapping(value = "/deleteByBatch")
    public Result deleteByBatch(@RequestParam(value = "ids",required = true) String ids) {
        Result resp = new Result();
        try {
            audienceRegisterService.deleteByBatch(ids);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("删除成功！");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage(e.getMessage());
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

    /**
     * 导出租用行为信息
     * @param response
     * @param map
     * @throws Exception
     */
    @ApiOperation(value = "租用行为-导出")
    @PreAuthorize("@pms.hasPermission('rent_exp')")
    @PostMapping("/rentExport")
    public void rentExport(HttpServletResponse response, @RequestBody HashMap map) throws Exception{
        audienceRegisterService.rentExport(response,map);
    }
    /**
     *Date 2018-09-29 16:54
     *@Description 移交财务部 具体还不清楚 简单的修改了字段的值
     */
    @PostMapping(value = "/moveFinancial")
    @ApiOperation(value="isMoveFinancial",httpMethod = "POST")
    @ApiImplicitParam(name = "isMoveFinancial" ,value = "是否移交财务1是,2否",dataType = "int")
    public Result moveFinancial(@RequestBody AdRent rent) {
        Result resp = new Result();
        try {
            audienceRegisterService.moveFinancial(rent);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        }catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_FAIL);
            resp.setMessage(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
    @ApiOperation(value="单条数据查看")
    @ApiImplicitParam(name = "rentid" ,value = "ID",dataType = "int")
    @PostMapping(value = "/selectById")
    public Result selectById(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            resp.setData(audienceRegisterService.selectById(json.getInteger("rentid")));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

}
