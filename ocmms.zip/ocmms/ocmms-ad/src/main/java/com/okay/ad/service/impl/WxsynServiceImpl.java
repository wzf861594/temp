package com.okay.ad.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.WxdataSyn;
import com.okay.ad.entity.WxDatasynLog;
import com.okay.ad.mapper.WxsynMapper;
import com.okay.ad.service.WxsynService;
import com.okay.ad.task.DTO.BodyParams;
import com.okay.ad.utils.HttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.awt.font.FontRenderContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Map;

/**
 * @author tingjun
 */

@Service
public class WxsynServiceImpl implements WxsynService {
    private final Logger logger = LoggerFactory.getLogger(WxsynServiceImpl.class);
    @Autowired
    HttpClient httpClientUtil;

    @Autowired
    WxsynMapper wxsynMapper;

    @Autowired
    WxdataSyn wxdataSyn;

    @Override
    public JSONObject wxsynbydate(Map<String, String> map) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("msg", "同步完成！详情请看日志");
        long startTime = System.currentTimeMillis();
        logger.info("手动同步微信数据开始----------------");
        try {
            String type = map.get("type");
            String accessToken = httpClientUtil.httpUtil();
            String s_start_date = map.get("startDate");
            String S_endDate = map.get("endDate");
            LocalDate startDate = LocalDate.parse(s_start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalDate endDate = LocalDate.parse(S_endDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            long between = ChronoUnit.DAYS.between(startDate, endDate);
            int c = (int) (between / 6);
            int c1 = (int) (between % 6);
            if ("ALL".equals(type)) {
                //处理跨度大于7
                ry(accessToken, s_start_date, S_endDate, startDate, endDate, c, c1);
                for (int j = 0; j <= between; j++) {
                    tw(accessToken, startDate, j);
                }
            }
            if ("RY".equals(type)) {
                //处理跨度大于7
                ry(accessToken, s_start_date, S_endDate, startDate, endDate, c, c1);

            }
            if ("TW".equals(type)) {
                for (int j = 0; j <= between; j++) {
                    tw(accessToken, startDate, j);
                }
            }
            long endTime = System.currentTimeMillis();
            logger.info("手动同步微信数据结束----------------耗时：" + (endTime - startTime) + " ms");
        } catch (Exception e) {
            jsonObject.put("code", 4);
            jsonObject.put("msg", "同步error：" + e.getMessage());
            logger.error("手动同步微信数据error: " + e);
        }
        return jsonObject;
    }

    private void ry(String accessToken, String s_start_date, String s_endDate, LocalDate startDate, LocalDate endDate, int c, int c1) {
        if (c != 0) {
            for (int i = 0; i < c; i++) {
                BodyParams params = new BodyParams();
                LocalDate plusWeeks1 = startDate.plusDays(i * 6);
                LocalDate plusWeeks = plusWeeks1.plusDays(6);
                params.setBegin_date(plusWeeks1.toString());
                params.setEnd_date(plusWeeks.toString());
                wxdataSyn.getUserCumulate(accessToken, params);
                wxdataSyn.getUserSumMary(accessToken, params);
            }

            if (c1 != 0) {
                LocalDate ystartDate = endDate.minusDays(c1);
                BodyParams params = new BodyParams();
                params.setBegin_date(ystartDate.toString());
                params.setEnd_date(s_endDate);
                wxdataSyn.getUserCumulate(accessToken, params);
                wxdataSyn.getUserSumMary(accessToken, params);
            }
        } else {
            BodyParams params = new BodyParams();
            params.setBegin_date(s_start_date);
            params.setEnd_date(s_endDate);
            wxdataSyn.getUserCumulate(accessToken, params);
            wxdataSyn.getUserSumMary(accessToken, params);
        }
    }

    private void tw(String accessToken, LocalDate startDate, int j) {
        BodyParams params = new BodyParams();
        LocalDate localDate = startDate.plusDays(j);
        params.setBegin_date(localDate.toString());
        params.setEnd_date(localDate.toString());
        wxdataSyn.getArticleSummary(accessToken, params);
    }

    @Override
    public void lnsertLog(WxDatasynLog wxDatasynLog) {
        wxsynMapper.insertentity(wxDatasynLog);
    }
}