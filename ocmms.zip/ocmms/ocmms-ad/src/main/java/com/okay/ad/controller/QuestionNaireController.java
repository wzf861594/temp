package com.okay.ad.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.entity.Question;
import com.okay.ad.entity.QuestionNaire;
import com.okay.ad.entity.QuestionOption;
import com.okay.ad.exception.OkayException;
import com.okay.ad.service.IQuestionNaireService;
import com.okay.framework.entity.User;
import com.okay.framework.utils.ComUtils;
import com.okay.okay.common.log.annotation.SysLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "问卷调查")
@RequestMapping("/questionNaire")
public class QuestionNaireController {

    @Autowired
    private IQuestionNaireService questionNaireService;
    @Value("${questionAnswer.paper.url}")
    private String questionAnswerPaperURL;

    @SysLog("观众数字化问卷调查新增")
    @ApiOperation(value = "新增或编辑问卷")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "nairetitle",value = "问卷标题",dataType = "String",paramType = "body"),
            @ApiImplicitParam(name = "summary",value = "问卷内容",dataType = "String",paramType = "body"),
            @ApiImplicitParam(name="questitle" ,value="问题标题",dataType = "String",paramType = "body"),
            @ApiImplicitParam(name="pubstatus" ,value="问题描述",dataType = "String",paramType = "body"),
            @ApiImplicitParam(name="optionstitle" ,value="选项标题",dataType = "String",paramType = "body"),
            @ApiImplicitParam(name="optsummary" ,value="描述",dataType = "String",paramType = "body")
    })
    @PostMapping(value = "/addOMdifyQuestionNaire")
    public Result addomdifyquestionnaire(HttpServletRequest req, HttpServletResponse res, @RequestBody JSONObject json) {
        //获取当前用户
        User user = ComUtils.getLoginUser();
        JSONObject questionNaireObj =  json.getJSONObject("questionNaire");
        String questionNaireStr = JSONObject.toJSONString(questionNaireObj);
        QuestionNaire questionNaire = JSON.parseObject(questionNaireStr,QuestionNaire.class);
        questionNaire.setCreatuser(user.getUserId());
        JSONArray questionAry = json.getJSONArray("question");
        List<Question> questionList = new ArrayList<>();
        for(int i=0; i<questionAry.size(); i++){
            String questionStr = JSONObject.toJSONString(questionAry.get(i));
            Question question = JSON.parseObject(questionStr,Question.class);
            questionList.add(question);
        }
        Result resp = new Result();
        boolean result = true;
        try {
            if (questionNaire.getNaireid() == null || "".equals(questionNaire.getNaireid())) {
                result = questionNaireService.addQuestionNaire(questionNaire, questionList);
            }else{
                result = questionNaireService.updateQuestionNaire(questionNaire, questionList);
            }
            if(result == true) {
                resp.setCode(TicketStatus.STATUS_SUCCESS);
                resp.setMessage("成功");
                return resp;
            }else{
                resp.setCode(TicketStatus.STATUS_NEW_FAIL);
                resp.setMessage("失败");
            }
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
            resp.setMessage("系统错误");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return resp;
    }


    @ApiOperation(value = "问卷调查删除", httpMethod = "POST")
    @ApiImplicitParam(name = "naireids", dataType = "String")
    @SysLog("观众数字化问卷调查删除")
    @PreAuthorize("@pms.hasPermission('questionnaire_del')")
    @PostMapping(value = "/deleteQuestionNaire")
    public Result deleteData(@RequestBody JSONObject json) {
        Result resp = new Result();
        String naireids = json.getString("naireids");
        if (StringUtils.isBlank(naireids)) {
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
            resp.setMessage("删除失败！必要参数为空");
            return resp;
        }
        List<String> collect = Stream.of(naireids.split(",")).collect(Collectors.toList());
        for (String naireid : collect) {

            try {
                questionNaireService.deleteQuestionNaire(Integer.valueOf(naireid));
                resp.setCode(TicketStatus.STATUS_SUCCESS);
                resp.setMessage("删除成功");
            } catch (OkayException e) {
                e.printStackTrace();
                resp.setMessage("系统错误："+e.getMessage());
                resp.setCode(TicketStatus.STATUS_NEW_FAIL);
            } catch (Exception e) {
                e.printStackTrace();
                resp.setMessage("内部错误:"+e.getMessage());
                resp.setCode(TicketStatus.STATUS_NEW_FAIL);
            }
        }
        return resp;
    }

    @ApiOperation(value = "调查问卷列表",httpMethod = "POST",notes = "根据各种条件查询列表数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int",required = true),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name = "nairetitle",value = "问卷标题",dataType = "String",paramType = "query", required = false),
            @ApiImplicitParam(name="pubstatus" ,value="1-已发布  2-未发布",dataType = "Integer", required = false),
            @ApiImplicitParam(name = "questionNaireStartTime" ,value = "开始时间",dataType = "String",paramType = "query",required = false),
            @ApiImplicitParam(name = "questionNaireEndTime" ,value = "结束时间",dataType = "String",paramType = "query",required = false),
            @ApiImplicitParam(name="searchParam" ,value="关键字",dataType = "String")
    })
    @PostMapping(value = "/queryQuesNaireList")
    public Result quertQuestionNaireList(@RequestBody JSONObject json) {
       Result resp = new Result();
        try {
            Map<String, Object> aMap = new HashMap<>(8);
            aMap.put("nairetitle",json.getString("nairetitle"));
            aMap.put("pubstatus",json.getInteger("pubstatus"));
            aMap.put("questionNaireStartTime",json.getString("questionNaireStartTime"));
            aMap.put("questionNaireEndTime",json.getString("questionNaireEndTime"));
            aMap.put("searchParam",json.getString("searchParam"));
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            List<Map<String, Object>> data = questionNaireService.getHashMapList(aMap, json.getInteger("currentPage"), json.getInteger("pageSize"));
            for (Map<String, Object> map : data) {
                map.put("questionUrl", questionAnswerPaperURL);
            }
            resp.setData(data);
            resp.setTotal(questionNaireService.getCount(aMap));
        }catch (Exception ex){
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG+": "+ ex.getMessage());
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return resp;
    }


    @ApiOperation(value="修改发布状态",httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "naireid" ,value = "ID",dataType = "int"),
            @ApiImplicitParam(name = "pubstatus" ,value = "发布状态(1-已发布  2-未发布)",dataType = "int")
    })
    @PostMapping(value = "/updatePubstatus")
    public Result updatePubstatus(HttpServletRequest req, @RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            //获取当前用户
            User user = ComUtils.getLoginUser();
            QuestionNaire questionNaire = new QuestionNaire();
            questionNaire.setUpdateuser(user.getUserId());
            questionNaire.setNaireid(json.getInteger("naireid"));
            questionNaire.setPubstatus(json.getInteger("pubstatus"));
            questionNaireService.updateQuestionNaire(questionNaire);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("修改成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误: "+e.getMessage());
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误: "+e.getMessage());
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return resp;
    }

    @ApiOperation(value = "问卷调查统计")
    @ApiImplicitParam(name = "naireid", value = "ID", dataType = "int")
    @PostMapping(value = "/getQuestionList")
    public Result getQuestionList(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            // resp.setData(questionNaireService.queryNaireResultStatisical(json.getInteger("naireid")));
            List<QuestionOption> listNaire = questionNaireService.queryStatistical(json.getInteger("naireid"));
            resp.setData(listNaire);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setTotal(listNaire.size());
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误：" + e.getMessage());
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误：" + e.getMessage());
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return resp;
    }


    @ApiOperation(value="问卷调查查看")
    @ApiImplicitParam(name = "naireid" ,value = "ID",dataType = "int")
    @PostMapping(value = "/getQuestionNaire")
    public Result getQuestionNaire(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            resp.setData(questionNaireService.getQuestionNaire(json.getInteger("naireid")));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误"+e.getMessage());
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return resp;
    }

    @SysLog("观众数字化问卷调查修改")
    @ApiOperation(value = "更新问卷调查")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "nairetitle",value = "问卷标题",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "summary",value = "问卷内容",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="questitle" ,value="问题标题",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="pubstatus" ,value="问题描述",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="optionstitle" ,value="选项标题",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="summary" ,value="选项描述",dataType = "String",paramType = "query")
    })
    @PostMapping(value = "/updateQuestionNaire")
    public Result updateQuestionNaire(HttpServletRequest req, HttpServletResponse res, @RequestBody JSONObject json) {
        //获取当前用户
        User user = ComUtils.getLoginUser();
        JSONObject questionNaireObj =  json.getJSONObject("questionNaire");
        String questionNaireStr = JSONObject.toJSONString(questionNaireObj);
        QuestionNaire questionNaire = JSON.parseObject(questionNaireStr,QuestionNaire.class);
        questionNaire.setCreatuser(user.getUserId());
        JSONArray questionAry = json.getJSONArray("question");
        List<Question> questionList = new ArrayList<>();
        for(int i=0; i<questionAry.size(); i++){
            String questionStr = JSONObject.toJSONString(questionAry.get(i));
            Question question = JSON.parseObject(questionStr,Question.class);
            questionList.add(question);
        }
        Result resp = new Result();
        try {
            questionNaireService.updateQuestionNaire(questionNaire, questionList);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("更新成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
            resp.setMessage("系统错误："+e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return resp;
    }
    /**
     *Date 2018-10-10 15:20
     *@Description 导出问卷调查
     *Param {"ids":[123,212]}
     */
   /* @ApiOperation(value = "导出问卷调查",httpMethod = "POST")
    @ApiImplicitParam(name="ids" ,value="{\"ids\":[123,212]}",dataType = "String",paramType = "query")
    @RequestMapping(value = "/outPutQuestionNaire",method = RequestMethod.POST)
    public Result outPutQuestionNaire(@RequestBody String ids, HttpServletRequest request,
                                      HttpServletResponse response) {
        Result resp = new Result();
        try {
            JSONObject jsonObject = JSONObject.parseObject(ids);
            JSONArray jsonList = jsonObject.getJSONArray("ids");
            List<Integer> idsList  = JSONObject.parseArray(jsonList.toJSONString(), Integer.class);
            HashMap map = questionService.queryQuestionListForIds(idsList);
            List<QuestionNaire> list = (List<QuestionNaire>) map.get("dataList");
            String tableName = "asdasd.xls";
            if(list.size()>0) {
                ImprotDownLoadUtil.TemplateoutputQuestionNaire(tableName,map,request,response);
            } else {
                resp.setMessage("没有找到ID的信息或没有得到ID,请检查");
            }

        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_FAIL);
            resp.setMessage(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage(e.getMessage());
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
*/
}
