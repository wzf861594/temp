package com.okay.ad.mapper;

public interface AdgeneralqueryMapper{

    int  getPassengerflowinrealtime(int i);

    int  getpassengerflowinrealtimeCg(int i);
}