package com.okay.ad.service;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用  service
 *
 * @author zengxiaoquan
 */
public interface ADMSStatisticalService {


    /**
     * 馆内实时流量导出
     */
    void exportPassengerFlow(HttpServletResponse response, HashMap map) throws Exception;

    /**
     * 观众类型到访导出
     */
    void exportAudienceType(HttpServletResponse response, HashMap map) throws Exception;


    /**
     * 观众到访导出
     *
     * @param object
     * @return
     */
    void export(HttpServletResponse response, HashMap object) throws Exception;

    /**
     * 到访观众分析
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getListAudiencevisit(HashMap map);

    /**
     * 到访观众类型统计
     *
     * @param map
     * @return
     */
    Map<String, Object> getListAudienceTypeVisit(HashMap map);


}




