package com.okay.ad.utils;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class TicketDataUtil {

    public static List<Map<String, Object>> encryption(List<Map<String, Object>> data){

        List<Map<String, Object>> orderListMap = new ArrayList<Map<String, Object>>();

        if(data != null && !data.isEmpty()) {
            for(int i=0;i<data.size();i++) {
                Map<String, Object> orderDetailed = data.get(i);
                String phone = orderDetailed.get("phoneno").toString();
                if(""!=phone||null!=phone) {
                    orderDetailed.put("phoneno", phone.substring(0, 3)+"****"+phone.substring(7, phone.length()));
                }
                String papersno = orderDetailed.get("papersno").toString();
                switch(papersno.length()){
                    //身份证或驾驶证
                    case 18:
                        papersno = papersno.substring(0, 6)+"********"+papersno.substring(14, papersno.length());
                        orderDetailed.put("papersno", papersno);
                        break;
                    //军官证或8位护照
                    case 8:
                        papersno = papersno.substring(0,3)+"**"+papersno.substring(6, papersno.length());
                        orderDetailed.put("papersno", papersno);
                        break;
                    //7位护照
                    case 7:
                        papersno = papersno.substring(0,3)+"**"+papersno.substring(6,papersno.length());
                        orderDetailed.put("papersno", papersno);
                        break;
                }
                orderListMap.add(i,orderDetailed);
            }
            return orderListMap;
        }else {
            return null;
        }
    }
}
