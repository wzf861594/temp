package com.okay.ad.entity;

import com.okay.ad.annotation.Table;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.Date;

// 累计用户数据
@Data
@Table(value = "wx_usercumulate")
@ApiModel(value = "累计用户数据")
public class WxUserCumulate {

    private int id;
    // 日期
    private String refDate;
    // 总用户量
    private int cumulateUser;
    // 总用户量
    private Date createdate;

}
