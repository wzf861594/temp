package com.okay.ad.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.PageQueryBean;
import com.okay.ad.common.QueryCondition;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.entity.QuestionNaire;
import com.okay.ad.entity.QuestionOption;
import com.okay.ad.exception.OkayException;
import com.okay.ad.service.QuestionService;
import com.okay.ad.utils.ImprotDownLoadUtil;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;

@CrossOrigin(allowCredentials ="true")
@RestController
@RequestMapping("/adms/question")
public class QuestionController {


    @Autowired
    private QuestionService questionService;

    /**
     *@Description 调查问卷列表
     * Param {"questionNaire": {"nairetitle": "好改好", "currentPage": 0,"pageSize": 0,"pubstatus": 0}}
     *
     */
    @ApiOperation(value = "调查问卷列表",httpMethod = "POST",notes = "根据各种条件查询列表数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="当前页",dataType = "int",required = true),
            @ApiImplicitParam(name="pageSize" ,value="分页数",dataType = "int"),
            @ApiImplicitParam(name = "rangeDate",value = "起止日期2018-01-01/2018-10-10",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "nairetitle",value = "问卷标题",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="TicketPlatform" ,value="观众来源1微信2官网3一体机",dataType = "int"),
            @ApiImplicitParam(name="questionStatus" ,value="1-已发布  2-未发布",dataType = "int"),
    })
    @RequestMapping(value = "/queryQuestionList",method = {RequestMethod.POST})
    public Result quertQuestionList(@RequestBody QueryCondition condition) {
        Result resp = new Result();
        try {
            PageQueryBean pageQueryBean = questionService.queryQuestionList(condition);
            resp.setData(pageQueryBean);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_FAIL);
            resp.setMessage("系统错误");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
    /**
     *Date 2018-10-10 14:11
     *@Description 新增问卷
     * Param {"naireStartTime":"2018-10-11","naireEndTime":"2018-10-12","bigTitle":"asdasd",
     *       "questionList":[{"title":"asda","option":["选项1","选项2"]},{"title":"dierge","option":["选项1","选项2"]},{"title":"disange","option":["选项1","选项2"]}]}
     */
    @ApiOperation(value = "新增问卷",httpMethod = "POST",notes = "根据各种条件查询列表数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name="naireStartTime" ,value="问卷开始时间",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="naireEndTime" ,value="问卷结束时间",dataType = "Stirng",paramType = "query"),
            @ApiImplicitParam(name = "bigTitle",value = "问卷标题",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "questionList",value = "问卷标题",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="TicketPlatform" ,value="观众来源1微信2官网3一体机",dataType = "int"),
            @ApiImplicitParam(name="questionStatus" ,value="[{\"title\":\"asda\",\"option\":[\"选项1\",\"选项2\"]},{\"title\":\"dierge\",\"option\":[\"选项1\",\"选项2\"]}",dataType = "String",paramType = "query")
    })
    @RequestMapping(value = "/insertQuestion",method = {RequestMethod.POST})
    public Result InsertQuestion(HttpServletRequest req, HttpServletResponse res, @RequestBody String obj) {
        Result resp = new Result();
        try {
            int i = questionService.addQuestion(obj);
            resp.setMessage("插入成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_FAIL);
            resp.setMessage("系统错误");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }


    /**
     *Date 2018-10-10 15:20
     *@Description 导出问卷调查
     *Param {"ids":[123,212]}
     */
    @ApiOperation(value = "导出问卷调查",httpMethod = "POST")
    @ApiImplicitParam(name="ids" ,value="{\"ids\":[123,212]}",dataType = "String",paramType = "query")
    @RequestMapping(value = "/outPutQuestionNaire",method = RequestMethod.POST)
    public Result outPutQuestionNaire(@RequestBody String ids, HttpServletRequest request,
                                      HttpServletResponse response) {
        Result resp = new Result();
        try {
            JSONObject jsonObject = JSONObject.parseObject(ids);
            JSONArray jsonList = jsonObject.getJSONArray("ids");
            List<Integer> idsList  = JSONObject.parseArray(jsonList.toJSONString(), Integer.class);
            HashMap map = questionService.queryQuestionListForIds(idsList);
            List<QuestionNaire> list = (List<QuestionNaire>) map.get("dataList");
            String tableName = "asdasd.xls";
            if(list.size()>0) {
                ImprotDownLoadUtil.TemplateoutputQuestionNaire(tableName,map,request,response);
            } else {
                resp.setMessage("没有找到ID的信息或没有得到ID,请检查");
            }

        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_FAIL);
            resp.setMessage("系统错误");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }


    /**
     *Date 2018-10-11 16:21
     *@Description 问卷调查统计
     *Param {"ids":问卷的ID}
     */
    @ApiOperation(value = "问卷调查统计",httpMethod = "POST")
    @ApiImplicitParam(name="ids" ,value="{\"ids\":问卷的ID}",dataType = "String",paramType = "query")
    @RequestMapping(value = "/questionStatistical",method = RequestMethod.POST)
    public Result questionStatistical(@RequestBody String ids) {
        Result resp = new Result();
        try {
            List<QuestionOption> list = questionService.queryStatistical(ids);
            resp.setData(list);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_ERROE);
            resp.setMessage("系统错误");
        }
        return resp;
    }
}
