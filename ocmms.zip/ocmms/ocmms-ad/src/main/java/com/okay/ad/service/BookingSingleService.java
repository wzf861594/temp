package com.okay.ad.service;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.entity.BookingSingle;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @auther: xiazhili
 * @date: 2020-08-27 10:31
 */
public interface BookingSingleService {
    //根据id获取数据
    BookingSingle findById(String singleId);

    //根据条件获取个人档案信息列表
    List<BookingSingle> selectInfo(Map<String, Object> aMap);

    //根据条件获取个人档案信息列表总数
    int selectInfoCount(Map<String, Object> aMap);

    //获取个人门票预约列表
    List<BookingSingle> getTicketList(Map<String, Object> aMap);

    //根据个人门票预约列表总数
    int getTicketListCount(Map<String, Object> aMap);

    //获取活动讲座预约列表
    List<BookingSingle> getActTicketList(Map<String, Object> aMap);

    //根据活动讲座预约列表总数
    int getActTicketListCount(Map<String, Object> aMap);

    void personExport(HttpServletResponse response, HashMap object)throws Exception;

    void teamExport(HttpServletResponse response, HashMap object)throws Exception ;

    void actExport(HttpServletResponse response, HashMap object)throws Exception ;
}
