package com.okay.ad.service.impl;

import java.util.List;

import com.okay.ad.entity.AdmsTrafficstatisticsMonth;
import com.okay.ad.mapper.AdmsTrafficstatisticsMonthMapper;
import com.okay.ad.service.IAdmsTrafficstatisticsMonthService;

import org.springframework.stereotype.Service;


import javax.annotation.Resource;

/**
* 通用  serviceimpl
*
* @author  zengxiaoquan
*/
@Service(value = "aAdmsTrafficstatisticsMonthServiceImpl")
public  class AdmsTrafficstatisticsMonthServiceImpl implements IAdmsTrafficstatisticsMonthService {

	@Resource
    private AdmsTrafficstatisticsMonthMapper aAdmsTrafficstatisticsMonthMapper;

    @Override
    public List<AdmsTrafficstatisticsMonth> getAllData() {
        return aAdmsTrafficstatisticsMonthMapper.getAllData();
    }

	 

}




