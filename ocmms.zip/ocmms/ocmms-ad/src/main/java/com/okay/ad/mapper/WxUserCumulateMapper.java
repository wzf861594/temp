package com.okay.ad.mapper;

import com.okay.ad.entity.WxUserCumulate;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface WxUserCumulateMapper {

    @Select("select count(1) from wx_usercumulate where ref_date = #{ref_date}")
    int selectUserCumulate(@Param("ref_date") String ref_date);

    @Insert("insert into wx_usercumulate(ref_date,cumulate_user) values(#{wxUserCumulate.refDate},#{wxUserCumulate.cumulateUser})")
    void insertUserCumulate(@Param("wxUserCumulate") WxUserCumulate wxUserCumulate);

}
