package com.okay.ad.service;

import java.util.List;
import java.util.Map;
import com.okay.ad.entity.AdmsPeopledatatrend;

/**
* 通用  service
*
* @author zengxiaoquan
*/
public interface IAdmsPeopledatatrendService {

    /**
     * 获取全部数据
     * @return int
     */
    List<AdmsPeopledatatrend> getAllData();


    /**
     * 获取全部数据_返回map集合
     *
     */
    List<Map> getmapData();


}




