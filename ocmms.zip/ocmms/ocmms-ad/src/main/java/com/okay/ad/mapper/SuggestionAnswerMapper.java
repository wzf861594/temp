package com.okay.ad.mapper;

import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.SuggestionAnswer;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SuggestionAnswerMapper {

    int insert(SuggestionAnswer record);

    int updateByPrimaryKey(SuggestionAnswer record);

    int selectAnswerCountByCondition(QueryCondition condition);

    List<SuggestionAnswer> selectListByCondition(QueryCondition condition);

    /**
     * 单条数据查看
     * @param recid
     * @return
     */
    SuggestionAnswer selectByPrimaryKey(Integer recid);

    /**
     * 单条数据的增加
     * @param record
     * @return
     */
    int insertSelective(SuggestionAnswer record);

    /**
     * 单条数据的删除
     * @param recid
     * @return
     */
    int deleteByPrimaryKey(Integer recid);

    int deleteByBatch(@Param(value = "ids") List<String> ids);

    /**
     * 单条数据的修改
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(SuggestionAnswer record);

    /**
     * 批量查询
     * @param aMap
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap);


    /**
     * 根据条件获取数据总量
     * @param aMap
     * @return int
     */
    int getCount(Map<String, Object> aMap);

}