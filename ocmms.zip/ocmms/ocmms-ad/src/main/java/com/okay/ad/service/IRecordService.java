package com.okay.ad.service;



import com.okay.ad.entity.Record;

import java.util.List;


public interface IRecordService {

    /**
     * 问卷调查填写录入
     * @param recordList
     * @return
     */
    int addRecord(List<Record> recordList);

}
