package com.okay.ad.mapper;

import com.okay.ad.entity.Question;

import java.util.List;
import java.util.Map;

public interface QuestionMapper {
    int deleteByPrimaryKey(Integer quesid);

    int insert(Question record);

    int insertSelective(Question record);

    Question selectByPrimaryKey(Integer quesid);

    int updateByPrimaryKeySelective(Question record);

    int updateByPrimaryKeyWithBLOBs(Question record);

    int updateByPrimaryKey(Question record);

    List<Question> selectByNaireId(int id);

    /**
     * 根据所属问卷调查删除问题
     * @param naireid
     * @return
     */
    int deleteByNaireId(int naireid);

    /**
     * 根据所属问卷调查的id获取问题(以Map形式返回)
     * @param naireid
     * @return
     */
    List<Map<String, Object>>  selectMapByNaireId(int naireid);

    /**
     *  根据所属问卷调查的id获取问题和答案
     */
    List<Map<String,Object>> selectQuestionResultByQuesId(int naireid);
}