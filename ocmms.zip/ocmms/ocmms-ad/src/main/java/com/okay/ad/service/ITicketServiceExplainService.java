package com.okay.ad.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.okay.ad.entity.Explain;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 通用  service
 *
 * @author zengxiaoquan
 */
public interface ITicketServiceExplainService {


    /**
     * 根据条件获取数据总量
     * @param aMap
     * @return int
     */
    int getCount(Map<String, Object> aMap);
    /**
     * 批量查询
     * @param aMap
     * @return List<TicketServiceExplain>
     */
    List<Explain> getEntityList(Map<String, Object> aMap);

    /**
     * 批量查询 分页
     * @param aMap
     * @param pageNum 页码
     * @param pageSize 分页大小
     * @return List<TicketServiceExplain>
     */
    List<Explain> getEntityList(Map<String, Object> aMap, int pageNum, int pageSize);

    /**
     * 单条查询
     * @param aKey
     * @return TicketServiceExplain
     */
    Explain getEntityByPrimaryKey(String aKey);



    /**
     * 批量查询
     * @param aMap
     * @return  List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap);

    /**
     * 批量查询 分页
     * @param aMap
     * @param pageNum 页码
     * @param pageSize 分页大小
     * @return  List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize);

    /**
     * 单条查询
     * @param aKey
     * @return HashMap
     */
    HashMap getHashMapByPrimaryKey(String aKey);

    /**
     * 添加
     * @param aTicketServiceExplain
     * @return boolean
     */
    public boolean addEntity(Explain aTicketServiceExplain);

    /**
     * 更新
     * @param aTicketServiceExplain
     * @return boolean
     */
    public boolean updateEntity(Explain aTicketServiceExplain);

    /**
     * 物理删除
     * @param  aKey
     * @return boolean
     */
    public boolean deleteEntity(String aKey);
    /**
     * 通用批量添加
     *
     * @param sqlId
     * @param data
     * @return
     */
    public boolean batchAddEntitys(String sqlId, List data);

    void deleteByBatch(String ids);

    //  自己写的
    /**
     * 批量查询
     * @param aMap
     * @return  List<Map<String, Object>>
     */
    List<Map<String, Object>> getEXHashMapList(Map<String, Object> aMap, int pageNum, int pageSize);

    /**
     * 批量查询
     * @param aMap
     * @return  List<Map<String, Object>>
     */
    List<Map<String, Object>> getEXHashMapList(Map<String, Object> aMap);

    /**
     * 下载模板
     * @return  List<Map<String, Object>>
     */
    void downLoadExplainExcel(HttpServletRequest request, HttpServletResponse response, Integer type, List<Map<String, Object>> list) throws IOException;
    /**
     * 导入数据
     * @return  List<Map<String, Object>>
     */
    List<Map<String,Object>> explainUpload(MultipartFile file, HttpServletRequest request, Integer type) throws IOException;
    /**
     * 导入数据
     * @return  List<Map<String, Object>>
     */
    void outPutAllExplain(List<Map<String, Object>> lists, String tableName, HttpServletRequest request, HttpServletResponse response, Integer type
            , List<Map<String, Object>> listDate) throws IOException;


    Explain selectByPrimaryKey(Integer explainid);

    void explainExport(HttpServletResponse response, HashMap object)throws Exception;
}




