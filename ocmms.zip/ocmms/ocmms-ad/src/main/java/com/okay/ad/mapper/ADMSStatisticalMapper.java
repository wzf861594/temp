package com.okay.ad.mapper;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用 Mapper
 */
public interface ADMSStatisticalMapper {


    /**
     * 馆内实时流浪导出
     */
    List<Map<String, Object>> getPassengerflowinrealtime(HashMap map);

    /**
     * 团体导出
     */
    List<Map<String, Object>> exportListOrganizationVisit(HashMap map);

    /**
     * 成人与儿童票导出
     */
    List<Map<String, Object>> exportListAudiencePersonAndChildrensVisit(HashMap map);

    /**
     * 到访观众分析导出
     */
    List<Map<String, Object>> exportListAudiencevisit(HashMap map);


    /**
     * 到访观众分析
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getListAudiencevisit(HashMap map);

    /**
     * 成人与儿童统计
     *
     * @param map
     * @return
     */
    Map<String, Object> getListAudiencePersonAndChildrensVisit(HashMap map);

    /**
     * 团票统计
     *
     * @param map
     * @return
     */
    Map<String, Object> getListOrganizationVisit(HashMap map);
}




