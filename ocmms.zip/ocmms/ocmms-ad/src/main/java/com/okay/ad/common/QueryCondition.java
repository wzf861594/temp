package com.okay.ad.common;

import lombok.Data;

@Data
public class QueryCondition extends PageQueryBean {
    //观众姓名
    private String name;

    //归还状态
    private Integer isReturnStatus;


    //领取状态
    private Integer receiveStatus;

    //寄存牌号
    private String registerNumber;

    /**租用日期时间段 /号分割**/
    private String rangeDate;

    private String startDate;

    private String endDate;

    /**观众信息**/
    private String audienceMessage;

    /**手机号**/
    private String phoneNum;

    /**证件号**/
    private String cardNo;

    /**观众来源**/
    private int TicketPlatform;

    /**票种类别**/
    private int tid;

    /**观众类别 0否 1是**/
    private int isTeam;

    /**展览名称**/
    private String specialName;

    /**id集合**/
    private String ids;

     /**类型**/
    private int productType;

     /**调查报告大标题**/
    private String nairetitle;

     /**调查报告内容描述**/
    private String summary;

     /**调查报告问题标题**/
    private String questionName;

     /**问题标题选项**/
    private String option;

     /**调查问卷状态**/
    private int questionStatus;

     /**创建人**/
    private String createMan;

     /***更新人**/
     private String updateMan;

     /**意见来源**/
    private int suggestionResource;

     /**意见类型**/
    private int suggestionType;

     /**状态**/
     private int status;

    private int isReturnDeposit;

}
