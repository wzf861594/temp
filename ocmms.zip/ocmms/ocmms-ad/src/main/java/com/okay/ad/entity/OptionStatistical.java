package com.okay.ad.entity;

import lombok.Data;

@Data
public class OptionStatistical {

    private String optionName;

    private int count;

    private String percentage;
}
