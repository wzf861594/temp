package com.okay.ad.mapper;

import java.util.List;
import java.util.Map;

/**
* 通用 Mapper
*
* @author  zengxiaoquan
*/
public interface AdmsActivitylistMapper {

    /**
     * 统计现场活动意见
     * @return HashMap
     */
    List<Map<Object,Object>> suggestionStatisticsList(Map<String, Object> map);
}




