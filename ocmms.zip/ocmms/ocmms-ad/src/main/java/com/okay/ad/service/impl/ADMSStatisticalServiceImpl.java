package com.okay.ad.service.impl;

import com.google.common.base.Stopwatch;
import com.okay.ad.mapper.ADMSStatisticalMapper;
import com.okay.ad.service.ADMSStatisticalService;
import org.apache.poi.hpsf.DocumentSummaryInformation;
import org.apache.poi.hpsf.SummaryInformation;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 */
@Service(value = "admsStatisticalServiceImpl")
public class ADMSStatisticalServiceImpl implements ADMSStatisticalService {

    private static final Logger log = LoggerFactory.getLogger(ADMSStatisticalServiceImpl.class);

    @Autowired(required = false)
    private ADMSStatisticalMapper aADMSStatisticalMapper;

    @Autowired
    private AdgeneralqueryImpl adgeneralquery;


    @Override
    public void exportPassengerFlow(HttpServletResponse response, HashMap map) throws Exception {
        String fileName = "馆内客流实时统计"+ LocalDate.now()+"_"+  LocalTime.now().getHour()+"时";
        String tielie = "馆内客流实时统计(" + LocalDate.now() + ")";
        //标题内容a
        List<String> titleCol = new ArrayList<>();
        titleCol.add("时间点");
        titleCol.add("实时人流");
        // for (int i = 9; i < 18; i++) {
        //     titleCol.add("" + i + "点统计客流数");
        // }
        List<Map<String, Object>> passengerflowinrealtime = adgeneralquery.getPassengerflowinrealtime();
        List<String> datavalu = new ArrayList<>();
        // for (int i = 9; i < 18; i++) {
        //     datavalu.add("" + i + "");
        // }
        datavalu.add("x");
        datavalu.add("y");
        export(response, fileName, tielie, titleCol, passengerflowinrealtime, datavalu);
    }

    @Override
    public void exportAudienceType(HttpServletResponse response, HashMap map) throws Exception {
        Stopwatch stopwatch = Stopwatch.createStarted();
        List<Map<String, Object>> mapList1 = aADMSStatisticalMapper.exportListOrganizationVisit(map);
        List<Map<String, Object>> mapList2 = aADMSStatisticalMapper.exportListAudiencePersonAndChildrensVisit(map);
        mapList1.addAll(mapList2);
        //合并2个集合
        Set<String> set = new HashSet<>();
        List<Map<String, Object>> orderdate = mapList1.stream()
                .collect(Collectors.groupingBy(o -> {
                    //暂存所有key
                    set.addAll(o.keySet());
                    return o.get("orderdate");
                })).entrySet().stream().map(o -> {
                    //合并
                    Map<String, Object> mapALL = o.getValue().stream().flatMap(m -> {
                        return m.entrySet().stream();
                    }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> b));
                    //为没有的key赋值0
                    set.stream().forEach(k -> {
                        if (!mapALL.containsKey(k)) mapALL.put(k, 0);
                    });

                    return mapALL;
                }).collect(Collectors.toList());

        String tielie = "观众类型到访统计(" + map.get("beginDate") + ")至(" + map.get("endDate") + ")";
        //标题内容a
        List<String> titleCol = new ArrayList<>();
        titleCol.add("日期");
        titleCol.add("儿童统计数量");
        titleCol.add("成人统计数量");
        titleCol.add("团体统计数量");
        String fileName = "观众类型到访统计表";
        List<String> datavalu = new ArrayList<>();
        datavalu.add("orderdate");
        datavalu.add("childrens");
        datavalu.add("person");
        datavalu.add("organization");
        export(response, fileName, tielie, titleCol, orderdate, datavalu);
        stopwatch.stop();
        log.info("观众数字化 导出 观众到访类型统计 耗时：" + stopwatch.toString());
    }

    @Override
    public List<Map<String, Object>> getListAudiencevisit(HashMap map) {
        return aADMSStatisticalMapper.getListAudiencevisit(map);
    }

    @Override
    public Map<String, Object> getListAudienceTypeVisit(HashMap map) {
        Map<String, Object> personAndchildrens = aADMSStatisticalMapper.getListAudiencePersonAndChildrensVisit(map);
        Map<String, Object> organization = aADMSStatisticalMapper.getListOrganizationVisit(map);
        Map<String, Object> audienceType = new HashMap<>();
        audienceType.putAll(personAndchildrens);
        audienceType.putAll(organization);
        return audienceType;
    }

    @Override
    public void export(HttpServletResponse response, HashMap object) throws Exception {
        Stopwatch stopwatch = Stopwatch.createStarted();
        List<Map<String, Object>> listAudiencevisit = aADMSStatisticalMapper.exportListAudiencevisit(object);
        //处理导出

        HSSFWorkbook sheets = new HSSFWorkbook();
        HSSFSheet sheet = sheets.createSheet("数据导出");

        String tielie = "观众到访统计(" + object.get("beginDate") + ")至(" + object.get("endDate") + ")";
        //标题内容a
        List<String> titleCol = new ArrayList<>();
        titleCol.add("日期");
        titleCol.add("统计数量");
        List<String> datavalu = new ArrayList<>();
        datavalu.add("orderdate");
        datavalu.add("acount");
        String fileName = "观众到访统计表";
        export(response, fileName, tielie, titleCol, listAudiencevisit, datavalu);
        stopwatch.stop();
        log.info("观众数字化 导出 观众到访统计 耗时：" + stopwatch.toString());

    }

    //观众数字化 导出excel 模板
    private void export(HttpServletResponse response, String filename, String title, List<String> titleCol, List<Map<String, Object>> datas, List<String> datavalues) throws Exception {
        HSSFWorkbook sheets = new HSSFWorkbook();
        HSSFSheet sheet = sheets.createSheet("数据导出");

        int n = titleCol.size();
        //全局统一字体
        String fontCNType = "宋体";
        //设置n列，各自的列宽 = 3000毫米
        int width = 5000;
        int widthTitle = 8000;
        int height = 2500;
        for (int i = 0; i < n; i++) {
            if (i == 0) {
                sheet.setColumnWidth(i, widthTitle);
            } else {
                sheet.setColumnWidth(i, width);
            }
        }
        //标题行样式
        sheet.createFreezePane(0, 2, 0, 2);
        CellStyle titleCellStyle = sheets.createCellStyle();
        titleCellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
        titleCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        CellRangeAddress range = new CellRangeAddress(0, 0, 0, (n - 1));
        sheet.addMergedRegion(range);
        Font font = sheets.createFont();
        font.setFontName(fontCNType);
        font.setBold(true);
        font.setFontHeightInPoints((short) 10);
        titleCellStyle.setFont(font);
        //标题
        HSSFRow row = sheet.createRow(0);
        HSSFCell titleCell = row.createCell(0);
        titleCell.setCellStyle(titleCellStyle);
        titleCell.setCellValue(title);
        row.setHeight((short) 800);

        //head样式
        CellStyle headCellStyle = sheets.createCellStyle();
        Font headFont = sheets.createFont();
        headCellStyle.setAlignment(HorizontalAlignment.CENTER);
        headCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        headFont.setBold(true);
        headCellStyle.setFont(headFont);

        //data 样式
        CellStyle dataStyle = sheets.createCellStyle();
        dataStyle.setAlignment(HorizontalAlignment.CENTER);
        dataStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        //头行
        HSSFRow rowHead2 = sheet.createRow(1);
        rowHead2.setHeight((short) 500);
        for (int d = 0; d < titleCol.size(); d++) {
            HSSFCell datecell = rowHead2.createCell(d);
            datecell.setCellStyle(headCellStyle);
            datecell.setCellValue(titleCol.get(d));
        }
        //数据行
        int i = 2;
        for (int data = 0; data < datas.size(); data++) {
            HSSFRow dataRow = sheet.createRow(i);
            for (int dataL = 0; dataL < n; dataL++) {
                HSSFCell datecell = dataRow.createCell(dataL);
                datecell.setCellStyle(dataStyle);
                datecell.setCellValue(Objects.toString(datas.get(data).get(datavalues.get(dataL)), "0"));
            }
            i++;
        }
        response.reset();
        response.setContentType("application/x-download");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(filename, "UTF-8") + ".xls");
        response.addHeader("filename", URLEncoder.encode(filename, "UTF-8") + ".xls");
        sheets.write(response.getOutputStream());

    }
}




