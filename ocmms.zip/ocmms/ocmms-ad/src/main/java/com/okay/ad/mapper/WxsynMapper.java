package com.okay.ad.mapper;

import com.okay.ad.entity.WxDatasynLog;

/**
 * @author tingjun
 */

public interface WxsynMapper {

    void insertentity(WxDatasynLog wxDatasynLog);
}
