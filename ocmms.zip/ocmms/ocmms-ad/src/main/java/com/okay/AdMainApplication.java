package com.okay;

import com.okay.okay.common.feign.annotation.EnableOkayFeignClients;
import com.okay.okay.common.security.annotation.EnableOkayResourceServer;
import com.okay.okay.common.swagger.annotation.EnableOkaySwagger2;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author ZHU.HQ
 * @date 2020/7/29 10:42
 */
@MapperScan("com.okay.**.mapper")
@EnableOkaySwagger2
@SpringCloudApplication
@EnableOkayFeignClients
@EnableFeignClients
@EnableOkayResourceServer
public class AdMainApplication {
    public static void main(String[] args) {
        SpringApplication.run(AdMainApplication.class, args);
    }
}
