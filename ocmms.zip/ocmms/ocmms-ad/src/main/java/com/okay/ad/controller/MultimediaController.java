package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.mapper.MultimediaMapper;
import com.okay.ad.service.BaseServiceClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


//多媒体
@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "多媒体分析")
@RequestMapping("/adms/multimediaAnalysis")
public class MultimediaController {


    @Autowired(required = false)
    private MultimediaMapper multimediaMapper;

    @Autowired
    private BaseServiceClient aBaseServiceClient;

    // 用户关注数量
    @ApiOperation(value = "用户关注数量")
    @RequestMapping(value = "/queryUserCumulate", method = {RequestMethod.GET})
    @ResponseBody
    public Result queryUserCumulate(@RequestParam(value="type",required = true,defaultValue = "week")String type , @RequestParam(value="time",required = true)String time) {
        Result result =new Result();
        try {
            switch (type) {
                case "week":
                    HashMap<String, Object> weekmap =new HashMap<>();
                    weekmap.put("time",time);
                    List<Map<String, Object>> week = multimediaMapper.userCumulateWeek(weekmap);
                    result.setData(week);
                    result.setTotal(week.size());
                    break;
                case "month":
                    HashMap<String,Object> monthmap = new HashMap<>();
                    monthmap.put("time",time);
                    List<Map<String, Object>> month = multimediaMapper.userCumulateMonth(monthmap);
                    result.setData(month);
                    result.setTotal(month.size());
                    break;
                case "year":
                    HashMap<String, Object> yearmap =new HashMap<>();
                    yearmap.put("time",time);
                    List<Map<String, Object>> year = multimediaMapper.userCumulateYear(yearmap);
                    result.setData(year);
                    result.setTotal(year.size());
                    break;
                default:
                    result.setCode(TicketStatus.STATUS_NEW_FAIL);
                    return result;

            }
            result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            result.setCode(TicketStatus.STATUS_SUCCESS);
        }catch(Exception e){
            e.printStackTrace();
            result.setMessage("失败："+e.getMessage());
            result.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return result;
    }

    // 新增用户关注
    @ApiOperation(value = "新增用户关注")
    @RequestMapping(value = "/queryUserSummary", method = {RequestMethod.GET})
    @ResponseBody
    public Result queryUserSummary(@RequestParam(value="type",required=true, defaultValue = "week")String type , @RequestParam(value="time",required = true)String time) {
        Result result =new Result();
        try {
            // 1 是周 2 月 3 年
            switch (type) {
                case "week":
                    HashMap<String,Object> weekmap = new HashMap<>();
                    weekmap.put("time",time);
                    List<Map<String, Object>> week = multimediaMapper.userSummaryWeek(weekmap);
                    result.setData(week);
                    result.setTotal(week.size());
                    break;
                case "month":
                    HashMap<String,Object> monthmap = new HashMap<>();
                    monthmap.put("time",time);
                    List<Map<String, Object>> month = multimediaMapper.userSummaryMonth(monthmap);
                    result.setData(month);
                    result.setTotal(month.size());
                    break;
                case "year":
                    HashMap<String,Object> yearmap = new HashMap<>();
                    yearmap.put("time",time);
                    List<Map<String, Object>> year = multimediaMapper.userSummaryYear(yearmap);
                    result.setData(year);
                    result.setTotal(year.size());
                    break;
                default:
                    result.setCode(TicketStatus.STATUS_NEW_FAIL);
                    return result;
            }
            result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            result.setCode(TicketStatus.STATUS_SUCCESS);
        }catch(Exception e){
            e.printStackTrace();
            result.setMessage("失败："+e.getMessage());
            result.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return result;
    }

    // 文章热度
    @ApiOperation(value = "文章热度")
    @RequestMapping(value = "/selectArticleHot", method = {RequestMethod.GET})
    @ResponseBody
    public Result selectArticleHot(@RequestParam(value="type",required = true, defaultValue = "week")String type , @RequestParam(value="time",required = true)String time) {
        Result result =new Result();
        try {
            // 1 是周 2 月 3 年
            switch (type) {
                case "week":
                    HashMap<String,Object> weekmap = new HashMap<>();
                    weekmap.put("time",time);
                    List<Map<String, Object>> week = multimediaMapper.articleHotWeek(weekmap);
                    result.setData(week);
                    result.setTotal(week.size());
                    break;
                case "month":
                    HashMap<String,Object> monthmap = new HashMap<>();
                    monthmap.put("time",time);
                    List<Map<String, Object>> month = multimediaMapper.articleHotMonth(monthmap);
                    result.setData(month);
                    result.setTotal(month.size());
                    break;
                case "year":
                    HashMap<String,Object> yearmap = new HashMap<>();
                    yearmap.put("time",time);
                    List<Map<String, Object>> year = multimediaMapper.articleHotYear(yearmap);
                    result.setData(year);
                    result.setTotal(year.size());
                    break;
                default:
                    result.setCode(TicketStatus.STATUS_NEW_FAIL);
                    return result;
            }
            result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            result.setCode(TicketStatus.STATUS_SUCCESS);
        }catch(Exception e){
            e.printStackTrace();
            result.setMessage("失败："+e.getMessage());
            result.setCode(TicketStatus.STATUS_NEW_FAIL);
        }
        return result;
    }



    //统计多媒体分析微信用户增长数
    @ApiOperation(value = "统计多媒体分析微信用户增长数", notes = "addNewUser")
    @RequestMapping(value = "/selectAddNewUser", method = {RequestMethod.GET})
    @ResponseBody
    public JSONObject selectAddNewUser(@RequestParam(value="type",required = true)Integer type , @RequestParam(value="time",required = false)String time) {

        JSONObject aJSONObject = new JSONObject();
        try {
            // 1 是周 2 月  3 年
            switch (type) {
                case 1:
                    List<Map<String, Object>> week = multimediaMapper.selectweek();
                    aJSONObject.put("data", week);
                    break;
                case 2:
                    HashMap<String,Object> map = new HashMap<>();
                    map.put("time",time);
                    List<Map<String, Object>> month = multimediaMapper.selectmonth(map);
                    aJSONObject.put("data", month);
                    break;
                case 3:
                    List<Map<String, Object>> year = multimediaMapper.selectyear();
                    aJSONObject.put("data", year);
                    break;
                default:
                    aJSONObject.put("message", "请传入类型");
                    aJSONObject.put("status", 1);
                    return aJSONObject;
            }
            aJSONObject.put("message", "成功");
            aJSONObject.put("status", 0);
        }catch(Exception e){
            e.printStackTrace();
            aJSONObject.put("message", "失败");
            aJSONObject.put("status", 1);
        }
        return aJSONObject;
    }
    //统计多媒体分析微信用户增长数
    @ApiOperation(value = "微信文章评论统计", notes = "wxcomment")
    @RequestMapping(value = "/wxcomment", method = {RequestMethod.GET})
    @ResponseBody
    public JSONObject getwxcomment(@RequestParam(value="type",required = true)Integer type ,
                                   @RequestParam(value="time",required = false)String time) {

        JSONObject aJSONObject = new JSONObject();
        try {
            // 1 是周 2 月  3 年
            switch (type) {
                case 1:
                    List<Map<String, Object>> week = multimediaMapper.selectCommentweek();
                    aJSONObject.put("data", week);
                    break;
                case 2:
                    HashMap<String,Object> map = new HashMap<>();
                    map.put("time",time);
                    List<Map<String, Object>> month = multimediaMapper.selectCommentmonth(map);
                    aJSONObject.put("data", month);
                    break;
                case 3:
                    List<Map<String, Object>> year =multimediaMapper.selectCommentyear();

                    aJSONObject.put("data", year);
                    break;
                default:
                    aJSONObject.put("message", "请传入类型");
                    aJSONObject.put("status", 1);
                    return aJSONObject;
            }
            aJSONObject.put("message", "成功");
            aJSONObject.put("status", 0);
        }catch(Exception e){
            e.printStackTrace();
            aJSONObject.put("message", "失败");
            aJSONObject.put("status", 1);
        }
        return aJSONObject;
    }
    //统计多媒体分析访问量统计
    @ApiOperation(value = "统计多媒体分析访问量统计", notes = "addNewUser")
    @RequestMapping(value = "/selectVisitCount", method = {RequestMethod.GET})
    @ResponseBody
    public JSONObject selectVisitCount(@RequestParam(value="type",required = true)Integer type , @RequestParam(value="time",required = false)String time) {

        JSONObject aJSONObject = new JSONObject();
        try {
            // 1 是周 2 月  3 年
            switch (type) {
                case 1:
                    List<Map<String, Object>> week = multimediaMapper.selectVisitweek();
                    aJSONObject.put("data", week);
                    break;
                case 2:
                    HashMap<String,Object> map = new HashMap<>();
                    map.put("time",time);
                    List<Map<String, Object>> month = multimediaMapper.selectVisitmonth(map);
                    aJSONObject.put("data", month);
                    break;
                case 3:
                    List<Map<String, Object>> year = multimediaMapper.selectVisityear();
                    aJSONObject.put("data", year);
                    break;
                default:
                    aJSONObject.put("message", "请传入类型");
                    aJSONObject.put("status", 1);
                    return aJSONObject;
            }
            aJSONObject.put("message", "成功");
            aJSONObject.put("status", 0);
        }catch(Exception e){
            e.printStackTrace();
            aJSONObject.put("message", "失败");
            aJSONObject.put("status", 1);
        }
        return aJSONObject;
    }



}
