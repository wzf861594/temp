package com.okay.ad.service;


import com.okay.ad.common.PageQueryBean;
import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.QuestionOption;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

public interface QuestionService {

    PageQueryBean queryQuestionList(QueryCondition condition);

    HashMap queryQuestionListForIds(List<Integer> idsList);

    int addQuestion(String obj) throws ParseException;

    List<QuestionOption> queryStatistical(String ids);
}
