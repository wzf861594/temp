package com.okay.ad.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.entity.SuggestionAnswer;
import com.okay.ad.exception.OkayException;
import com.okay.ad.service.ISuggestionAnswerService;
import com.okay.okay.common.log.annotation.SysLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

@CrossOrigin(allowCredentials ="true")
@RestController
@Api(tags = "题库管理")
@RequestMapping("/suggestionAnswer")
public class SuggestionAnswerController {

    @Autowired
    private ISuggestionAnswerService suggestionAnswerService;

    /**
     *@Description 题库录入
     */
    @SysLog("观众数字化题库管理新增")
    @ApiOperation(value = "题库录入")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "suggestioncontent",value = "意见内容描述",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "suggestionanswer",value = "意见答案",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="suggestiontype" ,value="意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)",dataType = "int",paramType = "query")
    })
    @PostMapping(value = "/insert")
    public Result insertSuggestionAnswer(@RequestBody JSONObject json) {
        String suggstionAnswerStr = JSONObject.toJSONString(json);
        SuggestionAnswer suggstionAnswer = JSON.parseObject(suggstionAnswerStr,SuggestionAnswer.class);

        Result resp = new Result();
        try {
            suggestionAnswerService.addSuggestionAnswer(suggstionAnswer);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("保存成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setCode(TicketStatus.STATUS_FAIL);
            resp.setMessage("系统错误");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

    /**
     *@Description 单条删除
     */
    @ApiOperation(value="单条删除")
    @ApiImplicitParam(name = "id" ,value = "ID",dataType = "int")
    @PostMapping(value = "/delete")
    public Result deleteSuggestionAnswer(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            suggestionAnswerService.deleteSuggestionAnswer(json.getInteger("recid"));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("删除成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
    /**
     * 题库删除
     * @param ids
     * @return
     */
    @SysLog("观众数字化题库管理删除")
    @ApiOperation(value="多条题库删除")
    @ApiImplicitParam(name = "ids" ,value = "ID",dataType = "String")
    @DeleteMapping(value = "/deleteByBatch")
    public Result deleteByBatch(@RequestParam(value = "ids",required = true) String ids){
        Result result = new Result();
        try {
            suggestionAnswerService.deleteByBatch(ids);
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setMessage("删除成功！");
        } catch (OkayException e) {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            result.setMessage("内部错误");
            result.setCode(TicketStatus.STATUS_ERROE);
        }
        return  result;
    }


    /**
     *@Description 题库数据列表
     *
     */
    @ApiOperation(value = "题库数据列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="currentPage" ,value="页数",dataType = "int"),
            @ApiImplicitParam(name="pageSize" ,value="页长",dataType = "int"),
            @ApiImplicitParam(name = "suggestiontype",value = "意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)",dataType = "int"),
            @ApiImplicitParam(name="searchParam" ,value="关键字",dataType = "String")
    })
    @PostMapping(value = "/query")
    public Result querySuggestionAnswer(@RequestBody JSONObject json) {
       Result resp = new Result();
        try {
            Map<String, Object> aMap = new HashMap<>();
            aMap.put("suggestiontype",json.getInteger("suggestiontype"));
            aMap.put("searchParam",json.getString("searchParam"));
            resp.setData(suggestionAnswerService.getHashMapList(aMap, json.getInteger("currentPage"), json.getInteger("pageSize")));
            resp.setTotal(suggestionAnswerService.getCount(aMap));
            resp.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        }catch (Exception ex){
            resp.setMessage(TicketStatus.STATUS_EXCEPTION_MSG);
            resp.setCode(TicketStatus.STATUS_EXCEPTION);
        }
        return resp;
    }


    /**
     *@Description 单条数据编辑
     */
    @SysLog("观众数字化题库管理编辑")
    @ApiOperation(value="单条数据编辑")
    @ApiImplicitParams({
            @ApiImplicitParam(name="recid" ,value="ID",dataType = "int",paramType = "query", required = true),
            @ApiImplicitParam(name = "suggestioncontent",value = "意见内容描述",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "suggestionanswer",value = "意见答案",dataType = "String",paramType = "query"),
            @ApiImplicitParam(name="suggestiontype" ,value="意见类型(1留言,2资讯,3投诉,4求助,5建议,6媒体来访,7内部协调,8其他)",dataType = "int",paramType = "query")
    })
    @PostMapping(value = "/update")
    public Result updateSuggestionAnswer(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            String suggstionAnswerStr = JSONObject.toJSONString(json);
            SuggestionAnswer suggstionAnswer = JSON.parseObject(suggstionAnswerStr,SuggestionAnswer.class);
            SimpleDateFormat  sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            suggestionAnswerService.updateQuestionAnswer(suggstionAnswer);
            resp.setCode(TicketStatus.STATUS_SUCCESS);
            resp.setMessage("修改成功");
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }

    /**
     *@Description 单条数据查看
     */
    @ApiOperation(value="单条数据查看")
    @ApiImplicitParam(name = "id" ,value = "ID",dataType = "int")
    @PostMapping(value = "/select")
    public Result selectSuggestionAnswer(@RequestBody JSONObject json) {
        Result resp = new Result();
        try {
            resp.setData(suggestionAnswerService.selectSuggestionAnswer(json.getInteger("recid")));
            resp.setCode(TicketStatus.STATUS_SUCCESS);
        } catch (OkayException e) {
            e.printStackTrace();
            resp.setMessage("系统错误");
            resp.setCode(TicketStatus.STATUS_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setMessage("内部错误");
            resp.setCode(TicketStatus.STATUS_ERROE);
        }
        return resp;
    }
}
