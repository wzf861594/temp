package com.okay.ad.utils;

import com.okay.ad.entity.StaticConstant;
import org.bouncycastle.util.encoders.Encoder;
import org.bouncycastle.util.encoders.UrlBase64;
import org.bouncycastle.util.encoders.UrlBase64Encoder;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;

/**
 * 单点登录AES加解密
 */
public class SSOAESUtils {

    // 解密
    public static String decrypt(String decryptResult) throws Exception {
        String randomkey = StaticConstant.getAeskey();
        //String deskey = "eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJMdWNreSIsImlhdCI6MTUzOTMyNDcwNiwiaXNzIjoiT2theWdpcyIsImF1ZCI6Inp6eiIsInN1YiI6ImUxZmQ1MzZmLTc1YjctNGFmMC05YjRiLWUwMDNlNjliYWU3MiIsImV4cCI6MTU0MTkxNjcwNn0.uSnksvSYKNTXsgHgWS_L3jljr6SA4xWIHPvvGeJwXOc";
        KeyGenerator kgen = KeyGenerator.getInstance("AES");// 创建AES的Key生产者
        kgen.init(128, new SecureRandom(randomkey.getBytes()));// 利用用户密码作为随机数初始化出
        SecretKey secretKey = kgen.generateKey();// 根据用户密码，生成一个密钥
        byte[] enCodeFormat = secretKey.getEncoded();// 返回基本编码格式的密钥，如果此密钥不支持编码，则返回
        SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");// 转换为AES专用密钥
        Cipher cipher = Cipher.getInstance("AES");// 创建密码器
        cipher.init(Cipher.DECRYPT_MODE, key);// 初始化为解密模式的密码器
        byte[] pasByte = cipher.doFinal(UrlBase64.decode(decryptResult));
        return new String(pasByte, "UTF-8");
    };

    // 加密
    public static String encrypt(String data, String deskey) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");// 创建AES的Key生产者
        kgen.init(128, new SecureRandom(deskey.getBytes()));// 利用用户密码作为随机数初始化出
        SecretKey secretKey = kgen.generateKey();// 根据用户密码，生成一个密钥
        byte[] enCodeFormat = secretKey.getEncoded();// 返回基本编码格式的密钥，如果此密钥不支持编码，则返回
        SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");// 转换为AES专用密钥
        Cipher cipher = Cipher.getInstance("AES");// 创建密码器
        byte[] byteContent = data.getBytes("utf-8");
        cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化为加密模式的密码器
        byte[] pasByte = cipher.doFinal(byteContent);// 加密
        return new String(urlBase64Encode(pasByte), "UTF-8");
    }

    public static byte[] urlBase64Encode(byte[] paramArrayOfByte) {
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
        try {
            Encoder encoder = new UrlBase64Encoder();
            encoder.encode(paramArrayOfByte, 0, paramArrayOfByte.length, localByteArrayOutputStream);
        } catch (IOException localIOException) {
            throw new RuntimeException("exception encoding URL safe base64 string: " + localIOException);
        }
        return localByteArrayOutputStream.toByteArray();
    }
}
