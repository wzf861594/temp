package com.okay.ad.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.okay.ad.common.Result;
import com.okay.ad.common.TicketStatus;
import com.okay.ad.mapper.TicketTeamMapper;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;


/**
*
* @author  zengxiaoquan
*/
@CrossOrigin(allowCredentials ="true")
@Controller
@Api(tags = "团体观众档案")
@RequestMapping(value = "/adms/team/")
public  class TicketArchivesTeamController {

    @Autowired
    TicketTeamMapper ticketTeamMapper;


    //团体票查看
    @GetMapping("/View")
    @ResponseBody
    public Result view(@RequestParam("id") String id){
        Result result =new Result();
        Map<String, Object> view = ticketTeamMapper.view(id);
        result.success(view,view == null ? 0: 1);
        return result;
     }

    //团体票显示
    @PostMapping("/getList")
    @ResponseBody
    public Result getList(@RequestBody JSONObject jsonObject) {
        Result result = new Result();
        try {
            int pageNum = jsonObject.getInteger("currentPage") == null ? 1 : jsonObject.getInteger("currentPage");
            int pageSize = jsonObject.getInteger("pageSize") == null ? 20 : jsonObject.getInteger("pageSize");
            Map<String, Object> map = new HashMap<>();
            map.put("name",jsonObject.getString("name"));
            map.put("startDate",jsonObject.getString("startDate"));
            map.put("endDate",jsonObject.getString("endDate"));
            Page<Object> objects = PageHelper.startPage(pageNum, pageSize);
            ticketTeamMapper.getlist(map);
            result.setData(objects.getResult());
            result.setTotal((int) objects.getTotal());
            result.setCode(TicketStatus.STATUS_SUCCESS);
            result.setMessage(TicketStatus.STATUS_SUCCESS_MSG);
        } catch (Exception e) {
            e.printStackTrace();
            result.setCode(TicketStatus.STATUS_NEW_FAIL);
            result.setMessage(TicketStatus.STATUS_EXCEPTION_MSG+": "+e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

}




