package com.okay.ad.mapper;

import com.okay.ad.common.QueryCondition;
import com.okay.ad.entity.Suggestion;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SuggestionMapper {

    int insert(Suggestion record);

    Suggestion selectByPrimaryKey(Integer recid);

    int updateByPrimaryKey(Suggestion record);

    int count(QueryCondition condition);

    List<Suggestion> selectByCondition(QueryCondition condition);

    void batchInsert(List<Suggestion> list);

    /**
     * 单条数据修改
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Suggestion record);

    /**
     * 单条数据删除
     * @param recid
     * @return
     */
    int deleteByPrimaryKey(Integer recid);

    int deleteByBatch(@Param(value = "ids") List<String> ids);
    /**
     * 单条数据修改
     * @param record
     * @return
     */
    int insertSelective(Suggestion record);

    /**
     * 批量查询
     * @param aMap
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getHashMapList(Map<String, Object> aMap);


    /**
     * 根据条件获取数据总量
     * @param aMap
     * @return int
     */
    int getCount(Map<String, Object> aMap);

    List<Map<String, Object>>  suggestExport();

}