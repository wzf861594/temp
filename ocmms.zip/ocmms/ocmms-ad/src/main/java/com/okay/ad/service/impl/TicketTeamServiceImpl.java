package com.okay.ad.service.impl;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageHelper;
import com.okay.ad.mapper.TicketTeamMapper;
import com.okay.ad.service.ITicketTeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketTeamServiceImpl implements ITicketTeamService {


    @Autowired
    private TicketTeamMapper ticketTeamMapper;

    /**
     * 获取团体门票预约列表
     *
     * @param aMap
     * @param pageNum  页码
     * @param pageSize 分页大小
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getTeamTicketList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return ticketTeamMapper.getTeamTicketList(aMap);
    }

    /**
     * 获取团体门票预约总数
     *
     * @param aMap
     * @return int
     */
    @Override
    public int getTeamTicketCount(Map<String, Object> aMap) {
        return ticketTeamMapper.getTeamTicketCount(aMap);
    }

    @Override
    public List<Map<String, Object>> teamExport() {
        return ticketTeamMapper.teamExport();
    }
}




