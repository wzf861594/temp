package com.okay.ad.service.impl;

import com.github.pagehelper.PageHelper;
import com.okay.ad.entity.Suggestion;
import com.okay.ad.entity.SuggestionAnswer;
import com.okay.ad.exception.OkayException;
import com.okay.ad.mapper.SuggestionAnswerMapper;
import com.okay.ad.mapper.SuggestionMapper;
import com.okay.ad.service.SuggestService;
import com.okay.ad.utils.ExportUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.util.*;

@Service
public class SuggestServiceImpl implements SuggestService {

    @Autowired
    SuggestionMapper suggestionMapper;

    @Autowired
    SuggestionAnswerMapper suggestionAnswerMapper;

    @Override
    public List<Map<String, Object>> getHashMapList(Map<String, Object> aMap, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return suggestionMapper.getHashMapList(aMap);
    }
    @Override
    public int getCount(Map<String, Object> aMap) {
        return suggestionMapper.getCount(aMap);
    }

    @Override
    public  Suggestion updateSuggestion(Suggestion suggestion) {
        Suggestion newSuggestion = new Suggestion();
        suggestion.setUpdatedate(new Date());
        int i = suggestionMapper.updateByPrimaryKeySelective(suggestion);
        if(i == 1) {
            newSuggestion  =  suggestionMapper.selectByPrimaryKey(suggestion.getRecid());
        }
        return newSuggestion;
    }

    @Override
    public boolean deleteSuggestion(int recId) {
        if (suggestionMapper.deleteByPrimaryKey(recId) == 1) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void deleteByBatch(String ids) {
        suggestionMapper.deleteByBatch(Arrays.asList(ids.split(",")));
    }

    @Override
    public boolean addSuggestion(Suggestion suggestion) throws ParseException {
        if(suggestion.getSuggestionresult() != null){
            suggestion.setSuggestionstate(1);
        }
        suggestion.setCreatedate(new Date());
        if (suggestionMapper.insertSelective(suggestion) == 1) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    @Transactional
    public void batchInsert(List<Suggestion> list) {
        if(list.size()>0) {
            suggestionMapper.batchInsert(list);
        } else {
            throw new OkayException("集合为空");
        }
    }

    @Override
    public Suggestion selectSuggestion(int recId){
        return  suggestionMapper.selectByPrimaryKey(recId);
    }

    @Override
    public Suggestion dealSuggestion(Suggestion suggestion) {
        Suggestion newSuggestion = new Suggestion();
        suggestion.setUpdatedate(new Date());
        suggestion.setSuggestionstate(1);
        int i = suggestionMapper.updateByPrimaryKeySelective(suggestion);
        if(i == 1) {
            newSuggestion  =  suggestionMapper.selectByPrimaryKey(suggestion.getRecid());
        }
        return newSuggestion;
    }
    @Transactional
    @Override
    public boolean createSuggestionPool(int recId){
        Suggestion suggestion =  suggestionMapper.selectByPrimaryKey(recId);
        suggestion.setIscreateanswer(1);
        /*将意见的内容插入到题库*/
        SuggestionAnswer suggestionAnswer = new SuggestionAnswer();
        suggestionAnswer.setSuggestiontype(suggestion.getSuggestiontype());
        suggestionAnswer.setSuggestionanswer(suggestion.getSuggestionresult());
        suggestionAnswer.setSuggestioncontent(suggestion.getSuggestioncontent());
        int i = suggestionAnswerMapper.insertSelective(suggestionAnswer);
        int j = suggestionMapper.updateByPrimaryKeySelective(suggestion);
        if(i== 1 && j==1){
            return  true;
        } else {
            return false;
        }
    }

    @Override
    public void suggestExport(HttpServletResponse response, HashMap object) throws Exception {
        List<Map<String, Object>> bookingSingleList = suggestionMapper.suggestExport();
        //头部-导出行
        List<String> titleCol = new ArrayList<>();
        titleCol.add("意见来源");
        titleCol.add("观众名称");
        titleCol.add("意见类型");
        titleCol.add("意见提交时间");
        titleCol.add("意见反馈渠道");
        titleCol.add("意见内容");
        titleCol.add("意见处理结果");
        List<String> datavalue = new ArrayList<>();
        datavalue.add("SuggestionResourceStr");
        datavalue.add("AudienceName");
        datavalue.add("SuggestionTypeStr");
        datavalue.add("SubmitDate");
        datavalue.add("FeedbackChannelStr");
        datavalue.add("SuggestionContent");
        datavalue.add("SuggestionResult");
        String fileName = "意见管理列表";
        ExportUtil.exportInfo(response, fileName, titleCol, bookingSingleList, datavalue);
    }
}

