package com.okay.ad.mapper;

import com.okay.ad.entity.WxArticleSummary;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface WxArticleSummaryMapper {

    @Select("select count(1) from wx_articlesummary where ref_date = #{ref_date} and title = #{title}")
    int selectArticleSummary(@Param("ref_date") String ref_date, @Param("title") String title);

    @Insert("insert into wx_articlesummary(ref_date,msgid,title,int_page_read_user,int_page_read_count,ori_page_read_user,ori_page_read_count,share_user,share_count,add_to_fav_user,add_to_fav_count) " +
            "values(#{wxArticleSummary.refDate},#{wxArticleSummary.msgid},#{wxArticleSummary.title},#{wxArticleSummary.intPageReadUser},#{wxArticleSummary.intPageReadCount}," +
            "#{wxArticleSummary.oriPageReadUser},#{wxArticleSummary.oriPageReadCount},#{wxArticleSummary.shareUser},#{wxArticleSummary.shareCount},#{wxArticleSummary.addToFavUser},#{wxArticleSummary.addToFavCount})")
    void insertArticleSummary(@Param("wxArticleSummary") WxArticleSummary wxArticleSummary);

    @Select("select count(1) from wx_articlesummary where title like concat('%', #{title}, '%') and (ref_date >= #{startDate} or #{startDate} is null) and (ref_date <= #{endDate} or #{endDate} is null)")
    int countArticleSummary(@Param("title") String title, @Param("startDate") String startDate, @Param("endDate") String endDate);

    @Select("select ref_date,title,int_page_read_count,share_user,share_count,add_to_fav_user,add_to_fav_count from wx_articlesummary where title like concat('%', #{title}, '%') and (ref_date >= #{startDate} or #{startDate} is null) and (ref_date <= #{endDate} or #{endDate} is null) order by ref_date desc limit #{pageNo},#{pageSize}")
    List<Map<String, Object>> listArticleSummary(@Param("title") String title, @Param("startDate") String startDate, @Param("endDate") String endDate, @Param("pageNo") int pageNo, @Param("pageSize") int pageSize);

}
