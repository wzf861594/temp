function listData(questionId) {
    $.ajax({
        type: "GET",
        url: "/questionAnswer/getList?id=" + questionId,
        dataType: "json",
        success: function (data) {
            let html = "";
            for (var i = 0; i < data.list.length; i++) {
                html += '<div class="form-group">';
                if (i < 10) {
                    html += '<div class="title" ><span class="icon">0' + (i + 1) + '</span>' + data.list[i].title + '</div>';
                } else {
                    html += '<div class="title"><span class="icon">' + (i + 1) + '</span>' + data.list[i].title + '</div>';
                }
                if (data.list[i].datas) {
                    if (data.list[i].type == 'check') {
                        html += '<div class="check checkbox">';
                        for (let j = 0; j < data.list[i].datas.length; j++) {
                            html += '<span onclick="checkChoice(this)" id=' + data.list[i].datas[j].value + '><i></i>' + data.list[i].datas[j].name + ' </span>';
                        }
                        html += ' </div>';
                    } else {
                        html += '<div class="check">';
                        for (let j = 0; j < data.list[i].datas.length; j++) {
                            html += '<span onclick="radioChoice(this)" id=' + data.list[i].datas[j].value + '><i></i>' + data.list[i].datas[j].name + ' </span>';
                        }
                        html += ' </div>';
                    }
                }
                if (data.list[i].type == 3) {
                    html += ' <input  type="text" value="" />';
                }
                if (data.list[i].type == 4) {
                    html += ' <textarea  value="" /></textarea>';
                }
                html += '</div>';
            }
            html += '<div id="submit" class="submit">提交</div>';
            $(".form").append(html);
        }
    })
}

function radioChoice(p) {
    $(p).addClass("in").siblings().removeClass("in");
}

function checkChoice(p) {
    if ($(p).hasClass("in")) {
        $(p).removeClass("in");
    } else {
        $(p).addClass("in");
    }
};
//提交事件
$(document).on("click", ".submit", function () {
    //获取有几个选项
    var xx = $(".title").length;
    //获取所有点击的value
    var arrt = new Array();
    $("span[class= in]").each(function () {
        arrt.push($(this).attr("id"));
    })
    console.log(arrt.length);
    if (arrt.length == 0) {
        $.alert("消息提示", "请选择答案！");
        return;
    }
    if (xx != arrt.length){
        $.alert("消息提示", "请填完所有答案后提交！");
        return;
    }
    $.confirm("消息提示", "确定要提交吗？");
    $.isok = function () {
        var data = {};
        data["record"] = arrt;
        $.ajax({
            type: "post",
            url: "/record/addRecord",
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(data),
            dataType: "json",
            beforeSend: function () {
                $.toast("加载中....", 0);
            },
            success: function (data) {
                if (data.code == '1') {
                    window.location.href ="/record/succes";
                } else {
                    $.alert("错误提示", "处理失败！" + data.message);
                }
            },
            error: function (data) {
                console.log("error"+data.responseText);
                $.alert("错误提示", "请求失败！请联系管理员！ " + data.statusText);
            },
            complete: function () {
                $.removetoast();
            },
        })
    }
})