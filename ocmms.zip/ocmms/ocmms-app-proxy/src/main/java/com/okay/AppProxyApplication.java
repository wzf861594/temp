package com.okay;

//import com.okay.okay.common.feign.annotation.EnableOkayFeignClients;
//import com.okay.okay.common.security.annotation.EnableOkayResourceServer;
//import com.okay.okay.common.swagger.annotation.EnableOkaySwagger2;
//import org.mybatis.spring.annotation.MapperScan;
//import org.springframework.cloud.openfeign.EnableFeignClients;

//import com.okay.okay.common.feign.annotation.EnableOkayFeignClients;
//import com.okay.okay.common.security.annotation.EnableOkayResourceServer;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
//import org.springframework.cloud.client.SpringCloudApplication;


/**
 * @ClassName test
 * @Description TODO
 * @Author cxc
 * @Date 2021/6/10 13:54
 * @Version 1.0
 */
@MapperScan("com.okay.**.mapper")
//@EnableOkaySwagger2
@SpringCloudApplication
//@EnableOkayFeignClients
@EnableFeignClients
//@EnableOkayResourceServer
public class AppProxyApplication {
    public static void main(String[] args) {
        SpringApplication.run(AppProxyApplication.class,args);
    }
}
