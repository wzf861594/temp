package com.okay.appproxy.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @ClassName AppProxyConfig
 * @Description TODO
 * @Author cxc
 * @Date 2021/6/10 15:28
 * @Version 1.0
 */
@Data
@Component
@ConfigurationProperties(prefix = "cxcproxy")
public class AppProxyConfig {
    @Value("${servlet_url:}")
    private String servletUrl;
    @Value("${target_url:}")
    private String targetUrl;
}
