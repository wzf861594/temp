package com.okay.appproxy.handler;

import com.okay.appproxy.config.AppProxyConfig;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.mitre.dsmiley.httpproxy.ProxyServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;


/**
 * @ClassName AppProxyHandler
 * @Description TODO
 * @Author cxc
 * @Date 2021/6/10 15:04
 * @Version 1.0
 */
@Configuration
@AllArgsConstructor
public class AppProxyHandler implements EnvironmentAware {

    private AppProxyConfig appProxyConfig;
    @Bean
    public ServletRegistrationBean servletRegistrationBean() {
        ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(new ProxyServlet(), appProxyConfig.getServletUrl());
        servletRegistrationBean.setName("cxcProxy");
        servletRegistrationBean.addInitParameter("targetUri", appProxyConfig.getTargetUrl());
        servletRegistrationBean.addInitParameter(ProxyServlet.P_LOG, "true");
        return servletRegistrationBean;
    }

    @Override
    public void setEnvironment(Environment environment) {

    }
}
