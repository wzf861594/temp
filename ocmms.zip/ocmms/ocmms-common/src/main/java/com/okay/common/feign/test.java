package com.okay.common.feign;


import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/**
 * @author wzf
 * @description
 * @date 2021-12-20 9:14
 */

public class test {
    public static void main(String args[]){
    }

}