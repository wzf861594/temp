package com.okay.rfid.info;

import java.util.Date;

/**
 * rfid_beacon
 * @author 
 */
public interface RfidBeacon {

    String getId();

    String getRfid();

    String getType();

    String getDescribe();

    String getState();

    String getCreatedBy();

    Date getCreatedTime();

    String getUpdatedBy();

    Date getUpdatedTime();

}