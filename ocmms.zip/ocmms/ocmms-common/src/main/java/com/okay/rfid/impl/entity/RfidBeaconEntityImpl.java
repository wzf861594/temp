package com.okay.rfid.impl.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.okay.rfid.info.RfidBeacon;
import com.okay.rfid.entity.RfidBeaconEntity;

import java.io.Serializable;
import java.util.Date;

/**
 * rfid_beacon
 * @author 
 */
public class RfidBeaconEntityImpl implements RfidBeaconEntity, RfidBeacon, Serializable {

    @Deprecated
    public enum BeaconState {
        ACCESS,
        BINDING,
        DELETE,
    }

    public enum State {
        ACCESS,
        BINDING,
        DELETE,
    }

    /**
     * 主键
     */
    private String id;

    /**
     * RFID
     */
    private String rfid;

    /**
     * RFID类型
     */
    private String type;

    /**
     * 描述
     */
    private String describe;

    /**
     * 状态
     */
    private State state;


    private String createdBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createdTime;

    private String updatedBy;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updatedTime;

    private static final long serialVersionUID = 1L;

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getRfid() {
        return rfid;
    }

    @Override
    public void setRfid(String rfid) {
        this.rfid = rfid;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String getDescribe() {
        return describe;
    }

    @Override
    public void setDescribe(String describe) {
        this.describe = describe;
    }

    @Override
    public String getState() {
        return state != null ? state.name() : null;
    }

    @Override
    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setState(String state) {
        this.state = state != null ? State.valueOf(state) : null;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public Date getCreatedTime() {
        return createdTime;
    }

    @Override
    public String getUpdatedBy() {
        return updatedBy;
    }

    @Override
    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public Date getUpdatedTime() {
        return updatedTime;
    }

    @Override
    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

}