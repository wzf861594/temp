package com.okay.rfid.impl.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.okay.rfid.info.RfidAccess;
import com.okay.rfid.entity.RfidAccessEntity;

import java.io.Serializable;
import java.util.Date;

/**
 * rfid_access
 * @author 
 */
public class RfidAccessEntityImpl implements RfidAccessEntity, RfidAccess, Serializable {
    /**
     * 主键
     */
    private String id;

    /**
     * RFID
     */
    private String rfid;

    /**
     * 接入业务
     */
    private String accessBusiness;

    /**
     * 分类
     */
    private String type;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createdTime;

    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 业务ID
     */
    private String businessId;

    /**
     * 业务类型
     */
    private String businessType;

    private static final long serialVersionUID = 1L;

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getRfid() {
        return rfid;
    }

    @Override
    public void setRfid(String rfid) {
        this.rfid = rfid;
    }

    @Override
    public String getAccessBusiness() {
        return accessBusiness;
    }

    @Override
    public void setAccessBusiness(String accessBusiness) {
        this.accessBusiness = accessBusiness;
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public Date getCreatedTime() {
        return createdTime;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public void setBusinessId(String businessId) {
        this.businessId = businessId;
    }

    @Override
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    @Override
    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public String getBusinessId() {
        return businessId;
    }

    @Override
    public String getBusinessType() {
        return businessType;
    }

}