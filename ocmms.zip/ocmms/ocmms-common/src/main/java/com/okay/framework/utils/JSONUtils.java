package com.okay.framework.utils;

import com.alibaba.fastjson.JSONObject;

/**
 * @ClassName: JSONUtils
 * @Description: JSON工具
 * @author: HQ.ZHU
 * @date: 2019-07-26 17:45
 * @version: V1.0
 */
public class JSONUtils {

    private JSONObject jsonObject = null;

    public JSONUtils(){
        jsonObject = new JSONObject();
    }

    public JSONUtils(JSONObject jsonObject){
        if(jsonObject == null)
            throw new RuntimeException("JSONUtils对像实例化失败，参数不能为空！");
        this.jsonObject = jsonObject;
    }

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public JSONUtils put (String key, Object value){
        jsonObject.put(key, value);
        return this;
    }

    public JSONObject success () {
        jsonObject.put("code", 1);
        return jsonObject;
    }

    public JSONObject fail (String msg) {
        this.put("code", 4).put("msg", msg);
        return jsonObject;
    }
}
