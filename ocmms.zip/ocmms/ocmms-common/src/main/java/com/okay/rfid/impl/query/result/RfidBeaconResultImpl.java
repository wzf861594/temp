package com.okay.rfid.impl.query.result;

import com.okay.rfid.impl.entity.RfidBeaconEntityImpl;
import com.okay.rfid.query.result.RfidBeaconResult;

public class RfidBeaconResultImpl extends RfidBeaconEntityImpl implements RfidBeaconResult {

    private String name;

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}
