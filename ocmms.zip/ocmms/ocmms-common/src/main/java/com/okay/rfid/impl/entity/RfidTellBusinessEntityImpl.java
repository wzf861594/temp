package com.okay.rfid.impl.entity;

import com.okay.rfid.info.RfidTellBusiness;
import com.okay.rfid.entity.RfidTellBusinessEntity;

import java.io.Serializable;

/**
 * rfid_tell_business
 * @author 
 */
public class RfidTellBusinessEntityImpl implements RfidTellBusinessEntity, RfidTellBusiness, Serializable {

    /**
     * 主键
     */
    private String id;

    /**
     * RFID识别记录ID
     */
    private String tellLogId;

    /**
     * 接入业务
     */
    private String accessBusiness;

    /**
     * 业务ID
     */
    private String accessBusinessId;

    /**
     * 业务类型
     */
    private String accessBusinessType;

    /**
     * 是否异常
     */
    private Boolean isError;

    /**
     * 异常类型
     */
    private String exceptionType;

    /**
     * 异常信息
     */
    private String exceptionMsg;

    /**
     * 是否异步
     */
    private Boolean isAsync;

    private static final long serialVersionUID = 1L;

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getTellLogId() {
        return tellLogId;
    }

    @Override
    public void setTellLogId(String tellLogId) {
        this.tellLogId = tellLogId;
    }

    @Override
    public String getAccessBusiness() {
        return accessBusiness;
    }

    @Override
    public void setAccessBusiness(String accessBusiness) {
        this.accessBusiness = accessBusiness;
    }

    @Override
    public String getAccessBusinessId() {
        return accessBusinessId;
    }

    @Override
    public void setAccessBusinessId(String accessBusinessId) {
        this.accessBusinessId = accessBusinessId;
    }

    @Override
    public String getAccessBusinessType() {
        return accessBusinessType;
    }

    @Override
    public void setAccessBusinessType(String accessBusinessType) {
        this.accessBusinessType = accessBusinessType;
    }

    @Override
    public Boolean getIsError() {
        return isError;
    }

    @Override
    public void setIsError(Boolean isError) {
        this.isError = isError;
    }

    @Override
    public String getExceptionType() {
        return exceptionType;
    }

    @Override
    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public String getExceptionMsg() {
        return exceptionMsg;
    }

    @Override
    public void setExceptionMsg(String exceptionMsg) {
        this.exceptionMsg = exceptionMsg;
    }

    @Override
    public Boolean getIsAsync() {
        return isAsync;
    }

    @Override
    public void setIsAsync(Boolean isAsync) {
        this.isAsync = isAsync;
    }

    @Override
    public boolean isError() {
        return isError;
    }

    @Override
    public boolean isAsync() {
        return isAsync;
    }

}