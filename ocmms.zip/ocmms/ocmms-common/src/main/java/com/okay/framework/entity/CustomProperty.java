package com.okay.framework.entity;

import java.util.Date;

public class CustomProperty {
    private String customId;

    private String customObj;

    private Date createTime;

    private String createUser;

    private Date updateTime;

    private String updateUser;

    private String customResourceId;

    private String attributeObj;

    public String getCustomId() {
        return customId;
    }

    public void setCustomId(String customId) {
        this.customId = customId;
    }

    public String getCustomObj() {
        return customObj;
    }

    public void setCustomObj(String customObj) {
        this.customObj = customObj;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getCustomResourceId() {
        return customResourceId;
    }

    public void setCustomResourceId(String customResourceId) {
        this.customResourceId = customResourceId;
    }

    public String getAttributeObj() {
        return attributeObj;
    }

    public void setAttributeObj(String attributeObj) {
        this.attributeObj = attributeObj;
    }
}