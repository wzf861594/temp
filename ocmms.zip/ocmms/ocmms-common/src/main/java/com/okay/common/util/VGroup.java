package com.okay.common.util;

import javax.validation.GroupSequence;

/**
 * @classname VGroup
 * @description
 * @date 2019/11/13 11:06
 * @created by JUN
 */
@GroupSequence({
        VGroup.$1.class,
        VGroup.$2.class,
        VGroup.$3.class,
        VGroup.$4.class,
        VGroup.$5.class,
        VGroup.$6.class,
        VGroup.$7.class,
        VGroup.$8.class
})
public interface VGroup {

    interface $1 { }
    interface $2 { }
    interface $3 { }
    interface $4 { }
    interface $5 { }
    interface $6 { }
    interface $7 { }
    interface $8 { }

}
