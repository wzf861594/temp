package com.okay.rfid.mapper;

import com.okay.rfid.entity.RfidAccessEntity;
import com.okay.rfid.info.RfidAccess;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface RfidAccessMapperRfid extends RfidBaseMapper<RfidAccessEntity> {

    int deleteByRfid(String rfid);

    List<? extends RfidAccess> selectByRfid(String rfid);

}