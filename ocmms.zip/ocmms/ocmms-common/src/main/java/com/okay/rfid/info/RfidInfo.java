package com.okay.rfid.info;

import java.util.Date;

/**
 * rfid_info
 * @author 
 */
public interface RfidInfo {

    String getId();

    String getName();

    String getRfid();

    String getType();

    String getDescribe();

    String getBusinessId();

    String getBusinessType();

    Date getCreatedTime();

    String getCreatedBy();

    Date getLastUpdatedTime();

    String getLastUpdatedBy();

    Boolean getIsDelete();

    boolean isDelete();

}