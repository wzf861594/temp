package com.okay.framework.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.common.feign.RemoteDictExtensionService;
import com.okay.okay.admin.api.entity.SysDict;
import com.okay.okay.admin.api.entity.SysDictItem;
import com.okay.okay.common.core.constant.CacheConstants;
import com.okay.okay.common.core.util.R;
import com.okay.okay.common.log.annotation.SysLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author ZHU.HQ
 * @date 2020/7/30 10:27
 */
@RestController
@RequestMapping("/dict")
public class DictController {

    @Autowired
    private RemoteDictExtensionService remoteDictExtensionService;
    /**
     * 通过ID查询字典信息
     *
     * @param id ID
     * @return 字典信息
     */
    @GetMapping("/{id}")
    public R getById(@PathVariable Integer id) {
        return remoteDictExtensionService.getById(id);
    }

    /**
     * 分页查询字典信息
     *
     * @param page 分页对象
     * @return 分页对象
     */
    @GetMapping("/page")
    public R getDictPage(Page page, SysDict sysDict) {
        return remoteDictExtensionService.getDictPage(sysDict, page.getCurrent(), page.getSize());
    }

    /**
     * 通过字典类型查找字典
     *
     * @param type 类型
     * @return 同类型字典
     */
    @GetMapping("/type/{type}")
    public R getDictByType(@PathVariable String type) {
        return remoteDictExtensionService.getDictByType(type);
    }

    /**
     * 添加字典
     *
     * @param sysDict 字典信息
     * @return success、false
     */
    @SysLog("添加字典")
    @PostMapping
    @PreAuthorize("@pms.hasPermission('sys_dict_add')")
    public R save(@Valid @RequestBody SysDict sysDict) {
        return remoteDictExtensionService.save(sysDict);
    }

    /**
     * 删除字典，并且清除字典缓存
     *
     * @param id ID
     * @return R
     */
    @SysLog("删除字典")
    @DeleteMapping("/{id}")
    @PreAuthorize("@pms.hasPermission('sys_dict_del')")
    public R removeById(@PathVariable Integer id) {
        return remoteDictExtensionService.removeById(id);
    }

    /**
     * 修改字典
     *
     * @param sysDict 字典信息
     * @return success/false
     */
    @PutMapping
    @SysLog("修改字典")
    @PreAuthorize("@pms.hasPermission('sys_dict_edit')")
    public R updateById(@Valid @RequestBody SysDict sysDict) {
        return remoteDictExtensionService.updateById(sysDict);
    }

    /**
     * 分页查询
     *
     * @param page        分页对象
     * @param sysDictItem 字典项
     * @return
     */
    @GetMapping("/item/page")
    public R getSysDictItemPage(Page page, SysDictItem sysDictItem) {
        return remoteDictExtensionService.getSysDictItemPage(sysDictItem, page.getCurrent(), page.getSize());
    }


    /**
     * 通过id查询字典项
     *
     //* @param id id
     * @return R
     */
    @GetMapping("/item/{id}")
    public R getDictItemById(@PathVariable("id") Integer id) {
        return remoteDictExtensionService.getDictItemById(id);
    }

    /**
     * 新增字典项
     *E
     * @param sysDictItem 字典项
     * @return R
     */
    @SysLog("新增字典项")
    @PostMapping("/item")
    public R save(@RequestBody SysDictItem sysDictItem) {
        return remoteDictExtensionService.save(sysDictItem);
    }

    /**
     * 修改字典项
     *
     * @param sysDictItem 字典项
     * @return R
     */
    @SysLog("修改字典项")
    @PutMapping("/item")
    public R updateById(@RequestBody SysDictItem sysDictItem) {

        return remoteDictExtensionService.updateById(sysDictItem);
    }

    /**
     * 通过id删除字典项
     *
     * @param id id
     * @return R
     */
    @SysLog("删除字典项")
    @DeleteMapping("/item/{id}")
    public R removeDictItemById(@PathVariable Integer id) {
        return remoteDictExtensionService.removeDictItemById(id);
    }
}
