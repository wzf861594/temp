package com.okay.rfid.info;

import java.util.Date;

/**
 * rfid_access
 * @author 
 */
public interface RfidAccess {

    String getId();

    String getRfid();

    String getAccessBusiness();

    String getType();

    Date getCreatedTime();

    String getCreatedBy();

    String getBusinessId();

    String getBusinessType();

}