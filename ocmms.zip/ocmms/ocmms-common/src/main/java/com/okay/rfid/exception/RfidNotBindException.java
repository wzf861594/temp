package com.okay.rfid.exception;

public class RfidNotBindException extends RfidException {

    public RfidNotBindException() {}

    public RfidNotBindException(String message) {
        super(message);
    }

    public RfidNotBindException(String message, Throwable cause) {
        super(message, cause);
    }

}
