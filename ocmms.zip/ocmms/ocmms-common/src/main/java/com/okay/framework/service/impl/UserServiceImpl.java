package com.okay.framework.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.okay.common.model.MetadataModel;
import com.okay.common.util.MetadataUtil;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.entity.dto.SysUserDTO;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.mapper.UserMapper;
import com.okay.framework.service.SequenceService;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.ComUtils;
import com.okay.framework.utils.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sun.misc.BASE64Encoder;

import java.util.*;

/**
 * @ClassName: UserServiceImpl
 * @Description: 用户实体业务类
 * @author: HQ.ZHU
 * @date: 2019-04-25 18:52
 * @version: V1.0
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SequenceService sequenceService;

    @Override
    public User getLoginUser() {
        return ComUtils.getLoginUser();
    }

    /**
     * @Author : xdn
     * @Description : 用户数据列表.
     * @Return : 返回查询的用户信息列表集合.
     **/
    @Override
    @Transactional
    public List<Map<String, String>> findDataListByPage(Page page) {
        List<Map<String, String>> userList = new ArrayList<Map<String, String>>();
        try {
            page.pageStart(true);
            userList = userMapper.selectDataList(page);
            page.pageEnd();
        } catch (Exception e) {
            if (page.getPageHelper() != null) page.getPageHelper().close();
            throw e;
        }
        return userList;
    }

    @Override
    public IPage<Map<String, Object>> contactUserList(com.baomidou.mybatisplus.extension.plugins.pagination.Page page, SysUserDTO sysUser) {
        MetadataModel model = MetadataUtil.getMetadataModel();

        IPage<Map<String, Object>> mapIPage = userMapper.contactUserList(page, sysUser);
        mapIPage.getRecords().stream().forEach(row -> {
            row.put("deptId", model.getDeptName((Integer) row.get("deptId")));
            row.put("sex", model.getDictName("gender", row.get("sex")+""));
            row.put("duty", model.getDictName("duty_type", row.get("duty") + ""));
        });
        return mapIPage;


    }

    /**
     * @Author : xdn
     * @Description : 根据单个ID查询.
     * @Return : 返回用户信息.
     **/
    @Override
    public User findUserById(String userId) {
        return userMapper.selectByPrimaryKey(userId);
    }

    /**
     * @Author : xdn
     * @Description : 用户新增
     * @Return : 返回新增用户信息.
     **/
    @Override
    public User add(User user) {
        //账号重复校验
        User existUser = userMapper.selectByAccount(user.getAccount());
        if (existUser != null) {
            throw new BaseRuntimeException(String.format(SysErrorDefine.EXIST_DATA_FAIL, "账号" + user.getAccount()));
        }
        try {
            user.setUserId(sequenceService.getSequence().toString());
            user.setHiredate(new Date());
            user.setPassWord("111111");
            user.setDutyState("1");
            user.setPassWord(MD5Utils.MD5Encode(user.getPassWord()));
            if (userMapper.insertSelective(user) != 1) {
                throw new RuntimeException();
            }
            ;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BaseRuntimeException(SysErrorDefine.ADD_DATA_ERROR);
        }
        return user;
    }

    /**
     * @Author : xdn
     * @Description : 用户删除
     * @Return :
     **/
    @Override
    @Transactional
    public void remove(Set<String> userIdList) {
        try {
            Map<String, Object> objectMap = new HashMap<String, Object>();
            objectMap.put("userIdList", userIdList);
            int handleNum = userMapper.deleteByParams(objectMap);
            if (handleNum == 0) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.REMOVE_DATA_ERROR);
        }
    }

    /**
     * @Author : xdn
     * @Description : 用户信息修改
     * @Return : 返回修改用户信息.
     **/
    @Override
    public User modifyUserInfo(User user) {
        String userId = user.getUserId();
        User userBase = userMapper.selectByPrimaryKey(userId);
        User newUser = new User();
        if (userBase != null) {
            newUser.setUserId(user.getUserId());
            newUser.setAccount(user.getAccount());
            newUser.setUserName(user.getUserName());
            newUser.setDeptId(user.getDeptId());
            newUser.setSex(user.getSex());
            newUser.setMobile(user.getMobile());
            newUser.setSeqNo(user.getSeqNo());
            newUser.setDuty(user.getDuty());
            int handleNum = userMapper.updateUserInfoByKey(newUser);
            if (handleNum == 0) {
                throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
            }
        } else {
            throw new BaseRuntimeException(SysErrorDefine.NOT_DATA_FAIL);
        }
        return newUser;
    }

    /**
     * @Author : xdn
     * @Description : 个人信息修改
     **/
    @Override
    public void modifyPersonalInfo(User user) {

        try {
            // 获取当前登录人
            User loginUser = this.getLoginUser();
            if (loginUser != null) {
                User newUser = new User();
                newUser.setUserId(loginUser.getUserId());
                newUser.setUserName(user.getUserName());
                newUser.setSex(user.getSex());
                newUser.setBirthday(user.getBirthday());
                newUser.setIdCard(user.getIdCard());
                newUser.setNativePlace(user.getNativePlace());
                newUser.setEmail(user.getEmail());
                newUser.setMobile(user.getMobile());
                Integer handleNum = userMapper.updatePersonalInfoByKey(newUser);
                if (handleNum == 0) {
                    throw new RuntimeException();
                }
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
        }
    }

    /**
     * @Author : xdn
     * @Description : 个人密码修改
     * @Return :
     **/
    @Override
    public void modifyPersonalPass(String oldPass, String newPass) {

        newPass = MD5Utils.MD5Encode(newPass);
        oldPass = MD5Utils.MD5Encode(oldPass);
        // 获取当前登录人
        User loginUser = this.getLoginUser();
        if (loginUser != null) {
            User user = findUserById(loginUser.getUserId());
            String pass = user.getPassWord();
            if (!oldPass.equals(pass)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHECK_DATA_LEGAL_FAIL, "原密码"));
            }
            User newUser = new User();
            newUser.setPassWord(newPass);
            newUser.setUserId(loginUser.getUserId());
            Integer handleNum = userMapper.updateByPrimaryKeySelective(newUser);
            if (handleNum == 0) {
                throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
            }
        }
    }

    /**
     * @Author : xdn
     * @Description : 部门调整
     * @Return :
     **/
    @Override
    @Transactional
    public void adjustDept(Set<String> userIdList, String deptId) {
        try {
            Map<String, Object> objectMap = new HashMap<String, Object>();
            objectMap.put("userIdList", userIdList);
            objectMap.put("deptId", deptId);
            Integer handleNum = userMapper.updateByParams(objectMap);
            if (userIdList.size() != handleNum) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
        }
    }

    /**
     * @Author : xdn
     * @Description : 注销用户
     * @Return :
     **/
    @Override
    @Transactional
    public void cancel(Set<String> userIdList) {
        try {
            Map<String, Object> objectMap = new HashMap<String, Object>();
            objectMap.put("userIdList", userIdList);
            objectMap.put("status", 0);
            Integer handleNum = userMapper.updateByParams(objectMap);
            if (userIdList.size() != handleNum) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.CANCEL_ERROR);
        }
    }

    /**
     * @Author : xdn
     * @Description : 取消注销
     * @Return :
     **/
    @Override
    public void unCancel(Set<String> userIdList) {
        try {
            Map<String, Object> objectMap = new HashMap<String, Object>();
            objectMap.put("userIdList", userIdList);
            objectMap.put("status", 1);
            Integer handleNum = userMapper.updateByParams(objectMap);
            if (userIdList.size() != handleNum) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
        }
    }

    /**
     * @Author : xdn
     * @Description : 锁定用户
     * @Return :
     **/
    @Override
    public void lock(Set<String> userIdList) {
        try {
            Map<String, Object> objectMap = new HashMap<String, Object>();
            objectMap.put("userIdList", userIdList);
            objectMap.put("isLock", 1);
            Integer handleNum = userMapper.updateByParams(objectMap);
            if (userIdList.size() != handleNum) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.LOCK_ERROR);
        }
    }

    /**
     * @Author : xdn
     * @Description : 解锁用户
     * @Return :
     **/
    @Override
    public void unLock(Set<String> userIdList) {
        try {
            Map<String, Object> objectMap = new HashMap<String, Object>();
            objectMap.put("userIdList", userIdList);
            objectMap.put("isLock", 0);
            Integer handleNum = userMapper.updateByParams(objectMap);
            if (userIdList.size() != handleNum) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.UNLOCK_ERROR);
        }
    }

    /**
     * @Author : xdn
     * @Description : 重置密码
     * @Return :
     **/
    @Override
    @Transactional
    public void resetPass(Set<String> userIdList) {
        try {
            Map<String, Object> objectMap = new HashMap<String, Object>();
            objectMap.put("userIdList", userIdList);
            objectMap.put("pass", MD5Utils.MD5Encode("111111"));
            Integer handleNum = userMapper.updateByParams(objectMap);
            if (userIdList.size() != handleNum) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.RESET_ERROR);
        }
    }

    @Override
    public void updateImage(User user) {
        try {
            userMapper.updateByPrimaryKeySelective(user);
        } catch (Exception e) {
            throw new BaseRuntimeException(SysErrorDefine.UPLOAD_DATA_ERROR);
        }
    }

    @Override
    public Map<String, Object> findUserForMapById(String userId) {
        Map<String, Object> userMap = userMapper.selectForMapById(userId);
        if (userMap != null) {
            byte[] imageByte = (byte[]) userMap.get("photo");
            String imageToBase64 = getUserPhoto(imageByte);
            userMap.put("userImage", imageToBase64);
        }
        return userMap;
    }

    @Override
    public List<User> findUserByDeptId(String deptId) {
        return userMapper.findUserByDeptId(deptId);
    }

    @Override
    public List<User> findUserByRoleId(String roleId) {
        return userMapper.findUserByRoleId(roleId);
    }

    @Override
    public List<User> findUserWithDeptByQuery(Map<String, Object> query) {
        return userMapper.selectUserWithDeptByQuery(query);
    }

    @Override
    public List<Map> findUserInDept(Map<String, Object> map) {
        return userMapper.selectUserInDept(map);
    }

    public String getUserPhoto(byte[] imageByte) {
        StringBuffer buffer = new StringBuffer();
        if (imageByte != null && !"".equals(imageByte)) {
            BASE64Encoder encoder = new BASE64Encoder();
            String image = encoder.encode(imageByte);
            buffer.append("data:image/jpeg;base64,");
            buffer.append(image);
        }
        return buffer.toString();
    }

}
