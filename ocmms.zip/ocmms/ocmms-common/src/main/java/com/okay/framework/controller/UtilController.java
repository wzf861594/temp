package com.okay.framework.controller;

import com.baomidou.mybatisplus.extension.api.R;
import com.okay.framework.utils.DateUtil;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.Objects;

/**
 * @Author CZJ[OKAY]
 * @Date 2020/7/18 14:29
 * @Description 工具类
 **/
@RestController
@RequestMapping("/util")
public class UtilController {
    /**
     * @param type 时间类型
     * @return R
     * @Description 获得服务器当前日期，以格式为：yyyy-MM-dd的日期字符串形式返回
     */
    @GetMapping("/getDate")
    public R getDate(@RequestParam("type") String type) {
        String nowTime = DateFormatUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss");
        if (Objects.equals(type, "date")) {
            nowTime = DateFormatUtils.format(new Date(), "yyyy-MM-dd");
        }
        return R.ok(nowTime).setMsg("");
    }

}
