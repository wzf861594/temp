package com.okay.framework.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Dept;
import com.okay.framework.entity.Page;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface DeptMapper extends BaseMapper<Dept> {

    int insert(Dept dept);

    int deleteByPrimaryKey(String deptId);

    int updateByPrimaryKey(Dept dept);

    // xdn
    int insertSelective(Dept dept);

    int updateByPrimaryKeySelective(Dept dept);

    Dept selectByPrimaryKey(String deptId);

    List<Dept> selectDataList(Page page);

    Map<String, Object> selectLinkDataByDeptId(String deptId);

    int deleteByParams(Map<String, Object> map);

    int updateByParams(Map<String, Object> map);

    List<DataTree> selectDeptToDeptDataTree();

    List<DataTree> recursionSelectDeptDataTree(String deptId);

    List<Dept> selectByDeptCode(String deptCode);

    List<Dept> selectByQueryMap(Map<String, Object> qeury);
}