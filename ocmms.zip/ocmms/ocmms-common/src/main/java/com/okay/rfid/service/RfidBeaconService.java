package com.okay.rfid.service;

import com.okay.rfid.info.RfidBeacon;
import com.okay.rfid.query.RfidBeaconQuery;

import java.util.Collection;
import java.util.List;

public interface RfidBeaconService {

    /**
     * 创建信标.
     * @param rfid 必填，同时只能存在一个RFID.
     * @param type RFID分类.
     * @param describe
     * @return
     */
    RfidBeacon createRfidBeacon(String rfid, String type, String describe);


    /**
     * 更新信标.
     * @param rfid 必填，根据RFID更新.
     * @param type RFID分类.
     * @param describe
     * @return
     */
    RfidBeacon updateRfidBeacon(String rfid, String type, String describe);


    /**
     * 批量创建信标.
     * @param rfids 只能同时存在一个RFID.
     * @param type RFID分类.
     * @param describe
     * @return
     */
    List<? extends RfidBeacon> createRfidBeacons(Collection<String> rfids, String type, String describe);


    /**
     * 批量更新信标.
     * @param rfids 只能同时存在一个RFID.
     * @param type 如果没有任何关联则为null，具体值根据业务输入.
     * @return
     */
    List<? extends RfidBeacon> updateRfidBeaconsType(Collection<String> rfids, String type);


    /**
     * 删除信标.
     * @param rfid
     * @return
     */
    RfidBeacon deleteRfidBeacon(String rfid);

    /**
     * 删除信标.
     * @param rfids
     * @return
     */
    List<? extends RfidBeacon> deleteRfidBeacons(Collection<String> rfids);

    /**
     * 获取信标.
     * @param rfid
     * @return
     */
    RfidBeacon getRfidBeacon(String rfid);


    RfidBeaconQuery createRfidBeaconQuery();

}
