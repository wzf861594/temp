package com.okay.framework.service;

import com.okay.framework.entity.Page;
import com.okay.framework.entity.ServerInfo;

import java.util.List;

/**
 * @Description:
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-18 16:31
 */

public interface ServerInfoService {

    ServerInfo findByServerInfoId(String serverInfoId);

    List<ServerInfo> findByPage(Page page);

    int updateByServerInfoIdSelective(ServerInfo serverInfo);

    int batchUpdateByServerInfoIdSelective(List<ServerInfo> serverInfoList);
}
