package com.okay.framework.controller;

import com.okay.framework.entity.Fun;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.exception.SequenceCreateException;
import com.okay.framework.exception.SysLogger;
import com.okay.framework.service.SequenceService;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.JSONTools;
import com.okay.framework.utils.WebUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 所有控制器的基类
 */
public class BaseController {
    /**
     * 公共日志对象
     */
    protected SysLogger logger = SysLogger.getSysLogger(BaseController.class);

    @Resource
    private SequenceService sequenceService;

    @Resource
    private UserService userService;

    protected HttpSession getSession() {
        return WebUtils.getSession();
    }

    protected HttpServletRequest getRequest() {
        return WebUtils.getRequest();
    }

    protected HttpServletResponse getResponse() {
        return WebUtils.getResponse();
    }

    /**
     * 获取当前登录用户
     * @return
     */
    protected User getLoginUser() {
        return userService.getLoginUser();
    }
    /**
     * 获取当前登录用的权限
     * @return
     */
    protected List<Fun> getFunInLoginUser() {
        return getLoginUser().getFunList();
    }

    /**
     * 获取序例
     * @param tableName
     * @return
     * @throws SequenceCreateException
     */
    protected Long getSequence(String tableName) throws SequenceCreateException {
        return sequenceService.getSequence(tableName);
    }

    /**
     * 获取序例
     * @return
     * @throws SequenceCreateException
     */
    protected String getSequence() {
        return sequenceService.getSequence();
    }

    /**
     * 转换page正常的返回数据
     * @return
     */
    protected String convertPageData(Page page) {
        return new JSONTools()
                .append("code", 0)
                .append("page", page.getPageNum())
                .append("limit", page.getPages())
                .append("count", page.getTotal())
                .append("data", page.getData())
                .toString();
    }
}
