package com.okay.common.model;

import java.io.Serializable;

/**
 * 记录进度的模型
 * @author ZHU.HQ
 * @date 2021/1/6 16:50
 */
public class ProgressModel implements Serializable {

    private final static long serialVersionUID = 1L;
    private int total = 0;
    private int current = 0;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) {
        this.current = current;
    }

    public void addCurrent(int current) {
        this.current += current;
    }
}
