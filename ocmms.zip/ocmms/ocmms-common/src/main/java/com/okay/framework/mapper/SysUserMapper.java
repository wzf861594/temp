package com.okay.framework.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.okay.framework.entity.SysUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author okay
 */
@Mapper
public interface SysUserMapper extends BaseMapper<SysUser> {

@Select("SELECT DISTINCT  user_id FROM sys_user")
List<Integer> getUserId();

}