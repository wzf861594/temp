package com.okay.rfid.impl.service;

import com.okay.rfid.entity.RfidBeaconEntity;
import com.okay.rfid.entity.RfidInfoEntity;
import com.okay.rfid.exception.RfidDeletedStateException;
import com.okay.rfid.exception.RfidException;
import com.okay.rfid.impl.entity.RfidInfoEntityImpl;
import com.okay.rfid.info.RfidInfo;
import com.okay.rfid.mapper.RfidBeaconMapperRfid;
import com.okay.rfid.mapper.RfidInfoMapperRfid;
import com.okay.rfid.impl.query.RfidInfoQueryImpl;
import com.okay.rfid.impl.entity.RfidBeaconEntityImpl.State;
import com.okay.rfid.mapper.RfidInfoQueryMapper;
import com.okay.rfid.query.RfidInfoQuery;
import com.okay.rfid.service.RfidInfoService;
import com.okay.rfid.util.Generate;
import com.okay.rfid.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class RfidInfoServiceImpl implements RfidInfoService {

    protected static final boolean DELETE_STATE_FALSE = false;

    protected static final boolean DELETE_STATE_TRUE = true;

    @Autowired
    protected RfidInfoMapperRfid rfidInfoMapper;

    @Autowired
    protected RfidBeaconMapperRfid rfidBeaconMapper;

    @Autowired
    protected RfidInfoQueryMapper rfidInfoQueryMapper;

    @Override
    @Transactional
    public RfidInfo createRfidInfo(String name, String rfid, String type, String businessId, String businessType, String createdBy, String describe) {
        if(StringUtil.isNull(name)) {
            throw new RfidException("name is null");
        }
        if(StringUtil.isNull(rfid)) {
            throw new RfidException( "RFID is null");
        }
        if(!StringUtil.isNull(businessId)) {
            if(StringUtil.isNull(businessType)) {
                throw new RfidException("businessType is null");
            }
        }
        if(rfidInfoMapper.selectByRfid(rfid) != null) {
            throw new RfidException("RFID已存在");
        }

        updateBeacon(rfid, State.BINDING);

        RfidInfoEntity infoEntity = new RfidInfoEntityImpl();
        infoEntity.setId(Generate.getNextId());
        infoEntity.setName(name);
        infoEntity.setRfid(rfid);
        infoEntity.setType(type);
        infoEntity.setBusinessId(businessId);
        infoEntity.setBusinessType(businessType);
        infoEntity.setDescribe(describe);
        infoEntity.setCreatedBy(createdBy);
        infoEntity.setCreatedTime(new Date());
        infoEntity.setLastUpdatedBy(createdBy);
        infoEntity.setLastUpdatedTime(new Date());
        infoEntity.setIsDelete(DELETE_STATE_FALSE);
        rfidInfoMapper.insert(infoEntity);

        return infoEntity;
    }

    @Override
    @Transactional
    public RfidInfo updateRfidInfo(String id, String name, String type, String lastUpdatedBy, String describe) {
        if(StringUtil.isNull(id)) {
            throw new RfidException("id is null");
        }
        if(StringUtil.isNull(name)) {
            throw new RfidException("name is null");
        }
        RfidInfoEntity infoEntity = rfidInfoMapper.selectByPrimaryKey(id);
        if(infoEntity == null) {
            throw new RfidException("不存在");
        }
        if(infoEntity.isDelete()) {
            throw new RfidDeletedStateException("删除状态");
        }

        infoEntity.setName(name);
        infoEntity.setType(type);
        infoEntity.setDescribe(describe);
        infoEntity.setLastUpdatedBy(lastUpdatedBy);
        infoEntity.setLastUpdatedTime(new Date());
        rfidInfoMapper.updateByPrimaryKey(infoEntity);

        return infoEntity;
    }

    @Override
    @Transactional
    public RfidInfo removeRfidInfo(String id, String lastUpdatedBy) {
        if(StringUtil.isNull(id)) {
            throw new RfidException("id is null");
        }
        RfidInfoEntity infoEntity = rfidInfoMapper.selectByPrimaryKey(id);
        if(infoEntity == null) {
            throw new RfidException("不存在");
        }
        if(infoEntity.isDelete()) {
            throw new RfidDeletedStateException("删除状态");
        }

        updateBeacon(infoEntity.getRfid(), State.DELETE);

        infoEntity.setIsDelete(DELETE_STATE_TRUE);
        infoEntity.setLastUpdatedBy(lastUpdatedBy);
        infoEntity.setLastUpdatedTime(new Date());
        rfidInfoMapper.updateByPrimaryKey(infoEntity);

        return infoEntity;
    }

    @Override
    @Transactional
    public RfidInfo deleteRfidInfo(String id) {
        if(StringUtil.isNull(id)) {
            throw new RfidException("id is null");
        }
        RfidInfoEntity infoEntity = rfidInfoMapper.selectByPrimaryKey(id);
        if(infoEntity == null) {
            throw new RfidException("不存在");
        }
        try {
            updateBeacon(infoEntity.getRfid(), State.DELETE);
        } catch (RfidDeletedStateException e) {
            // 不处理删除状态异常.
        }
        rfidInfoMapper.deleteByPrimaryKey(id);
        return infoEntity;
    }

    @Override
    public RfidInfo getRfidInfo(String id) {
        if(StringUtil.isNull(id)) {
            throw new RfidException("id is null");
        }
        return rfidInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public RfidInfoQuery createRfidInfoQuery() {
        return new RfidInfoQueryImpl(rfidInfoQueryMapper);
    }

    protected void updateBeacon(String rfid, State state) {
        RfidBeaconEntity beaconEntity = rfidBeaconMapper.selectByRfid(rfid);
        if(beaconEntity == null) {
            throw new RfidException("RFID不存在");
        }
        State currState = beaconEntity.getState() != null ? State.valueOf(beaconEntity.getState()) : null;
        if(currState != null && currState == state) {
            return;
        }
        if(State.DELETE == currState) {
            throw new RfidDeletedStateException("删除状态");
        }
        if(currState == null || (currState == State.BINDING && state != State.BINDING)) {
            beaconEntity.setState(state.name());
            beaconEntity.setUpdatedTime(new Date());
            rfidBeaconMapper.updateByPrimaryKey(beaconEntity);
        } else {
            throw new RfidException("state '" + currState + "' to '" + state + "' error");
        }
    }

}
