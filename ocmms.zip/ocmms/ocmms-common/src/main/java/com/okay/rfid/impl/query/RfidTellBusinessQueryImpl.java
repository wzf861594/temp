package com.okay.rfid.impl.query;


import com.okay.rfid.mapper.RfidTellBusinessQueryMapper;
import com.okay.rfid.query.RfidTellBusinessQuery;
import com.okay.rfid.query.result.RfidTellBusinessResult;

public class RfidTellBusinessQueryImpl extends RfidQueryImpl<RfidTellBusinessQueryImpl, RfidTellBusinessQuery, RfidTellBusinessResult> implements RfidTellBusinessQuery {

    private String tellLogId;

    protected RfidTellBusinessQueryImpl() {}

    public RfidTellBusinessQueryImpl(RfidTellBusinessQueryMapper mapper) {
        super(mapper);
    }

    @Override
    public RfidTellBusinessQuery tellLogId(String tellLogId) {
        RfidTellBusinessQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.tellLogId = tellLogId;
        return this;
    }

    @Override
    public RfidTellBusinessQuery orderByTimeDesc() {
        setOrderBy("timeDesc");
        return this;
    }

    public String getTellLogId() {
        return tellLogId;
    }

    public void setTellLogId(String tellLogId) {
        this.tellLogId = tellLogId;
    }
}
