package com.okay.rfid.impl.query;

import com.okay.rfid.impl.entity.RfidBeaconEntityImpl;
import com.okay.rfid.mapper.RfidBeaconQueryMapper;
import com.okay.rfid.query.RfidBeaconQuery;
import com.okay.rfid.query.result.RfidBeaconResult;

public class RfidBeaconQueryImpl extends RfidQueryImpl<RfidBeaconQueryImpl, RfidBeaconQuery, RfidBeaconResult> implements RfidBeaconQuery {

    private RfidBeaconEntityImpl.State state;

    protected RfidBeaconQueryImpl() {}

    public RfidBeaconQueryImpl(RfidBeaconQueryMapper mapper) {
        super(mapper);
    }

    @Override
    public RfidBeaconQuery state(String state) {
        RfidBeaconQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.state = RfidBeaconEntityImpl.State.valueOf(state);
        return this;
    }

    @Override
    public RfidBeaconQuery orderByUpdateTimeDesc() {
        setOrderBy("updateTimeDesc");
        return this;
    }

    public RfidBeaconEntityImpl.State getState() {
        return state;
    }

    public void setState(RfidBeaconEntityImpl.State state) {
        this.state = state;
    }

}
