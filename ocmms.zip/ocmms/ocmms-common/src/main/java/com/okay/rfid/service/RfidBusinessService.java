package com.okay.rfid.service;

import com.okay.rfid.entity.RfidBusinessEntity;
import com.okay.rfid.info.RfidBusiness;
import com.okay.rfid.query.RfidBusinessQuery;

public interface RfidBusinessService {

    RfidBusinessEntity newRfidBusiness();

    RfidBusinessEntity newRfidBusiness(RfidBusiness business);

    RfidBusiness createRfidBusiness(RfidBusinessEntity business);

    RfidBusiness updateRfidBusiness(RfidBusinessEntity business);

    RfidBusiness deleteRfidBusiness(RfidBusinessEntity business);

    RfidBusiness deleteRfidBusiness(String id);

    RfidBusiness getRfidBusiness(String id);

    RfidBusinessQuery createRfidBusinessQuery();

}
