package com.okay.rfid.query.result;

import com.okay.rfid.info.RfidTellLog;
import com.okay.rfid.entity.RfidTellLogEntity;

public interface RfidTellLogResult extends RfidTellLog {

    String getRfid();

    void setRfid(String rfid);

    String getName();

    void setName(String name);

    Integer getCountAllBusiness();

    void setCountAllBusiness(Integer countAllBusiness);

    Integer getCountBusiness();

    void setCountBusiness(Integer countBusiness);

    Integer getCountErrorBusiness();

    void setCountErrorBusiness(Integer countErrorBusiness);

}
