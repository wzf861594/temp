package com.okay.rfid.impl.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.okay.rfid.info.RfidBusiness;
import com.okay.rfid.entity.RfidBusinessEntity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

/**
 * rfid_business
 * @author 
 */
public class RfidBusinessEntityImpl implements RfidBusinessEntity, RfidBusiness, Serializable {
    /**
     * 主键
     */
    private String id;

    /**
     * 父级ID
     */
    private String parentId;

    /**
     * 业务ID
     */
    private String businessId;

    /**
     * 业务类型
     */
    private String businessType;

    /**
     * 业务人
     */
    private String businessBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createdTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updatedTime;

    /**
     * 是否完成
     */
    private Boolean isComplete;

    private static final long serialVersionUID = 1L;

    public RfidBusinessEntityImpl() {}

    public RfidBusinessEntityImpl(RfidBusiness business) {
        this.id = business.getId();
        this.parentId = business.getParentId();
        this.businessId = business.getBusinessId();
        this.businessType = business.getBusinessType();
        this.businessBy = business.getBusinessBy();
        this.createdTime = business.getCreatedTime();
        this.updatedTime = business.getUpdatedTime();
        this.isComplete = business.getIsComplete();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getParentId() {
        return parentId;
    }

    @Override
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    @Override
    public String getBusinessId() {
        return businessId;
    }

    @Override
    public void setBusinessId(String businessId) {
        this.businessId = businessId;
    }

    @Override
    public String getBusinessType() {
        return businessType;
    }

    @Override
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    @Override
    public String getBusinessBy() {
        return businessBy;
    }

    @Override
    public void setBusinessBy(String businessBy) {
        this.businessBy = businessBy;
    }

    @Override
    public Date getCreatedTime() {
        return createdTime;
    }

    @Override
    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public Date getUpdatedTime() {
        return updatedTime;
    }

    @Override
    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    @Override
    public Boolean getIsComplete() {
        return isComplete;
    }

    @Override
    public void setIsComplete(Boolean isComplete) {
        this.isComplete = isComplete;
    }

    @Override
    public boolean isComplete() {
        return isComplete;
    }

}