package com.okay.rfid.mapper;

import com.okay.rfid.query.RfidTellLogQuery;
import com.okay.rfid.query.result.RfidTellLogResult;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RfidTellLogQueryMapper extends QueryMapper<RfidTellLogQuery, RfidTellLogResult> {

}