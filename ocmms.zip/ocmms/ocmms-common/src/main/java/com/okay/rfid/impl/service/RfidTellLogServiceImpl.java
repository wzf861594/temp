package com.okay.rfid.impl.service;

import com.okay.rfid.mapper.RfidTellLogMapperRfid;
import com.okay.rfid.impl.query.RfidTellLogQueryImpl;
import com.okay.rfid.mapper.RfidTellLogQueryMapper;
import com.okay.rfid.query.RfidTellLogQuery;
import com.okay.rfid.service.RfidTellLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RfidTellLogServiceImpl implements RfidTellLogService {

    @Autowired
    protected RfidTellLogMapperRfid rfidTellLogMapper;

    @Autowired
    protected RfidTellLogQueryMapper rfidTellLogQueryMapper;

    @Override
    public RfidTellLogQuery createRfidTellLogQuery() {
        return new RfidTellLogQueryImpl(rfidTellLogQueryMapper);
    }
}
