package com.okay.framework.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.framework.entity.Message;
import com.okay.framework.entity.dto.MessageDTO;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @Author CZJ[OKAY]
 * @Date 2020/8/25 11:09
 * @Description 消息提醒Service
 **/
public interface MessageService {

    //新增
    int insert(MessageDTO dto);

    //修改
    int updateById(MessageDTO dto);

    //删除
    int deleteById(String id);

    //获取单个消息
    Message geMessage(String id);

    //获取多个项目信息
    IPage<Message> listMessage(Page page, MessageDTO dto);

    //修改消息为已读状态
    int updateRead(String id);

    /**
     * 获取未读消息
     *
     * @return R
     **/
    int getMessageNum();
}
