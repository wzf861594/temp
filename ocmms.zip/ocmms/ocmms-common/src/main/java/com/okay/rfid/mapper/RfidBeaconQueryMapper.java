package com.okay.rfid.mapper;

import com.okay.rfid.query.RfidBeaconQuery;
import com.okay.rfid.query.result.RfidBeaconResult;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface RfidBeaconQueryMapper extends QueryMapper<RfidBeaconQuery, RfidBeaconResult> {

}