package com.okay.framework.service.impl;

import com.okay.framework.entity.CustomObject;
import com.okay.framework.entity.CustomProperty;
import com.okay.framework.mapper.CustomObjectMapper;
import com.okay.framework.mapper.CustomPropertyMapper;
import com.okay.framework.service.CustomPropertyService;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.service.SequenceService;
import com.okay.framework.utils.ComUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-03 12:05
 */

@Service
public class CustomPropertyServiceImpl implements CustomPropertyService {

    @Autowired
    private CustomPropertyMapper customPropertyMapper;
    @Autowired
    private CustomObjectMapper customObjectMapper;
    @Autowired
    private SequenceService sequenceService;


    @Override
    public CustomProperty insert(CustomProperty customProperty) {

        if (StringUtils.isEmpty(customProperty.getCustomId())){
            customProperty.setCustomId(sequenceService.getSequence());
        }
        if (StringUtils.isEmpty(customProperty.getCreateUser())){
            User user = ComUtils.getLoginUser();
            customProperty.setCreateUser(user.getUserId());
        }
        if (customProperty.getCreateTime() == null){
            customProperty.setCreateTime(new Date());
        }
        customPropertyMapper.insert(customProperty);
        return customProperty;
    }

    @Override
    public CustomProperty update(CustomProperty customProperty) {
        if (StringUtils.isEmpty(customProperty.getUpdateUser())){
            User user = ComUtils.getLoginUser();
            customProperty.setUpdateUser(user.getUserId());
        }
        if (customProperty.getUpdateTime() == null){
            customProperty.setUpdateTime(new Date());
        }
        customPropertyMapper.updateByCustomResourceIdSelective(customProperty);
        return customProperty;
    }

    @Override
    public CustomProperty saveData(CustomProperty customProperty) {

        if (StringUtils.isEmpty(customProperty.getCustomResourceId())){
            throw new BaseRuntimeException("自定义资源主键不能为空");
        }
        List<CustomProperty> customPropertyList = customPropertyMapper.selectByCustomResourceId(customProperty.getCustomResourceId());

        if (customPropertyList != null && customPropertyList.size() > 0){
            update(customProperty);
        }else {
            insert(customProperty);
        }
        return customProperty;
    }

    @Override
    public List<CustomProperty> findByCustomResourceId(String customResourceId) {
        return customPropertyMapper.selectByCustomResourceId(customResourceId);
    }

    @Override
    public List<CustomObject> findAllCustomObject() {
        return customObjectMapper.selectAllObject();
    }
}
