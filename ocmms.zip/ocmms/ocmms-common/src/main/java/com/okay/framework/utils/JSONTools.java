package com.okay.framework.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName: JSONTools 
 * @Description: JSON工具类 
 * @author HQ.ZHU，wenlh
 * @date 2017年10月25日 15:48:33
 */
public class JSONTools {
	
	/**
	 * JSON 集合
	 */
	private Map<String, Object> jsonMap = new HashMap<String, Object>();
	
	public JSONTools() {
		jsonMap = new HashMap<String, Object>();
	}
	
	public JSONTools(Map<String, Object> map) {
		jsonMap = map;
	}
	
	/**
	 * 追加JSON属性
	 * @param key
	 * @param value
	 * @return
	 */
	public JSONTools append(String key, Object value){
		jsonMap.put(key, value);
		return this;
	}
	
	/**
	 * 成功的JSON
	 * @return
	 */
	public String successJson(){
		return this.append("state", true).toString();
	}
	
	/**
	 * 失败的JSON
	 * @param msg
	 * @return
	 */
	public String failJson(String msg){
		return this.append("state", false).append("msg", msg).toString();
	}
	
	/**
	 * 返回JSON格式串
	 */
	@Override
	public String toString() {
		return JSONObject.toJSONString(jsonMap, SerializerFeature.WriteMapNullValue);
	}
	
	/**
	 * 返回Map对象.
	 * @return
	 * @author wenlh
	 * @date 2017年10月24日 14:03:55
	 */
	public Map<String, Object> toMap() {
		return this.jsonMap;
	}
	
	/**
	 * 返回json对象.
	 * @return
	 * @author wenlh
	 * @date 2017年10月24日 14:03:37
	 */
	public JSONObject toJson() {
		return new JSONObject(this.jsonMap);
	}
	
	/**
	 * 成功结果.
	 * @return
	 * @author wenlh
	 * @date 2017年10月24日 14:02:32
	 */
	public JSONTools success(){
		return this.append("state", true);
	}
	
	/**
	 * 失败结果.
	 * @param msg 失败的信息.
	 * @return
	 * @author wenlh
	 * @date 2017年10月24日 14:02:46
	 */
	public JSONTools fail(String msg){
		return this.append("state", false).append("msg", msg);
	}
	
	public JSONTools clean() {
		jsonMap.clear();
		return this;
	}

	/**
	 * 格式化对象为JSON
	 * @param object
	 * @return
	 */
	public static String format(Object object){
		if(object instanceof Collection) {
			return JSONArray.toJSONString(object, SerializerFeature.WriteMapNullValue);
		}else{
			return JSONObject.toJSONString(object, SerializerFeature.WriteMapNullValue);
		}
	}
}
