package com.okay.framework.entity.dto;

import com.okay.framework.entity.SysUser;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户表(SysUser)实体类
 *
 * @author makejava（zyx）
 * @since 2020-09-12 14:06:40
 */
@Data
public class SysUserDTO extends SysUser {
    private String chineseName;
}