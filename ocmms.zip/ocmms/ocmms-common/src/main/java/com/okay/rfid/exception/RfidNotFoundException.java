package com.okay.rfid.exception;

public class RfidNotFoundException extends RfidException {

    public RfidNotFoundException() {}

    public RfidNotFoundException(String message) {
        super(message);
    }

    public RfidNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
