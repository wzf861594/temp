package com.okay.rfid.query.result;

import com.okay.rfid.info.RfidAccess;
import com.okay.rfid.entity.RfidAccessEntity;

public interface RfidAccessResult extends RfidAccess {

    String getName();

    void setName(String name);
}
