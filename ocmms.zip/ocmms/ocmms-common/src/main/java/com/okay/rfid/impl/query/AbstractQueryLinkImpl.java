package com.okay.rfid.impl.query;

import com.okay.rfid.query.QueryLinkCondition;
import com.okay.rfid.query.QueryLink;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractQueryLinkImpl<C extends QueryLinkCondition, O, R> extends AbstractQueryImpl<R> implements QueryLink<O> {

    private List<C> queryObjects;

    private C currQueryObject;

    public AbstractQueryLinkImpl() {
        this(null, null);
    }

    public AbstractQueryLinkImpl(C currQueryObject) {
        this(null, currQueryObject);
    }

    public AbstractQueryLinkImpl(List<C> queryObjects, C currQueryObject) {
        this.queryObjects = queryObjects;
        init(currQueryObject);
    }

    public AbstractQueryLinkImpl(List<C> queryObjects) {
        this(queryObjects, null);
    }

    private void init(C currQueryObject) {
        this.currQueryObject = currQueryObject;
        if(currQueryObject != null) {
            loadQueryObjects().add(currQueryObject);
        } else {
            try {
                this.currQueryObject = (C) this;
                loadQueryObjects().add(this.currQueryObject);
            } catch (Exception e) {}
        }
    }

    @Override
    public O or() {
        currQueryObject = newQueryObject();
        currQueryObject.setInOrCondition(true);
        currQueryObject.setLinkOrCondition(true);
        loadQueryObjects().add(currQueryObject);
        return (O)this;
    }

    @Override
    public O and() {
        currQueryObject = newQueryObject();
        loadQueryObjects().add(currQueryObject);
        return (O)this;
    }

    @Override
    public O andOr() {
        currQueryObject = newQueryObject();
        currQueryObject.setInOrCondition(true);
        loadQueryObjects().add(currQueryObject);
        return (O) this;
    }

    @Override
    public O orAnd() {
        currQueryObject = newQueryObject();
        currQueryObject.setLinkOrCondition(true);
        loadQueryObjects().add(currQueryObject);
        return (O) this;
    }

    @Override
    public O endLink() {
        currQueryObject = newQueryObject();
        loadQueryObjects().add(currQueryObject);
        return (O) this;
    }

    private List<C> loadQueryObjects() {
        if(queryObjects == null) {
            queryObjects = new ArrayList<>();
        }
        return queryObjects;
    }

    protected abstract C newQueryObject();

    public C getCurrQueryObject() {
        return currQueryObject;
    }

    public void setCurrQueryObject(C currQueryObject) {
        this.currQueryObject = currQueryObject;
    }

    public List<C> getQueryObjects() {
        return queryObjects;
    }

    public void setQueryObjects(List<C> queryObjects) {
        this.queryObjects = queryObjects;
    }

}
