package com.okay.rfid.support;

public interface AsyncExecute {

}
