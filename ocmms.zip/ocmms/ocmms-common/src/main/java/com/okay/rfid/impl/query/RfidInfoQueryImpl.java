package com.okay.rfid.impl.query;

import com.okay.rfid.mapper.RfidInfoQueryMapper;
import com.okay.rfid.query.RfidInfoQuery;
import com.okay.rfid.query.result.RfidInfoResult;


public class RfidInfoQueryImpl extends RfidQueryImpl<RfidInfoQueryImpl, RfidInfoQuery, RfidInfoResult> implements RfidInfoQuery {

    protected RfidInfoQueryImpl() {}

    public RfidInfoQueryImpl(RfidInfoQueryMapper mapper) {
        super(mapper);
        setDeleted(false);
    }

    @Override
    public RfidInfoQuery orderByLastUpdateTimeDesc() {
        setOrderBy("lastUpdateTimeDesc");
        return this;
    }

    @Override
    public RfidInfoQuery includeDeleted() {
        setDeleted(null);
        return this;
    }
}
