package com.okay.common.constants;

/**
 * @author ZHU.HQ
 * @date 2020/7/3 6:28
 */
public interface ServiceNameConstants {

    /*********************************************** feign接口服务-Start ***********************************************/
    /**
     * 数字资源接口服务
     */
    String DR_SERVICE = "ocmms-dr";
    /**
     * 藏品系统接口服务
     */
    String CP_SERVICE = "ocmms-cp";
    /**
     * 数字资源接口服务
     */
    String OA_SERVICE = "ocmms-oa";
    /**
     * 数字资源接口服务
     */
    String PORTAL_SERVICE = "ocmms-portal";
    /*********************************************** feign接口服务-End ***********************************************/

    /*********************************************** 系统前辍标识-Start ***********************************************/
    /**
     * 数字资源接口服务
     */
    String DR_PREFIX = "/ocmms-dr";
    /**
     * 藏品系统接口服务
     */
    String CP_PREFIX = "/ocmms-cp";
    /**
     * 数字资源接口服务
     */
    String OA_PREFIX = "/ocmms-oa";
    /**
     * 数字资源接口服务
     */
    String PORTAL_PREFIXE = "/ocmms-portal";
    /*********************************************** 系统前辍标识-End ***********************************************/
}
