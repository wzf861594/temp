package com.okay.rfid.exception;

public class RfidNotFoundAccessException extends RfidException {
    public RfidNotFoundAccessException() {}

    public RfidNotFoundAccessException(String message) {
        super(message);
    }

    public RfidNotFoundAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
