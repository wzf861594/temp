package com.okay.rfid.impl.query.result;

import com.okay.rfid.impl.entity.RfidInfoEntityImpl;
import com.okay.rfid.query.result.RfidBusinessData;
import com.okay.rfid.query.result.RfidInfoResult;

public class RfidInfoResultImpl extends RfidInfoEntityImpl implements RfidInfoResult, RfidBusinessData {

    private Object businessData;

    @Override
    public Object getBusinessData() {
        return businessData;
    }

    @Override
    public void setBusinessData(Object data) {
        businessData = data;
    }
}
