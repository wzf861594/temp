package com.okay.rfid.mapper;

import com.okay.rfid.entity.RfidBeaconEntity;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface RfidBeaconMapperRfid extends RfidBaseMapper<RfidBeaconEntity> {

    RfidBeaconEntity selectByRfid(String rfid);

}