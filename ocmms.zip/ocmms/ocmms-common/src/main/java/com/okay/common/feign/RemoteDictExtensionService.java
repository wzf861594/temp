package com.okay.common.feign;

import com.okay.okay.admin.api.entity.SysDict;
import com.okay.okay.admin.api.entity.SysDictItem;
import com.okay.okay.admin.api.metadata.DictInfo;
import com.okay.okay.common.core.constant.ServiceNameConstants;
import com.okay.okay.common.core.util.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author ZHU.HQ
 * @date 2020/7/2 10:58
 */
@FeignClient(contextId = "remoteDictExtensionService", value = ServiceNameConstants.UPMS_SERVICE)
public interface RemoteDictExtensionService {

    @GetMapping("/metadata/dict/all")
    R<List<DictInfo>> getAllDicts();

    @RequestMapping("/dict/{dictType}/{value}")
    R getDictByType(@PathVariable("dictType") String dictType, @PathVariable("value") String value);

    /**
     * 通过ID查询字典信息
     *
     * @param id ID
     * @return 字典信息
     */
    @GetMapping("/dict/{id}")
    R getById(@PathVariable("id") Integer id);

    /**
     * 分页查询字典信息
     *
     * @param sysDict
     * @param current
     * @param size
     * @return
     */
    @GetMapping("/dictExtension/page")
    R getDictPage(@RequestBody SysDict sysDict, @RequestParam("current") Long current, @RequestParam("size") Long size);

    /**
     * 通过字典类型查找字典
     *
     * @param type 类型
     * @return 同类型字典
     */
    @GetMapping("/dict/type/{type}")
    R getDictByType(@PathVariable("type") String type);

    /**
     * 添加字典
     *
     * @param sysDict 字典信息
     * @return success、false
     */
    @PostMapping("/dict")
    R save(@RequestBody SysDict sysDict);

    /**
     * 删除字典，并且清除字典缓存
     *
     * @param id ID
     * @return R
     */
    @DeleteMapping("/dict/{id}")
    R removeById(@PathVariable("id") Integer id);

    /**
     * 修改字典
     *
     * @param sysDict 字典信息
     * @return success/false
     */
    @PutMapping("/dict")
    R updateById(@RequestBody SysDict sysDict);

    /**
     * 分页查询
     *
     * @param sysDictItem
     * @param current
     * @param size
     * @return
     */
    @GetMapping("/dictExtension/item/page")
    R getSysDictItemPage(@RequestBody SysDictItem sysDictItem, @RequestParam("current") Long current, @RequestParam("size") Long size);


    /**
     * 通过id查询字典项
     *
     * @param id id
     * @return R
     */
    @GetMapping("/dict/item/{id}")
    R getDictItemById(@PathVariable("id") Integer id);

    /**
     * 新增字典项
     *
     * @param sysDictItem 字典项
     * @return R
     */
    @PostMapping("/dict/item")
    R save(@RequestBody SysDictItem sysDictItem);

    /**
     * 修改字典项
     *
     * @param sysDictItem 字典项
     * @return R
     */
    @PutMapping("/dict/item")
    R updateById(@RequestBody SysDictItem sysDictItem);

    /**
     * 通过id删除字典项
     *
     * @param id id
     * @return R
     */
    @DeleteMapping("/dict/item/{id}")
    R removeDictItemById(@PathVariable("id") Integer id);
}
