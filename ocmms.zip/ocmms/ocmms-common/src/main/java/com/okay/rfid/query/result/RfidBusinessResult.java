package com.okay.rfid.query.result;

import com.okay.rfid.info.RfidBusiness;
import com.okay.rfid.entity.RfidBusinessEntity;

import java.util.Collection;

public interface RfidBusinessResult extends RfidBusiness {

    Collection<RfidBusinessResult> getSubset();

    void setSubset(Collection<RfidBusinessResult> subset);
}
