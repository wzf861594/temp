package com.okay.framework.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.okay.framework.entity.SysUserRole;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author CZJ
 */
@Mapper
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {
}