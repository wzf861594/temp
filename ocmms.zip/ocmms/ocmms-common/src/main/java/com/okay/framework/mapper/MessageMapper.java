package com.okay.framework.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.okay.framework.entity.Message;

/**
 * @Author CZJ[OKAY]
 * @Date 2020/8/25 11:07
 * @Description 消息提醒mapper
 **/
public interface MessageMapper extends BaseMapper<Message> {
}
