package com.okay.common.model;

import com.okay.common.util.MetadataUtil;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.okay.admin.api.metadata.DeptInfo;
import com.okay.okay.admin.api.metadata.DictInfo;
import com.okay.okay.admin.api.metadata.DictItemInfo;
import com.okay.okay.admin.api.metadata.UserInfo;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * 元数据模型：MetadataModel
 * 装载了部门、用户、字典的元数据
 * 并且提供便捷的工具方法
 *
 * @author ZHU.HQ
 * @date 2020/7/7 20:19
 */
public class MetadataModel {

    private List<UserInfo> userInfoList;
    private List<DeptInfo> deptInfoList;
    private List<DictInfo> dictInfoList;

    /**
     * 根据userId获取UserInfo
     *
     * @param userId
     * @return
     */
    public UserInfo getUserInfo(Integer userId) {
        if (userInfoList == null)
            userInfoList = MetadataUtil.getAllUsers();
        for (UserInfo userInfo : userInfoList) {
            if (userInfo.getUserId().equals(userId))
                return userInfo;
        }
        return null;
    }

    /**
     * 获取用户中文名称
     *
     * @param userId
     * @return
     */
    public String getUserName(Integer userId) {
        if (userInfoList == null)
            userInfoList = MetadataUtil.getAllUsers();
        for (UserInfo userInfo : userInfoList) {
            if (userInfo.getUserId().equals(userId))
                return userInfo.getChineseName();
        }
        return "";
    }

    /**
     * 获取用户中文名称
     *
     * @param userId
     * @return
     */
    public String getUserName(String userId) {
        if (userInfoList == null)
            userInfoList = MetadataUtil.getAllUsers();
        for (UserInfo userInfo : userInfoList) {
            if (Objects.equals(String.valueOf(userInfo.getUserId()), userId))
                return userInfo.getChineseName();
        }
        return "";
    }

    /**
     * * 批量获取用户中文名称
     *
     * @param userIds
     * @author: xiandn
     * @return: 返回用户中文名的List集合.
     */
    public List<String> getUserNameList(String userIds) {
        if (StringUtils.isEmpty(userIds)) {
            throw new BaseRuntimeException("查询用户主键为空");
        }
        if (userInfoList == null) {
            userInfoList = MetadataUtil.getAllUsers();
        }

        List<String> userNameList = new ArrayList<String>();
        List<String> userIdList = Arrays.asList(userIds.split(","));
        for (String userId : userIdList) {
            if (StringUtils.isEmpty(userId)) {
                continue;
            }
            for (UserInfo userInfo : userInfoList) {
                if (userInfo.getUserId().equals(Integer.valueOf(userId))) {
                    userNameList.add(userInfo.getChineseName());
                    break;
                }
            }
        }
        return userNameList;
    }

    /**
     * 根据deptId获取DeptInfo
     *
     * @param deptId
     * @return
     */
    public DeptInfo getDeptInfo(Integer deptId) {
        if (deptInfoList == null)
            deptInfoList = MetadataUtil.getAllDepts();
        for (DeptInfo deptInfo : deptInfoList) {
            if (deptInfo.getDeptId().equals(deptId))
                return deptInfo;
        }
        return null;
    }

    /**
     * 获取部门中文名称
     *
     * @param deptId
     * @return
     */
    public String getDeptName(Integer deptId) {
        if (deptInfoList == null)
            deptInfoList = MetadataUtil.getAllDepts();
        for (DeptInfo deptInfo : deptInfoList) {
            if (deptInfo.getDeptId().equals(deptId))
                return deptInfo.getName();
        }
        return "";
    }

    /**
     * 获取字典翻译数据
     *
     * @param type
     * @param value
     * @return
     */
    public String getDictName(String type, String value) {
        if (dictInfoList == null)
            dictInfoList = MetadataUtil.getAllDicts();
        for (DictInfo dictInfo : dictInfoList) {
            if (dictInfo.getType().equals(type)) {
                List<DictItemInfo> dictItemInfoList = dictInfo.getDictItemInfoList();
                for (DictItemInfo dictItemInfo : dictItemInfoList) {
                    if (dictItemInfo.getValue().equals(value))
                        return dictItemInfo.getLabel();
                }
            }
        }
        return "";
    }

    public List<UserInfo> getUserInfoList() {
        return userInfoList;
    }

    public void setUserInfoList(List<UserInfo> userInfoList) {
        this.userInfoList = userInfoList;
    }

    public List<DeptInfo> getDeptInfoList() {
        return deptInfoList;
    }

    public void setDeptInfoList(List<DeptInfo> deptInfoList) {
        this.deptInfoList = deptInfoList;
    }

    public List<DictInfo> getDictInfoList() {
        return dictInfoList;
    }

    public void setDictInfoList(List<DictInfo> dictInfoList) {
        this.dictInfoList = dictInfoList;
    }
}
