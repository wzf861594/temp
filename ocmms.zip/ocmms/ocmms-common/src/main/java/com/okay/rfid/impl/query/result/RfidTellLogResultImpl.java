package com.okay.rfid.impl.query.result;

import com.okay.rfid.impl.entity.RfidTellLogEntityImpl;
import com.okay.rfid.query.result.RfidTellLogResult;

public class RfidTellLogResultImpl extends RfidTellLogEntityImpl implements RfidTellLogResult {

    private String rfid;
    private String name;
    private Integer countAllBusiness;
    private Integer countBusiness;
    private Integer countErrorBusiness;

    @Override
    public String getRfid() {
        return rfid;
    }

    @Override
    public void setRfid(String rfid) {
        this.rfid = rfid;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Integer getCountAllBusiness() {
        return countAllBusiness;
    }

    @Override
    public void setCountAllBusiness(Integer countAllBusiness) {
        this.countAllBusiness = countAllBusiness;
    }

    @Override
    public Integer getCountBusiness() {
        return countBusiness;
    }

    @Override
    public void setCountBusiness(Integer countBusiness) {
        this.countBusiness = countBusiness;
    }

    @Override
    public Integer getCountErrorBusiness() {
        return countErrorBusiness;
    }

    @Override
    public void setCountErrorBusiness(Integer countErrorBusiness) {
        this.countErrorBusiness = countErrorBusiness;
    }
}
