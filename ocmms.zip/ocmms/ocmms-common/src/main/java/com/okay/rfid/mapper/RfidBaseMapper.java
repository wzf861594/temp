package com.okay.rfid.mapper;

public interface RfidBaseMapper<E> {

    int deleteByPrimaryKey(String id);

    int insert(E record);

    E selectByPrimaryKey(String id);

    int updateByPrimaryKey(E record);

}