package com.okay.common.feign;

import com.okay.okay.admin.api.entity.SysDept;
import com.okay.okay.admin.api.metadata.DeptInfo;
import com.okay.okay.common.core.constant.ServiceNameConstants;
import com.okay.okay.common.core.util.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @author ZHU.HQ
 * @date 2020/6/23 9:11
 */
@FeignClient(contextId = "remoteDeptExtensionService", value = ServiceNameConstants.UPMS_SERVICE)
public interface RemoteDeptExtensionService {

	@PostMapping("/dept")
    R user(@RequestBody SysDept sysDept);

    @GetMapping("/metadata/dept/all")
    R<List<DeptInfo>> getAllDepts();
}
