package com.okay.rfid.query.result;

import com.okay.rfid.info.RfidBeacon;
import com.okay.rfid.entity.RfidBeaconEntity;

public interface RfidBeaconResult extends RfidBeacon {

    String getName();

    void setName(String name);

}
