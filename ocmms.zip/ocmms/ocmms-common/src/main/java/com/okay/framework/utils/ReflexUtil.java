package com.okay.framework.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @ClassName: ReflexUtil
 * @Description: 反射操作工具.
 * @author: wenlh
 * @date: 2019年4月28日 15:27:19
 * @version: V1.0
 */
public final class ReflexUtil {
	
	private ReflexUtil () {}
	
	/**
	 * @MethodName: synInvoke
	 * @Description: 同步访问操作,匹配模式采用方法名匹配,如果操作对象里存在重载方法就可能会出现异常.
	 * @param obj 操作的对象.
	 * @param methodName 方法名称.
	 * @param param 方法参数
	 * @return
	 * @throws Exception
	 * @author wenlh
	 * @date 2017年10月27日 18:58:06
	 */
	public final synchronized static Object synInvoke(Object obj, String methodName, Object ... param) throws Exception {
		return invoke(obj, methodName, param);
	}

	/**
	 * @MethodName: invoke
	 * @Description: 同步访问操作,匹配模式采用方法名匹配,如果操作对象里存在重载方法就可能会出现异常.
	 * @param obj 操作的对象.
	 * @param methodName 方法名称.
	 * @param param 方法参数
	 * @return
	 * @throws Exception
	 * @author wenlh
	 * @date 2017年10月27日 18:58:06
	 */
	public final static Object invoke(Object obj, String methodName, Object ... param) throws Exception {
		try {
			Class<?> cla = obj.getClass();
			if(param != null && param.length != 0) {
				Method[] methods = cla.getMethods();
				for(int i = 0 ; i < methods.length ; i ++) {
					Method method = methods[i];
					if(method.getName().equals(methodName)) {
						return method.invoke(obj, param);
					}
				}
			} else {
				Method method = cla.getMethod(methodName);
				return method.invoke(obj);
			}
			
		} catch (InvocationTargetException e) {
			try {
				throw e.getTargetException();
			} catch (Throwable e1) {
				throw new Exception(e1.getMessage());
			}
		}
		return null;
	}
}
