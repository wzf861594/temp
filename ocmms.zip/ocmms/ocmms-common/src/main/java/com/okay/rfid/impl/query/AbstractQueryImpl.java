package com.okay.rfid.impl.query;

import com.okay.rfid.query.Query;

import java.util.List;

public abstract class AbstractQueryImpl<R> extends QueryPropertyObject implements Query<R> {

    @Override
    public Page<R> list(int pageNum, int pageSize) {

        if(pageNum <= 0) {
            pageNum = 1;
        }
        if(pageSize <= 0 || pageSize > Integer.MAX_VALUE) {
            pageSize = Integer.MAX_VALUE;
        }

        setFirstResult((pageNum-1) * pageSize);
        setMaxResults(pageSize);
        initQueryProperty();

        long total = executeCount();
        Page page = new Page(pageNum, pageSize, total > 0 ? (int)(total/pageSize) + ((total%pageSize) == 0 ? 0 : 1) : 0, total, null);
        if(total > 0) {
            List<R> result = execute();
            if(result != null) {
                page.addAll(result);
            }
        }
        return page;
    }

    @Override
    public List<R> list() {
        return execute();
    }

    @Override
    public R singleResult() {
        List<R> result = execute();
        if(result != null && result.size() > 1) {
            throw new RuntimeException("there are multiple");
        }
        return result == null || result.isEmpty() ? null : result.get(0);
    }

    @Override
    public long count() {
        return executeCount();
    }

    private void initQueryProperty() {
        setLimitAfter("LIMIT #{maxResults} OFFSET #{firstResult}");
    }

    protected abstract List<R> execute();

    protected abstract long executeCount();

}
