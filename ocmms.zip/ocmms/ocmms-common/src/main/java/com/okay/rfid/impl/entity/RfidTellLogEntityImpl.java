package com.okay.rfid.impl.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.okay.rfid.info.RfidTellLog;
import com.okay.rfid.entity.RfidTellLogEntity;

import java.io.Serializable;
import java.util.Date;

/**
 * rfid_tell_log
 * @author 
 */
public class RfidTellLogEntityImpl implements RfidTellLogEntity, RfidTellLog, Serializable {

    public enum State {
        DENIED,
        NORMAL,
        ERROR
    }

    /**
     * 主键
     */
    private String id;

    /**
     * RFID信标ID
     */
    private String beaconId;

    /**
     * 设备ID
     */
    private String deviceId;

    /**
     * 时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date time;

    /**
     * 操作人
     */
    private String operator;

    private State state;

    private static final long serialVersionUID = 1L;

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getBeaconId() {
        return beaconId;
    }

    @Override
    public void setBeaconId(String beaconId) {
        this.beaconId = beaconId;
    }

    @Override
    public String getDeviceId() {
        return deviceId;
    }

    @Override
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    @Override
    public Date getTime() {
        return time;
    }

    @Override
    public void setTime(Date time) {
        this.time = time;
    }

    @Override
    public String getOperator() {
        return operator;
    }

    @Override
    public String getState() {
        return state != null ? state.name() : null;
    }

    @Override
    public void setOperator(String operator) {
        this.operator = operator;
    }

    @Override
    public void setState(String state) {
        this.state = state != null ? State.valueOf(state) : null;
    }

}