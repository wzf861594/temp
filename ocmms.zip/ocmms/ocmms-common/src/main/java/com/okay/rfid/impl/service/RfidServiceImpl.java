package com.okay.rfid.impl.service;

import com.okay.rfid.exception.*;
import com.okay.rfid.factory.RfidAccessFactory;
import com.okay.rfid.impl.DefaultRfidTellBusiness;
import com.okay.rfid.impl.DefaultRfidTelllog;
import com.okay.rfid.impl.entity.RfidBeaconEntityImpl;
import com.okay.rfid.impl.entity.RfidTellLogEntityImpl;
import com.okay.rfid.info.RfidAccess;
import com.okay.rfid.info.RfidBeacon;
import com.okay.rfid.info.RfidInfo;
import com.okay.rfid.mapper.*;
import com.okay.rfid.service.RfidService;
import com.okay.rfid.support.AsyncExecute;
import com.okay.rfid.impl.DefaultRfidExecute;
import com.okay.rfid.util.Generate;
import com.okay.rfid.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.concurrent.*;

@Service
public class RfidServiceImpl implements RfidService {

    protected static final boolean STATE_FALSE = false;

    protected static final boolean STATE_TRUE = true;

    @Autowired
    protected RfidBeaconMapperRfid rfidBeaconMapper;

    @Autowired
    protected RfidInfoMapperRfid rfidInfoMapper;

    @Autowired
    protected RfidTellLogMapperRfid rfidTellLogMapper;

    @Autowired
    protected RfidAccessMapperRfid rfidAccessMapper;

    @Autowired
    protected RfidTellBusinessMapperRfid rfidTellBusinessMapper;

    @Autowired
    protected RfidServiceImpl rfidServiceImpl;

    protected ExecutorService executorService;

    @Override
    public void execute(String rfid, String deviceId, String operator, Object param) {
        if(StringUtil.isNull(rfid)) {
            throw new RfidNullException("RFID不能为空");
        }
        RfidBeacon beacon = rfidBeaconMapper.selectByRfid(rfid);
        if(beacon == null) {
            throw new RfidNotFoundException("RFID不存在");
        }
        if(beacon.getState() == null) {
            throw new RfidNotBindException("RFID未绑定");
        }

        // 对类型进行区分处理.
        RfidBeaconEntityImpl.State currState = beacon.getState() != null ? RfidBeaconEntityImpl.State.valueOf(beacon.getState()) : null;
        switch(currState) {
            case ACCESS:
                handleAccess(beacon, deviceId, operator, param);
                break;
            case BINDING:
                handleUse(beacon, deviceId, operator, param);
                break;
            case DELETE:
                handleDelete(beacon, deviceId, operator, param);
                break;
            default:
                throw new RfidNotFoundException("未找到处理类型");
        }
    }

    protected void handleAccess(RfidBeacon beacon, String deviceId, String operator, Object param) {
        String rfid = beacon.getRfid();
        List<? extends RfidAccess> accessList = rfidAccessMapper.selectByRfid(rfid);
        handle(beacon, null, accessList, deviceId, operator, param);
    }

    protected void handleUse(RfidBeacon beacon, String deviceId, String operator, Object param) {
        String rfid = beacon.getRfid();
        RfidInfo info = rfidInfoMapper.selectByRfid(rfid);
        if(info == null) {
            throw new RfidNotFoundException("RFID不存在");
        }
        List<? extends RfidAccess> accessList = rfidAccessMapper.selectByRfid(rfid);
        handle(beacon, info, accessList, deviceId, operator, param);
    }

    protected void handleDelete(RfidBeacon beacon, String deviceId, String operator, Object param) {
        throw new RfidDeletedStateException("删除状态");
    }

    protected void handle(RfidBeacon beacon, RfidInfo info, List<? extends RfidAccess> accessList, String deviceId, String operator, Object param) {
        // 创建日志. 无论如何都要保存日志.
        DefaultRfidTelllog tellLog = createTellLog(beacon.getId(), deviceId, operator);
        // 创建业务执行回溯列表.
        List<DefaultRfidTellBusiness> tellBusinessList = new ArrayList<>();

        try {
            // 检测是否接入业务.
            if(accessList == null || accessList.isEmpty()) {
                throw new RfidNotFoundAccessException("没有接入业务");
            }
            for(RfidAccess access : accessList) {
                DefaultRfidTellBusiness tellBusiness = createTellBusiness(tellLog.getId(), access.getAccessBusiness(), param);
                tellBusinessList.add(tellBusiness);

                rfidServiceImpl.executeBusiness(info, access, tellLog, tellBusiness);
            }
        } catch (RfidNotFoundAccessException e) {
            tellLog.setState(RfidTellLogEntityImpl.State.DENIED.name());
            throw e;
        } catch (Throwable e) {
            tellLog.setState(RfidTellLogEntityImpl.State.ERROR.name());
            throw e;
        } finally {
            rfidServiceImpl.saveTellLog(tellLog, tellBusinessList);
        }
    }

    protected DefaultRfidTelllog createTellLog(String beaconId, String deviceId, String operator) {
        DefaultRfidTelllog tellLog = new DefaultRfidTelllog();
        tellLog.setId(Generate.getNextId());
        tellLog.setBeaconId(beaconId);
        tellLog.setDeviceId(deviceId);
        tellLog.setOperator(operator);
        tellLog.setTime(new Date());
        tellLog.setState(RfidTellLogEntityImpl.State.NORMAL.name());
        return tellLog;
    }

    protected DefaultRfidTellBusiness createTellBusiness(String tellLogId, String accessBusiness, Object param) {
        DefaultRfidTellBusiness tellBusiness = new DefaultRfidTellBusiness();
        tellBusiness.setId(Generate.getNextId());
        tellBusiness.setTellLogId(tellLogId);
        tellBusiness.setAccessBusiness(accessBusiness);
        tellBusiness.setIsAsync(STATE_FALSE);
        tellBusiness.setIsError(STATE_FALSE);
        return tellBusiness;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void saveTellLog(DefaultRfidTelllog tellLog, List<DefaultRfidTellBusiness> tellBusiness) {
        rfidTellLogMapper.insert(tellLog);
        if(tellBusiness != null) {
            for(DefaultRfidTellBusiness record : tellBusiness) {
                rfidTellBusinessMapper.insert(record);
            }
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void executeBusiness(RfidInfo info, RfidAccess access, DefaultRfidTelllog tellLog, DefaultRfidTellBusiness tellBusiness) {
        try {
            String accessBusiness = tellBusiness.getAccessBusiness();

            Collection<Runnable> baseRunnables = RfidAccessFactory.getMatch(accessBusiness);
            if(baseRunnables == null || baseRunnables.isEmpty()) {
                throw new RfidException("RFIDAccessFactory '" + accessBusiness + "' not found");
            }

            for(Runnable baseRunnable : baseRunnables) {
                run(baseRunnable, info, access, tellLog, tellBusiness);
            }
        } catch (Throwable e) {
            tellBusiness.setIsError(STATE_TRUE);
            tellBusiness.setExceptionType(e.getClass().getSimpleName());
            tellBusiness.setExceptionMsg(e.getMessage() != null ? e.getMessage().length() > 4000 ? e.getMessage().substring(0, 3999):e.getMessage() : null);
            throw e;
        }
    }

    protected void run(Runnable baseRunnable, RfidInfo info, RfidAccess access, DefaultRfidTelllog tellLog, DefaultRfidTellBusiness tellBusiness) {
        Runnable runnable = baseRunnable;
        if(baseRunnable instanceof DefaultRfidExecute) {
            runnable = ((DefaultRfidExecute)baseRunnable).createSupport(info, access, tellLog, tellBusiness);
        }

        if(baseRunnable instanceof AsyncExecute) {
            if(executorService == null) {
                initExecutors();
            }

            Runnable finalRunnable = runnable;
            executorService.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        finalRunnable.run();
                    } catch (Throwable e) {
                        tellBusiness.setIsError(STATE_TRUE);
                        tellBusiness.setExceptionType(e.getClass().getSimpleName());
                        tellBusiness.setExceptionMsg(e.getMessage() != null ? e.getMessage().length() > 4000 ? e.getMessage().substring(0, 3999):e.getMessage() : null);
                        try {
                            rfidTellBusinessMapper.updateByPrimaryKey(tellBusiness);
                        } catch (Throwable e1) {}
                    }
                }
            });
            tellBusiness.setIsAsync(STATE_TRUE);
        } else {
            runnable.run();
        }
    }

    protected synchronized void initExecutors() {
        if(executorService == null) {
            executorService = new ThreadPoolExecutor(2, Runtime.getRuntime().availableProcessors(),
                    0, TimeUnit.SECONDS,
                    new ArrayBlockingQueue<>(256),
                    new ThreadPoolExecutor.DiscardPolicy());
        }
    }
}
