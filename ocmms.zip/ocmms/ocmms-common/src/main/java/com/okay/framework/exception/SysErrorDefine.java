package com.okay.framework.exception;

/***
 * 系统错误定义
 * 错误代码由 固定3位数+n位 构成
 * 错误代码的组成为：模块代码(2位)+错误级别(1位)+错误代码(n位)
 * 模块代码(2位)：
 * 01 门户
 * 02 数字资源
 * 03 藏品
 * 04 OA
 * 05 框架
 * 06 流程引擎
 * 07 自定义表单
 * 错误级别(1位)：
 * 1 正常
 * 2 警告
 * 3 询问
 * 4 错误
 * 5 会话失效[TOKEN失效，回到登录页面]
 * 错误代码(n位) ：
 * 可自行定义
 */
public class SysErrorDefine {

    /**
     * 非自定义异常 默认提示异常代码
     **/
    public static final String SYSTEM_ERROR_CODE = "0541";

    /**
     * 非自定义异常 默认提示异常信息
     **/
    public static final String SYSTEM_ERROR_MSG = "程序异常，请联系管理员！";

    /***************************代码 1 正常（建议SUCCESS结尾）*********************************/
    public static final String ADD_DATA_SUCCESS = "【051001】新增成功";
    public static final String UPDATE_SUCCESS = "【051002】更新成功！";
    public static final String DELETE_SUCCESS = "【051003】删除成功！";
    public static final String CANCEL_SUCCESS = "【051004】注销成功！";
    public static final String RESET_SUCCESS = "【051005】重置成功！";
    public static final String LOCK_SUCCESS = "【051006】锁定成功！";
    public static final String UNLOCK_SUCCESS = "【051007】解锁成功！";
    public static final String SAVE_SUCCESS = "【051008】保存成功！";
    public static final String RECOVER_SUCCESS = "【051009】恢复成功！";
    public static final String PUBLIC_SUCCESS = "【051010】发布成功！";
    public static final String UPLOAD_SUCCESS = "【051011】上传成功！";

    /***************************代码 2 警告（建议FAIL结尾）*********************************/
    public static final String CHOOSE_HANDLE_DATA = "【052001】请选择%s操作数据！";
    public static final String CHECK_NOT_NULL = "【052002】%s为必填项！";
    public static final String CHECK_DATA_LEGAL_FAIL = "【052003】输入的%s不正确！";
    public static final String NOT_DATA_FAIL = "【052004】无对应数据！";
    public static final String EXIST_DATA_FAIL = "【052005】%s已存在！";
    public static final String PARAM_ISNULL_FAIL = "【052006】参数%s不能空！";
    public static final String NOT_INTEGER_TYPE_FAIL = "【052007】参数%s必须是整数类型！";
    public static final String USER_OR_PASSWORD_ISNULL_FAIL = "【052008】用户名或密码不能为空！";
    public static final String REMOVE_LINKED_DATA_FAIL = "【052009】该数据存在关联的数据，不能删除！请先删除关联的数据，再删除该数据。";
    public static final String HANDLE_DATA_FAIL = "【052102】该数据不可执行%s操作。";
    public static final String OVER_LENGTH_FAIL = "【052103】%s已经超过了长度限制";
    public static final String RECOVER_FAIL = "【052104】使用的列表数据已满，无法恢复数据！";
    public static final String PASS_FAIL = "【052105】两次输入的新密码不一致！";

    /***************************代码 3 询问（建议ASK开头）*********************************/
    public static final String ASK_HANDLE_DEL = "【053001】是否删除？";
    public static final String ASK_HANDLE_CANCEl = "【053002】是否注销？";
    public static final String ASK_HANDLE_UNCANCEl = "【053003】是否取消注销？";
    public static final String ASK_HANDLE_RESET = "【053004】是否重置密码？";
    public static final String ASK_HANDLE_LOCK = "【053005】是否锁定用户？";
    public static final String ASK_HANDLE_UNLOCK = "【053006】是否解锁用户？";
    public static final String ASK_HANDLE_CANCEL = "【053007】是否撤销？";
    public static final String ASK_RECOVER_DELETE = "【053008】是否恢复删除数据？";

    /***************************代码 4 错误（建议ERROR结尾）*********************************/
    public static final String ADD_DATA_ERROR = "【054001】新增失败！";
    public static final String MODIFY_DATA_ERROR = "【054002】修改失败！";
    public static final String REMOVE_DATA_ERROR = "【054003】删除失败！";
    public static final String CANCEL_ERROR = "【054004】注销失败！";
    public static final String RESET_ERROR = "【054005】重置失败！";
    public static final String LOCK_ERROR = "【054006】锁定失败！";
    public static final String UNLOCK_ERROR = "【054007】解锁失败！";
    public static final String USER_NOT_EXIST_ERROR = "【054008】用户不存在！";
    public static final String PASSWORD_ERROR = "【054009】密码不正确！";
    public static final String AUTOCODE_NOT_FOUND_ERROR = "【054010】编码类型为[%s]自动编码策略不存在,请先配置";
    public static final String AUTOCODE_ILLEGAL_ERROR = "【054011】自动编号配置错误,非法扩展信息[%s]";
    public static final String RECOVER_DATA_ERROR = "【054012】恢复失败！";
    public static final String UPLOAD_DATA_ERROR = "【054013】上传失败！";
    public static final String PUBLIC_ERROR = "【054014】发布失败！";
    public static final String REPEAL_ERROR = "【054015】撤销失败！";
    public static final String SAVE_ERROR = "【054016】保存失败！";

    /***************************代码 5 错误（建议ERROR结尾）*********************************/
    public static final String SESSION_INVALIDATION_ERROR = "【05501】登录超时，请重新登录！";
}
