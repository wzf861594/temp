package com.okay.rfid.entity;

import com.okay.rfid.info.RfidBeacon;

import java.util.Date;

/**
 * rfid_beacon
 * @author 
 */
public interface RfidBeaconEntity extends RfidBeacon {

    void setId(String id);

    void setRfid(String rfid);

    void setType(String type);

    void setDescribe(String describe);

    void setState(String state);

    void setCreatedBy(String createdBy);

    void setCreatedTime(Date createdTime);

    void setUpdatedBy(String updatedBy);

    void setUpdatedTime(Date updatedTime);

}