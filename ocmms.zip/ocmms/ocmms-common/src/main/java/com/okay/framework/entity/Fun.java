package com.okay.framework.entity;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Fun implements Serializable {
    /**
	 * 列序化ID
	 */
	private static final long serialVersionUID = 3346918667487822157L;

	private String funId;

    @NotBlank(message = "功能名称不能为空")
    private String funName;

    @NotBlank(message = "功能编码不能为空")
    private String funCode;

    private Integer funType;

    private String url;

    private String path;

    private String component;

    private String icon;

    private String parentId;

    //是否记录日起，默认1为记录。
    private Integer isLogger;

    private String event;

    private String javaScript;

    private String exParam;

    //是否隐藏
    private Integer isHide;

    //同级下的分组
    private Integer groups;

    private Integer seqNo;

    //是否默认功能
    private Integer isPower;

    private String remark;

    private String portalIcon;

    //记录用户当前选中的功能菜单
    private boolean selected;

    //子功能菜单集
    private List<Fun> childrenList = new ArrayList<Fun>();
    
    public String getFunId() {
        return funId;
    }

    public void setFunId(String funId) {
        this.funId = funId;
    }

    public String getFunName() {
        return funName;
    }

    public void setFunName(String funName) {
        this.funName = funName;
    }

    public String getFunCode() {
        return funCode;
    }

    public void setFunCode(String funCode) {
        this.funCode = funCode;
    }

    public Integer getFunType() {
        return funType;
    }

    public void setFunType(Integer funType) {
        this.funType = funType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Integer getIsLogger() {
        return isLogger;
    }

    public void setIsLogger(Integer isLogger) {
        this.isLogger = isLogger;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getJavaScript() {
        return javaScript;
    }

    public void setJavaScript(String javaScript) {
        this.javaScript = javaScript;
    }

    public String getExParam() {
        return exParam;
    }

    public void setExParam(String exParam) {
        this.exParam = exParam;
    }

    public Integer getIsHide() {
        return isHide;
    }

    public void setIsHide(Integer isHide) {
        this.isHide = isHide;
    }

    public Integer getGroups() {
        return groups;
    }

    public void setGroups(Integer groups) {
        this.groups = groups;
    }

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public Integer getIsPower() {
        return isPower;
    }

    public void setIsPower(Integer isPower) {
        this.isPower = isPower;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getPortalIcon() {
        return portalIcon;
    }

    public void setPortalIcon(String portalIcon) {
        this.portalIcon = portalIcon;
    }

    public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public List<Fun> getChildrenList() {
		return childrenList;
	}

	public void setChildrenList(List<Fun> childrenList) {
		this.childrenList = childrenList;
	}  
    
}