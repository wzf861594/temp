package com.okay.rfid.service;

import com.okay.rfid.query.RfidTellLogQuery;

public interface RfidTellLogService {

    RfidTellLogQuery createRfidTellLogQuery();

}
