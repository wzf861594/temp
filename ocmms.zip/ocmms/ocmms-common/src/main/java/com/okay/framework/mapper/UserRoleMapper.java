package com.okay.framework.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.okay.framework.entity.SysUserRole;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author okay
 */
@Mapper
public interface UserRoleMapper extends BaseMapper<SysUserRole> {

}