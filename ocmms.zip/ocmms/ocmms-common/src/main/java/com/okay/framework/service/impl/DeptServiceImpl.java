package com.okay.framework.service.impl;

import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Dept;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.mapper.DeptMapper;
import com.okay.framework.service.DeptService;
import com.okay.framework.service.SequenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @ClassName: DeptServiceImpl
 * @Description: 类描述信息
 * @author: HQ.ZHU
 * @date: 2019-04-25 18:51
 * @version: V1.0
 */
@Service
public class DeptServiceImpl implements DeptService {

    @Autowired
    private DeptMapper deptMapper;

    @Autowired
    private SequenceService sequenceService;

    /**
      *@Author : xdn
      *@Description : 部门数据列表
      *@Return :
      **/
    @Override
    public List<Dept> findDataListByPage(Page page) {
        List<Dept> deptList = null;
        try {
            page.pageStart(true);
            deptList = deptMapper.selectDataList(page);
            page.pageEnd();
        } catch (Exception e) {
            if(page.getPageHelper() != null) page.getPageHelper().close();
            throw e;
        }
        return deptList;
    }

    /**
      *@Author : xdn
      *@Description : 根据id查询部门信息
      *@Return :
      **/
    @Override
    public Map<String,Object> findDataMapById(String deptId) {
        return deptMapper.selectLinkDataByDeptId(deptId);
    }

    /**
      *@Author : xdn
      *@Description : 部门新增
      *@Return :
      **/
    @Override
    public Dept add(Dept dept) {
        List<Dept> existDept = deptMapper.selectByDeptCode(dept.getDeptCode());
        if (existDept != null && existDept.size() > 0){
            throw new BaseRuntimeException(String.format(SysErrorDefine.EXIST_DATA_FAIL,"编码" + dept.getDeptCode()));
        }

        dept.setDeptId(sequenceService.getSequence().toString());
        Integer handleNum = deptMapper.insertSelective(dept);
        if (handleNum != 1){
            throw new BaseRuntimeException(SysErrorDefine.ADD_DATA_ERROR);
        }
        return dept;
    }

    /**
      *@Author : xdn
      *@Description : 部门修改
      *@Return :
      **/
    @Override
    public void modify(Dept dept) {
        Dept baseDept = deptMapper.selectByPrimaryKey(dept.getDeptId());
        if (baseDept != null){
            Dept newDept = new Dept();
            newDept.setDeptId(dept.getDeptId());
            newDept.setDeptName(dept.getDeptName());
            newDept.setDeptCode(dept.getDeptCode());
            newDept.setDeptType(dept.getDeptType());
            newDept.setManager(dept.getManager());
            newDept.setLeader(dept.getLeader());
            newDept.setSeqNo(dept.getSeqNo());
            newDept.setParentId(dept.getParentId());
            newDept.setRemark(dept.getRemark());
            Integer handleNum = deptMapper.updateByPrimaryKeySelective(newDept);
            if (handleNum != 1){
                throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
            }
        }
    }

    /**
      *@Author : xdn
      *@Description : 部门删除
      *@Return :
      **/
    @Override
    @Transactional
    public void remove(Set<String> deptIdList) {

        try{
            Map<String,Object> objectMap = new HashMap<String,Object>();
            objectMap.put("deptIdList",deptIdList);
            int handleNum = deptMapper.deleteByParams(objectMap);
            if (handleNum == 0){
                throw new RuntimeException();
            }
        }catch (Exception e){
            throw new BaseRuntimeException(SysErrorDefine.REMOVE_DATA_ERROR);
        }

    }

    /**
      *@Author : xdn
      *@Description : 部门注销
      *@Return :
      **/
    @Override
    @Transactional
    public void cancel(Set<String> deptIdList) {
        try{
            Map<String,Object> objectMap = new HashMap<String,Object>();
            objectMap.put("deptIdList",deptIdList);
            objectMap.put("status",0);
            int handleNum = deptMapper.updateByParams(objectMap);
            if (handleNum == 0){
                throw new RuntimeException();
            }
        }catch (Exception e){
            throw new BaseRuntimeException(SysErrorDefine.CANCEL_ERROR);
        }
    }

    /**
      *@Author : xdn
      *@Description : 注销部门恢复
      *@Return :
      **/
    @Override
    @Transactional
    public void recover(Set<String> deptIdList) {
        try{
            Map<String,Object> objectMap = new HashMap<String,Object>();
            objectMap.put("deptIdList",deptIdList);
            objectMap.put("status",1);
            int handleNum = deptMapper.updateByParams(objectMap);
            if (handleNum == 0){
                throw new RuntimeException();
            }
        }catch (Exception e){
            throw new BaseRuntimeException(SysErrorDefine.RECOVER_DATA_ERROR);
        }
    }

    /**
      *@Author : xdn
      *@Description : 部门树查询
      *@Return :
      **/
    @Override
    public List<DataTree> findDataTreeList() {
        return deptMapper.selectDeptToDeptDataTree();
    }

    /**
      *@Author : xdn
      *@Description : 根据父节点查询
      *@Return :
      **/
    @Override
    public List<DataTree> findDataTreeListByDeptId(String deptId) {
        return deptMapper.recursionSelectDeptDataTree(deptId);
    }

    @Override
    public List<Dept> findDataListByQuery(Map<String, Object> qeury) {
        return deptMapper.selectByQueryMap(qeury);
    }
}
