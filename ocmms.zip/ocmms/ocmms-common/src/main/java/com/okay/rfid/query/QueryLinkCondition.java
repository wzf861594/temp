package com.okay.rfid.query;

public interface QueryLinkCondition {

    boolean getInOrCondition();

    void setInOrCondition(boolean inOrCondition);

    boolean getLinkOrCondition();

    void setLinkOrCondition(boolean linkOrCondition);
}
