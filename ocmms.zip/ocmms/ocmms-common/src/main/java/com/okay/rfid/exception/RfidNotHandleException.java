package com.okay.rfid.exception;

public class RfidNotHandleException extends RfidException {
    public RfidNotHandleException() {}

    public RfidNotHandleException(String message) {
        super(message);
    }

    public RfidNotHandleException(String message, Throwable cause) {
        super(message, cause);
    }
}
