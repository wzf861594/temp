package com.okay.framework.entity;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

public class Role implements Serializable {
    /**
	 * 列序化ID
	 */
	private static final long serialVersionUID = -4871566725849267119L;

	private String roleId;

    private String roleCode;

    @NotBlank(message = "角色名称不能为空")
    private String roleName;

    private String parentId;

    private Integer seqNo;

    private Integer status;

    private Integer isCancel;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIsCancel() {
        return isCancel;
    }

    public void setIsCancel(Integer isCancel) {
        this.isCancel = isCancel;
    }
}