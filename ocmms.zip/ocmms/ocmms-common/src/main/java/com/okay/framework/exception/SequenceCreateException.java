package com.okay.framework.exception;

/**
 * @ClassName: SequenceCreateException
 * @Description: 序列生成器自定义异常
 * @author: HQ.ZHU
 * @date: 2019-04-21 1:33
 * @version: V1.0
 */
public class SequenceCreateException extends Exception{
    public SequenceCreateException() {
        super();
    }

    public SequenceCreateException(String message) {
        super(message);
    }

    public SequenceCreateException(String message, Throwable cause) {
        super(message, cause);
    }

    public SequenceCreateException(Throwable cause) {
        super(cause);
    }

    protected SequenceCreateException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
