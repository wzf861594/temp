package com.okay.framework.service;

import com.okay.framework.entity.SysUserRole;

import java.util.List;

/**
 * 用户角色表表服务接口
 *
 * @author okay
 * @time 2021年10月25日12:41:30
 */
public interface UserRoleService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return SysUserRole 实例对象
     */
    SysUserRole getByUserId(Integer userId);

    /**
     * 根据角色主键获取数据列表
     *
     * @param roleId 主键
     * @return List 角色对应的提示bean的List集合.
     */
    List<SysUserRole> getByRoleId(Integer roleId);

    /**
     * 保存角色用户.
     *
     * @param roleId     角色主键.
     * @param userIdList 用户主键List集合.
     * @return boolean 返回操作是否成功.
     */
    boolean saveRoleUser(Integer roleId, List<Integer> userIdList);
}