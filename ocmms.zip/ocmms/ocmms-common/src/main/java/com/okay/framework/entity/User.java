package com.okay.framework.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.Transient;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@TableName("v_sys_user")
public class User implements Cloneable, Serializable {
    /**
     * 列序化ID
     */
    private static final long serialVersionUID = 8559950740402320822L;

    @TableField("userId")
    private String userId;

    @NotBlank(message = "用户名不能为空")
    private String account;

    @NotBlank(message = "用户账号不能为空")
    @TableField("userName")
    private String userName;

    @TableField("pwd")
    private String passWord;

    @TableField("idCard")
    @Pattern(regexp = "(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)", message = "身份证号不正确")
    private String idCard;

    private Integer sex;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthday;

    @Pattern(regexp = "^1[3456789]\\d{9}$", message = "手机号不正确")
    private String mobile;

    @TableField("homePhone")
    private String homePhone;

    @TableField("workPhone")
    private String workPhone;

    @Email(message = "邮箱格式不正确")
    private String email;

    private String address;

    @TableField("postCode")
    private String postCode;

    private Integer political;

    private Integer nation;

    @TableField("nativePlace")
    private String nativePlace;

    private Integer duty;

    @TableField(exist = false)
    private String dutyShow;

    @TableField("dutyState")
    private String dutyState;

    @TableField("deptId")
    private String deptId;

    @TableField(exist = false)
    private String deptName;

    private Integer marriage;

    private Integer health;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date hiredate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date termdate;

    @TableField("seqNo")
    @Min(value = 0, message = "序号为空或者不小于0的数值")
    private Integer seqNo;

    private String status;

    @TableField("isLock")
    private String isLock;

    private String remark;

    private byte[] photo;

    @TableField(exist = false)
    private Dept dept;

    @TableField(exist = false)
    private List<Fun> funList = new ArrayList<>();

    @ApiModelProperty(value = "开始时间")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd", iso = DateTimeFormat.ISO.DATE)
    @TableField(exist = false)
    private Date startTime;

    @ApiModelProperty(value = "结束时间")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd", iso = DateTimeFormat.ISO.DATE)
    @TableField(exist = false)
    private Date endTime;

}