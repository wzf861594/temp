package com.okay.rfid.mapper;

import com.okay.rfid.entity.RfidTellBusinessEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RfidTellBusinessMapperRfid extends RfidBaseMapper<RfidTellBusinessEntity> {

}