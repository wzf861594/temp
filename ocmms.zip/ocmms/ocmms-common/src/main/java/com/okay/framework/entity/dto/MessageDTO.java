package com.okay.framework.entity.dto;

import com.okay.framework.entity.Message;
import lombok.Data;

/**
 * @Author CZJ[OKAY]
 * @Date 2020/8/25 11:13
 * @Description 消息提醒dto
 **/
@Data
public class MessageDTO extends Message {
}
