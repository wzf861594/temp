package com.okay.framework.service.impl;

import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.Role;
import com.okay.framework.mapper.RoleMapper;
import com.okay.framework.service.RoleService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: RoleServiceImpl
 * @Description: 角色管理业务类
 * @author: HQ.ZHU
 * @date: 2019-04-25 18:52
 * @version: V1.0
 */
@Service
public class RoleServiceImpl implements RoleService {
    @Resource
    private RoleMapper roleMapper;

    @Override
    @Transactional
    public Page findList(Page page) {
        try {
            page.pageStart(true);
            roleMapper.selectDataList(page);
            page.pageEnd();
        } catch (Exception e) {
            if(page.getPageHelper() != null) page.getPageHelper().close();
            throw e;
        }
        return page;
    }

    @Override
    @Transactional
    public Role findById(String id) {
        return roleMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<String> findSelectedUser(String roleId) {
        return roleMapper.selectSelectedUser(roleId);
    }

    @Override
    public List<DataTree> findDataTreeList() {
        return roleMapper.selectDataTreeList();
    }

    @Override
    @Transactional
    public Integer add(Role role) {
        return roleMapper.insertSelective(role);
    }


    @Override
    @Transactional
    public Integer modify(Role role) {
        return roleMapper.updateByPrimaryKey(role);
    }

    @Override
    @Transactional
    public Integer remove(String id) {
        return roleMapper.deleteByPrimaryKey(id);
    }

    @Override
    @Transactional
    public int removeBatch(ArrayList<String> idList) {
        return roleMapper.deleteBatch(idList);
    }

    @Override
    public int removeUserFormRole(String roleId, List<String> userIdList) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("roleId", roleId);
        map.put("userIdList", userIdList);
        return roleMapper.deleteUserFromRole(map);
    }

    @Override
    @Transactional
    public int cancel(Role role) {
        return roleMapper.updateByPrimaryKey(role);
    }

    @Override
    @Transactional
    public int recover(Role role) {
        return roleMapper.updateStatusByPrimaryKey(role);
    }

    @Override
    @Transactional
    public void savePermission(String id, List<Map<String, String>> rolePermissionList) {
        roleMapper.deleteRolePermissionById(id);
        if (rolePermissionList != null & rolePermissionList.size() > 0) {
            roleMapper.insertBatchRolePermission(rolePermissionList);
        }
    }

    @Override
    public void saveSelectedUsers(String roleId, List<Map<String, String>> roleUserList) {
        roleMapper.deleteUserRole(roleId);
        if (roleUserList != null & roleUserList.size() > 0) {
            roleMapper.insertBatchUserRole(roleUserList);
        }
    }

}
