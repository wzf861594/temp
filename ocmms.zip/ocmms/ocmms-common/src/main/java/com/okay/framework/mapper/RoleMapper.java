package com.okay.framework.mapper;

import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.Role;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Mapper
public interface RoleMapper {

    List<Page> selectDataList(Page page);

    List<String> selectSelectedUser(String roleId);

    List<DataTree> selectDataTreeList();

    Role selectByPrimaryKey(String roleId);

    int insert(Role role);

    int insertSelective(Role role);

    int insertBatchRolePermission(List<Map<String, String>> permissionIds);

    int insertBatchUserRole(@Param("list") List<Map<String, String>> roleUserList);

    int updateByPrimaryKeySelective(Role role);

    int updateByPrimaryKey(Role role);

    int updateStatusByPrimaryKey(Role role);

    int deleteByPrimaryKey(String roleId);

    int deleteBatch(ArrayList<String> idList);

    int deleteRolePermissionById(String id);

    int deleteUserRole(String roleId);

    int deleteUserFromRole(Map<String, Object> map);

}