package com.okay.common.feign;

import com.okay.okay.admin.api.dto.UserDTO;
import com.okay.okay.admin.api.metadata.UserInfo;
import com.okay.okay.common.core.constant.ServiceNameConstants;
import com.okay.okay.common.core.util.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author ZHU.HQ
 * @date 2020/7/2 10:58
 */
@FeignClient(contextId = "remoteUserExtensionService", value = ServiceNameConstants.UPMS_SERVICE)
public interface RemoteUserExtensionService {
    @PostMapping("/user")
    R user(@RequestBody UserDTO userDto);

//    @GetMapping("/user/info/{username}")
//    R<UserInfo> info(@PathVariable("username") String username, @RequestHeader(SecurityConstants.FROM) String from);

    @PutMapping("/user")
    R modify(@RequestBody UserDTO userDTO);

    @GetMapping("/userExtension/getUsers")
    R getUsers(@RequestParam("userIds") String userIds);

    @GetMapping("/metadata/user/all")
    R<List<UserInfo>> getAllUsers();

    @GetMapping("/userExtension/userId/{userId}")
    R getByUserId(@RequestParam("userId") Integer userId);

}
