package com.okay.rfid.exception;

public class RfidNullException extends RfidException {

    public RfidNullException() {}

    public RfidNullException(String message) {
        super(message);
    }

    public RfidNullException(String message, Throwable cause) {
        super(message, cause);
    }

}
