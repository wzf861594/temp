package com.okay.rfid.impl.query;

import com.okay.rfid.mapper.RfidBusinessQueryMapper;
import com.okay.rfid.query.RfidBusinessQuery;
import com.okay.rfid.query.result.RfidBusinessResult;

import java.util.List;

public class RfidBusinessQueryImpl extends RfidQueryImpl<RfidBusinessQueryImpl, RfidBusinessQuery, RfidBusinessResult> implements RfidBusinessQuery {

    private boolean putAllSubset;

    private RfidBusinessQueryMapper mapper;

    protected RfidBusinessQueryImpl() {}

    public RfidBusinessQueryImpl(RfidBusinessQueryMapper mapper) {
        super(mapper);
        this.mapper = mapper;
    }

    @Override
    protected List<RfidBusinessResult> execute() {
        if(isPutAllSubset()) {
            return mapper.selectQueryIncludeAllSubset(this);
        } else {
            return super.execute();
        }
    }

    @Override
    public RfidBusinessQuery putAllSubset() {
        RfidBusinessQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.putAllSubset = true;
        return this;
    }

    public boolean isPutAllSubset() {
        return putAllSubset;
    }

    public void setPutAllSubset(boolean putAllSubset) {
        this.putAllSubset = putAllSubset;
    }
}
