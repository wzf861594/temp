package com.okay.rfid.impl.query;

public class QueryPropertyObject {

    private String prefix;

    private String limitBefore;

    private String limitAfter;

    private Integer maxResults;

    private Integer firstResult;

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getLimitBefore() {
        return limitBefore;
    }

    public void setLimitBefore(String limitBefore) {
        this.limitBefore = limitBefore;
    }

    public String getLimitAfter() {
        return limitAfter;
    }

    public void setLimitAfter(String limitAfter) {
        this.limitAfter = limitAfter;
    }

    public Integer getMaxResults() {
        return maxResults;
    }

    public void setMaxResults(Integer maxResults) {
        this.maxResults = maxResults;
    }

    public Integer getFirstResult() {
        return firstResult;
    }

    public void setFirstResult(Integer firstResult) {
        this.firstResult = firstResult;
    }
}
