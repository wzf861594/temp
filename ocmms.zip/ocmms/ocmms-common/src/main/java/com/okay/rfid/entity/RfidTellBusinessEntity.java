package com.okay.rfid.entity;

import com.okay.rfid.info.RfidTellBusiness;

/**
 * rfid_tell_business
 * @author 
 */
public interface RfidTellBusinessEntity extends RfidTellBusiness {

    void setId(String id);

    void setTellLogId(String tellLogId);

    void setAccessBusiness(String accessBusiness);

    void setAccessBusinessId(String accessBusinessId);

    void setAccessBusinessType(String accessBusinessType);

    void setIsError(Boolean isError);

    void setExceptionType(String exceptionType);

    void setExceptionMsg(String exceptionMsg);

    void setIsAsync(Boolean isAsync);

}