package com.okay.rfid.impl.query.result;

import com.okay.rfid.impl.entity.RfidTellBusinessEntityImpl;
import com.okay.rfid.query.result.RfidBusinessData;
import com.okay.rfid.query.result.RfidTellBusinessResult;

import java.util.Date;

public class RfidTellBusinessResultImpl extends RfidTellBusinessEntityImpl implements RfidTellBusinessResult, RfidBusinessData {

    private String rfid;
    private String name;
    private Date time;

    private Object businessData;

    @Override
    public String getRfid() {
        return rfid;
    }

    @Override
    public void setRfid(String rfid) {
        this.rfid = rfid;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Date getTime() {
        return time;
    }

    @Override
    public void setTime(Date time) {
        this.time = time;
    }

    @Override
    public Object getBusinessData() {
        return businessData;
    }

    @Override
    public void setBusinessData(Object data) {
        businessData = data;
    }
}
