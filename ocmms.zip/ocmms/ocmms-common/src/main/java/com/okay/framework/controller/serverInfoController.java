package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.ServerInfo;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.service.ServerInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Description:
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-18 16:30
 */

@RestController
@RequestMapping(value = "/serverInfo")
public class serverInfoController {

    @Autowired
    private ServerInfoService serverInfoService;

    @RequestMapping(value = "/dataList", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getdataList() {
        JSONObject jsonObject = new JSONObject();

        Page page = new Page();
        page.setPageSize(0);

        List<ServerInfo> dataList = serverInfoService.findByPage(page);

        jsonObject.put("code", 1);
        jsonObject.put("data", dataList);

        return jsonObject;
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject save(@RequestBody ServerInfo serverInfo) {
        JSONObject jsonObject = new JSONObject();

        try{
            serverInfoService.updateByServerInfoIdSelective(serverInfo);
            jsonObject.put("code", 1);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }

    @RequestMapping(value = "/saveBatch", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject saveBatch(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();

        try{
            List<ServerInfo> serverInfos = jsonParam.getJSONArray("serverInfoList").toJavaList(ServerInfo.class);
            serverInfoService.batchUpdateByServerInfoIdSelective(serverInfos);
            jsonObject.put("code", 1);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }

        return jsonObject;
    }
}
