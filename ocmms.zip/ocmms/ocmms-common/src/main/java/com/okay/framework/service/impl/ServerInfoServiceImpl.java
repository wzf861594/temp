package com.okay.framework.service.impl;

import com.okay.common.constants.RedisConstant;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.ServerInfo;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.mapper.ServerInfoMapper;
import com.okay.framework.service.ServerInfoService;
import com.okay.framework.utils.ComUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-18 16:38
 */
@Slf4j
@Service
public class ServerInfoServiceImpl implements ServerInfoService {

    @Autowired
    private ServerInfoMapper serverInfoMapper;

    @Override
    @Cacheable(value = RedisConstant.REDIS_SERVER_CONFIG, unless = "#result == null")
    public ServerInfo findByServerInfoId(String serverInfoId) {
        ServerInfo serverInfo = serverInfoMapper.selectByPrimaryKey(serverInfoId);
        return serverInfo;
    }

    @Override
    @CacheEvict(value = RedisConstant.REDIS_SERVER_CONFIG, allEntries = true)
    public List<ServerInfo> findByPage(Page page) {
        try {
            page.pageStart(true);
            List<ServerInfo> rsultDataList = serverInfoMapper.selectByPage(page);
            page.pageEnd();
            return rsultDataList;
        } catch (Exception e) {
            if (page.getPageHelper() != null) page.getPageHelper().close();
            throw e;
        }
    }

    @Override
    @CacheEvict(value = RedisConstant.REDIS_SERVER_CONFIG, allEntries = true)
    public int updateByServerInfoIdSelective(ServerInfo serverInfo) {
        User user = ComUtils.getLoginUser();
        if (serverInfo.getUpdateTime() == null) {
            serverInfo.setUpdateTime(new Date());
        }
        if (serverInfo.getUpdateUser() == null) {
            serverInfo.setUpdateUser(user.getUserId());
        }
        int handleNum = serverInfoMapper.updateByPrimaryKeySelective(serverInfo);
        if (handleNum != 1) {
            throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
        }
        return handleNum;
    }

    @Override
    @Transactional
    public int batchUpdateByServerInfoIdSelective(List<ServerInfo> serverInfoList) {
        int handleNum = 0;
        for (ServerInfo serverInfo : serverInfoList) {
            handleNum += updateByServerInfoIdSelective(serverInfo);
        }
        if (handleNum != serverInfoList.size()) {
            throw new BaseRuntimeException("更新失败");
        }
        return handleNum;
    }
}
