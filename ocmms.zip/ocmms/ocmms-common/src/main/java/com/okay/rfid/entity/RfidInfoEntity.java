package com.okay.rfid.entity;


import com.okay.rfid.info.RfidInfo;

import java.util.Date;

/**
 * rfid_info
 * @author
 */
public interface RfidInfoEntity extends RfidInfo {

    void setId(String id);

    void setName(String name);

    void setRfid(String rfid);

    void setType(String type);

    void setDescribe(String describe);

    void setBusinessId(String businessId);

    void setBusinessType(String businessType);

    void setCreatedTime(Date createdTime);

    void setCreatedBy(String createdBy);

    void setLastUpdatedTime(Date lastUpdatedTime);

    void setLastUpdatedBy(String lastUpdatedBy);

    void setIsDelete(Boolean isDelete);

}