package com.okay.common.constants;

/**
 * redis缓存常量
 *
 * @author okay
 * @time 2021年12月20日16:36:45
 */

public class RedisConstant {

    /**
     * 服务配置缓存
     */
    public static final String REDIS_SERVER_CONFIG = "redis_server_config";

}
