package com.okay.rfid.query;

import java.util.List;

public interface Query<R> {

    List<R> list(int pageNum, int pageSize);

    List<R> list();

    R singleResult();

    long count();
}
