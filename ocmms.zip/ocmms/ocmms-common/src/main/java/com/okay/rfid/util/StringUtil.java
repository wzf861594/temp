package com.okay.rfid.util;

public class StringUtil {

    public static boolean isNull(String str) {
        if(str != null && str.length() > 0 && !"".equals(str.trim())) {
            return false;
        }
        return true;
    }
}
