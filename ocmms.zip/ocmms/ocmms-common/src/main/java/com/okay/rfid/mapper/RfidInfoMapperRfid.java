package com.okay.rfid.mapper;

import com.okay.rfid.info.RfidInfo;
import com.okay.rfid.entity.RfidInfoEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RfidInfoMapperRfid extends RfidBaseMapper<RfidInfoEntity> {

    RfidInfo selectByRfid(String rfid);

    RfidInfo selectByRfidAndIgnoreDelete(String rfid);

}