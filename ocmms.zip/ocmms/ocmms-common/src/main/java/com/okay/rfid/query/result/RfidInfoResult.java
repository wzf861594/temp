package com.okay.rfid.query.result;

import com.okay.rfid.info.RfidInfo;
import com.okay.rfid.entity.RfidInfoEntity;

public interface RfidInfoResult extends RfidInfo  {

}
