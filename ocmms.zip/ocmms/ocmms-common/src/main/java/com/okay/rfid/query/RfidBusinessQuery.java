package com.okay.rfid.query;

import com.okay.rfid.query.result.RfidBusinessResult;

import java.util.Collection;

public interface RfidBusinessQuery extends QueryLink<RfidBusinessQuery>, Query<RfidBusinessResult>  {

    RfidBusinessQuery parentId(String parentId);

    RfidBusinessQuery businessId(String businessId, String businessType);

    RfidBusinessQuery businessIds(Collection<String> businessIds, String businessType);

    RfidBusinessQuery businessType(String businessType);

    RfidBusinessQuery complete();

    RfidBusinessQuery uncomplete();

    RfidBusinessQuery putAllSubset();

}
