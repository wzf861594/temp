package com.okay.framework.exception;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;

/**
 *  @ClassName: ExceptionUtil
 *	@Description: 异常信息操作工具
 *  @author: zhongmz
 *  @Date: 2019/7/17 16:41
 *  @version: V1.0
 */
public class ExceptionUtil {

    private static SysLogger logger = SysLogger.getSysLogger(ExceptionUtil.class);

    private static final int  CORRECT_CODE= 1;

    private static final int ASK_CODE = 2;

    private static final int WARM_CODE = 3;

    private static final int ERROR_CODE = 4;

    private static final String startChar = "【";

    private static final String endChar = "】";

    /**
     * JSONOBject返回结果处理
     * obj:null-正常返回  BaseRuntimeException-自定义异常  Exception-未定义异常
     * code:错误级别  1-正常 2-警告 3-询问 4-错误
     * @Param jsonObject
     * @Param obj
     * @return void
     */
    public static void formatResultJsonObject(JSONObject jsonObject, Object obj){

        try {
            logger = SysLogger.getSysLogger(
                    Class.forName(new Throwable().getStackTrace()[1].getClassName()));
        } catch (ClassNotFoundException e) {}

        if(obj == null)
        {
            jsonObject.put("code", CORRECT_CODE);
        } else if(obj instanceof String){
            jsonObject.put("code", CORRECT_CODE);
            jsonObject.put("msg", getErrorMessage((String) obj));
        }
        else if(obj instanceof BaseRuntimeException){
            BaseRuntimeException e = (BaseRuntimeException)obj;
            jsonObject.put("code", e.getErrorLevel());
            jsonObject.put("msg", e.getErrorMessage());
            logger.error(e.getMessage());
        }
        else if(obj instanceof Exception)
        {
            Exception e = (Exception) obj;
            jsonObject.put("code", ERROR_CODE);
            jsonObject.put("msg", SysErrorDefine.SYSTEM_ERROR_MSG);
            logger.error(e.getMessage());
            e.printStackTrace();
        }
    }

    protected static String getErrorMessage(String message){
        if(StringUtils.isNotBlank(message) && message.startsWith(startChar) && message.indexOf(endChar) != -1)
        {
            int endIndex = message.indexOf(endChar);
            return message.substring(endIndex + 1);
        }
        return message;
    }
}
