package com.okay.rfid.query;

import com.okay.rfid.query.result.RfidInfoResult;

import java.util.Collection;
import java.util.Date;

public interface RfidInfoQuery extends QueryLink<RfidInfoQuery>, Query<RfidInfoResult> {

    RfidInfoQuery nameLike(String nameLike);

    RfidInfoQuery rfidLike(String rfidLike);

    RfidInfoQuery businessId(String businessId, String businessType);

    RfidInfoQuery businessType(String businessType);

    RfidInfoQuery businessIds(Collection<String> businessIds, String businessType);

    RfidInfoQuery type(String types);

    RfidInfoQuery types(String... types);

    @Deprecated
    RfidInfoQuery normal();

    RfidInfoQuery includeDeleted();

    RfidInfoQuery deleted();

    RfidInfoQuery gteLastUpdatedTime(Date date);

    RfidInfoQuery ltLastUpdatedTime(Date date);

    RfidInfoQuery orderByLastUpdateTimeDesc();
}
