package com.okay.rfid.impl.query.result;

import com.okay.rfid.impl.entity.RfidAccessEntityImpl;
import com.okay.rfid.query.result.RfidAccessResult;
import com.okay.rfid.query.result.RfidBusinessData;

public class RfidAccessResultImpl extends RfidAccessEntityImpl implements RfidAccessResult, RfidBusinessData {

    private Object businessData;
    private String name;

    @Override
    public Object getBusinessData() {
        return businessData;
    }

    @Override
    public void setBusinessData(Object data) {
        businessData = data;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}
