package com.okay.common.feign;

import com.okay.okay.admin.api.dto.MenuTree;
import com.okay.okay.admin.api.entity.SysMenu;
import com.okay.okay.common.core.constant.ServiceNameConstants;
import com.okay.okay.common.core.util.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author ZHANG.YX
 * @date 2020-7-24
 */
@FeignClient(contextId = "remoteMenuExtensionService", value = ServiceNameConstants.UPMS_SERVICE)
public interface RemoteMenuExtensionService {

    /**
     * 获取系统菜单
     * @type type = top （获取顶部菜单的）
     * @parentId parentId = 顶部导航栏的ID （获取子菜单 ）
     * 参数都为空，则取出全部菜单
     * @return
     */
    @GetMapping("/menu")
    R<List<MenuTree>> getSysMenu(@RequestParam("type") String type, @RequestParam("parentId") String parentId);

    /**
     * @author ZHU.HQ
     * @date 2020-7-30
     *
     * 返回当前用户的树形菜单集合
     * @param type     类型
     * @param parentId 父节点ID
     * @return 当前用户的树形菜单
     */
    @GetMapping("/menu")
    R getUserMenu(@RequestParam("type") String type, @RequestParam("parentId") Integer parentId);

    /**
     * @author ZHU.HQ
     * @date 2020-7-30
     *
     * 返回树形菜单集合
     * @param lazy     是否是懒加载
     * @param parentId 父节点ID
     * @return 树形菜单
     */
    @GetMapping(value = "/menu/tree")
    R getTree(@RequestParam("lazy") boolean lazy, @RequestParam("parentId") Integer parentId);

    /**
     * @author ZHU.HQ
     * @date 2020-7-30
     *
     * 返回角色的菜单集合
     * @param roleId 角色ID
     * @return 属性集合
     */
    @GetMapping("/menu/tree/{roleId}")
    R getRoleTree(@PathVariable("roleId") Integer roleId);

    /**
     * @author ZHU.HQ
     * @date 2020-7-30
     *
     * 通过ID查询菜单的详细信息
     * @param id 菜单ID
     * @return 菜单详细信息
     */
    @GetMapping("/menu/{id}")
    R getById(@PathVariable("id") Integer id);

    /**
     * @author ZHU.HQ
     * @date 2020-7-30
     *
     * 新增菜单
     * @param sysMenu 菜单信息
     * @return success/false
     */
    @PostMapping("/menu")
    R save(@RequestBody SysMenu sysMenu);

    /**
     * @author ZHU.HQ
     * @date 2020-7-30
     *
     * 删除菜单
     * @param id 菜单ID
     * @return success/false
     */
    @DeleteMapping("/menu/{id}")
    R removeById(@PathVariable("id") Integer id);

    /**
     * @author ZHU.HQ
     * @date 2020-7-30
     *
     * 更新菜单
     * @param sysMenu
     * @return
     */
    @PutMapping("/menu")
    R update(@RequestBody SysMenu sysMenu);
}
