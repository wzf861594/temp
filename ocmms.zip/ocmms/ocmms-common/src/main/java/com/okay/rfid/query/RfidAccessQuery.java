package com.okay.rfid.query;

import com.okay.rfid.query.result.RfidAccessResult;

import java.util.Date;

public interface RfidAccessQuery extends QueryLink<RfidAccessQuery>, Query<RfidAccessResult> {

    RfidAccessQuery nameLike(String nameLike);

    RfidAccessQuery rfidLike(String rfidLike);

    RfidAccessQuery businessId(String businessId, String businessType);

    RfidAccessQuery type(String types);

    RfidAccessQuery types(String ... types);

    RfidAccessQuery accessBusiness(String accessBusiness);

    RfidAccessQuery orderByCreatedTimeDesc();

    RfidAccessQuery gteCreatedTime(Date date);

    RfidAccessQuery ltCreatedTime(Date date);
}
