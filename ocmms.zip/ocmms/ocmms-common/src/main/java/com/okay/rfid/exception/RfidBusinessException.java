package com.okay.rfid.exception;

public class RfidBusinessException extends RfidException {
    public RfidBusinessException() {}

    public RfidBusinessException(String message) {
        super(message);
    }

    public RfidBusinessException(String message, Throwable cause) {
        super(message, cause);
    }
}
