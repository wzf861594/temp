package com.okay.rfid.service;


import com.okay.rfid.query.RfidTellBusinessQuery;

public interface RfidTellBusinessService {

    RfidTellBusinessQuery createRfidTellBusinessQuery();

}
