package com.okay.rfid.impl.query;

import com.okay.rfid.mapper.QueryMapper;
import com.okay.rfid.query.Query;
import com.okay.rfid.query.QueryLinkCondition;

import java.util.List;

public class QueryImpl<C extends QueryImpl, O extends Query<R>, R> extends AbstractQueryLinkImpl<C, O, R> implements QueryLinkCondition {

    private QueryMapper mapper;

    private boolean inOrCondition;

    private boolean linkOrCondition;

    public QueryImpl() {
        this(null, null, null);
    }

    public QueryImpl(List<C> queryObjects) {
        this(null, queryObjects, null);
    }

    public QueryImpl(List<C> queryObjects, C currQueryObject) {
        this(null, queryObjects, currQueryObject);
    }

    public QueryImpl(C currQueryObject) {
        this(null, null, currQueryObject);
    }

    public QueryImpl(QueryMapper mapper) {
        this(mapper, null, null);
    }

    public QueryImpl(QueryMapper mapper, List<C> queryObjects) {
        this(mapper, queryObjects, null);
    }

    public QueryImpl(QueryMapper mapper, C currQueryObject) {
        this(mapper, null, currQueryObject);
    }

    public QueryImpl(QueryMapper mapper, List<C> queryObjects, C currQueryObject) {
        super(queryObjects, currQueryObject);
        this.mapper = mapper;
    }

    @Override
    protected List<R> execute() {
        return mapper.selectQuery(this);
    }

    @Override
    protected long executeCount() {
        return mapper.selectQueryCount(this);
    }

    @Override
    protected C newQueryObject() {
        try {
            return (C) getCurrQueryObject().getClass().newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        throw new RuntimeException("newInstance error. no empty-argument constructor");
    }

    @Override
    public C getCurrQueryObject() {
        C currQueryObject = super.getCurrQueryObject();
        if(currQueryObject != null) {
            return currQueryObject;
        } else {
            return (C) this;
        }
    }

    public QueryMapper getMapper() {
        return mapper;
    }

    public void setMapper(QueryMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public boolean getInOrCondition() {
        return inOrCondition;
    }

    @Override
    public void setInOrCondition(boolean inOrCondition) {
        this.inOrCondition = inOrCondition;
    }

    @Override
    public boolean getLinkOrCondition() {
        return linkOrCondition;
    }

    @Override
    public void setLinkOrCondition(boolean linkOrCondition) {
        this.linkOrCondition = linkOrCondition;
    }

    public boolean isInOrCondition() {
        return inOrCondition;
    }

    public boolean isLinkOrCondition() {
        return linkOrCondition;
    }

}
