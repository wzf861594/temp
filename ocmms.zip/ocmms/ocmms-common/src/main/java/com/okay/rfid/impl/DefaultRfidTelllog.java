package com.okay.rfid.impl;

import com.okay.rfid.impl.entity.RfidTellLogEntityImpl;

public class DefaultRfidTelllog extends RfidTellLogEntityImpl {

    @Deprecated
    private boolean isNotLog;

    @Deprecated
    public void setNotLog() {
    }

    @Deprecated
    public boolean isNotLog() {
        return false;
    }

}
