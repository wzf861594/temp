package com.okay.framework.entity;

import java.util.Date;
import java.io.Serializable;

/**
 * 用户表(SysUser)实体类
 *
 * @author makejava（zyx）
 * @since 2020-09-12 14:06:40
 */
public class SysUser implements Serializable {
    private static final long serialVersionUID = -89714245798005200L;
    /**
    * 主键ID
    */
    private Integer userId;
    
    private String username;
    
    private String password;
    
    private String salt;
    
    private String phone;
    
    private String avatar;
    /**
    * 部门ID
    */
    private Integer deptId;
    /**
    * 创建时间
    */
    private Date createTime;
    /**
    * 修改时间
    */
    private Date updateTime;
    
    private String lockFlag;
    
    private String delFlag;
    /**
    * 微信登录openId
    */
    private String wxOpenid;
    /**
    * 小程序openId
    */
    private String miniOpenid;
    /**
    * QQ openId
    */
    private String qqOpenid;
    /**
    * 码云 标识
    */
    private String giteeLogin;
    /**
    * 开源中国 标识
    */
    private String oscId;
    /**
    * 所属租户
    */
    private Integer tenantId;
    /**
     * AUD(标识 A-新增 U-修改 D-删除)
     */
    private String AUD;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getLockFlag() {
        return lockFlag;
    }

    public void setLockFlag(String lockFlag) {
        this.lockFlag = lockFlag;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getWxOpenid() {
        return wxOpenid;
    }

    public void setWxOpenid(String wxOpenid) {
        this.wxOpenid = wxOpenid;
    }

    public String getMiniOpenid() {
        return miniOpenid;
    }

    public void setMiniOpenid(String miniOpenid) {
        this.miniOpenid = miniOpenid;
    }

    public String getQqOpenid() {
        return qqOpenid;
    }

    public void setQqOpenid(String qqOpenid) {
        this.qqOpenid = qqOpenid;
    }

    public String getGiteeLogin() {
        return giteeLogin;
    }

    public void setGiteeLogin(String giteeLogin) {
        this.giteeLogin = giteeLogin;
    }

    public String getOscId() {
        return oscId;
    }

    public void setOscId(String oscId) {
        this.oscId = oscId;
    }

    public Integer getTenantId() {
        return tenantId;
    }

    public void setTenantId(Integer tenantId) {
        this.tenantId = tenantId;
    }

    public String getAUD() {
        return AUD;
    }

    public void setAUD(String AUD) {
        this.AUD = AUD;
    }
}