package com.okay.rfid.query;

import com.okay.rfid.query.result.RfidTellBusinessResult;

import java.util.Date;

public interface RfidTellBusinessQuery extends QueryLink<RfidTellBusinessQuery>, Query<RfidTellBusinessResult> {

    RfidTellBusinessQuery tellLogId(String tellLogId);

    RfidTellBusinessQuery nameLike(String nameLike);

    RfidTellBusinessQuery rfidLike(String rfidLike);

    RfidTellBusinessQuery type(String type);

    RfidTellBusinessQuery types(String... types);

    RfidTellBusinessQuery orderByTimeDesc();

    RfidTellBusinessQuery gteTime(Date date);

    RfidTellBusinessQuery ltTime(Date date);

    RfidTellBusinessQuery accessBusiness(String accessBusiness);

}
