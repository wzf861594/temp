package com.okay.framework.exception;

import com.alibaba.fastjson.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolationException;

/**
 *  @ClassName: ControllerGlobalExceptionHandel
 *	@Description: 全局异常处理
 *  @author: zhongmz
 *  @Date: 2019/9/6 16:02
 *  @version: V1.0
 */
@ControllerAdvice
public class ControllerGlobalExceptionHandel {

    //前端返回码处理规则：1-正常 2-警告 3-询问 4-错误

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    public JSONObject handException(ConstraintViolationException e){
        JSONObject jsonObject = new JSONObject();
        ExceptionUtil.formatResultJsonObject(jsonObject, e);
        return jsonObject;
    }

    @ExceptionHandler(TransactionSystemException.class)
    @ResponseBody
    public JSONObject handException(TransactionSystemException e){
        JSONObject jsonObject = new JSONObject();
        ExceptionUtil.formatResultJsonObject(jsonObject, e);
        return jsonObject;
    }

    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public JSONObject handException(MethodArgumentNotValidException e){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 2);
        jsonObject.put("msg", getErrorMsg(e.getMessage()));
        return jsonObject;
    }

    /**
     * 截取异常信息
     * @Param message
     * @return java.lang.String
     */
    public String getErrorMsg(String message){
        String resultMsg = "";
        if(message.indexOf("[") > -1 && message.indexOf("]") > -1){
            int startIndex = message.lastIndexOf("[") + 1;
            int endIndex = message.lastIndexOf("]") - 1;
            resultMsg = message.substring(startIndex, endIndex);
        }
        return resultMsg;
    }

}
