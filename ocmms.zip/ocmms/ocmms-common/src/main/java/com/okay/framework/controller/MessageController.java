package com.okay.framework.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.framework.entity.Message;
import com.okay.framework.entity.dto.MessageDTO;
import com.okay.framework.service.MessageService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @Author CZJ[OKAY]
 * @Date 2020/8/25 15:05
 * @Description 消息提醒
 **/
@RestController
@AllArgsConstructor
@RequestMapping("/message")
public class MessageController {

    private final MessageService messageService;

    /**
     * @param dto 查询条件dto
     * @Description 获取列表
     **/
    @PostMapping("/listMessage")
    public R<IPage<Message>> listMessage(Page page, MessageDTO dto) {
        return R.ok(messageService.listMessage(page, dto)).setMsg("");
    }

    /**
     * @param id 消息ID
     * @Description 消息已读
     **/
    @PostMapping("/read")
    public R read(@RequestParam(value = "id") String id) {
        return R.ok(messageService.updateRead(id));
    }


    /**
     * 获取未读消息
     *
     * @return R
     **/
    @GetMapping("/getMessageNum")
    public R getMessageNum() {
        return R.ok(messageService.getMessageNum()).setMsg("");
    }

}
