package com.okay.framework.service.impl;

import com.okay.framework.exception.SequenceCreateException;
import com.okay.framework.mapper.SequenceMapper;
import com.okay.framework.service.SequenceService;
import com.okay.framework.utils.ComUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * @ClassName: SequenceServiceImpl
 * @Description: 序列业务实现类
 * @author: HQ.ZHU
 * @date: 2019-04-21 0:21
 * @version: V1.0
 */
@Service
public class SequenceServiceImpl implements SequenceService {

    @Resource
    private SequenceMapper sequenceMapper;

    /**
     * @MethodName: getSequence
     * @Description:主键生成规则：首次获取需要新增，默让首次的序列为1，以后获取时
     *                会先进行查询获取，然后+1更新回原来序列值。首次插入或更新会根据影
     *                响记录来判断是否成功，如失败则抛出异常并回滚事务。
     * @Author: HQ.ZHU
     * @date: 2019-04-21 1:51
     */
    @Override
    @Transactional
    public synchronized Long getSequence(String tableName) throws SequenceCreateException {

        if(tableName == null || "".equals(tableName))
            throw new SequenceCreateException("序列参数不能为空！");

        //统一用大写匹配
        tableName = tableName.toUpperCase();

        //受影响的行记录总数
        Integer rows = 0;
        Long sequence = sequenceMapper.selectSequence(tableName);
        if(sequence == null || sequence <= 0){
            sequence = 1L;
            rows = sequenceMapper.insertSequence(tableName, sequence);
        } else {
            ++ sequence;
            rows = sequenceMapper.updateSequence(tableName, sequence);
        }
        //影响记录数不为1时抛出异常，让事务回滚。
        if (rows != 1L)
            throw new SequenceCreateException("序列生成或更新失败！");

        return sequence;
    }

    /**
     * 统一主键序列
     * @return
     */
    @Override
    public String getSequence() {
        return ComUtils.getUUID();
    }
}
