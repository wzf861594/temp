package com.okay.framework.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName: Page
 * @Description: 分页对象
 * @author: HQ.ZHU
 * @date: 2019-04-25 16:38
 * @version: V1.0
 */
public class Page implements Serializable {
    private static final long serialVersionUID = -4345443724311352651L;
    /**
     * 当前页（页码）
     */
    //@JsonProperty(value = "page")
    private Integer pageNum = 1;
    /**
     * 每页记录数
     */
    //@JsonProperty(value = "limit")
    private Integer pageSize = 20;
    /**
     *  开始行数
     */
    private Integer startRow = 1;
    /**
     *  结束行数
     */
    private Integer endRow;
    /**
     * 总页数
     */
    private Integer pages;
    /**
     * 列名排序
     */
    private String orderBy;
    /**
     * 全部记录的总数
     */
    //@JsonProperty(value = "count")
    private Integer total;
    /**
     * 设置代码为0，代表查询正常返回
     * 设置代码为1，代表查询异常并返回错误信息。
     */
    private Integer code = 0;
    /**
     * 给前端返回的信息
     */
    private String msg;
    /**
     * 返回的数据集
     */
    private Object data;
    /**
     * Mybatis分页插件
     */
    @JSONField(serialize = false)
    private com.github.pagehelper.Page pageHelper;
    @JSONField(serialize = false)
    private PageInfo pageInfo;

    /**
     * 查询条件
     */
    private Map<String, Object> conditionMap = new HashMap<>();

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Integer getStartRow() {
        return startRow;
    }

    public void setStartRow(Integer startRow) {
        this.startRow = startRow;
    }

    public Integer getEndRow() {
        return endRow;
    }

    public void setEndRow(Integer endRow) {
        this.endRow = endRow;
    }

    public Integer getPages() {
        return pages;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public com.github.pagehelper.Page getPageHelper() {
        return pageHelper;
    }

    public void setPageHelper(com.github.pagehelper.Page pageHelper) {
        this.pageHelper = pageHelper;
    }

    public PageInfo getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(PageInfo pageInfo) {
        this.pageInfo = pageInfo;
    }

    public Map<String, Object> getConditionMap() {
        return conditionMap;
    }

    public void setConditionMap(Map<String, Object> conditionMap) {
        this.conditionMap = conditionMap;
    }

    public Object getCondition(String key){
        return conditionMap.get(key);
    }

    public void putCondition(String key, Object object){
        conditionMap.put(key, object);
    }

    //Mybatis分页插件
    public void pageStart(boolean isCount){
        pageHelper = PageHelper.startPage(this.pageNum, this.pageSize, isCount);
        //加入排序字段
        if(pageHelper != null && this.orderBy != null && !"".equals(this.orderBy)){
            pageHelper.setOrderBy(this.orderBy);
        }
    }

    //Mybatis分页插件
    public void pageEnd(){
        pageInfo = new PageInfo<>(pageHelper);
        this.setTotal((int) pageInfo.getTotal());
        this.setStartRow(pageInfo.getStartRow());
        this.setEndRow(pageInfo.getEndRow());
        this.setPages(pageInfo.getPages());
        this.setData(pageInfo.getList());
    }
}