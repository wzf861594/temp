package com.okay.framework.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * @author okay
 */
@Data
@TableName("sys_message")
public class Message {

    /**
     * 主键
     **/
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    /**
     * 消息对象类型
     **/
    @NotBlank(message = "消息对象类型不能为空 oa_message_type")
    private String businessType;

    /**
     * 消息对象ID
     **/
    @NotBlank(message = "消息对象ID不能为空")
    private String businessId;

    /**
     * 消息提醒对象
     **/
    @NotBlank(message = "消息提醒对象不能为空")
    private String remindObject;

    /**
     * 是否已读 1、已读  0、未读
     **/
    @NotBlank(message = "消息对象类型不能为空")
    private String isRead;

    /**
     * 消息内容
     **/
    @NotBlank(message = "消息内容不能为空")
    private String content;

    /**
     * 路由地址
     **/
    @NotBlank(message = "路由地址不能为空")
    private String routerPath;

    /**
     * top菜单ID
     **/
    private Integer topMenuId;

    /**
     * 备注
     **/
    private String remark;

    /**
     * 创建时间
     **/
    private Date createTime;

    /**
     * 创建人
     **/
    private String creator;

    /**
     * 最后修改时间
     **/
    private Date editTime;

    /**
     * 最后修改人
     **/
    private String editor;
}