package com.okay.framework.utils;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Objects;

/**
 * 数据导出通用工具
 *
 * @author zhangyx
 * @since 2019/11/14 17:35
 */
public class DataExportUtils {

    //创建一个工作簿
    public static HSSFWorkbook creakWorkBook(List headerList, List dataList) {
        HSSFWorkbook hssfWorkbook = new HSSFWorkbook();
        try {
            HSSFSheet hssfSheet = hssfWorkbook.createSheet("数据导出");
            //表头单元格样式
            HSSFCellStyle cellStyle = hssfWorkbook.createCellStyle();
            cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//上下居中
            cellStyle.setFillForegroundColor(IndexedColors.GOLD.getIndex());//背景填充色
            cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            cellStyle.setBorderBottom(BorderStyle.THIN);//边框色
            cellStyle.setBorderTop(BorderStyle.THIN);
            cellStyle.setBorderLeft(BorderStyle.THIN);
            cellStyle.setBorderRight(BorderStyle.THIN);

            HSSFFont hssfFont = hssfWorkbook.createFont();
            hssfFont.setBold(true);
            hssfFont.setFontName("宋体");
            hssfFont.setFontHeightInPoints((short) 11);
            cellStyle.setFont(hssfFont);

            //     HSSFRow hssfRow = hssfSheet.createRow(0);
            //     setCellValue(hssfRow, "序号", 0, cellStyle);
            //     for (int i = 0; i < headerList.size(); i++) {
            //         // 调整每一列宽度
            //         hssfSheet.autoSizeColumn((short) i);
            //
            //         String value = headerList.get(i).toString();
            //         setCellValue(hssfRow, value, i + 1, cellStyle);
            //     }
            // }
            // //---------------------写入数据
            // if (true) {
            //     //内容单元格样式
            //     HSSFCellStyle cellStyle = hssfWorkbook.createCellStyle();
            //     cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            //
            //     cellStyle.setBorderBottom(BorderStyle.THIN);//边框色
            //     cellStyle.setBorderTop(BorderStyle.THIN);
            //     cellStyle.setBorderLeft(BorderStyle.THIN);
            //     cellStyle.setBorderRight(BorderStyle.THIN);
            //
            //     HSSFFont hssfFont = hssfWorkbook.createFont();
            //     hssfFont.setBold(false);
            //     hssfFont.setFontName("宋体");
            //     hssfFont.setFontHeightInPoints((short) 11);
            //     cellStyle.setFont(hssfFont);
            //
            //
            //     for (int i = 0; i < dataList.size(); i++) {
            //         HSSFRow hssfRow = hssfSheet.createRow(i+1);
            //         setCellValue(hssfRow, String.valueOf(i  + 1), 0, cellStyle);
            //         List data = (List) dataList.get(i);
            //         for (int j = 0; j < data.size(); j++) {
            //             // 调整每一列宽度
            //             hssfSheet.autoSizeColumn((short) j);
            //
            //             if (null != data.get(j)) {
            //                 String value = data.get(j).toString();
            //                 setCellValue(hssfRow, value, j + 1, cellStyle);
            //             } else {
            //                 setCellValue(hssfRow, "", j + 1, cellStyle);
            //             }
            //         }
            //     }
            // }

            /**
             * 2021-01-26日 优化v1.0
             * @author tingjun
             */
            //内容单元格样式
            HSSFCellStyle dataCellStyle = hssfWorkbook.createCellStyle();
            dataCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            dataCellStyle.setBorderBottom(BorderStyle.THIN);//边框色
            dataCellStyle.setBorderTop(BorderStyle.THIN);
            dataCellStyle.setBorderLeft(BorderStyle.THIN);
            dataCellStyle.setBorderRight(BorderStyle.THIN);
            HSSFFont dataHssfFont = hssfWorkbook.createFont();
            dataHssfFont.setBold(false);
            dataHssfFont.setFontName("宋体");
            dataHssfFont.setFontHeightInPoints((short) 11);
            dataCellStyle.setFont(dataHssfFont);

            //head
            HSSFRow hssfRow = hssfSheet.createRow(0);
            for (int i = 0; i <= headerList.size(); i++) {
                if (i == 0) {
                    setCellValue(hssfRow, "序号", 0, cellStyle);
                } else {
                    setCellValue(hssfRow, Objects.toString(headerList.get(i - 1), ""), i, cellStyle);
                }
                hssfSheet.autoSizeColumn(i);
            }
            //data
            for (int i = 0; i < dataList.size(); i++) {
                HSSFRow row = hssfSheet.createRow(i + 1);
                List data = (List) dataList.get(i);
                for (int j = 0; j <= data.size(); j++) {
                    // 调整每一列宽度
                    HSSFCell cell = row.createCell(j);
                    if (j == 0) {
                        cell.setCellValue(i + 1);
                    } else {
                        cell.setCellValue(Objects.toString(data.get(j - 1), ""));
                    }
                    cell.setCellStyle(dataCellStyle);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return hssfWorkbook;
    }


    /**
     * 单元格赋值
     *
     * @param hssfRow
     * @param cellIndex
     */
    private static void setCellValue(HSSFRow hssfRow, String value, int cellIndex, HSSFCellStyle hssfCellStyle) {
        HSSFCell hssfCell = hssfRow.getCell(cellIndex);
        if (hssfCell == null) {
            hssfCell = hssfRow.createCell(cellIndex);
        }
        hssfCell.setCellValue(value);

        //单元格样式
        if (hssfCellStyle != null) {
            hssfCell.setCellStyle(hssfCellStyle);
        }
    }


    /**
     * 发送响应流方法
     */
    public static void setResponseHeader(HttpServletResponse response, HSSFWorkbook hssfWorkbook, String fileName) {
        try {
            response.reset();
            response.setContentType("application/x-download");
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName + "(" + DateUtil.getNextTime() + ")", "UTF-8") + ".xls");
            response.addHeader("filename", URLEncoder.encode(fileName + "(" + DateUtil.getNextTime() + ")", "UTF-8") + ".xls");
            hssfWorkbook.write(response.getOutputStream());
            hssfWorkbook.close();
            response.setStatus(200);
        } catch (IOException e) {

            e.printStackTrace();
        }
    }
}

