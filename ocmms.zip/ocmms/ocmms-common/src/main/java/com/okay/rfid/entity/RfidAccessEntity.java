package com.okay.rfid.entity;

import com.okay.rfid.info.RfidAccess;

import java.util.Date;

/**
 * rfid_access
 * @author 
 */
public interface RfidAccessEntity extends RfidAccess {

    void setId(String id);

    void setRfid(String rfid);

    void setAccessBusiness(String accessBusiness);

    void setType(String type);

    void setCreatedTime(Date createdTime);

    void setCreatedBy(String createdBy);

    void setBusinessId(String businessId);

    void setBusinessType(String businessType);

}