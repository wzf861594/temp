package com.okay.rfid.mapper;

import com.okay.rfid.query.RfidBusinessQuery;
import com.okay.rfid.query.result.RfidBusinessResult;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface RfidBusinessQueryMapper extends QueryMapper<RfidBusinessQuery, RfidBusinessResult>  {

    List<RfidBusinessResult> selectQueryIncludeAllSubset(RfidBusinessQuery query);

}