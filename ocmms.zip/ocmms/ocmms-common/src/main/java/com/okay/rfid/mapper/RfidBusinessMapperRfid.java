package com.okay.rfid.mapper;

import com.okay.rfid.entity.RfidBusinessEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RfidBusinessMapperRfid extends RfidBaseMapper<RfidBusinessEntity> {

}