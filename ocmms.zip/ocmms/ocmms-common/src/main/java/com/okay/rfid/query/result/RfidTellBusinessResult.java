package com.okay.rfid.query.result;

import com.okay.rfid.info.RfidTellBusiness;
import com.okay.rfid.entity.RfidTellBusinessEntity;

import java.util.Date;

public interface RfidTellBusinessResult extends RfidTellBusiness {

    String getRfid();

    void setRfid(String rfid);

    String getName();

    void setName(String name);

    Date getTime();

    void setTime(Date time);

}
