package com.okay.rfid.mapper;

import com.okay.rfid.query.RfidAccessQuery;
import com.okay.rfid.query.result.RfidAccessResult;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface RfidAccessQueryMapper extends QueryMapper<RfidAccessQuery, RfidAccessResult> {

}