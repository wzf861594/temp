package com.okay.rfid.impl.query;

import com.okay.rfid.mapper.RfidAccessQueryMapper;
import com.okay.rfid.query.RfidAccessQuery;
import com.okay.rfid.query.result.RfidAccessResult;

public class RfidAccessQueryImpl extends RfidQueryImpl<RfidAccessQueryImpl, RfidAccessQuery, RfidAccessResult> implements RfidAccessQuery {

    protected RfidAccessQueryImpl() {}

    public RfidAccessQueryImpl(RfidAccessQueryMapper mapper) {
        super(mapper);
    }

    @Override
    public RfidAccessQuery orderByCreatedTimeDesc() {
        setOrderBy("createdTimeDesc");
        return this;
    }

}
