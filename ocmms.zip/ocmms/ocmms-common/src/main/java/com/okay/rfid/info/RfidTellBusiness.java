package com.okay.rfid.info;

/**
 * rfid_tell_business
 * @author 
 */
public interface RfidTellBusiness {

    String getId();

    String getTellLogId();

    String getAccessBusiness();

    String getAccessBusinessId();

    String getAccessBusinessType();

    Boolean getIsError();

    String getExceptionType();

    String getExceptionMsg();

    Boolean getIsAsync();

    boolean isError();

    boolean isAsync();

}