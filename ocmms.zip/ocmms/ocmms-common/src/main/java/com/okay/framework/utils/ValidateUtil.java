package com.okay.framework.utils;

import java.util.Collection;

/**
 * @ClassName: ValidateUtil
 * @Description: 数据校验工具.
 * @author: wenlh
 * @date: 2019年4月28日 15:27:19
 * @version: V1.0
 */
public final class ValidateUtil {
	
	/**
	 * 判断空操作.
	 * @param param
	 * @return
	 * @author wenlh
	 * @date 2017年11月9日 09:45:36
	 */
	public static boolean isNull(Object param) {
		boolean result = false;
		if(param == null) {
			result = true;
		} else if(param instanceof String) {
			String paramStr = (String) param;
			if("".equals(paramStr) || "null".equalsIgnoreCase(paramStr)) {
				result = true;
			}
		} else if(param instanceof Collection) {
			result = ((Collection<?>) param).isEmpty();
		}
		return result;
	}
	
	
	/**
	 * 证验是否数值类型
	 * @param str
	 * @return
	 */
	public static boolean isNumeric(String str) {
		if(str != null && !"".equals(str) && str.matches("\\d+")) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 证验是否数值类型
	 * @param str
	 * @return
	 */
	public static boolean isNumeric(String str, boolean signed) {
		String matches = signed ? "-?\\d+" : "\\d+";
		if(str != null && !"".equals(str) && str.matches(matches)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 条件判断,只会返回true、false.
	 * 只有为true时才返回true,其它返回false.
	 * @param object
	 * @return
	 * @author wenlh
	 * @date 2017年11月3日 14:21:25
	 */
	public static boolean isCondition(Object object) {
		boolean result = false;
		if(object != null ) {
			if(object instanceof String) { // 字符串判断.
				String scope = (String) object;
				if("true".equalsIgnoreCase(scope)) {
					result = true;
				} else {
					result = false;
				}
			} else if(object instanceof Boolean) {
				Boolean scope = (Boolean) object;
				if(scope) {
					result = true;
				} else {
					result = false;
				}
			} 
		}
		return result;
	}
	
	/**
	 * 条件判断,只会返回true、false.
	 * 只有为false时才返回false,其它返回true.
	 * @param object
	 * @return
	 * @author wenlh
	 * @date 2017年11月3日 14:21:25
	 */
	public static boolean isConditionNot(Object object) {
		boolean result = true;
		if(object != null ) {
			if(object instanceof String) { // 字符串判断.
				String scope = (String) object;
				if("false".equalsIgnoreCase(scope)) {
					result = false;
				} else {
					result = true;
				}
			} else if(object instanceof Boolean) {
				Boolean scope = (Boolean) object;
				if(scope) {
					result = true;
				} else {
					result = false;
				}
			} 
		}
		return result;
	}
}
