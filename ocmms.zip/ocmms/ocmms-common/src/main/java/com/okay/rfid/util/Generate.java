package com.okay.rfid.util;

import java.util.UUID;

public class Generate {

    public static String getNextId() {
        return UUID.randomUUID().toString();
    }
}
