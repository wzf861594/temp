package com.okay.framework.utils;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.okay.framework.exception.BaseRuntimeException;
import org.apache.commons.lang3.StringUtils;
import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.List;
import java.util.*;

/**
 * @Description: 二维码工具类
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-10 11:56
 */

public class QRCodeUtils {

    // 内容编码
    private static final String CHARSET = "UTF-8";
    // 生成二维码类型
    public static final String FORMAT = "JPG";
    // 二维码宽
    public static final Integer QRCODE_WIDTH = 360;
    // 二维码高
    public static final Integer QRCODE_HEIGHT = 360;
    // 二维码颜色==黑色
    private static final Integer BLACK = 0xFF000000;
    // 二维码颜色==白色
    private static final Integer WHITE = 0xFFFFFFFF;
    // 二维码图片格式==jpg和png两种
    private static final List<String> IMAGE_TYPE = new ArrayList<>();

    static {
        IMAGE_TYPE.add("JPG");
        IMAGE_TYPE.add("PNG");
    }

    /**
     * zxing方式生成二维码
     * 注意：
     * 1,设置容错率为最高,一般容错率越高,图片越不清晰, 但是只有将容错率设置高一点才能兼容logo图片
     * 2,logo图片默认占二维码图片的20%,设置太大会导致无法解析
     *
     * @param content 二维码包含的内容，文本或网址
     * @param width 生成的二维码图片宽 默认（250）
     * @param height 生成的二维码图片高 默认（250）
     * @param logoBufferedImage logo
     * @param storePath 生成的二维码图片存放位置
     * @param qrCodeName 生成的二维码图片名称
     */
    public static BufferedImage createQrCodeAndStore(String content, Integer width, Integer height, BufferedImage logoBufferedImage, String storePath, String qrCodeName, String text) throws Exception{

        try {
            //图片类型
            String imageType = FORMAT;

            //生成二维码存放路径
            if (storePath == null || "".equals(storePath)){
                throw new RuntimeException("缺失存储路径");
            }

            File storeFile = new File(storePath);
            if (storeFile.isDirectory()){
                String name = qrCodeName == null ? DateUtil.getNextTime() : qrCodeName;
                storePath = storePath + File.separator + name + "." + imageType;
            }

            File newStoreFile = new File(storePath);
            if (!newStoreFile.exists()) {
                newStoreFile.mkdirs();
            }

            // 创建二维码图片流，
            BufferedImage image = createQrCodeBufferedImage(content, width, height, logoBufferedImage, text);

            // 将流形式的二维码写入到目录文件中
            ImageIO.write(image, imageType, newStoreFile);

            return image;
        }catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("二维码创建失败");
        }
    }

    public static BufferedImage createQrCodeBufferedImage(String content, Integer width, Integer height, String logoUrl, String text) throws Exception{

        BufferedImage bufferedImage = null;
        //判断是否写入logo图片
        if (StringUtils.isNotEmpty(logoUrl)) {
            File logoFile = new File(logoUrl);
            if (logoFile.isFile()){
                BufferedImage logoImage = ImageIO.read(logoFile);
                bufferedImage = createQrCodeBufferedImage(content, width, height, logoImage, text);
            }
        }else {
            bufferedImage = createQrCodeBufferedImage(content, width, height, bufferedImage, text);
        }

        return bufferedImage;
    }

    /**
     * 创建二维码，并返回二维码图片流
     *
     * @param content 二维码文本内容
     * @param width 二维码宽 默认（360）
     * @param height 二维码高 默认（360）
     * @param logoBufferedImage logo
     * @return
     */
    public static BufferedImage createQrCodeBufferedImage(String content, Integer width, Integer height, BufferedImage logoBufferedImage, String text) throws Exception{
        if (width == null || width <= 0) {
            width = QRCODE_WIDTH;
        }
        if (height == null || height <= 0) {
            height = QRCODE_HEIGHT;
        }

        try {
            // 设置编码字符集
            Map<EncodeHintType, Object> hints = new HashMap<>();
            // 设置编码
            hints.put(EncodeHintType.CHARACTER_SET, CHARSET);
            // 设置容错率最高
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            // 设置边框距
            hints.put(EncodeHintType.MARGIN, 1);
            // 1、生成二维码
            BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, width, height, hints);
            // 2、获取二维码宽高
            int codeWidth = bitMatrix.getWidth();
            int codeHeight = bitMatrix.getHeight();
            // 3、将二维码放入缓冲流
            BufferedImage image = new BufferedImage(codeWidth, codeHeight, BufferedImage.TYPE_INT_RGB);
            // 4、循环将二维码内容定入黑白图案,生成二维数组
            for (int i = 0; i < codeWidth; i++) {
                for (int j = 0; j < codeHeight; j++) {
                    image.setRGB(i, j, bitMatrix.get(i, j) ? BLACK : WHITE);
                }
            }
            //判断是否写入logo图片
            if (logoBufferedImage != null) {
                image = insertLogoImage(image, logoBufferedImage);
            }
            // 是否添加文字
            if (StringUtils.isNotEmpty(text)){
                image = insertText(image, text);
            }

            return image;
        } catch (WriterException e) {
            e.printStackTrace();
            throw new RuntimeException("二维码创建失败");
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("二维码创建失败");
        }
    }

    /**
     * 给二维码图片添加Logo
     *
     * @param qrCodePath 二维码图片路径
     * @param logoPath logo图片路径
     * @param storePath 合成后的图片存储路径
     * @return 返回添加成功与否
     */
    public static BufferedImage insertLogoImageAndStore(String qrCodePath, String logoPath, String storePath)throws Exception {
        try {
            File qrPic = new File(qrCodePath);
            File logoPic = new File(logoPath);

            if (!qrPic.isFile() && !logoPic.isFile()) {
                return null;
            }
            if (storePath == null || "".equals(storePath)){
                return null;
            }
            File storeFile = new File(storePath);
            if (storeFile.isDirectory()){
                String qrCodeName =  qrCodePath.substring(qrCodePath.lastIndexOf(File.separator) + 1);
                storePath = storePath + File.separator + qrCodeName;
            }

            File newStoreFile = new File(storePath);
            if (newStoreFile.isFile()){
                String fileSuffix = storePath.substring(storePath.lastIndexOf(".") + 1).toUpperCase();
                if (!IMAGE_TYPE.contains(fileSuffix)){
                    storePath = storePath.substring(0,storePath.lastIndexOf(".") + 1) + FORMAT;
                }
            }

            // 获取二维码图片流
            BufferedImage qrBufferedImage = ImageIO.read(qrPic);
            // 获取Logo图片流
            BufferedImage logoBufferedImage = ImageIO.read(logoPic);

            return insertLogoImageAndStore(qrBufferedImage, logoBufferedImage, storePath);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("logo插入失败");
        }
    }

    /**
     * 给二维码图片流添加Logo
     *
     * @param qrBufferedImage 二维码图片流
     * @param logoPic logo图片文件
     * @param storePath 合成后的图片存储路径
     * @return 返回添加成功与否
     */
    public static BufferedImage insertLogoImageAndStore(BufferedImage qrBufferedImage, File logoPic, String storePath) throws Exception {
        try {
            //读取Logo图片
            BufferedImage logoBufferedImage = ImageIO.read(logoPic);
            return insertLogoImageAndStore(qrBufferedImage, logoBufferedImage, storePath);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("logo插入失败");
        }
    }

    /**
     * 给二维码图片流添加Logo
     *
     * @param qrBufferedImage 二维码图片流
     * @param logoBufferedImage logo图片流
     * @param storePath 合成后的图片存储路径
     * @return 返回添加成功与否
     */
    public static BufferedImage insertLogoImageAndStore(BufferedImage qrBufferedImage, BufferedImage logoBufferedImage, String storePath)throws Exception {
        try {
            File file = new File(storePath);
            if (!file.isFile()){
                return null;
            }
            if (qrBufferedImage == null || logoBufferedImage == null){
                return null;
            }
            File storeFile = new File(storePath);
            if (storeFile.isFile()){
                String fileSuffix = storePath.substring(storePath.lastIndexOf(".") + 1).toUpperCase();
                if (!IMAGE_TYPE.contains(fileSuffix)){
                    storePath = storePath.substring(0,storePath.lastIndexOf(".") + 1) + FORMAT;
                }
            }

            File newFile = new File(storePath);
            if (!newFile.exists()) {
                newFile.mkdirs();
            }

            insertLogoImage(qrBufferedImage, logoBufferedImage);

            ImageIO.write(qrBufferedImage, FORMAT, newFile);

            return qrBufferedImage;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("logo插入失败");
        }
    }

    /**
     * 给二维码图片流添加Logo
     *
     * @param qrBufferedImage 二维码图片流
     * @param logoBufferedImage logo图片流
     * @return 返回添加logo后图片流
     */
    public static BufferedImage insertLogoImage(BufferedImage qrBufferedImage, BufferedImage logoBufferedImage)throws Exception {
        try {
            if (qrBufferedImage == null || logoBufferedImage == null){
                return null;
            }
            //获取二维码图片的绘图对象(二维码画板)
            Graphics2D graphics = qrBufferedImage.createGraphics();

            //设置logo的大小,最多20%
            int widthLogo = logoBufferedImage.getWidth(null) > qrBufferedImage.getWidth() * 2 / 10 ? (qrBufferedImage.getWidth() * 2 / 10) : logoBufferedImage.getWidth(null);
            int heightLogo = logoBufferedImage.getHeight(null) > qrBufferedImage.getHeight() * 2 / 10 ? (qrBufferedImage.getHeight() * 2 / 10) : logoBufferedImage.getHeight(null);

            // 计算图片放置位置，默认在中间
            int x = (qrBufferedImage.getWidth() - widthLogo) / 2;
            int y = (qrBufferedImage.getHeight() - heightLogo) / 2;

            // 开始绘制图片
            graphics.drawImage(logoBufferedImage, x, y, widthLogo, heightLogo, null);
            graphics.drawRoundRect(x, y, widthLogo, heightLogo, 15, 15);

            // 边框宽度及圆滑程度设置
            graphics.setStroke(new BasicStroke(3f));

            // 边框颜色
            graphics.setColor(Color.WHITE);
            graphics.drawRect(x, y, widthLogo, heightLogo);

            // 结束绘制，释放内存
            graphics.dispose();

            // 刷新二维码
            logoBufferedImage.flush();
            qrBufferedImage.flush();

            return qrBufferedImage;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("logo插入失败");
        }
    }

    /**
     * 添加文字描述
     * @param image
     * @param text
     * @return
     */
    public static BufferedImage insertText(BufferedImage image, String text)throws Exception  {
        try {
            if (image == null || StringUtils.isEmpty(text)){
                return null;
            }
            // 创建新的图片
            BufferedImage newImage = new BufferedImage(image.getWidth(), (image.getHeight() + 45), BufferedImage.TYPE_4BYTE_ABGR);

            // 获取新图片面板
            Graphics2D graphics = newImage.createGraphics();

            // 将上述制作好的二维码画到新图片面板上
            graphics.drawImage(image, 0, 0, image.getWidth(), image.getHeight(), null);

            // 将文字画到新图片面板上
            graphics.setColor(Color.WHITE);
            graphics.setFont(new Font("楷体", Font.BOLD, 16)); // 字体、字型、字号

            // 获取文字的长度
            int textWidth = graphics.getFontMetrics().stringWidth(text);
            if (textWidth > image.getWidth()) {
                // 长度过长就截取前部分
                String note1 = text.substring(0, 15);
                int strWidth1 = graphics.getFontMetrics().stringWidth(note1);
                graphics.drawString(note1, 150 - strWidth1 / 2, image.getHeight() + (newImage.getHeight() - image.getHeight()) / 2 + 5);
            } else {
                graphics.drawString(text, 150 - textWidth / 2, image.getHeight() + (newImage.getHeight() - image.getHeight()) / 2 + 5); // 画文字
            }

            graphics.dispose();
            newImage.flush();
            image = newImage;

            return image;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("文字描述插入失败");
        }
    }

    /**
     * 解密，将生成的二维码转换成文字
     * @param file:二维码文件
     * @throws Exception
     */
    public static String decodeQrCode(File file) throws Exception{

        //文件是否存在
        if(!file.exists()){
            return "";
        }
        //将file转换成内存中的一张图片
        BufferedImage bufferedImage = ImageIO.read(file);

        return decodeQrCode(bufferedImage);
    }

    /**
     * 解密，将生成的二维码转换成文字
     * @param bufferedImage:二维码文件流
     * @throws Exception
     */
    public static String decodeQrCode(BufferedImage bufferedImage) throws Exception{

        if(bufferedImage == null){
            return "";
        }

        LuminanceSource luminanceSource = new BufferedImageLuminanceSource(bufferedImage);
        Binarizer binarizer = new HybridBinarizer(luminanceSource);
        BinaryBitmap binaryBitmap = new BinaryBitmap(binarizer);

        //将图片的文字信息解析到result中
        MultiFormatReader formatter = new MultiFormatReader();
        Result result = formatter.decode(binaryBitmap);
        System.out.println("解析文字为: " + result.getText());

        return result.getText();
    }

    public static BufferedImage byteToBufferedImage(byte[] bytes) {

        if (bytes == null){
            return null;
        }
        BufferedImage bufferedImage = null;
        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
            bufferedImage = ImageIO.read(byteArrayInputStream);// byteArrayInputStream可以为InputStream();
        }catch (Exception e){
            e.printStackTrace();
        }
        return bufferedImage;
    }

    public static byte[] bufferedImageToByte(BufferedImage bufferedImage) {

        if(bufferedImage == null){
            return null;
        }

        byte[] imageByte = null;
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, QRCodeUtils.FORMAT, out);
            imageByte = out.toByteArray();
        }catch (Exception e){
            e.printStackTrace();
        }
        return imageByte;
    }

    public static InputStream bufferedImageToInputStream(BufferedImage bufferedImage) {
        if(bufferedImage == null){
            return null;
        }
        return new ByteArrayInputStream(bufferedImageToByte(bufferedImage));
    }

    public static String byteToBase64(byte[] bytes) {
        if(bytes == null){
            return null;
        }
        InputStream inputStream = new ByteArrayInputStream(bytes);
        return inputStreamToBase64(inputStream);
    }
    /**
     * 图片转换Base64的方法
     *
     * @param inputStream     
     */
    public static String inputStreamToBase64(InputStream inputStream) {
        if (inputStream == null){
            return "";
        }
        InputStream in = inputStream;
        StringBuffer buffer = new StringBuffer();
        // 读取图片字节数组
        try {
            byte[] data = new byte[in.available()];
            in.read(data);
            in.close();

            // 对字节数组Base64编码
            BASE64Encoder encoder = new BASE64Encoder();
            buffer.append("data:image/jpeg;base64,");
            buffer.append(encoder.encode(Objects.requireNonNull(data)));
        } catch (IOException e) {
            throw new BaseRuntimeException("转换出错");
        } finally {
            if (null != in) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        // 返回Base64编码过的字节数组字符串
        return buffer.toString();
    }

    public static void main(String[] args) {
        try {
//            createQrCode("http://www.baidu.com",
//                    300,
//                    300,
//                    "D:\\OkayProject\\Product\\picture\\玉兔.jpg",
//                    "D:\\OkayProject\\Product\\picture\\",
//                    "玉兔二维码");

//        createQrCode("http://www.baidu.com",
//                300,
//                300,
//                null,
//                "D:\\OkayProject\\Product\\picture",
//                "玉兔二维码");
//
//        insertLogoImage("D:\\OkayProject\\Product\\picture\\玉兔二维码.jpg",
//                "D:\\OkayProject\\Product\\picture\\玉兔.jpg",
//                "D:\\OkayProject\\Product\\picture");

//            File file = new File("D:\\OkayProject\\Product\\picture\\玉兔二维码.jpg");
//            decodeQrCode(file);

//            createQrCode("http://www.baidu.com",
//                    300,
//                    300,
//                    "D:\\OkayProject\\Product\\picture\\玉兔.jpg",
//                    "D:\\OkayProject\\Product\\picture\\",
//                    "玉兔二维码",
//                    "这是文字描述这是文字描述这是文字描述");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
