package com.okay.rfid.exception;

public class RfidDeletedStateException extends RfidException {
    public RfidDeletedStateException() {}

    public RfidDeletedStateException(String message) {
        super(message);
    }

    public RfidDeletedStateException(String message, Throwable cause) {
        super(message, cause);
    }
}
