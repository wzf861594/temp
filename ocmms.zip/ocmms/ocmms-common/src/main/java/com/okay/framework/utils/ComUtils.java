package com.okay.framework.utils;

import com.okay.common.model.MetadataModel;
import com.okay.common.util.MetadataUtil;
import com.okay.framework.entity.Dept;
import com.okay.framework.entity.User;
import com.okay.okay.common.security.service.OkayUser;
import com.okay.okay.common.security.util.SecurityUtils;

import java.util.UUID;

/**
 * @ClassName: ComUtils
 * @Description: 类描述信息
 * @author: HQ.ZHU
 * @date: 2019-04-19 1:15
 * @version: V1.0
 */
public class ComUtils {

    /**
     * 获取UUID
     *
     * @return
     */
    public static String getUUID() {
        return UUID.randomUUID().toString().toUpperCase();
    }

    /**
     * 获取登录用户
     *
     * @return
     */
    public static <T> T getLoginUser() {
        /**
         * 获取当前登录用户
         */
        OkayUser okayUser = SecurityUtils.getUser();
        /**
         * 元数据对象
         */
        MetadataModel metadataModel = MetadataUtil.getMetadataModel();
        User user = new User();
        user.setUserId(String.valueOf(okayUser.getId()));
        user.setUserName(metadataModel.getUserName(okayUser.getId()));
        user.setAccount(okayUser.getUsername());
        user.setDeptId(String.valueOf(okayUser.getDeptId()));
        user.setPassWord(okayUser.getPassword());

        /**
         * 部门对象信息也装载到用户对象里
         */
        Dept dept = new Dept();
        dept.setDeptId(user.getDeptId());
        dept.setDeptName(metadataModel.getDeptName(okayUser.getDeptId()));
        user.setDept(dept);
        return (T) user;
    }
}
