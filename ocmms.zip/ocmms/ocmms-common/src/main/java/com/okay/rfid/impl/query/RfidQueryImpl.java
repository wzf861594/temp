package com.okay.rfid.impl.query;

import com.okay.rfid.mapper.QueryMapper;
import com.okay.rfid.query.Query;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

public class RfidQueryImpl<C extends RfidQueryImpl, O extends Query<R>, R> extends QueryImpl<C, O, R> {

    private String rfid;
    private String rfidLike;
    private String type;
    private Collection<String> types;
    private String businessId;
    private String businessType;
    private Collection<String> businessIds;
    private String accessBusiness;
    private String nameLike;
    private Boolean deleted;
    private Boolean includeDeleted;
    private Date gteLastUpdatedTime;
    private Date ltLastUpdatedTime;
    private String parentId;
    private Boolean complete;
    private Boolean noneState;
    private Date gteUpdateTime;
    private Date ltUpdateTime;
    private Date gteCreatedTime;
    private Date ltCreatedTime;
    private Date gteTime;
    private Date ltTime;
    private String orderBy;

    public RfidQueryImpl() {}

    public RfidQueryImpl(QueryMapper mapper) {
        super(mapper);
    }

    public O rfid(String rfid) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.rfid = rfid;
        return (O) this;
    }

    public O rfidLike(String rfidLike) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.rfidLike = rfidLike;
        return (O) this;
    }

    public O type(String type) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.type = type;
        return (O) this;
    }


    public O accessBusiness(String accessBusiness) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.accessBusiness = accessBusiness;
        return (O) this;
    }

    public O types(String... types) {
        if(types != null && types.length != 0) {
            RfidQueryImpl currQueryObject = getCurrQueryObject();
            if(currQueryObject.types == null) {
                currQueryObject.types = new HashSet<>();
            }
            for(String type : types) {
                currQueryObject.types.add(type);
            }
        }
        return (O) this;
    }

    public O businessId(String businessId, String businessType) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.businessId = businessId;
        currQueryObject.businessType = businessType;
        return (O) this;
    }

    public O businessType(String businessType) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.businessType = businessType;
        return (O) this;
    }

    public O businessIds(Collection<String> businessIds, String businessType) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.businessIds = businessIds;
        currQueryObject.businessType = businessType;
        return (O) this;
    }


    public O noneState() {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.noneState = true;
        return (O) this;
    }

    public O gteUpdateTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.gteUpdateTime = date;
        return (O) this;
    }

    public O ltUpdateTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.ltUpdateTime = date;
        return (O) this;
    }

    public O gteCreatedTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.gteCreatedTime = date;
        return (O) this;
    }

    public O ltCreatedTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.ltCreatedTime = date;
        return (O) this;
    }

    public O gteTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.gteTime = date;
        return (O) this;
    }

    public O ltTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.ltTime = date;
        return (O) this;
    }

    public O parentId(String parentId) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.parentId = parentId;
        return (O) this;
    }


    public O complete() {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.complete = true;
        return (O) this;
    }

    public O uncomplete() {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.complete = false;
        return (O) this;
    }

    public O nameLike(String nameLike) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.nameLike = nameLike;
        return (O) this;
    }

    @Deprecated
    public O normal() {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.deleted = false;
        return (O) this;
    }

    public O deleted() {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.deleted = true;
        return (O) this;
    }

    public O includeDeleted() {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.includeDeleted = true;
        return (O) this;
    }

    public O gteLastUpdatedTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.gteLastUpdatedTime = date;
        return (O) this;
    }

    public O ltLastUpdatedTime(Date date) {
        RfidQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.ltLastUpdatedTime = date;
        return (O) this;
    }

    public String getRfid() {
        return rfid;
    }

    public void setRfid(String rfid) {
        this.rfid = rfid;
    }

    public String getRfidLike() {
        return rfidLike;
    }

    public void setRfidLike(String rfidLike) {
        this.rfidLike = rfidLike;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Collection<String> getTypes() {
        return types;
    }

    public void setTypes(Collection<String> types) {
        this.types = types;
    }

    public String getBusinessId() {
        return businessId;
    }

    public void setBusinessId(String businessId) {
        this.businessId = businessId;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public Collection<String> getBusinessIds() {
        return businessIds;
    }

    public void setBusinessIds(Collection<String> businessIds) {
        this.businessIds = businessIds;
    }

    public Boolean getNoneState() {
        return noneState;
    }

    public void setNoneState(Boolean noneState) {
        this.noneState = noneState;
    }

    public Date getGteUpdateTime() {
        return gteUpdateTime;
    }

    public void setGteUpdateTime(Date gteUpdateTime) {
        this.gteUpdateTime = gteUpdateTime;
    }

    public Date getLtUpdateTime() {
        return ltUpdateTime;
    }

    public void setLtUpdateTime(Date ltUpdateTime) {
        this.ltUpdateTime = ltUpdateTime;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Boolean getComplete() {
        return complete;
    }

    public void setComplete(Boolean complete) {
        this.complete = complete;
    }

    public String getNameLike() {
        return nameLike;
    }

    public void setNameLike(String nameLike) {
        this.nameLike = nameLike;
    }

    public Date getGteLastUpdatedTime() {
        return gteLastUpdatedTime;
    }

    public void setGteLastUpdatedTime(Date gteLastUpdatedTime) {
        this.gteLastUpdatedTime = gteLastUpdatedTime;
    }

    public Date getLtLastUpdatedTime() {
        return ltLastUpdatedTime;
    }

    public void setLtLastUpdatedTime(Date ltLastUpdatedTime) {
        this.ltLastUpdatedTime = ltLastUpdatedTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public Boolean getIncludeDeleted() {
        return includeDeleted;
    }

    public void setIncludeDeleted(Boolean includeDeleted) {
        this.includeDeleted = includeDeleted;
    }

    public Date getGteCreatedTime() {
        return gteCreatedTime;
    }

    public void setGteCreatedTime(Date gteCreatedTime) {
        this.gteCreatedTime = gteCreatedTime;
    }

    public Date getLtCreatedTime() {
        return ltCreatedTime;
    }

    public void setLtCreatedTime(Date ltCreatedTime) {
        this.ltCreatedTime = ltCreatedTime;
    }

    public Date getGteTime() {
        return gteTime;
    }

    public void setGteTime(Date gteTime) {
        this.gteTime = gteTime;
    }

    public Date getLtTime() {
        return ltTime;
    }

    public void setLtTime(Date ltTime) {
        this.ltTime = ltTime;
    }

    public String getAccessBusiness() {
        return accessBusiness;
    }

    public void setAccessBusiness(String accessBusiness) {
        this.accessBusiness = accessBusiness;
    }
}
