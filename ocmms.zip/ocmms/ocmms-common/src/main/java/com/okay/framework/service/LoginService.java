package com.okay.framework.service;

import com.okay.framework.entity.User;

public interface LoginService {
    User selectByAccount(String account);
    User login(String account, String passWord);
}
