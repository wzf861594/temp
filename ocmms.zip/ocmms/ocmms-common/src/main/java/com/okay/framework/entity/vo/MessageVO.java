package com.okay.framework.entity.vo;

import com.okay.framework.entity.Message;
import lombok.Data;

/**
 * @Author CZJ[OKAY]
 * @Date 2020/8/25 17:54
 * @Description 消息提醒VO
 **/
@Data
public class MessageVO extends Message {

    /**
     * 消息对象类型
     **/
    private String businessTypeShow;

    /**
     * 创建人
     **/
    private String creatorShow;
}
