package com.okay.framework.exception;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;


/**
 *  @ClassName: BaseRuntimeException
 *	@Description:
 *	自定义异常信息
 *  标准错误信息定义为错误代码+错误信息
 *  如：【0541】程序异常，请联系程序开发人员！
 *  @author: zhongmz
 *  @Date: 2019/7/16 10:57
 *  @version: V1.0
 */
public class BaseRuntimeException extends RuntimeException{

	private static final String startChar = "【";

	private static final String endChar = "】";

	/**
	 * 设置错误代码+错误信息
	 * @Param message
	 */
	public BaseRuntimeException(String message) {
		super(message);
	}

	public BaseRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public BaseRuntimeException(Throwable cause) {
		super(cause);
	}

	protected BaseRuntimeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	
	/**
	 * 获取单纯的错误信息
	 * @return String  错误信息
	 */
	public String getErrorMessage(){
		String message = super.getMessage();
		if(StringUtils.isNotBlank(message) && message.startsWith(startChar) && message.indexOf(endChar) != -1)
		{
			int endIndex = message.indexOf(endChar);
			return message.substring(endIndex + 1);
		}
		return message;
	}

	/**
	 * 获取单纯的异常代码
     * 如未设置异常代码则获取异常信息中的异常代码,如异常信息中未设置异常代码则使用默认的异常代码
	 * @Param
	 * @return java.lang.String
	 */
	public String getErrorCode() {
		String message = getMessage();
		if(StringUtils.isNotBlank(message) && message.startsWith(startChar) && message.indexOf(endChar) != -1)
		{
			String errorCode = message.substring(1, message.indexOf(endChar));
			/***截取【】内的异常代码，如果截取不为数字或者异常码位数不足则设为默认代码（如：数字异常）***/
			if(errorCode.length()>2 && NumberUtils.isDigits(errorCode))
				return errorCode;
			return SysErrorDefine.SYSTEM_ERROR_CODE;

		}else
		{
			return SysErrorDefine.SYSTEM_ERROR_CODE;
		}

	}

	/**
	 * 截取异常等级
	 * @Param
	 * @return java.lang.String
	 */
	public int getErrorLevel()
	{
		String errorCodeString = this.getErrorCode().substring(2, 3);
		int errorCode = Integer.valueOf(errorCodeString).intValue();
		return errorCode;
	}

}
