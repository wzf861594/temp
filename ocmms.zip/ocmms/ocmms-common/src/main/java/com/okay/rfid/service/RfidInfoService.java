package com.okay.rfid.service;

import com.okay.rfid.info.RfidInfo;
import com.okay.rfid.query.RfidInfoQuery;

public interface RfidInfoService {

    /**
     * 创建RFID信息.
     * @param name 必填，名称.
     * @param rfid 必填，只能同时存在同一个非DELETE状态下的RFID.
     * @param type 必填，RFID的分类,具体值根据业务输入.
     * @param businessId 业务ID.
     * @param businessType 如果存在businessId则必填，业务分类,具体值根据业务输入.
     * @param createdBy
     * @param describe
     * @return
     */
    RfidInfo createRfidInfo(String name, String rfid, String type, String businessId, String businessType, String createdBy, String describe);

    /**
     * 更新RFID信息.
     * @param id 必填，根据ID更新信息.
     * @param name 必填，名称.
     * @param type 必填，RFID的分类,具体值根据业务输入.
     * @param lastUpdatedBy
     * @param describe
     * @return
             */
    RfidInfo updateRfidInfo(String id, String name, String type, String lastUpdatedBy, String describe);

    /**
     * 移除RFID信息.
     * <p/>移除后将成为历史数据，不可再改变.
     * @param id 必填，根据ID设置DELETE状态.
     * @param lastUpdatedBy
     * @return
     */
    RfidInfo removeRfidInfo(String id, String lastUpdatedBy);

    /**
     * 删除RFID信息.
     * @param id 必填，根据ID删除.
     * @return
     */
    RfidInfo deleteRfidInfo(String id);

    /**
     * 获取RFID信息.
     * @param id
     * @return
     */
    RfidInfo getRfidInfo(String id);


    RfidInfoQuery createRfidInfoQuery();

}
