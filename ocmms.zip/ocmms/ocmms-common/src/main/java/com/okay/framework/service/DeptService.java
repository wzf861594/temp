package com.okay.framework.service;

import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Dept;
import com.okay.framework.entity.Page;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @ClassName: DeptService
 * @Description: 部门管理业务处理类
 * @author: HQ.ZHU
 * @date: 2019-04-25 16:36
 * @version: V1.0
 */  
public interface DeptService {
    List<Dept> findDataListByPage(Page page);
    Map<String,Object> findDataMapById(String deptId);
    Dept add(Dept dept);
    void modify(Dept dept);
    void remove(Set<String> deptIdList);
    void cancel(Set<String> deptIdList);
    void recover(Set<String> deptIdList);
    List<DataTree> findDataTreeList();
    List<DataTree> findDataTreeListByDeptId(String deptId);
    List<Dept> findDataListByQuery(Map<String, Object> qeury);
}