package com.okay.common.util;

import com.okay.common.feign.RemoteMenuExtensionService;
import com.okay.okay.admin.api.dto.MenuTree;
import com.okay.okay.common.core.util.R;
import com.okay.okay.common.core.util.SpringContextHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zyx
 * @version 1.0
 * @date 2020/7/27 17:07
 * @describe 获取菜单工具
 */
public class MenuTreeUtil {
    /**
     * 获取菜单栏
     * @return
     */
    public static List<MenuTree> getAllMenu(String type,String parentId) {
        RemoteMenuExtensionService remoteMenuExtensionService
                = SpringContextHolder.getBean(RemoteMenuExtensionService.class);
        R<List<MenuTree>> result = remoteMenuExtensionService.getSysMenu(type,parentId);
        if(null != result){
            return result.getData();
        }
        return new ArrayList<>();
    }
}
