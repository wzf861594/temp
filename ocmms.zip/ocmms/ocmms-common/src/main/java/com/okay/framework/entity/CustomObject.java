package com.okay.framework.entity;

import java.util.List;

public class CustomObject {
    private String objId;

    private String objName;

    private String objSys;

    private Integer seqNo;

    private String parentId;

    private List<CustomObject> children;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getObjName() {
        return objName;
    }

    public void setObjName(String objName) {
        this.objName = objName;
    }

    public String getObjSys() {
        return objSys;
    }

    public void setObjSys(String objSys) {
        this.objSys = objSys;
    }

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public List<CustomObject> getChildren() {
        return children;
    }

    public void setChildren(List<CustomObject> children) {
        this.children = children;
    }
}