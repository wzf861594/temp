package com.okay.rfid.info;

import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * rfid_business
 * @author 
 */
public interface RfidBusiness {

    String getId();

    String getParentId();

    String getBusinessId();

    String getBusinessType();

    String getBusinessBy();

    Date getCreatedTime();

    Date getUpdatedTime();

    Boolean getIsComplete();

    boolean isComplete();

}