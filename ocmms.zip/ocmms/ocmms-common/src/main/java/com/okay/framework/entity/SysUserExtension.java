package com.okay.framework.entity;

import java.util.Date;
import java.io.Serializable;

/**
 * 系统员工表(SysUserExtension)实体类
 *
 * @author makejava（zyx）
 * @since 2020-09-12 14:06:40
 */
public class SysUserExtension implements Serializable {
    private static final long serialVersionUID = 508922994370523136L;
    /**
    * 主键ID
    */
    private Integer id;
    /**
    * 关联用户表ID
    */
    private Integer userId;
    /**
    * 名称
    */
    private String chineseName;
    /**
    * 身份证号
    */
    private String idCard;
    /**
    * 性别
    */
    private Integer sex;
    /**
    * 生日
    */
    private Date birthday;
    /**
    * 电子邮箱
    */
    private String email;
    /**
    * 住址
    */
    private String address;
    /**
    * 邮编
    */
    private String postCode;
    /**
    * 政治面貌
    */
    private Integer political;
    /**
    * 民族
    */
    private Integer nation;
    /**
    * 籍贯
    */
    private String nativePlace;
    /**
    * 职位
    */
    private Integer duty;
    /**
    * 在职状态
    */
    private String dutyState;
    /**
    * 婚姻状况
    */
    private Integer marriage;
    /**
    * 健康状况
    */
    private Integer health;
    /**
    * 入职日期
    */
    private Date hiredate;
    /**
    * 离职日期
    */
    private Date termdate;
    /**
    * 头像
    */
    private Object photo;
    /**
    * 排序
    */
    private Integer sort;
    /**
    * 备注
    */
    private String remark;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getChineseName() {
        return chineseName;
    }

    public void setChineseName(String chineseName) {
        this.chineseName = chineseName;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public Integer getPolitical() {
        return political;
    }

    public void setPolitical(Integer political) {
        this.political = political;
    }

    public Integer getNation() {
        return nation;
    }

    public void setNation(Integer nation) {
        this.nation = nation;
    }

    public String getNativePlace() {
        return nativePlace;
    }

    public void setNativePlace(String nativePlace) {
        this.nativePlace = nativePlace;
    }

    public Integer getDuty() {
        return duty;
    }

    public void setDuty(Integer duty) {
        this.duty = duty;
    }

    public String getDutyState() {
        return dutyState;
    }

    public void setDutyState(String dutyState) {
        this.dutyState = dutyState;
    }

    public Integer getMarriage() {
        return marriage;
    }

    public void setMarriage(Integer marriage) {
        this.marriage = marriage;
    }

    public Integer getHealth() {
        return health;
    }

    public void setHealth(Integer health) {
        this.health = health;
    }

    public Date getHiredate() {
        return hiredate;
    }

    public void setHiredate(Date hiredate) {
        this.hiredate = hiredate;
    }

    public Date getTermdate() {
        return termdate;
    }

    public void setTermdate(Date termdate) {
        this.termdate = termdate;
    }

    public Object getPhoto() {
        return photo;
    }

    public void setPhoto(Object photo) {
        this.photo = photo;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

}