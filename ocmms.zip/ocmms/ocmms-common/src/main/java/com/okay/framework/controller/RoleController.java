package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Role;
import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.service.RoleService;
import com.okay.framework.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: RoleController
 * @Description: 角色管理控制器
 * @author: HQ.ZHU
 * @date: 2019-05-15 1:19
 * @version: V1.0
 */
@RestController
@RequestMapping("/role")
public class RoleController extends BaseController {

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserService userService;

    /**
     * 根据ID获取角色
     * @param jsonParam
     * @return java.lang.String
     */
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    public JSONObject getById(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try {
            String roleId = jsonParam.getString("roleId");
            if(roleId == null || "".equals(roleId)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.PARAM_ISNULL_FAIL,"角色ID"));
            }
            Role role = roleService.findById(roleId);

            jsonObject.put("code", 1);
            jsonObject.put("data", role);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @RequestMapping(value = "/dataTree", method = RequestMethod.POST)
    public JSONObject dataTree(){
        JSONObject jsonObject = new JSONObject();
        try {
            List<DataTree> dataTreeList = roleService.findDataTreeList();
            jsonObject.put("code",1);
            jsonObject.put("data",dataTreeList);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 新增角色
     * @param role
     * @return java.lang.String
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST, produces = "application/json")
    public JSONObject add(@RequestBody @Valid Role role){
        JSONObject jsonObject = new JSONObject();
        try {
            role.setRoleId(this.getSequence());
            int row = roleService.add(role);
            if (row != 1) {
                throw new BaseRuntimeException(SysErrorDefine.ADD_DATA_ERROR);
            }

            role = roleService.findById(role.getRoleId());
            jsonObject.put("data", role);
            throw new BaseRuntimeException(SysErrorDefine.ADD_DATA_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 修改角色
     * @param role
     * @return java.lang.String
     */
    @RequestMapping(value = "/modify", method = RequestMethod.POST, produces = "application/json")
    public JSONObject modify(@RequestBody @Valid Role role){
        JSONObject jsonObject = new JSONObject();
        try {
            if(role.getRoleId() == null || "".equals(role.getRoleId())){
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA));
            }
            int row = roleService.modify(role);
            if(row != 1) {
                throw new BaseRuntimeException(SysErrorDefine.MODIFY_DATA_ERROR);
            }
            throw new BaseRuntimeException(SysErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 注销
     * @return
     */
    @RequestMapping(value = "/cancel", method = RequestMethod.POST, produces = "application/json")
    public JSONObject cancel(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        try {
            String roleId = jsonParam.getString("roleId");
            String confirmFlg = jsonParam.getString("confirmFlg");
            if (roleId == null || "".equals(roleId)){
                throw new BaseRuntimeException(SysErrorDefine.CHOOSE_HANDLE_DATA);
            }

            //判断是否为可删除的数据
            Role role = roleService.findById(roleId);
            if(role.getIsCancel() != null && role.getIsCancel() == 0){
                throw new BaseRuntimeException(String.format(SysErrorDefine.HANDLE_DATA_FAIL,"删除"));
            }

            //注销之前先判断是否绑定了用户
            List<User> userList = userService.findUserByRoleId(roleId);
            if(userList != null && userList.size()>0){
                throw new BaseRuntimeException(SysErrorDefine.REMOVE_LINKED_DATA_FAIL);
            }

            //确认删除询问提示
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)){
                throw new BaseRuntimeException(SysErrorDefine.ASK_HANDLE_CANCEl);
            }

            role.setStatus(2);
            int row = roleService.cancel(role);
            if(row != 1) {
                throw new BaseRuntimeException(SysErrorDefine.CANCEL_ERROR);
            }
            throw new BaseRuntimeException(SysErrorDefine.CANCEL_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 保存绑定的用户
     * @return
     */
    @RequestMapping(value = "saveSelected", method = RequestMethod.POST, produces = "application/json")
    public JSONObject saveSelectedUsers(@RequestBody JSONObject role){
        JSONObject jsonObject = new JSONObject();
        try{
            String roleId = role.getString("roleId");
            if(roleId == null || "".equals(roleId)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHECK_NOT_NULL,"角色ID"));
            }
            List<String> userIdList = (ArrayList<String>) role.get("userIds");
            List<Map<String, String>> roleUserList = new ArrayList<Map<String, String>>();
            for (int i=0; i<userIdList.size(); i++){
                Map<String, String> ur = new HashMap<String, String>();
                ur.put("recid", getSequence());
                ur.put("roleid", roleId);
                ur.put("userid", userIdList.get(i));
                ur.put("remark", "");
                roleUserList.add(ur);
            }
            roleService.saveSelectedUsers(roleId, roleUserList);
            //查询回显数据
            List<User> userList = userService.findUserByRoleId(roleId);
            jsonObject.put("userList", userList);
            throw new BaseRuntimeException(String.format(SysErrorDefine.SAVE_SUCCESS));
        }catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    @RequestMapping(value = "/removeSelected", method = RequestMethod.POST)
    public JSONObject removeSelectedUsers(@RequestBody JSONObject paramJson){
        JSONObject jsonObject = new JSONObject();
        try {
            String roleId = paramJson.getString("roleId");
            String confirmFlg = paramJson.getString("confirmFlg");
            if(roleId == null || "".equals(roleId)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHECK_NOT_NULL,"角色ID"));
            }
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.ASK_HANDLE_DEL));
            }
            List<String> userIdList = (ArrayList<String>) paramJson.get("userIds");
            List<Map<String, String>> roleUserList = new ArrayList<Map<String, String>>();
            roleService.removeUserFormRole(roleId, userIdList);
            //查询回显数据
            List<User> userList = userService.findUserByRoleId(roleId);
            jsonObject.put("userList", userList);
            throw new BaseRuntimeException(String.format(SysErrorDefine.DELETE_SUCCESS));
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

}
