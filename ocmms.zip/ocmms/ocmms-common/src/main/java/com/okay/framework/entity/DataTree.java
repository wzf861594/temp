package com.okay.framework.entity;

import java.io.Serializable;
import java.util.List;

/**
 * @ClassName: DataTree
 * @Description: 用于封装Layui的树结构实体
 * @author: HQ.ZHU
 * @date: 2019-05-03 19:57
 * @version: V1.0
 */
public class DataTree implements Serializable {

    private static final long serialVersionUID = 6459283726714575001L;
    private String nodeId;
    private String nodeName;
    private String nodeCode;
    private String href;
    private boolean spread = false;//是否展开，默认为false.
    private boolean checked;//是否选中
    private boolean disabled;//是否禁用选择
    private Integer nodeType;
    private String url;
    private String parentId;
    private List<DataTree> childNodes;
    private String remark;

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getNodeCode() {
        return nodeCode;
    }

    public void setNodeCode(String nodeCode) {
        this.nodeCode = nodeCode;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public boolean isSpread() {
        return spread;
    }

    public void setSpread(boolean spread) {
        this.spread = spread;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    public Integer getNodeType() {
        return nodeType;
    }

    public void setNodeType(Integer nodeType) {
        this.nodeType = nodeType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public List<DataTree> getChildNodes() {
        return childNodes;
    }

    public void setChildNodes(List<DataTree> childNodes) {
        this.childNodes = childNodes;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public int hashCode() {
        return nodeId != null ? nodeId.hashCode() : -999;
    }

}
