package com.okay.framework.service.impl;

import com.okay.framework.entity.User;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.mapper.UserMapper;
import com.okay.framework.service.LoginService;
import com.okay.framework.utils.MD5Utils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class LoginServiceImpl implements LoginService {

    @Resource
    private UserMapper userMapper = null;

    @Override
    public User login(String account, String passWord) {
        if ("".equals(account) || "".equals(passWord))
            throw new BaseRuntimeException(SysErrorDefine.USER_OR_PASSWORD_ISNULL_FAIL);

        User user = selectByAccount(account);

        if (user == null)
            throw new BaseRuntimeException(SysErrorDefine.USER_NOT_EXIST_ERROR);

        if (!user.getPassWord().equals(MD5Utils.MD5Encode(passWord)))
            throw new BaseRuntimeException(SysErrorDefine.PASSWORD_ERROR);

        return user;
    }

    @Override
    public User selectByAccount(String account) {
        return userMapper.selectByAccount(account);
    }
}
