package com.okay.rfid.impl.query;

import java.util.ArrayList;
import java.util.Collection;

public class Page<R> extends ArrayList<R> {
    protected int pageNum;
    protected int pageSize;
    protected int pageCount;
    protected long total;

    public Page() {}

    public Page(int pageNum, int pageSize, int pageCount, long total, Collection<R> data) {
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.pageCount = pageCount;
        this.total = total;
        if(data != null) {
            this.addAll(data);
        }
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public long getTotal() {
        return total;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageNum() {
        return pageNum;
    }


}
