package com.okay.framework.service;

import com.okay.framework.exception.SequenceCreateException;

/**
 * @ClassName: SequenceService
 * @Description: 序列业务接口
 * @author: HQ.ZHU
 * @date: 2019-04-21 0:15
 * @version: V1.0
 */
public interface SequenceService {
    Long getSequence(String tableName) throws SequenceCreateException;
    String getSequence() ;
}
