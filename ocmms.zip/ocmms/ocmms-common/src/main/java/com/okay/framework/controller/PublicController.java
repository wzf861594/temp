package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.framework.exception.ExceptionUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName: PublicController
 * @Description: 公共业务控制器
 * @author: HQ.ZHU
 * @date: 2019-09-29 9:42
 * @version: V1.0
 */
@RestController
@RequestMapping("/sysCommon")
public class PublicController extends BaseController {

    /**
     * 获取主键
     * @Param jsonParam
     * @return com.alibaba.fastjson.JSONObject
     */
    @RequestMapping(value = "/getPrimaryKey", method = RequestMethod.GET, produces = "application/json")
    public JSONObject getPrimaryKey(){
        JSONObject jsonObject = new JSONObject();
        try {
            String primaryKey = getSequence();

            jsonObject.put("code", 1);
            jsonObject.put("data", primaryKey);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 提供获取登录用户的公共接口
     * @return
     */
    @RequestMapping(value = "/loginUser", method = RequestMethod.GET, produces = "application/json")
    public JSONObject getLoginUserInfo(){
        JSONObject jsonObject = new JSONObject();
        try{
            jsonObject.put("loginUser", getLoginUser());
            jsonObject.put("code", 1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取用户功能列表
     * @return
     */
    @RequestMapping(value = "/userFuns", method = RequestMethod.GET, produces = "application/json")
    public JSONObject getUserFunList(){
        JSONObject jsonObject = new JSONObject();
        try{
            jsonObject.put("userFuns", getLoginUser());
            jsonObject.put("code", 1);
        }catch (Exception e){
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }
}
