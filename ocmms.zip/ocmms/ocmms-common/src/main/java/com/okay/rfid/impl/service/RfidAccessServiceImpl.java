package com.okay.rfid.impl.service;

import com.okay.rfid.entity.RfidAccessEntity;
import com.okay.rfid.entity.RfidBeaconEntity;
import com.okay.rfid.exception.RfidDeletedStateException;
import com.okay.rfid.exception.RfidException;
import com.okay.rfid.exception.RfidUniqueException;
import com.okay.rfid.impl.entity.RfidAccessEntityImpl;
import com.okay.rfid.impl.entity.RfidBeaconEntityImpl.State;
import com.okay.rfid.info.RfidAccess;
import com.okay.rfid.mapper.RfidAccessMapperRfid;
import com.okay.rfid.mapper.RfidAccessQueryMapper;
import com.okay.rfid.mapper.RfidBeaconMapperRfid;
import com.okay.rfid.impl.query.RfidAccessQueryImpl;
import com.okay.rfid.query.RfidAccessQuery;
import com.okay.rfid.service.RfidAccessService;
import com.okay.rfid.util.Generate;
import com.okay.rfid.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class RfidAccessServiceImpl implements RfidAccessService {

    @Autowired
    protected RfidAccessMapperRfid rfidAccessMapper;

    @Autowired
    protected RfidBeaconMapperRfid rfidBeaconMapper;

    @Autowired
    protected RfidAccessQueryMapper rfidAccessQueryMapper;

    @Override
    @Transactional
    public RfidAccess createRfidAccess(String rfid, String accessBusiness) {
        checkRequiredParam(rfid, accessBusiness);
        checkRfidUnique(rfid);
        updateBeacon(rfid, State.ACCESS);
        return saveRfidAccess(Generate.getNextId(), rfid, accessBusiness, null, null, null, null);
    }

    @Override
    @Transactional
    public RfidAccess createRfidAccess(String rfid, String accessBusiness, String type, String businessId, String businessType, String createdBy) {
        checkRequiredParam(rfid, accessBusiness);
        if(!StringUtil.isNull(businessId) && StringUtil.isNull(businessType)) {
            throw new RfidException("businessType is null");
        }
        checkRfidUnique(rfid);
        updateBeacon(rfid, State.ACCESS);
        return saveRfidAccess(Generate.getNextId(), rfid, accessBusiness, type, businessId, businessType, createdBy);
    }

    @Override
    @Transactional
    public RfidAccess createRfidAccessUnique(String rfid, String accessBusiness) {
        checkRequiredParam(rfid, accessBusiness);
        checkInRfidUnique(rfid);
        checkRfidUnique(rfid);
        updateBeacon(rfid, State.ACCESS);
        return saveRfidAccess(rfid, rfid, accessBusiness, null, null, null, null);
    }

    @Override
    @Transactional
    public RfidAccess createRfidAccessUnique(String rfid, String accessBusiness, String type, String businessId, String businessType, String createdBy) {
        checkRequiredParam(rfid, accessBusiness);
        if(!StringUtil.isNull(businessId) && StringUtil.isNull(businessType)) {
            throw new RfidException("businessType is null");
        }
        checkInRfidUnique(rfid);
        checkRfidUnique(rfid);
        updateBeacon(rfid, State.ACCESS);
        return saveRfidAccess(rfid, rfid, accessBusiness, type, businessId, businessType, createdBy);
    }

    @Override
    @Transactional
    public List<? extends RfidAccess> deleteRfidAccess(Collection<String> ids) {
        List<RfidAccessEntity> accessEntityList = getCheckIdFind(ids);
        for(RfidAccessEntity accessEntity : accessEntityList) {
            rfidAccessMapper.deleteByPrimaryKey(accessEntity.getId());
        }
        return accessEntityList;
    }

    @Override
    public List<? extends RfidAccess> getRfidAccess(String rfid) {
        if(StringUtil.isNull(rfid)) {
            throw new RfidException("RFID is null");
        }
        return rfidAccessMapper.selectByRfid(rfid);
    }

    @Override
    public RfidAccessQuery createRfidAccessQuery() {
        return new RfidAccessQueryImpl(rfidAccessQueryMapper);
    }

    protected RfidAccessEntity saveRfidAccess(String id, String rfid, String accessBusiness, String type, String businessId, String businessType, String createdBy) {
        RfidAccessEntity accessEntity = new RfidAccessEntityImpl();
        accessEntity.setId(id);
        accessEntity.setRfid(rfid);
        accessEntity.setAccessBusiness(accessBusiness);
        accessEntity.setCreatedTime(new Date());

        accessEntity.setType(type);
        accessEntity.setBusinessId(businessId);
        accessEntity.setBusinessType(businessType);
        accessEntity.setCreatedBy(createdBy);
        rfidAccessMapper.insert(accessEntity);

        return accessEntity;
    }

    protected List<RfidAccessEntity> getCheckIdFind(Collection<String> ids) {
        if(ids == null || ids.isEmpty()) {
            throw new RfidException("id is null");
        }
        List<RfidAccessEntity> accessEntityList = new ArrayList<>();
        Set<String> hasIds = new HashSet<>();
        for(String id : ids) {
            if(StringUtil.isNull(id)) {
                throw new RfidException("id is null");
            }
            if(!hasIds.contains(id)) {
                hasIds.add(id);
                RfidAccessEntity accessEntity = rfidAccessMapper.selectByPrimaryKey(id);
                if(accessEntity == null) {
                    throw new RfidException("RFIDAccess '" + id + "' not find");
                }
                accessEntityList.add(accessEntity);
            }
        }
        return accessEntityList;
    }

    protected void updateBeacon(String rfid, State state) {
        RfidBeaconEntity beaconEntity = rfidBeaconMapper.selectByRfid(rfid);
        if(beaconEntity == null) {
            throw new RfidException("RFID不存在");
        }
        State currState = beaconEntity.getState() != null ? State.valueOf(beaconEntity.getState()) : null;
        if(currState != null && currState == state) {
            return;
        }
        if(State.DELETE == currState) {
            throw new RfidDeletedStateException("删除状态");
        }
        if(currState == null || (currState == State.ACCESS && state != State.ACCESS)) {
            beaconEntity.setState(state.name());
            beaconEntity.setUpdatedTime(new Date());
            rfidBeaconMapper.updateByPrimaryKey(beaconEntity);
        }
    }

    protected void checkRfidUnique(String rfid) {
        if (rfidAccessMapper.selectByPrimaryKey(rfid) != null) {
            throw new RfidUniqueException("RFID接入唯一");
        }
    }

    protected void checkInRfidUnique(String rfid) {
        List<? extends RfidAccess> accessList = rfidAccessMapper.selectByRfid(rfid);
        if(accessList != null && !accessList.isEmpty()) {
            throw new RfidUniqueException("RFID接入唯一");
        }
    }

    protected void checkRequiredParam(String rfid, String accessBusiness) {
        if(StringUtil.isNull(rfid)) {
            throw new RfidException("RFID is null");
        }
        if(StringUtil.isNull(accessBusiness)) {
            throw new RfidException("accessBusiness is null");
        }
    }
}
