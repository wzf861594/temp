package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.R;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.service.UserRoleService;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 用户角色控制类
 *
 * @author okay
 * @time 2021年10月25日11:43:47
 */
@Validated
@RestController
@AllArgsConstructor
@RequestMapping("/userRole")
public class UserRoleController {

    private final UserRoleService userRoleService;

    /**
     * 通过角色主键查询数据列表
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/getByRoleId/{id}")
    public R getByRoleId(@NotNull(message = "ID不能为空") @PathVariable Integer id) {
        return R.ok(userRoleService.getByRoleId(id)).setMsg("");
    }

    /**
     * 保存分配的角色用户
     *
     * @param param
     * @return JSONObject
     */
    @PostMapping(value = "/saveRoleUser")
    public JSONObject saveRoleUser(@RequestBody JSONObject param) {
        JSONObject jsonObject = new JSONObject();
        try {
            Integer roleId = param.getInteger("roleId");
            List<Integer> userIdList = param.getJSONArray("userId").toJavaList(Integer.class);
            if (roleId == null) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "角色"));
            }
            boolean isOk = userRoleService.saveRoleUser(roleId, userIdList);
            String msg = isOk ? SysErrorDefine.SAVE_SUCCESS : SysErrorDefine.SAVE_ERROR;
            ExceptionUtil.formatResultJsonObject(jsonObject, msg);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }



}