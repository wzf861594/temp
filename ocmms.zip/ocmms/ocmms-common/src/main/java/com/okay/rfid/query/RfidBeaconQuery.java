package com.okay.rfid.query;

import com.okay.rfid.query.result.RfidBeaconResult;

import java.util.Date;


public interface RfidBeaconQuery extends QueryLink<RfidBeaconQuery>, Query<RfidBeaconResult> {

    RfidBeaconQuery nameLike(String nameLike);

    RfidBeaconQuery rfidLike(String rfidLike);

    RfidBeaconQuery type(String types);

    RfidBeaconQuery types(String... types);

    RfidBeaconQuery state(String state);

    RfidBeaconQuery noneState();

    RfidBeaconQuery gteUpdateTime(Date date);

    RfidBeaconQuery ltUpdateTime(Date date);

    RfidBeaconQuery orderByUpdateTimeDesc();

}
