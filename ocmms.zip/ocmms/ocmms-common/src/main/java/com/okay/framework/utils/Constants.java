package com.okay.framework.utils;

/**
 * @ClassName: Constants
 * @Description: 常量类
 * @author: HQ.ZHU
 * @date: 2019-04-19 1:18
 * @version: V1.0
 */
public class Constants {

    /**
     * 用户保存在会话中的固定KEY值
     */
    //public static final String USER_SESSION_KEY = "USER_SESSION_KEY_9F41C55E05583FF8E996AB59D55E1C3D";
    public static final String DATA_LIST_ERROR_MSG = "数据列表查询异常，请联系管理员！";

    /**
     * 自动缟码常量
     * 先在编码管理新增编号，然后在该地方登记常量备用
     * prefix: ATC（AUTOCODE）
     */
    public static final String ATC_PMS_CODE = "PMS_CODE";
    public static final String ATC_DICT_CODE = "DICT_CODE";

    /**
     * 当前选中的菜单权限
     */
    public static final String CURR_SELECT_PERMISSION = "SELECT_PERMISSION";
    public static final String USER_TOKEN = "Authorization";

    /**
     * 表单模型类型.
     */
    public static final long ACTIVITIFORM_MODEL_TYPE = 20L;
}
