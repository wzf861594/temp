package com.okay.rfid.mapper;

import com.okay.rfid.query.RfidInfoQuery;
import com.okay.rfid.query.result.RfidInfoResult;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RfidInfoQueryMapper extends QueryMapper<RfidInfoQuery, RfidInfoResult> {

}