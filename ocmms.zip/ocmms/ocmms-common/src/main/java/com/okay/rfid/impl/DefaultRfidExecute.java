package com.okay.rfid.impl;

import com.okay.rfid.factory.RfidAccessFactory;
import com.okay.rfid.info.RfidAccess;
import com.okay.rfid.info.RfidInfo;
import com.okay.rfid.util.StringUtil;

public abstract class DefaultRfidExecute implements Runnable {

    protected abstract class Support implements Runnable {
        private RfidInfo info;
        private RfidAccess access;
        private DefaultRfidTelllog tellLog;
        private DefaultRfidTellBusiness tellBusiness;
        public Support(RfidInfo info, RfidAccess access, DefaultRfidTelllog tellLog, DefaultRfidTellBusiness tellBusiness) {
            this.info = info;
            this.access = access;
            this.tellLog = tellLog;
            this.tellBusiness = tellBusiness;
        }

        public String getName() {
            return isInfo() ? info.getName() : null;
        }

        public String getRfid() {
            return isInfo() ? info.getRfid() : null;
        }

        public String getType() {
            return isInfo() ? info.getType() : null;
        }

        public String getBusinessId() {
            return isInfo() ? info.getBusinessId() : null;
        }

        public String getBusinessType() {
            return isInfo() ? info.getBusinessType() : null;
        }

        public String getDeviceId() {
            return tellLog.getDeviceId();
        }

        public String getOperator() {
            return tellLog.getOperator();
        }

        public String getAccessBusiness() {
            return tellBusiness.getAccessBusiness();
        }
        public String getAccessBusinessId() {
            return access.getBusinessId();
        }

        public String getAccessBusinessType() {
            return access.getBusinessType();
        }

        public String getAccessBusinessBy() {
            return access.getCreatedBy();
        }

        public Object getParam() {
            return tellBusiness.getParam();
        }

        public void bindBusiness(String accessBusinessId, String accessBusinessType) {
            if(StringUtil.isNull(accessBusinessId) && StringUtil.isNull(accessBusinessType)) {
                tellBusiness.setAccessBusinessId(accessBusinessId);
                tellBusiness.setAccessBusinessType(accessBusinessType);
            }
        }

        public boolean isInfo() {
            return info != null;
        }

        @Deprecated
        public void setNotLog() {
            tellLog.setNotLog();
        }

        @Deprecated
        public void setBusinessNotLog() {
            tellBusiness.setNotLog();
        }
    }

    public DefaultRfidExecute() {}

    public DefaultRfidExecute(String... keys) {
        for(String key : keys) {
            RfidAccessFactory.put(key, this);
        }
    }

    public Runnable createSupport(RfidInfo info, RfidAccess access, DefaultRfidTelllog tellLog, DefaultRfidTellBusiness tellBusiness) {
        return new Support(info, access, tellLog, tellBusiness) {
            @Override
            public void run() {
                execute(this);
            }
        };
    }

    @Override
    public void run() {
        execute(null);
    }

    public abstract void execute(Support support);

}