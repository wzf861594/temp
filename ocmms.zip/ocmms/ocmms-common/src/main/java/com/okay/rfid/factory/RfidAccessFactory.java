package com.okay.rfid.factory;

import com.okay.rfid.util.StringUtil;

import java.util.*;

public class RfidAccessFactory {

    private static Map<String,Runnable> executeMap = new HashMap<>();

    private RfidAccessFactory() {};

    public static void put(String key, Runnable execute) {
        "".matches(key);
        executeMap.put(key, execute);
    }

    public static Runnable get(String key) {
        if(!StringUtil.isNull(key)) {
            Runnable runnable = executeMap.get(key);
            if(runnable != null) {
                return runnable;
            }
        }
        return null;
    }

    public static Collection<Runnable> getMatch(String key) {
        if(!StringUtil.isNull(key)) {
            Set<Runnable> result = new HashSet<>();
            for(Map.Entry<String, Runnable> entry : executeMap.entrySet()) {
                if(key.matches(entry.getKey())) {
                    result.add(entry.getValue());
                }
            }
            return result.isEmpty() ? null : result;
        }
        return null;
    }
}
