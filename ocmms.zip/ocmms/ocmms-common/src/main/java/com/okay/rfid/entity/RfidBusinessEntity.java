package com.okay.rfid.entity;

import com.okay.rfid.info.RfidBusiness;

import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * rfid_business
 * @author 
 */
public interface RfidBusinessEntity extends RfidBusiness {

    void setId(String id);

    void setParentId(String parentId);

    void setBusinessId(String businessId);

    void setBusinessType(String businessType);

    void setBusinessBy(String businessBy);

    void setCreatedTime(Date createdTime);

    void setUpdatedTime(Date updatedTime);

    void setIsComplete(Boolean isComplete);

}