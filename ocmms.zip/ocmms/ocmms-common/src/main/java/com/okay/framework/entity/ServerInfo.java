package com.okay.framework.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author okay
 */
public class ServerInfo implements Serializable {
    private String serverInfoId;

    private String serverName;

    private String serverIp;

    private String serverPort;

    private Date updateTime;

    private String updateUser;

    public String getServerInfoId() {
        return serverInfoId;
    }

    public void setServerInfoId(String serverInfoId) {
        this.serverInfoId = serverInfoId;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public String getServerPort() {
        return serverPort;
    }

    public void setServerPort(String serverPort) {
        this.serverPort = serverPort;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }
}