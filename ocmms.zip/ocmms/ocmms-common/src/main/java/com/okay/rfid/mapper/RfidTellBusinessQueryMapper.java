package com.okay.rfid.mapper;

import com.okay.rfid.query.RfidTellBusinessQuery;
import com.okay.rfid.query.result.RfidTellBusinessResult;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RfidTellBusinessQueryMapper extends QueryMapper<RfidTellBusinessQuery, RfidTellBusinessResult> {

}