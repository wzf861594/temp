package com.okay.rfid.impl.service;

import com.okay.rfid.mapper.RfidTellBusinessMapperRfid;
import com.okay.rfid.impl.query.RfidTellBusinessQueryImpl;
import com.okay.rfid.mapper.RfidTellBusinessQueryMapper;
import com.okay.rfid.query.RfidTellBusinessQuery;
import com.okay.rfid.service.RfidTellBusinessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RfidTellBusinessServiceImpl implements RfidTellBusinessService {

    @Autowired
    protected RfidTellBusinessMapperRfid rfidTellBusinessMapper;

    @Autowired
    protected RfidTellBusinessQueryMapper rfidTellBusinessQueryMapper;

    @Override
    public RfidTellBusinessQuery createRfidTellBusinessQuery() {
        return new RfidTellBusinessQueryImpl(rfidTellBusinessQueryMapper);
    }
}
