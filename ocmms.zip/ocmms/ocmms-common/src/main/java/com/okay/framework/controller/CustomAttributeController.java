package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.okay.engine.editor.entity.Model;
import com.okay.engine.editor.entity.ModelRelease;
import com.okay.engine.editor.entity.ModelWithBLOBs;
import com.okay.engine.editor.service.ModelReleaseService;
import com.okay.engine.editor.service.ModelService;
import com.okay.framework.entity.CustomObject;
import com.okay.framework.entity.CustomProperty;
import com.okay.framework.entity.User;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.CustomPropertyService;
import com.okay.framework.utils.ComUtils;
import com.okay.framework.utils.Constants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 自定义字段属性控制类.
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-04 9:42
 */

@RestController
@RequestMapping(value = "/custom")
public class CustomAttributeController {

    @Autowired
    private CustomPropertyService customPropertyService;
    @Autowired
    protected ModelService modelService;
    @Autowired
    protected ObjectMapper objectMapper;
    @Autowired
    protected ModelReleaseService modelReleaseService;

    /**
     *@Author : xdn
     *@Description : 获取自定义属性
     *@Return :
     **/
    @RequestMapping(value = "/customAttribute/{customResourceId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getCustomAttribute(@PathVariable String customResourceId) {
        JSONObject jsonObject = new JSONObject();
        try {
            List<CustomProperty> customPropertyList = customPropertyService.findByCustomResourceId(customResourceId);
            if (customPropertyList != null && customPropertyList.size() > 0){
                jsonObject.put("customProperty", customPropertyList.get(0));
            }else {
                jsonObject.put("customProperty", new JSONObject());
            }
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取定义对象.
     * @return
     */
    @RequestMapping(value = "/customObj", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getCustomObject() {
        JSONObject jsonObject = new JSONObject();
        try {
            List<CustomObject> customObjects = customPropertyService.findAllCustomObject();

            List<JSONObject> customObjectList = new ArrayList<JSONObject>();
            for (CustomObject customObject : customObjects){
                if (customObject.getParentId() != null && !"0".equals(customObject.getParentId())){
                    JSONObject customJson = new JSONObject();
                    customJson.put("label", customObject.getObjName());
                    customJson.put("value", customObject.getObjId());
                    customObjectList.add(customJson);
                }
            }

            jsonObject.put("customObjectList", customObjects);
            jsonObject.put("data", customObjectList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 自定义字段表单管理列表.
     * @param param
     * @param pageNum
     * @param pageSize
     * @param system
     * @param name_like
     * @param groupId
     * @return
     */
    @RequestMapping(value = "/modelList/{pageNum}/{pageSize}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getModelList(@RequestParam Map<String,Object> param, @PathVariable Integer pageNum, @PathVariable Integer pageSize,
                                   @RequestParam(required = false) String system,
                                   @RequestParam(required = false) String name_like, @RequestParam(required = false) String groupId) {

        JSONObject result = new JSONObject();
        try {

            if(pageNum < 0) {
                pageNum = 1;
            }
            if(pageSize < 0 || pageSize > 1000) {
                pageSize = 20;
            }

            List<?> data = null;
            Integer pages = 0;
            Long total = 0L;

            boolean isSelect = true;

            // 过滤系统与不过滤系统的区别
//            if(system != null && !"".equals(system)) {
//                if(groupId == null || "".equals(groupId)) {
//                    MappingShowInfo groupInfo = customFormService.getFormGroup(system);
//                    if(groupInfo != null) {
//                        groupId = StringUtils.join(groupInfo.getMapping().keySet(), ",");
//                    } else {
//                        isSelect = false;
//                    }
//                }
//            }

            if(isSelect) {
                try (Page page = PageHelper.startPage(pageNum, pageSize, true)) {
                    page.setOrderBy("LAST_UPDATED_ desc");
                    Map<String, Object> query = new HashMap<String,Object>();
                    query.put("modelType", Constants.ACTIVITIFORM_MODEL_TYPE); // 根据创建的表单类型来过滤
                    query.put("name_like", name_like); // 表单名称
                    query.put("groupId", groupId); // 表单所属分类
                    data = modelService.getModelList(query);
                    pages = page.getPages();
                    total = page.getTotal();
                }
            }

            result.put("data", data);
            result.put("pages", pages);
            result.put("total", total);
            result.put("code", 1);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "获取表单列表:" + e.getMessage());
        }
        return result;
    }

    /**
     * 创建表单模型.
     * @param param
     * @return
     */
    @RequestMapping(value = "/createForm", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject createModel(@RequestBody JSONObject param) {
        JSONObject result = new JSONObject();
        try {

            String key = param.getString("key");
            String name = param.getString("name");
            String groupId = param.getString("groupId");
            String stencil = param.getString("stencil");
            String stencilset = param.getString("stencilset");
            //String keyPrefix = param.getString("keyPrefix");
            String description = param.getString("description");

            if(key == null || "".equals(key)) {
                throw new RuntimeException("key不能为空");
            }

            if(name == null || "".equals(name)) {
                throw new RuntimeException("name不能为空");
            }

            if(groupId == null || "".equals(groupId)) {
                throw new RuntimeException("groupId不能为空");
            }

            if(stencil == null || "".equals(stencil)) {
                throw new RuntimeException("stencil不能为空");
            }

//            if(keyPrefix == null || "".equals(keyPrefix)) {
//                throw new RuntimeException("keyPrefix不能为空");
//            }
//
//            String prefixKey = keyPrefix + ":" + key;

            String modelKey = key;

            if(modelService.getModelByKey(modelKey) != null) {
                throw new RuntimeException("key:" + modelKey + "重复");
            }

            String confirmFlg = param.getString("confirmFlg");
            if (confirmFlg == null || "".equals(confirmFlg) || "0".equals(confirmFlg)) {
                result.put("code", 3);
                result.put("msg", "是否创建表单？");
                return result;
            }

            ObjectNode editorNode = objectMapper.createObjectNode();
            editorNode.put("stencil", stencil);
            if(stencilset != null && !"".equals(stencilset)) {
                editorNode.put("stencilset", stencilset);
            }

            // 编辑的数据
            String editorJson = editorNode.toString();

            ModelWithBLOBs model = modelService.createModel(name, modelKey, Constants.ACTIVITIFORM_MODEL_TYPE, description, groupId, editorJson, getUserId());

            result.put("data", model);
            result.put("code", 1);
            result.put("msg", "表单创建:成功");
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "表单创建:" + e.getMessage());
        }
        return result;
    }

    /**
     * 保存表单基本数据.
     * @param param
     * @return
     */
    @RequestMapping(value = "/saveForm", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject saveModel(@RequestBody JSONObject param) {
        JSONObject result = new JSONObject();
        try {

            String id = param.getString("id");
            String name = param.getString("name");
            String description = param.getString("description");

            if(id == null || "".equals(id)) {
                throw new RuntimeException("id不能为空");
            }

            if(name == null || "".equals(name)) {
                throw new RuntimeException("name不能为空");
            }

            Model model = modelService.getModel(id);
            if(model == null && model.getModelType() != Constants.ACTIVITIFORM_MODEL_TYPE) {
                throw new RuntimeException("表单不存在");
            }
            model.setName(name);
            model.setDescription(description);
            modelService.saveModel(model);
            result.put("code", 1);
            result.put("msg", "表单信息修改:成功");
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "表单信息修改:" + e.getMessage());
        }
        return result;
    }

    /**
     * 根据主键获取表单基本数据.
     * @param id
     * @return
     */
    @RequestMapping(value = "/getForm/{id}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getModel(@PathVariable String id) {
        JSONObject result = new JSONObject();
        try {
            ModelWithBLOBs model = modelService.getModel(id);
            if(model == null || model.getModelType() != Constants.ACTIVITIFORM_MODEL_TYPE) {
                throw new RuntimeException("表单不存在");
            }

            // 写入表单信息
            Map<String,Object> formInfo = new HashMap<String,Object>();
            //formInfo.put("showScenes", nodes);
            //formInfo.put("showNodes", nodes);

            Map<String,Object> finalResult = new HashMap<String,Object>();
            finalResult.put("model", model);
            finalResult.put("formInfo", formInfo);

            result.put("data", finalResult);
            result.put("code", 1);
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "获取表单信息:" + e.getMessage());
        }
        return result;
    }

    /**
     * 发布表单.
     * @param param
     * @return
     */
    @RequestMapping(value = "/public", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject publicModel(@RequestBody JSONObject param) {
        JSONObject result = new JSONObject();
        try {
            String id = param.getString("id");
            String modelEditorJson = param.getString("modelEditorJson");

            if(id == null || "".equals(id)) {
                throw new RuntimeException("id不能为空");
            }
            ModelWithBLOBs model = modelService.getModel(id);
            if(model == null && model.getModelType() != Constants.ACTIVITIFORM_MODEL_TYPE) {
                throw new RuntimeException("表单不存在");
            }

            if(modelEditorJson != null && !"".equals(modelEditorJson)) {
                JSONObject newModelEditor = null;
                try {
                    newModelEditor = JSONObject.parseObject(modelEditorJson);
                } catch (RuntimeException e) {
                    throw new RuntimeException("modelEditorJson格式异常");
                }

//                if(!JSONObject.parseObject(model.getModelEditorJson()).getString("stencil").equals(newModelEditor.getString("stencil"))) {
//                    throw new RuntimeException("不允许修改modelEditorJson中的stencil数据");
//                }
                modelService.saveModel(model.getId(), model.getName(), model.getModelKey(), null, modelEditorJson, false, null, getUserId());
            }

            modelService.publicModel(model.getId(), getUserId());
            result.put("code", 1);
            result.put("msg", "表单发布:成功");
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "表单发布:" + e.getMessage());
        }
        return result;
    }


    /**
     * 保存表单设计器编辑的Json数据.
     * @param param
     * @return
     */
    @RequestMapping(value = "/saveModelJson", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject saveModelJson(@RequestBody JSONObject param) {
        JSONObject result = new JSONObject();
        try {

            String id = param.getString("id");
            String modelEditorJson = param.getString("modelEditorJson");
            Boolean newVersion = param.getBoolean("newVersion");

            if(modelEditorJson == null || "".equals(modelEditorJson)) {
                throw new RuntimeException("modelEditorJson不能为空");
            }

            ModelWithBLOBs model = modelService.getModel(id);
            if(model == null && model.getModelType() != Constants.ACTIVITIFORM_MODEL_TYPE) {
                throw new RuntimeException("表单不存在");
            }

            JSONObject newModelEditor = null;
            try {
                newModelEditor = JSONObject.parseObject(modelEditorJson);
            } catch (RuntimeException e) {
                throw new RuntimeException("modelEditorJson格式异常");
            }

//            if(!JSONObject.parseObject(model.getModelEditorJson()).getString("stencil").equals(newModelEditor.getString("stencil"))) {
//                throw new RuntimeException("不允许修改modelEditorJson中的stencil数据");
//            }

            // 发布了模型默认为新版本.
            if(model.getDeploymentId() != null) {
                newVersion = true;
            } else if(newVersion == null) {
                newVersion = false;
            }

            modelService.saveModel(model.getId(), model.getName(), model.getModelKey(), null, modelEditorJson, newVersion, null, getUserId());

            result.put("code", 1);
            result.put("msg", "设计表单保存:成功");
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "设计表单保存:" + e.getMessage());
        }
        return result;
    }


    /**
     * 获取已发布的表单.
     * @param formKey
     * @return
     */
    @RequestMapping(value = "/getPublishForm/{formKey}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public JSONObject getPublishForm(@PathVariable String formKey) {
        JSONObject result = new JSONObject();
        try {
            Object formDef = null;

            // 获取发布的表单定义
            ModelRelease formModelRelease = parseGetModelRelease(formKey);
            if(formModelRelease != null) {
                formDef = JSONObject.parse(formModelRelease.getModelEditorJson());
            }

            Map<String,Object> finalResult = new HashMap<String,Object>();
            finalResult.put("formKey", formKey);
            finalResult.put("formDef", formDef);
            result.put("data", finalResult);
            result.put("code", 1);
            return result;
        } catch (Exception e) {
            result.put("code", 4);
            result.put("msg", "获取流程表单:" + e.getMessage());
        }
        return result;
    }

    protected ModelRelease parseGetModelRelease(String id) {
        ModelRelease modelRelease = null;
        if(id != null && !"".equals(id)) {
            modelRelease = modelReleaseService.getModelRelease(id);
            if(modelRelease == null) {
                modelRelease = modelReleaseService.getModelReleaseByKey(id);
            }
            if(modelRelease == null) {
                int index = id.lastIndexOf(":");
                if(index != -1) {
                    String versionStr = id.substring(index+1);
                    if(versionStr.matches("\\d+")) {
                        String key = id.substring(0, index);
                        modelRelease = modelReleaseService.getModelReleaseByKey(key, Long.parseLong(versionStr));
                    }
                }
            }
        }
        return modelRelease;
    }

    public String getUserId(){
        String userId = null;
        try {
            User user = ComUtils.getLoginUser();
            if(user != null) {
                userId = user.getUserId();
            }
        } catch(Exception e) {}
        if(userId == null) {
            throw new RuntimeException("登陆用户获取失败");
        }
        return userId;
    }
}
