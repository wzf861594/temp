package com.okay.rfid.service;

import com.okay.rfid.impl.entity.RfidTellBusinessEntityImpl;
import com.okay.rfid.impl.entity.RfidTellLogEntityImpl;
import com.okay.rfid.info.RfidInfo;

import java.util.List;

public interface RfidService {

    /**
     * 执行.
     * <p/> 执行识别的RFID具体业务能力.
     * @param rfid 必填，识别的RFID.
     * @param deviceId 设备ID.
     * @param operator 操作人.
     * @param param 参数.
     */
    void execute(String rfid, String deviceId, String operator, Object param);

//    void saveTellLog(RfidTellLogEntityImpl tellLog, List<RfidTellBusinessEntityImpl> tellBusiness);

//    void executeBusiness(RfidInfo info, RfidTellLogEntityImpl tellLog, RfidTellBusinessEntityImpl tellBusiness);

}