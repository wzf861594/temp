package com.okay.framework.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.entity.dto.SysUserDTO;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @ClassName: UserService
 * @Description: 用户信息管理接口
 * @author: HQ.ZHU
 * @date: 2019-04-25 18:14
 * @version: V1.0
 */  
public interface UserService {

    /**
     *  当前登录用户.
     * @return 返回登录用户对象.
     */
    User getLoginUser();

    /**
     * 用户列表分页查询.
     * @param page 分页对象.
     * @return 返回查询的用户信息列表集合.
     **/
    List<Map<String,String>> findDataListByPage(Page page);

    /**
     * 用户信息查询.
     * @param userId 用户主键.
     * @return 返回用户信息.
     **/
    User findUserById(String userId);

    /**
     * 新增用户.
     * @param user 用户对象.
     * @return 返回新增用户信息.
     */
    User add(User user);

    /**
     * 用户信息修改.
     * @param user 用户对象.
     * @return 返回修改用户信息.
     **/
    User modifyUserInfo(User user);

    /**
     * 个人信息修改.
     * @param user 用户对象.
     **/
    void modifyPersonalInfo(User user);

    /**
     * 批量删除.
     * @param userIdList 用户主键Set集合.
     */
    void remove(Set<String> userIdList);

    /**
     * 个人密码修改.
     * @param oldPass 原密码.
     * @param newPass 新密码.
     **/
    void modifyPersonalPass(String oldPass, String newPass);

    /**
     * 部门调整.
     * @param userIdList 用户主键Set集合.
     * @param deptId 部门ID.
     **/
    void adjustDept(Set<String> userIdList, String deptId);

    /**
     * 用户注销.
     * @param userIdList 用户主键Set集合.
     **/
    void cancel(Set<String> userIdList);

    /**
     * 用户注销恢复.
     * @param userIdList 用户主键Set集合.
     */
    void unCancel(Set<String> userIdList);

    /**
     * 用户锁定.
     * @param userIdList 用户主键Set集合.
     **/
    void lock(Set<String> userIdList);

    /**
     * 用户解锁.
     * @param userIdList 用户主键Set集合.
     */
    void unLock(Set<String> userIdList);

    /**
     * 重置密码.
     * @param userIdList 用户主键Set集合.
     **/
    void resetPass(Set<String> userIdList);

    /**
     * 用户头像更新.
     * @param user 用户对象.
     **/
    void updateImage(User user);

    /**
     * 查询用户Map集合
     * @param userId 用户id
     * @return 返回用户Map集合
     */
    Map<String,Object> findUserForMapById(String userId);

    /**
     * 根据部门查询用户信息.
     * @param deptId 部门主键.
     * @return 返回用户信息.
     **/
    List<User> findUserByDeptId(String deptId);

    /**
     * 根据部门查询用户信息.
     * @param roleId 角色主键.
     * @return 返回用户信息.
     **/
    List<User> findUserByRoleId(String roleId);

    /**
     * 多条件查询.
     * @param query 查询条件.
     * @return 返回用户信息List集合.
     */
    List<User> findUserWithDeptByQuery(Map<String,Object> query);

    /**
     * 按部门返回用户的列表数据
     * 作用于前端的用户选择组件的数据加载
     * @param map
     * @return
     */
    List<Map> findUserInDept(Map<String, Object> map);

    /**
     * 用户列表分页查询.
     * @param
     * @return 返回查询的用户信息列表集合.
     **/
    IPage<Map<String,Object>> contactUserList(com.baomidou.mybatisplus.extension.plugins.pagination.Page page, SysUserDTO sysUser);
}
