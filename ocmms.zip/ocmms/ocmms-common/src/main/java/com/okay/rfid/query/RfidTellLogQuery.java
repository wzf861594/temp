package com.okay.rfid.query;

import com.okay.rfid.query.result.RfidTellLogResult;

import java.util.Date;

public interface RfidTellLogQuery extends QueryLink<RfidTellLogQuery>, Query<RfidTellLogResult> {

    RfidTellLogQuery nameLike(String nameLike);

    RfidTellLogQuery rfidLike(String rfidLike);

    RfidTellLogQuery rfid(String rfid);

    RfidTellLogQuery type(String type);

    RfidTellLogQuery types(String... types);

    RfidTellLogQuery orderByTimeDesc();

    RfidTellLogQuery putCountTellBusiness();

    RfidTellLogQuery gteTime(Date date);

    RfidTellLogQuery ltTime(Date date);

    RfidTellLogQuery state(String state);

    RfidTellLogQuery noneState();

}
