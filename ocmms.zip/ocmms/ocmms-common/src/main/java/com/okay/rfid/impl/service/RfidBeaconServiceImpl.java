package com.okay.rfid.impl.service;

import com.okay.rfid.entity.RfidBeaconEntity;
import com.okay.rfid.exception.RfidException;
import com.okay.rfid.impl.entity.RfidBeaconEntityImpl;
import com.okay.rfid.info.RfidBeacon;
import com.okay.rfid.mapper.RfidBeaconMapperRfid;
import com.okay.rfid.impl.query.RfidBeaconQueryImpl;
import com.okay.rfid.mapper.RfidBeaconQueryMapper;
import com.okay.rfid.query.RfidBeaconQuery;
import com.okay.rfid.service.RfidBeaconService;
import com.okay.rfid.util.Generate;
import com.okay.rfid.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class RfidBeaconServiceImpl implements RfidBeaconService {

    @Autowired
    protected RfidBeaconMapperRfid rfidBeaconMapper;

    @Autowired
    protected RfidBeaconQueryMapper rfidBeaconQueryMapper;

    @Override
    @Transactional
    public RfidBeacon createRfidBeacon(String rfid, String type, String describe) {
        if(StringUtil.isNull(rfid)) {
            throw new RfidException("RFID is null");
        }

        if(rfidBeaconMapper.selectByRfid(rfid) != null) {
            throw new RfidException("RFID已存在");
        }

        RfidBeaconEntity beaconEntity = new RfidBeaconEntityImpl();
        beaconEntity.setId(Generate.getNextId());
        beaconEntity.setRfid(rfid);
        beaconEntity.setType(type);
        beaconEntity.setDescribe(describe);
        beaconEntity.setCreatedTime(new Date());
        beaconEntity.setUpdatedTime(new Date());
        rfidBeaconMapper.insert(beaconEntity);
        return beaconEntity;
    }

    @Override
    @Transactional
    public RfidBeacon updateRfidBeacon(String rfid, String type, String describe) {
        if(StringUtil.isNull(rfid)) {
            throw new RfidException("RFID is null");
        }
        RfidBeaconEntity beaconEntity = rfidBeaconMapper.selectByRfid(rfid);
        if(beaconEntity == null) {
            throw new RfidException("RFID不存在");
        }
        beaconEntity.setType(type);
        beaconEntity.setDescribe(describe);
        beaconEntity.setUpdatedTime(new Date());
        rfidBeaconMapper.updateByPrimaryKey(beaconEntity);
        return beaconEntity;
    }

    @Override
    @Transactional
    public List<? extends RfidBeacon> createRfidBeacons(Collection<String> rfids, String type, String describe) {
        Set<String> hasRfids = getCheckRfidExists(rfids);
        List<RfidBeaconEntity> beaconEntityList = new ArrayList<>();
        for(String rfid : hasRfids) {
            RfidBeaconEntity beaconEntity = new RfidBeaconEntityImpl();
            beaconEntity.setId(Generate.getNextId());
            beaconEntity.setRfid(rfid);
            beaconEntity.setType(type);
            beaconEntity.setDescribe(describe);
            beaconEntity.setCreatedTime(new Date());
            beaconEntity.setUpdatedTime(new Date());
            rfidBeaconMapper.insert(beaconEntity);
            beaconEntityList.add(beaconEntity);
        }
        return beaconEntityList;
    }

    @Override
    @Transactional
    public List<? extends RfidBeacon> updateRfidBeaconsType(Collection<String> rfids, String type) {
        List<RfidBeaconEntity> beaconEntityList = getCheckRfidFind(rfids);
        for(RfidBeaconEntity beaconEntity : beaconEntityList) {
            beaconEntity.setType(type);
            beaconEntity.setUpdatedTime(new Date());
            rfidBeaconMapper.updateByPrimaryKey(beaconEntity);
        }
        return beaconEntityList;
    }

    @Override
    @Transactional
    public RfidBeacon deleteRfidBeacon(String rfid) {
        if(StringUtil.isNull(rfid)) {
            throw new RfidException("RFID is null");
        }
        RfidBeaconEntity beaconEntity = rfidBeaconMapper.selectByRfid(rfid);
        if(beaconEntity == null) {
            throw new RfidException("RFID不存在");
        }
        rfidBeaconMapper.deleteByPrimaryKey(beaconEntity.getId());
        return beaconEntity;
    }

    @Override
    @Transactional
    public List<? extends RfidBeacon> deleteRfidBeacons(Collection<String> rfids) {
        List<RfidBeaconEntity> beaconEntityList = getCheckRfidFind(rfids);
        for(RfidBeaconEntity beaconEntity : beaconEntityList) {
            rfidBeaconMapper.deleteByPrimaryKey(beaconEntity.getId());
        }
        return beaconEntityList;
    }

    @Override
    public RfidBeacon getRfidBeacon(String rfid) {
        if(StringUtil.isNull(rfid)) {
            throw new RfidException("RFID is null");
        }
        return rfidBeaconMapper.selectByRfid(rfid);
    }

    @Override
    public RfidBeaconQuery createRfidBeaconQuery() {
        return new RfidBeaconQueryImpl(rfidBeaconQueryMapper);
    }

    protected Set<String> getCheckRfidExists(Collection<String> rfids) {
        if(rfids == null || rfids.isEmpty()) {
            throw new RfidException("RFID is null");
        }
        Set<String> hasRfids = new HashSet<>();
        for(String rfid : rfids) {
            if(StringUtil.isNull(rfid)) {
                throw new RfidException("RFID is null");
            }
            if(!hasRfids.contains(rfid)) {
                if(rfidBeaconMapper.selectByRfid(rfid) != null) {
                    throw new RfidException("RFID '" + rfid + "' already exists");
                }
                hasRfids.add(rfid);
            }
        }
        return hasRfids;
    }

    protected List<RfidBeaconEntity> getCheckRfidFind(Collection<String> rfids) {
        if(rfids == null || rfids.isEmpty()) {
            throw new RfidException("RFID is null");
        }
        List<RfidBeaconEntity> beaconEntityList = new ArrayList<>();
        Set<String> hasRfids = new HashSet<>();
        for(String rfid : rfids) {
            if(StringUtil.isNull(rfid)) {
                throw new RfidException("RFID is null");
            }
            if(!hasRfids.contains(rfid)) {
                hasRfids.add(rfid);
                RfidBeaconEntity beaconEntity = rfidBeaconMapper.selectByRfid(rfid);
                if(beaconEntity == null) {
                    throw new RfidException("RFID '" + rfid + "' not find");
                }
                beaconEntityList.add(beaconEntity);
            }
        }
        return beaconEntityList;
    }

}
