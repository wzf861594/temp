package com.okay.rfid.mapper;

import com.okay.rfid.entity.RfidTellLogEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RfidTellLogMapperRfid extends RfidBaseMapper<RfidTellLogEntity> {

}