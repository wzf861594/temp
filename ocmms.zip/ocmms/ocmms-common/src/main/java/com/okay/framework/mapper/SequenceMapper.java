package com.okay.framework.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SequenceMapper {
    Long selectSequence(String tableName);
    Integer updateSequence(@Param("tableName") String tableName, @Param("sequence") Long sequence);
    Integer insertSequence(@Param("tableName") String tableName, @Param("sequence") Long sequence);
}
