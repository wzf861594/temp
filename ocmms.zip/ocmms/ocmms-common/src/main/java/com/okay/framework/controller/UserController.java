package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.R;
import com.okay.common.model.MetadataModel;
import com.okay.common.util.MetadataUtil;
import com.okay.framework.entity.Dept;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.entity.dto.SysUserDTO;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.service.UserService;
import com.okay.framework.utils.AESUtil;
import com.okay.framework.utils.DataUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

@RestController
@RequestMapping("/user")
public class UserController extends BaseController {

    @Autowired
    private UserService userService;

    /**
     * @Author : xdn
     * @Description : 用户列表
     * @Return :
     **/
    @RequestMapping(value = "/dataList", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject dataList(@RequestBody Page page) {
        JSONObject jsonObject = new JSONObject();
        try {
            List<Map<String, String>> userList = userService.findDataListByPage(page);
            jsonObject.put("data", userList);
            jsonObject.put("pages", page.getPages());
            jsonObject.put("total", page.getTotal());
            jsonObject.put("pageNow", page.getPageNum());
            jsonObject.put("pageSize", page.getPageSize());
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 用户新增
     * @Return :
     **/
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject add(@RequestBody @Valid User user) {
        JSONObject jsonObject = new JSONObject();
        try {
            User newUser = userService.add(user);
            jsonObject.put("data", newUser);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.ADD_DATA_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 登录用户
     * @Return :
     **/
    @RequestMapping(value = "/getLoginUserInfo", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getLoginUserInfo() {
        JSONObject jsonObject = new JSONObject();
        try {
            User loginUser = this.getLoginUser();
            if (loginUser != null) {
                Map<String, Object> userMap = userService.findUserForMapById(loginUser.getUserId());
                jsonObject.put("data", userMap);
                jsonObject.put("code", 1);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 根据ID获取用户
     * @Return :
     **/
    @CrossOrigin
    @RequestMapping(value = "/getById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String userId = jsonParam.getString("userId");

        try {
            if (DataUtil.isEmpty(userId)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, ""));
            }
            User user = userService.findUserById(userId);
            jsonObject.put("data", user);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 用户信息修改
     * @Return :
     **/
    @RequestMapping(value = "/modifyById", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject modifyById(@RequestBody @Valid User user) {
        JSONObject jsonObject = new JSONObject();
        String userId = user.getUserId();
        try {
            if (DataUtil.isEmpty(userId)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, ""));
            }
            userService.modifyUserInfo(user);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 个人信息修改
     * @Return :
     **/
    @RequestMapping(value = "/modifyByLoginUser", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject modifyByLoginUser(@RequestBody @Valid User user) {
        JSONObject jsonObject = new JSONObject();
        try {
            userService.modifyPersonalInfo(user);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 个人密码修改
     * @Return :
     **/
    @RequestMapping(value = "/modifyPass", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject modifyPass(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();

        String oldPass = jsonParam.getString("oldPass");
        String newPass = jsonParam.getString("newPass");
        String checkNewPass = jsonParam.getString("checkPass");
        try {
            if (DataUtil.isEmpty(oldPass)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHECK_NOT_NULL, "原密码"));
            }
            if (DataUtil.isEmpty(newPass)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHECK_NOT_NULL, "新密码"));
            }
            if (!newPass.equals(checkNewPass)) {
                throw new BaseRuntimeException(SysErrorDefine.PASS_FAIL);
            }

            oldPass = AESUtil.deCode(oldPass);
            newPass = AESUtil.deCode(newPass);
            checkNewPass = AESUtil.deCode(checkNewPass);

            userService.modifyPersonalPass(oldPass, newPass);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 用户删除
     * @Return :
     **/
    @RequestMapping(value = "/remove", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject remove(@RequestBody JSONObject jsonParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            String userIds = jsonParam.getString("userIds");
            String confirmFlg = jsonParam.getString("confirmFlg");

            if (DataUtil.isEmpty(userIds)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, ""));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(SysErrorDefine.ASK_HANDLE_DEL);
            }
            Set<String> userIdList = new HashSet<>(Arrays.asList(userIds.split(",")));
            userService.remove(userIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.DELETE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 部门调整
     * @Return :
     **/
    @RequestMapping(value = "/adjustDept", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject adjustDept(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String userIds = jsonParam.getString("userIds");
        String deptId = jsonParam.getString("deptId");
        try {
            if (DataUtil.isEmpty(userIds)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "用户"));
            }
            if (DataUtil.isEmpty(deptId)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "部门"));
            }
            Set<String> userIdList = new HashSet<>(Arrays.asList(userIds.split(",")));
            userService.adjustDept(userIdList, deptId);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 用户注销
     * @Return :
     **/
    @RequestMapping(value = "/cancel", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject cancel(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String userIds = jsonParam.getString("userIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(userIds)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "用户"));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.ASK_HANDLE_CANCEl));
            }
            Set<String> userIdList = new HashSet<>(Arrays.asList(userIds.split(",")));
            userService.cancel(userIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.CANCEL_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 取消注销
     * @Return :
     **/
    @RequestMapping(value = "/unCancel", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject unCancel(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String userIds = jsonParam.getString("userIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(userIds)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "用户"));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.ASK_HANDLE_UNCANCEl));
            }
            Set<String> userIdList = new HashSet<>(Arrays.asList(userIds.split(",")));
            userService.unCancel(userIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 用户锁定
     * @Return :
     **/
    @RequestMapping(value = "/lock", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject lock(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String userIds = jsonParam.getString("userIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(userIds)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "用户"));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.ASK_HANDLE_LOCK));
            }
            Set<String> userIdList = new HashSet<>(Arrays.asList(userIds.split(",")));
            userService.lock(userIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.LOCK_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 用户解锁
     * @Return :
     **/
    @RequestMapping(value = "/unLock", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject unLock(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String userIds = jsonParam.getString("userIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(userIds)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "用户"));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.ASK_HANDLE_UNLOCK));
            }
            Set<String> userIdList = new HashSet<>(Arrays.asList(userIds.split(",")));
            userService.unLock(userIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UNLOCK_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 重置密码
     * @Return :
     **/
    @RequestMapping(value = "/resetPass", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public JSONObject resetPass(@RequestBody JSONObject jsonParam) {

        JSONObject jsonObject = new JSONObject();
        String userIds = jsonParam.getString("userIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(userIds)) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "用户"));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")) {
                throw new BaseRuntimeException(String.format(SysErrorDefine.ASK_HANDLE_RESET));
            }
            Set<String> userIdList = new HashSet<>(Arrays.asList(userIds.split(",")));
            userService.resetPass(userIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.RESET_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @Author : xdn
     * @Description : 个人头像上传
     * @Return :
     **/
    @RequestMapping(value = "/uploadImg", method = RequestMethod.POST)
    public JSONObject uploadImg(HttpServletRequest request, @RequestParam("file") MultipartFile uploadFile) {
        JSONObject jsonObject = new JSONObject();

        try {
            User loginUser = this.getLoginUser();
            if (loginUser != null) {
                byte[] imageByte = uploadFile.getBytes();
                User user = new User();
                user.setPhoto(imageByte);
                user.setUserId(loginUser.getUserId());
                userService.updateImage(user);

                String imageToBase64 = getUserPhoto(imageByte);
                jsonObject.put("imageToBase64", imageToBase64);
                jsonObject.put("code", 1);
            }
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 获取用户及对应的部门信息.
     *
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/getUserWithDept", method = RequestMethod.GET)
    public JSONObject getUserWithDept(@RequestParam Map<String, Object> jsonParam) {
        JSONObject jsonObject = new JSONObject();

        try {
            Object userNameObj = jsonParam.get("userName");

            Map<String, Object> query = new HashMap<>();
            query.put("likeName", userNameObj == null ? "" : userNameObj.toString());
            query.put("status", "1");
            List<User> userList = userService.findUserWithDeptByQuery(query);

            // 树型结构处理
            List<Map<String, Object>> dataList = userTreeHandle(userList);

            jsonObject.put("data", dataList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 用户头像输出流.
     *
     * @param response
     * @param userId
     */
    @RequestMapping(value = "/image/{userId}", method = RequestMethod.GET)
    public void getImageIo(HttpServletResponse response, @PathVariable String userId) {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        byte[] imageByte = null;

        try {
            // 创建图片输出流
            response.setContentType("image/jpeg");
            response.setCharacterEncoding("UTF-8");

            User user = userService.findUserById(userId);

            if (user != null) {
                imageByte = user.getPhoto();
            }

            if (imageByte != null) {
                outputStream = response.getOutputStream();
                outputStream.write(imageByte);
                outputStream.flush();
            }
        } catch (Exception e) {
            throw new RuntimeException("头像获取失败");
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                }
            }
        }
    }

    public List<Map<String, Object>> userTreeHandle(List<User> userList) {

        List<Map<String, Object>> userMapList = new ArrayList<>();
        MetadataModel model = MetadataUtil.getMetadataModel();

        Map<String, Map<String, Object>> tempMap = new HashMap<String, Map<String, Object>>();
        for (User user : userList) {
            Dept dept = user.getDept();
            if (dept != null) {
                Map<String, Object> tempUserMap = tempMap.get(dept.getDeptId());
                if (tempUserMap == null) {
                    tempUserMap = new HashMap<>();
                    tempUserMap.put("seqNo", dept.getSeqNo());
                    tempUserMap.put("deptId", dept.getDeptId());
                    tempUserMap.put("deptName", dept.getDeptName());
                    tempUserMap.put("deptCode", dept.getDeptCode());
                    tempUserMap.put("userList", new ArrayList<Map<String, Object>>());
                    userMapList.add(tempUserMap);

                    tempMap.put(dept.getDeptId(), tempUserMap);
                }
                String userStr = JSONObject.toJSONString(user);
                Map<String, Object> userMap = JSONObject.parseObject(userStr);

                // 用户头像
                userMap.put("userImage", getUserPhoto(user.getPhoto()));
                userMap.put("deptName", model.getDeptName(Integer.parseInt(user.getDeptId())));
                userMap.put("dutyShow", model.getDictName("duty_type", String.valueOf(user.getDuty())));

                ((List<Map<String, Object>>) tempUserMap.get("userList")).add(userMap);
            }
        }
        return userMapList;
    }

    public String getUserPhoto(byte[] imageByte) {
        StringBuffer buffer = new StringBuffer();
        if (imageByte != null && !"".equals(imageByte)) {
            BASE64Encoder encoder = new BASE64Encoder();
            String image = encoder.encode(imageByte);
            buffer.append("data:image/jpeg;base64,");
            buffer.append(image);
        }
        return buffer.toString();
    }

    /**
     * 按部门返回用户的列表数据
     * 作用于前端的用户选择组件的数据加载
     *
     * @return
     */
    @RequestMapping(value = "/userselect", method = RequestMethod.GET, produces = "application/json")
    public JSONObject userSelect(@RequestParam Map<String, Object> map) {
        JSONObject jsonObject = new JSONObject();
        List<Map> deptList = null;
        try {
            deptList = userService.findUserInDept(map);
            jsonObject.put("data", deptList);
            jsonObject.put("code", 1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * @param
     * @Description 获取用户列表
     **/
    @PostMapping("/contactUserList")
    public R contactUserList(com.baomidou.mybatisplus.extension.plugins.pagination.Page page, SysUserDTO sysUser) {
        return R.ok(userService.contactUserList(page, sysUser)).setMsg("");
        }
}