package com.okay.framework.entity;

import java.io.Serializable;

public class Sequence implements Serializable {
    private static final long serialVersionUID = -5990890232031414884L;
    private String tableName;
    private Long sequence;

    public Sequence() {
    }

    public Sequence(String tableName, Long sequence) {
        this.tableName = tableName;
        this.sequence = sequence;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Long getSequence() {
        return sequence;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }
}