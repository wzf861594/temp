package com.okay.rfid.impl.query;

import com.okay.rfid.query.QueryLinkCondition;

public class QueryConditionImpl implements QueryLinkCondition {

    private boolean inOrCondition;

    private boolean linkOrCondition;

    @Override
    public boolean getInOrCondition() {
        return inOrCondition;
    }

    @Override
    public void setInOrCondition(boolean inOrCondition) {
        this.inOrCondition = inOrCondition;
    }

    @Override
    public boolean getLinkOrCondition() {
        return linkOrCondition;
    }

    @Override
    public void setLinkOrCondition(boolean linkOrCondition) {
        this.linkOrCondition = linkOrCondition;
    }

    public boolean isInOrCondition() {
        return inOrCondition;
    }

    public boolean isLinkOrCondition() {
        return linkOrCondition;
    }
}
