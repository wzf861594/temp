package com.okay.rfid.query;

public interface QueryLink<O> {

    O or();

    O and();

    O orAnd();

    O andOr();

    O endLink();
}
