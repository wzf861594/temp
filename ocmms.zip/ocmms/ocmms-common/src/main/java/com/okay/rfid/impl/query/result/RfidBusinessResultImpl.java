package com.okay.rfid.impl.query.result;

import com.okay.rfid.impl.entity.RfidBusinessEntityImpl;
import com.okay.rfid.info.RfidBusiness;
import com.okay.rfid.query.result.RfidBusinessData;
import com.okay.rfid.query.result.RfidBusinessResult;

import java.util.Collection;

public class RfidBusinessResultImpl extends RfidBusinessEntityImpl implements RfidBusinessResult, RfidBusinessData {

    private Object businessData;

    private Collection<RfidBusinessResult> subset;

    @Override
    public Object getBusinessData() {
        return businessData;
    }

    @Override
    public void setBusinessData(Object data) {
        businessData = data;
    }

    @Override
    public Collection<RfidBusinessResult> getSubset() {
        return subset;
    }

    @Override
    public void setSubset(Collection<RfidBusinessResult> subset) {
        this.subset = subset;
    }
}
