package com.okay.framework.mapper;

import com.okay.framework.entity.Page;
import com.okay.framework.entity.ServerInfo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ServerInfoMapper {
    int deleteByPrimaryKey(String serverInfoId);

    int insert(ServerInfo record);

    int insertSelective(ServerInfo record);

    ServerInfo selectByPrimaryKey(String serverInfoId);

    int updateByPrimaryKeySelective(ServerInfo record);

    int updateByPrimaryKey(ServerInfo record);

    List<ServerInfo> selectByPage(Page page);
}