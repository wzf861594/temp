package com.okay.framework.entity;

import java.io.Serializable;

/**
 * 用户角色表(SysUserRole)实体类
 *
 * @author makejava（zyx）
 * @since 2020-09-12 14:06:40
 */
public class SysUserRole implements Serializable {
    private static final long serialVersionUID = 858987003744996199L;
    /**
     * 用户ID
     */
    private Integer userId;
    /**
     * 角色ID
     */
    private Integer roleId;


    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

}