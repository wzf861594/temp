package com.okay.rfid.mapper;

import java.util.List;

public interface QueryMapper<Q, R> {

    List<R> selectQuery(Q query);

    long selectQueryCount(Q query);

}