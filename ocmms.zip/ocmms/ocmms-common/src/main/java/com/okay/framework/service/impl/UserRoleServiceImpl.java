package com.okay.framework.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.okay.framework.entity.SysUserRole;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.mapper.SysUserRoleMapper;
import com.okay.framework.mapper.UserRoleMapper;
import com.okay.framework.service.UserRoleService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 用户角色表服务实现类
 *
 * @author okay
 * @time 2021年10月25日11:19:59
 */
@Service
@AllArgsConstructor
public class UserRoleServiceImpl extends ServiceImpl<UserRoleMapper, SysUserRole> implements UserRoleService {

    private final SysUserRoleMapper userRoleMapper;

    @Override
    public SysUserRole getByUserId(Integer userId) {
        LambdaQueryWrapper<SysUserRole> wrapper = Wrappers.lambdaQuery();
        wrapper.eq(SysUserRole::getUserId, userId);
        return userRoleMapper.selectOne(wrapper);
    }

    @Override
    public List<SysUserRole> getByRoleId(Integer roleId) {
        LambdaQueryWrapper<SysUserRole> wrapper = Wrappers.lambdaQuery();
        wrapper.eq(SysUserRole::getRoleId, roleId);
        return userRoleMapper.selectList(wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveRoleUser(Integer roleId, List<Integer> userIdList) {
        if (Objects.isNull(roleId)) {
            throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA, "角色"));
        }
        // 保存前根据roleId将已存在数据删除
        LambdaQueryWrapper<SysUserRole> wrapper = Wrappers.lambdaQuery();
        wrapper.eq(SysUserRole::getRoleId, roleId);
        userRoleMapper.delete(wrapper);

        // 保存新数据
        List<SysUserRole> userRoleList = new ArrayList<>();
        for (int i = 0; i < userIdList.size(); i++) {
            SysUserRole userRole = new SysUserRole();
            userRole.setRoleId(roleId);
            userRole.setUserId(userIdList.get(i));
            userRoleList.add(userRole);
        }
        if (userRoleList.size() > 0) {
            return saveBatch(userRoleList);
        } else {
            return true;
        }
    }
}