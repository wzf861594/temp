package com.okay.rfid.entity;

import com.okay.rfid.info.RfidTellLog;

import java.util.Date;

/**
 * rfid_tell_log
 * @author 
 */
public interface RfidTellLogEntity extends RfidTellLog {

    void setId(String id);

    void setBeaconId(String beaconId);

    void setDeviceId(String deviceId);

    void setTime(Date time);

    void setOperator(String operator);

    void setState(String state);
}