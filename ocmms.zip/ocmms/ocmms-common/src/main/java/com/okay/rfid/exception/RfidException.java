package com.okay.rfid.exception;

public class RfidException extends RuntimeException {

    public RfidException() {}

    public RfidException(String message) {
        super(message);
    }

    public RfidException(String message, Throwable cause) {
        super(message, cause);
    }

}
