package com.okay.rfid.impl.query;


import com.okay.rfid.impl.entity.RfidTellLogEntityImpl;
import com.okay.rfid.mapper.RfidTellLogQueryMapper;
import com.okay.rfid.query.RfidTellLogQuery;
import com.okay.rfid.query.result.RfidTellLogResult;

public class RfidTellLogQueryImpl extends RfidQueryImpl<RfidTellLogQueryImpl, RfidTellLogQuery, RfidTellLogResult> implements RfidTellLogQuery {

    private boolean putCountTellBusiness;

    private RfidTellLogEntityImpl.State state;

    protected RfidTellLogQueryImpl() {}

    public RfidTellLogQueryImpl(RfidTellLogQueryMapper mapper) {
        super(mapper);
    }

    @Override
    public RfidTellLogQuery orderByTimeDesc() {
        setOrderBy("timeDesc");
        return this;
    }

    @Override
    public RfidTellLogQuery putCountTellBusiness() {
        RfidTellLogQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.putCountTellBusiness = true;
        return this;
    }

    @Override
    public RfidTellLogQuery state(String state) {
        RfidTellLogQueryImpl currQueryObject = getCurrQueryObject();
        currQueryObject.state = RfidTellLogEntityImpl.State.valueOf(state);
        return this;
    }

    public boolean isPutCountTellBusiness() {
        return putCountTellBusiness;
    }

    public void setPutCountTellBusiness(boolean putCountTellBusiness) {
        this.putCountTellBusiness = putCountTellBusiness;
    }

    public RfidTellLogEntityImpl.State getState() {
        return state;
    }

    public void setState(RfidTellLogEntityImpl.State state) {
        this.state = state;
    }
}
