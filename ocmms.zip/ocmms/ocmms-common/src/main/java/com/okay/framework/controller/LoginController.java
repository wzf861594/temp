package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.service.LoginService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @ClassName: LoginController
 * @Description: 用户登入登出处理类
 * @author: HQ.ZHU
 * @date: 2019-04-18 1:14
 * @version: V1.0
 */  
@RestController
@RequestMapping("/login")
public class LoginController {

    @Resource
    private LoginService loginService;

    /**
     * 登入验证
     * @param
     * @return
     */
    @PostMapping(value = "/goLogin")
    public JSONObject login(@RequestBody JSONObject userInfo){
        JSONObject jsonObject = new JSONObject();
        try {


        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 用户登出
     * @return
     */
    @RequestMapping(value = "/logout", method = RequestMethod.GET, produces = "application/json")
    public JSONObject logout(){
        JSONObject jsonObject = new JSONObject();
        try {

        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }
}