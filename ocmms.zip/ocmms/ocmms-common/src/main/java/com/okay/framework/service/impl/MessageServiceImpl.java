package com.okay.framework.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.okay.common.model.MetadataModel;
import com.okay.common.util.MetadataUtil;
import com.okay.framework.entity.Message;
import com.okay.framework.entity.User;
import com.okay.framework.entity.dto.MessageDTO;
import com.okay.framework.entity.vo.MessageVO;
import com.okay.framework.mapper.MessageMapper;
import com.okay.framework.mapper.UserMapper;
import com.okay.framework.service.MessageService;
import com.okay.okay.common.security.service.OkayUser;
import com.okay.okay.common.security.util.SecurityUtils;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Author CZJ[OKAY]
 * @Date 2020/8/25 11:37
 * @Description 消息提醒ServiceImpl
 **/
@Service
@AllArgsConstructor
public class MessageServiceImpl implements MessageService {

    private final UserMapper userMapper;
    private final MessageMapper messageMapper;

    @Override
    public int insert(MessageDTO dto) {
        OkayUser user = SecurityUtils.getUser();
        Integer userId = user.getId();
        dto.setIsRead("0");
        dto.setCreator(String.valueOf(userId));
        dto.setCreateTime(new Date());
        dto.setEditor(String.valueOf(userId));
        dto.setEditTime(new Date());
        return messageMapper.insert(dto);
    }

    @Override
    public int updateById(MessageDTO dto) {
        OkayUser user = SecurityUtils.getUser();
        Integer userId = user.getId();
        dto.setEditor(String.valueOf(userId));
        dto.setEditTime(new Date());
        return messageMapper.updateById(dto);
    }

    @Override
    public int deleteById(String id) {
        return messageMapper.deleteBatchIds(Arrays.asList(id.split(",")));
    }

    @Override
    public Message geMessage(String id) {
        return messageMapper.selectById(id);
    }

    @Override
    public IPage<Message> listMessage(Page page, MessageDTO dto) {
        LambdaQueryWrapper<Message> wrapper = Wrappers.lambdaQuery();
        wrapper.orderByDesc(Message::getCreateTime);
        //提醒人
        wrapper.eq(Message::getRemindObject, SecurityUtils.getUser().getId());
        //是否已读
        wrapper.eq(Strings.isNotBlank(dto.getIsRead()), Message::getIsRead, dto.getIsRead());
        //消息内容
        wrapper.like(Strings.isNotBlank(dto.getContent()), Message::getContent, dto.getContent());
        //消息类型
        wrapper.eq(Strings.isNotBlank(dto.getBusinessType()), Message::getBusinessType, dto.getBusinessType());

        IPage<Message> iPage = messageMapper.selectPage(page, wrapper);
        MetadataModel model = MetadataUtil.getMetadataModel();
        List<Message> messageList = iPage.getRecords();
        //创建人id
        Stream<String> stream = messageList.stream().map(Message::getCreator);
        List<String> userId = Arrays.asList(stream.distinct().toArray(String[]::new));
        final Map<String, String> map = new HashMap<>();
        if (CollectionUtils.isNotEmpty(userId)) {
            List<User> users = userMapper.selectList(Wrappers.<User>lambdaQuery().in(User::getUserId, userId));
            map.putAll(users.stream().collect(Collectors.toMap(User::getUserId, User::getUserName)));
        }
        List<Message> newList = messageList.stream().map(item -> {
            MessageVO vo = new MessageVO();
            BeanUtils.copyProperties(item, vo);
            vo.setBusinessTypeShow(model.getDictName("oa_message_type", vo.getBusinessType()));
            vo.setCreatorShow(map.get(vo.getCreator()));
            return vo;
        }).collect(Collectors.toList());
        iPage.setRecords(newList);
        return iPage;
    }

    @Override
    public int updateRead(String id) {
        Message message = new Message();
        UpdateWrapper<Message> wrapper = new UpdateWrapper<>();
        wrapper.lambda().set(Message::getIsRead, "1").in(Message::getId, Arrays.asList(id.split(",")));
        return messageMapper.update(message, wrapper);
    }

    @Override
    public int getMessageNum() {
        LambdaQueryWrapper<Message> wrapper = Wrappers.lambdaQuery();
        wrapper.orderByDesc(Message::getCreateTime);
        //提醒人
        wrapper.eq(Message::getRemindObject, SecurityUtils.getUser().getId());
        //是否已读
        wrapper.eq(Message::getIsRead, 0);

        return messageMapper.selectCount(wrapper);
    }
}
