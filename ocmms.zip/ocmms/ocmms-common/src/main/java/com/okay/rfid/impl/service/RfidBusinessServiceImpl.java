package com.okay.rfid.impl.service;

import com.okay.rfid.entity.RfidBusinessEntity;
import com.okay.rfid.exception.RfidException;
import com.okay.rfid.impl.entity.RfidBusinessEntityImpl;
import com.okay.rfid.info.RfidBusiness;
import com.okay.rfid.mapper.RfidBusinessMapperRfid;
import com.okay.rfid.impl.query.RfidBusinessQueryImpl;
import com.okay.rfid.mapper.RfidBusinessQueryMapper;
import com.okay.rfid.query.RfidBusinessQuery;
import com.okay.rfid.service.RfidBusinessService;
import com.okay.rfid.util.Generate;
import com.okay.rfid.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class RfidBusinessServiceImpl implements RfidBusinessService {

    @Autowired
    protected RfidBusinessMapperRfid rfidBusinessMapper;

    @Autowired
    protected RfidBusinessQueryMapper rfidBusinessQueryMapper;

    @Override
    public RfidBusinessEntity newRfidBusiness() {
        return new RfidBusinessEntityImpl();
    }

    @Override
    public RfidBusinessEntity newRfidBusiness(RfidBusiness business) {
        return new RfidBusinessEntityImpl(business);
    }

    @Override
    @Transactional
    public RfidBusiness createRfidBusiness(RfidBusinessEntity businessEntity) {
        if(StringUtil.isNull(businessEntity.getBusinessId()) || StringUtil.isNull(businessEntity.getBusinessType())) {
            throw new RfidException("businessId or businessType is null");
        }

        if(StringUtil.isNull(businessEntity.getId())) {
            businessEntity.setId(Generate.getNextId());
        }

        if(businessEntity.getIsComplete() == null) {
            businessEntity.setIsComplete(true);
        }

        Date createdTime = businessEntity.getCreatedTime();
        Date updatedTime = businessEntity.getUpdatedTime();

        if(createdTime == null && updatedTime == null) {
            businessEntity.setCreatedTime(new Date());
            businessEntity.setUpdatedTime(new Date());
        } else if(createdTime != null && updatedTime != null) {
            if(createdTime.getTime() > updatedTime.getTime()) {
                throw new RfidException("createdTime > updatedTime");
            }
        } else if(createdTime != null && updatedTime == null) {
            businessEntity.setUpdatedTime(createdTime);
        } else if(createdTime == null && updatedTime != null) {
            businessEntity.setCreatedTime(updatedTime);
        }
        rfidBusinessMapper.insert(businessEntity);
        return businessEntity;
    }

    @Override
    @Transactional
    public RfidBusiness updateRfidBusiness(RfidBusinessEntity businessEntity) {
        if(StringUtil.isNull(businessEntity.getBusinessId()) || StringUtil.isNull(businessEntity.getBusinessType())) {
            throw new RfidException("businessId or businessType is null");
        }

        if(StringUtil.isNull(businessEntity.getId())) {
            throw new RfidException("id is null");
        }

        if(businessEntity.getIsComplete() == null) {
            throw new RfidException("complete state is null");
        }

        Date createdTime = businessEntity.getCreatedTime();
        Date updatedTime = businessEntity.getUpdatedTime();
        if(createdTime == null && updatedTime == null) {
            throw new RfidException("createdTime or updatedTime is null");
        }

        rfidBusinessMapper.updateByPrimaryKey(businessEntity);
        return businessEntity;
    }

    @Override
    @Transactional
    public RfidBusiness deleteRfidBusiness(RfidBusinessEntity businessEntity) {
        if(StringUtil.isNull(businessEntity.getId())) {
            throw new RfidException("id is null");
        }
        if(rfidBusinessMapper.deleteByPrimaryKey(businessEntity.getId()) == 0) {
            throw new RfidException("id not find");
        }
        return businessEntity;
    }

    @Override
    @Transactional
    public RfidBusiness deleteRfidBusiness(String id) {
        if(StringUtil.isNull(id)) {
            throw new RfidException("id is null");
        }
        RfidBusinessEntity businessEntity = rfidBusinessMapper.selectByPrimaryKey(id);
        if(businessEntity == null) {
            throw new RfidException("id not find");
        }
        rfidBusinessMapper.deleteByPrimaryKey(businessEntity.getId());
        return businessEntity;
    }

    @Override
    public RfidBusiness getRfidBusiness(String id) {
        if(StringUtil.isNull(id)) {
            throw new RfidException("id is null");
        }
        return rfidBusinessMapper.selectByPrimaryKey(id);
    }

    @Override
    public RfidBusinessQuery createRfidBusinessQuery() {
        return new RfidBusinessQueryImpl(rfidBusinessQueryMapper);
    }
}
