package com.okay.framework.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName: TokenUtil
 * @Description: Token生成工具
 * JWT 的 Token 的组成部分（1.头部 2.数据 3.签名）
 * 第一部分我们称它为头部(header),主要就是说明一下怎么处理这个token.
 * 第二部分我们称其为载荷(payload),里面是 Token 的具体内容.
 * 第三部分是签名（signature),分为三个部分，分别是用Base64编码的header和payload,再放进去一个Secret用加密算法加密一下
 * @author: zhongmz
 * @Date: 2019/6/27 10:38
 * @version: V1.0
 */
public class TokenUtil {

    public static final String JWT_TYP = "JWT";
    public static final String JWT_ALG = "HS256";

    public static final String JWT_ISS = "okay";
    public static final int JWT_EXP = 60 * 60 * 24 * 30;

    //公用秘钥-保存在服务端，客户端不知道秘钥，以防被攻击
    public static final String TOKEN_AES_KEY = "okayToken";

    /**
     * 生成token
     *
     * @param account 自定义数据
     * @param password 自定义数据
     * @return
     * @throws Exception
     */
    public static String getToken(String account, String password) throws Exception {
        //签发时间
        Date iatDate = new Date();

        //过期时间
        Calendar nowTime = Calendar.getInstance();
        nowTime.add(Calendar.SECOND, JWT_EXP);
        Date expiresDate = nowTime.getTime();

        //header信息
        Map<String, Object> header = new HashMap<String, Object>();
        header.put("typ", JWT_TYP);
        header.put("alg", JWT_ALG);

        String token = JWT.create()
                .withHeader(header)
                .withClaim("account", account)
                .withClaim("password", password)
                .withIssuer(JWT_ISS)
                .withIssuedAt(iatDate)
                .withExpiresAt(expiresDate)
                .sign(Algorithm.HMAC256(TOKEN_AES_KEY));
        return token;
    }

    /**
     * 解密Token
     *
     * @return boolean
     * @throws Exception
     * @Param token
     */
    public static Map<String, Claim> verifyToken(String token) throws Exception {
        JWTVerifier verifier = JWT.require(Algorithm.HMAC256(TOKEN_AES_KEY)).build();

        DecodedJWT jwt = verifier.verify(token);
        return jwt.getClaims();
    }

}