package com.okay.rfid.info;

import java.util.Date;

/**
 * rfid_tell_log
 * @author 
 */
public interface RfidTellLog {

    String getId();

    String getBeaconId();

    String getDeviceId();

    Date getTime();

    String getOperator();

    String getState();

}