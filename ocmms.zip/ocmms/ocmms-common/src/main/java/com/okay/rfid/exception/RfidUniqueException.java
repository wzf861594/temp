package com.okay.rfid.exception;

public class RfidUniqueException extends RfidException {

    public RfidUniqueException() {}

    public RfidUniqueException(String message) {
        super(message);
    }

    public RfidUniqueException(String message, Throwable cause) {
        super(message, cause);
    }

}
