package com.okay.framework.mapper;

import com.okay.framework.entity.CustomObject;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface CustomObjectMapper {
    int deleteByPrimaryKey(String objId);

    int insert(CustomObject record);

    int insertSelective(CustomObject record);

    CustomObject selectByPrimaryKey(String objId);

    int updateByPrimaryKeySelective(CustomObject record);

    int updateByPrimaryKey(CustomObject record);

    List<CustomObject> selectAllObject();
}