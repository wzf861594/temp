package com.okay.framework.config;


import com.zhuozhengsoft.pageoffice.poserver.AdminSeal;
import com.zhuozhengsoft.pageoffice.poserver.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author CZJ[OKAY]
 * @date 2021/11/1 17:06
 * @description PageOfficeBean
 **/
@Component
public class PageOfficeBean {

    @Value("${pageOffice.posyspath}")
    private String poSysPath;
    @Value("${pageOffice.popassword}")
    private String poPassWord;

    /**
     * 添加PageOffice的服务器端授权程序Servlet（必须）
     *
     * @return
     */
    @Bean
    public ServletRegistrationBean servletRegistrationBean() {
        Server poserver = new Server();
        //设置PageOffice注册成功后,license.lic文件存放的目录
        poserver.setSysPath(poSysPath);
        ServletRegistrationBean srb = new ServletRegistrationBean(poserver);
        srb.addUrlMappings("/pageOffice/poserver.zz");
        srb.addUrlMappings("/pageOffice/posetup.exe");
        srb.addUrlMappings("/pageOffice/pageoffice.js");
        srb.addUrlMappings("/pageOffice/jquery.min.js");
        srb.addUrlMappings("/pageOffice/pobstyle.css");
        srb.addUrlMappings("/pageOffice/sealsetup.exe");
        return srb;
    }

    /**
     * 添加印章管理程序Servlet（可选）
     *
     * @return
     */
    @Bean
    public ServletRegistrationBean servletRegistrationBean2() {
        AdminSeal adminSeal = new AdminSeal();
        //设置印章管理员admin的登录密码
        adminSeal.setAdminPassword(poPassWord);
        //设置印章数据库文件poseal.db存放的目录
        adminSeal.setSysPath(poSysPath);
        ServletRegistrationBean srb = new ServletRegistrationBean(adminSeal);
        srb.addUrlMappings("/pageOffice/adminseal.zz");
        srb.addUrlMappings("/pageOffice/sealimage.zz");
        srb.addUrlMappings("/pageOffice/loginseal.zz");
        return srb;
    }
}
