package com.okay.common.util;

import com.okay.common.feign.RemoteDeptExtensionService;
import com.okay.common.feign.RemoteDictExtensionService;
import com.okay.common.feign.RemoteUserExtensionService;
import com.okay.common.model.MetadataModel;
import com.okay.okay.admin.api.metadata.DeptInfo;
import com.okay.okay.admin.api.metadata.DictInfo;
import com.okay.okay.admin.api.metadata.DictItemInfo;
import com.okay.okay.admin.api.metadata.UserInfo;
import com.okay.okay.common.core.util.R;
import com.okay.okay.common.core.util.SpringContextHolder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 获取元数据工具
 * 包含：部门、用户、字色、字典等信息
 *
 * @author ZHU.HQ
 * @date 2020/7/2 13:45
 */
public class MetadataUtil {

    /**
     * 元数据模型：MetadataModel
     * 装载了部门、用户、字典的元数据
     * 并且提供便捷的工具方法
     *
     * @return
     */
    public static MetadataModel getMetadataModel() {
        return new MetadataModel();
    }

    /**
     * 查询全部用户信息（包含已注销用户）
     *
     * @return
     */
    public static List<UserInfo> getAllUsers() {
        RemoteUserExtensionService remoteUserExtensionService
                = SpringContextHolder.getBean(RemoteUserExtensionService.class);
        R<List<UserInfo>> result = remoteUserExtensionService.getAllUsers();
        if (result.getCode() == 0) {
            return result.getData();
        }
        return new ArrayList();
    }

    /**
     * 查询全部部门信息
     *
     * @return
     */
    public static List<DeptInfo> getAllDepts() {
        RemoteDeptExtensionService remoteDeptExtensionService
                = SpringContextHolder.getBean(RemoteDeptExtensionService.class);
        R<List<DeptInfo>> result = remoteDeptExtensionService.getAllDepts();
        if (result.getCode() == 0) {
            return result.getData();
        }
        return new ArrayList();
    }

    /**
     * 查询全部字典信息
     *
     * @return
     */
    public static List<DictInfo> getAllDicts() {
        RemoteDictExtensionService remoteDictExtensionService
                = SpringContextHolder.getBean(RemoteDictExtensionService.class);
        R<List<DictInfo>> result = remoteDictExtensionService.getAllDicts();
        if (result.getCode() == 0) {
            return result.getData();
        }
        return new ArrayList();
    }

    /**
     * 通过字典类型查找字典
     *
     * @param type 类型
     * @return 同类型字典
     */
    public static R getDictByType(String type) {
        RemoteDictExtensionService dictExtensionService = SpringContextHolder.getBean(RemoteDictExtensionService.class);
        return dictExtensionService.getDictByType(type);
    }

    /**
     * 查询全部字典信息
     *
     * @return
     */
    public static Map<String, List<DictItemInfo>> getAllDictToMap() {
        RemoteDictExtensionService service = SpringContextHolder.getBean(RemoteDictExtensionService.class);
        R<List<DictInfo>> result = service.getAllDicts();
        if (result.getCode() == 0) {
            List<DictInfo> dictInfos = result.getData();
            return dictInfos.stream().collect(Collectors.toMap(DictInfo::getType, DictInfo::getDictItemInfoList));
        }
        return new HashMap();
    }
}
