package com.okay.framework.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@TableName("v_sys_dept")
public class Dept implements Serializable {
    /**
     * 列序化ID
     */
    private static final long serialVersionUID = -5276489922601533202L;

    @TableField("deptId")
    private String deptId;

    @TableField("deptCode")
    @NotBlank(message = "部门名称不能为空")
    private String deptCode;

    @TableField("deptName")
    @NotBlank(message = "部门编码不能为空")
    private String deptName;

    @TableField("deptType")
    @NotNull(message = "部门类型不能为空")
    private Integer deptType;

    private String manager;

    private String leader;

    private Integer status;

    @TableField("seqNo")
    @Min(value = 0, message = "序号为空或者不小于0的数值")
    private Integer seqNo;

    @TableField("parentId")
    private String parentId;

    private String remark;

    @TableField(exist = false)
    private List<Dept> deptList = new ArrayList<Dept>();

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Integer getDeptType() {
        return deptType;
    }

    public void setDeptType(Integer deptType) {
        this.deptType = deptType;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<Dept> getDeptList() {
        return deptList;
    }

    public void setDeptList(List<Dept> deptList) {
        this.deptList = deptList;
    }

}