package com.okay.framework.utils;

import java.util.*;

/**
 * @ClassName: DataUtil
 * @Description: 数据处理工具.
 * @author: wenlh
 * @date: 2019年4月28日 15:27:19
 * @version: V1.0
 */
public class DataUtil {
    public interface HandleParse {
        public void hanlde(String key, Object obj, Object data);
    }

    public DataUtil() {
    }

    @SuppressWarnings("unchecked")
    public static Object getObject(String key, Object param) {
        Object data = null;
        if (param instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) param;
            if (map.containsKey(key)) {
                data = map.get(key);
            }
            if (data == null) {
                data = getParseObject(key, map);
            }
        }
        return data;
    }

    @SuppressWarnings("unchecked")
    public static Object getParseArray(String key, Object data) {
        Object value = null;
        if (data instanceof List) {
            List<Object> param = (List<Object>) data;
            for (int i = 0; i < param.size(); i++) {
                value = getParseObject(key, param.get(i));
                if (value != null) {
                    return value;
                }
            }
        }
        return value;
    }

    @SuppressWarnings("unchecked")
    public static Object getParseObject(String key, Object data) {
        Object result = null;
        if (data instanceof Map) {
            Map<String, Object> param = (Map<String, Object>) data;
            for (String name : param.keySet()) {
                Object obj = param.get(name);
                if (name.equals(key)) {
                    result = obj;
                } else if (obj instanceof Map) {
                    result = getParseObject(key, obj);
                } else if (obj instanceof List) {
                    result = getParseArray(key, obj);
                }
                if (result != null) {
                    return result;
                }
            }
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    public static void setParseArray(String key, Object data, Object val) {
        if (data instanceof List) {
            List<Object> param = (List<Object>) data;
            for (int i = 0; i < param.size(); i++) {
                setParseObject(key, param.get(i), val);
            }
        }
    }

    @SuppressWarnings("unchecked")
    public static void setParseObject(String key, Object data, Object val) {
        if (data instanceof Map) {
            Map<String, Object> param = (Map<String, Object>) data;
            for (String name : param.keySet()) {
                Object obj = param.get(name);
                if (name.equals(key)) {
                    param.put(key, val);
                } else if (obj instanceof Map) {
                    setParseObject(key, obj, val);
                } else if (obj instanceof List) {
                    setParseArray(key, obj, val);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    public static void handleParseObject(Object data, HandleParse handl) {
        if (data instanceof Map) {
            Map<String, Object> param = (Map<String, Object>) data;

            Set<String> set = param.keySet();
            String[] keys = new String[set.size()];
            param.keySet().toArray(keys);

            for (int i = 0; i < keys.length; i++) {
                String key = keys[i];
                Object obj = param.get(key);

                handl.hanlde(key, obj, param);

                if (obj instanceof Map) {
                    handleParseObject(obj, handl);
                } else if (obj instanceof List) {
                    handleParseArray(obj, handl);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    public static void handleParseArray(Object data, HandleParse handl) {
        if (data instanceof List) {
            List<Object> param = (List<Object>) data;
            for (Object obj : param) {
                if (obj instanceof Map) {
                    handleParseObject(obj, handl);
                } else if (obj instanceof List) {
                    handleParseArray(obj, handl);
                }
            }
        }
    }


    public static Set<String> getReplaceKeys(String str, String start, String end) {
        Set<String> result = new HashSet<String>();
        if (!ValidateUtil.isNull(str)) {
            int fromIndex = 0;
            while (str.indexOf(start, fromIndex) != -1) {
                int beginIndex = str.indexOf(start, fromIndex);
                if (beginIndex == -1) {
                    break;
                }
                int endIndex = str.indexOf(end, beginIndex = beginIndex + start.length());
                if (endIndex == -1) {
                    break;
                }
                result.add(str.substring(beginIndex, endIndex));
                fromIndex = endIndex + end.length();
            }
        }
        return result;
    }

    /**
     * @param sign 站位标识符
     * @param str
     * @return
     * @MethodName: getReplaceKeys
     * @Description: 取得占位符替换标志中的key值
     */
    public static Set<String> getReplaceKeys(String str, String sign) {
        return getReplaceKeys(str, sign, sign);
    }

    public static String replaceSign(String str, Map<String, Object> param, String sign) {
        return replaceSign(str, param, sign);
    }

    public static String replaceSign(String str, Map<String, Object> param, String start, String end) {
        if (ValidateUtil.isNull(start) || ValidateUtil.isNull(end)) {
            return str;
        } else if (ValidateUtil.isNull(str)) {
            return str;
        } else if (ValidateUtil.isNull(param)) {
            return str;
        } else {
            // 取得替换key
            Set<String> keys = getReplaceKeys(str, start, end);

            for (String k : keys) {
                Object val = getObject(k, param);

                // 当数据为空则不进行替换
                if (!ValidateUtil.isNull(val)) {
                    str = str.replaceAll(start + k + end, val.toString());
                }
            }
            return str;
        }
    }

    public static void dataMapping(String source, String target, Object data) {
        Object mappingData = getMappingData(source, data);
        setMappingData(target, data, mappingData);
    }

    @SuppressWarnings("unchecked")
    public static Object getMappingData(String source, Object data) {
        if (data == null) {
            return null;
        }

        while (source != null) {
            if (data instanceof Map) {
                Map<String, Object> node = (Map<String, Object>) data;

                int index = source.indexOf("\\.");
                String sourceKey = source.substring(0, (index == -1 ? source.length() : index));
                source = index == -1 ? null : source.substring(index);

                if ("*".equals(sourceKey)) {
                    if (source == null) {
                        return data;
                    }
                    while (source != null && "*".equals(sourceKey)) {
                        index = source.indexOf("\\.");
                        sourceKey = source.substring(0, (index == -1 ? source.length() : index));
                        source = index == -1 ? null : source.substring(index);
                    }

                    if ("*".equals(sourceKey)) {
                        return null;
                    }

                    data = getObject(sourceKey, data);

                } else {
                    if (!node.containsKey(sourceKey)) {
                        return null;
                    }
                    data = node.get(sourceKey);
                }
            } else if (data instanceof List) {
                List<Object> listData = (List<Object>) data;
                List<Object> resultData = new ArrayList<Object>();
                for (Object obj : listData) {
                    Object result = getMappingData(source, obj);
                    if (result != null) {
                        resultData.add(result);
                    }
                }
                return resultData.isEmpty() ? null : resultData;
            } else {
                return null;
            }
        }
        return data;
    }

    @SuppressWarnings("unchecked")
    public static void setMappingData(String target, Object data, Object mappingData) {
        if (data == null) {
            return;
        } else if (mappingData == null) {
            return;
        }

        while (target != null) {
            if (data instanceof Map) {
                Map<String, Object> node = (Map<String, Object>) data;

                int index = target.indexOf("\\.");
                String sourceKey = target.substring(0, (index == -1 ? target.length() : index));
                target = index == -1 ? null : target.substring(index);

                if ("*".equals(sourceKey)) {
                    while (target != null && "*".equals(sourceKey)) {
                        index = target.indexOf("\\.");
                        sourceKey = target.substring(0, (index == -1 ? target.length() : index));
                        target = index == -1 ? null : target.substring(index);
                    }

                    if ("*".equals(sourceKey)) {
                        return;
                    }
                    Object temp = getObject(sourceKey, data);
                    if (target != null) {
                        setMappingData(target, temp, mappingData);
                    } else {
                        setParseObject(sourceKey, data, mappingData);
                    }

                } else {
                    if (node.containsKey(sourceKey)) {
                        node.put(sourceKey, mappingData);
                    }
                }
            } else if (data instanceof List) {
                List<Object> listData = (List<Object>) data;
                for (Object obj : listData) {
                    setMappingData(target, obj, mappingData);
                }
            }
        }
    }

    /**
     * 全角字符转半角字符
     * @author: zyx
     */
    public static String charToDBC(String input) {
        char c[] = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == '\u3000') {
                c[i] = ' ';
            } else if (c[i] > '\uFF00' && c[i] < '\uFF5F') {
                c[i] = (char) (c[i] - 65248);
            }
        }
        return new String(c);
    }

    /**
     * map数组中的null数据转换成 ""代替
     * @author: zyx
     */
    public static void nullToEmpty(List<Map> mapList){
        for (int i = 0; i < mapList.size(); i++) {
            Map mapObj = mapList.get(i);
            Set keys = mapObj.keySet();
            Iterator iterator =  keys.iterator();
            while (iterator.hasNext()) {
                String key = (String)iterator.next();
                if(mapObj.get(key) == null){
                    mapObj.put(key, "");
                }
            }
        }
    }

    /**
     * 判空处理，去空格
     * @param str
     * @author: zyx
     * @return
     */
    public static boolean isEmpty(String str) {
        return str == null || str.trim().length() == 0;
    }
}
