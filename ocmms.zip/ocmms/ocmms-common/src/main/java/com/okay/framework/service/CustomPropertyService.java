package com.okay.framework.service;

import com.okay.framework.entity.CustomObject;
import com.okay.framework.entity.CustomProperty;

import java.util.List;

/**
 * @Description:
 * @Author: xdn
 * @Version: 1.0
 * @CreateDate 2020-03-03 11:49
 */

public interface CustomPropertyService {

    CustomProperty insert(CustomProperty customProperty);

    CustomProperty update(CustomProperty customProperty);

    CustomProperty saveData(CustomProperty customProperty);

    List<CustomProperty> findByCustomResourceId(String CustomObj);

    List<CustomObject> findAllCustomObject();

}
