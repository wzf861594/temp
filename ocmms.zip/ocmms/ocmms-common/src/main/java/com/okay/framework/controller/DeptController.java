package com.okay.framework.controller;

import com.alibaba.fastjson.JSONObject;
import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Dept;
import com.okay.framework.entity.Page;
import com.okay.framework.exception.BaseRuntimeException;
import com.okay.framework.exception.ExceptionUtil;
import com.okay.framework.exception.SysErrorDefine;
import com.okay.framework.service.DeptService;
import com.okay.framework.utils.DataUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.*;

/**
 * @ClassName: DeptController
 * @Description: 部门管理处理类
 * @author: HQ.ZHU
 * @date: 2019-04-18 1:14
 * @version: V1.0
 */  
@Controller
@RequestMapping("/dept")
public class DeptController extends BaseController {

    @Resource
    private DeptService deptService;

    /**
     *@Author : xdn
     *@Description : 部门列表
     *@Return :
     **/
    @RequestMapping(value = "/dataList", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject dataList(@RequestBody Page page){
        JSONObject jsonObject = new JSONObject();
        try {
            List<Dept> deptList = deptService.findDataListByPage(page);
            jsonObject.put("data",deptList);
            jsonObject.put("pages",page.getPages());
            jsonObject.put("total",page.getTotal());
            jsonObject.put("pageNow",page.getPageNum());
            jsonObject.put("pageSize",page.getPageSize());
            jsonObject.put("code",1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 部门信息
      *@Return :
      **/
    @RequestMapping(value = "/getById", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject getById(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();
        String deptId = jsonParam.getString("deptId");

        Dept dept = null;
        try {
            if (DataUtil.isEmpty(deptId)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA,""));
            }
            Map<String,Object>  depetMap = deptService.findDataMapById(deptId);
            jsonObject.put("data",depetMap);
            jsonObject.put("code",1);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 部门新增
      *@Return :
      **/
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject add(@RequestBody @Valid Dept dept){
        JSONObject jsonObject = new JSONObject();

        try {
            Dept newDept = deptService.add(dept);
            jsonObject.put("data",newDept);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.ADD_DATA_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 部门修改
      *@Return :
      **/
    @RequestMapping(value = "/modifyById", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject modifyById(@RequestBody @Valid Dept dept){
        JSONObject jsonObject = new JSONObject();
        try {
            deptService.modify(dept);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.UPDATE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 部门删除
      *@Return :
      **/
    @RequestMapping(value = "/remove", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject remove(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();

        String deptIds = jsonParam.getString("deptIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(deptIds)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA,""));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")){
                throw new BaseRuntimeException(SysErrorDefine.ASK_HANDLE_DEL);
            }

            Set<String> deptIdList = new HashSet<>(Arrays.asList(deptIds.split(",")));
            deptService.remove(deptIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject, SysErrorDefine.DELETE_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 部门注销
      *@Return :
      **/
    @RequestMapping(value = "/cancel", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject cancel(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();

        String deptIds = jsonParam.getString("deptIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(deptIds)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA,""));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")){
                throw new BaseRuntimeException(String.format(SysErrorDefine.ASK_HANDLE_CANCEl,""));
            }
            Set<String> deptIdList = new HashSet<>(Arrays.asList(deptIds.split(",")));
            deptService.cancel(deptIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject,SysErrorDefine.CANCEL_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     * 注销部门恢复
     * @param jsonParam
     * @return
     */
    @RequestMapping(value = "/recover", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject recover(@RequestBody JSONObject jsonParam){
        JSONObject jsonObject = new JSONObject();

        String deptIds = jsonParam.getString("deptIds");
        String confirmFlg = jsonParam.getString("confirmFlg");
        try {
            if (DataUtil.isEmpty(deptIds)){
                throw new BaseRuntimeException(String.format(SysErrorDefine.CHOOSE_HANDLE_DATA,""));
            }
            if (DataUtil.isEmpty(confirmFlg) || confirmFlg.trim().equals("0")){
                throw new BaseRuntimeException(SysErrorDefine.ASK_HANDLE_UNCANCEl);
            }
            Set<String> deptIdList = new HashSet<>(Arrays.asList(deptIds.split(",")));
            deptService.recover(deptIdList);
            ExceptionUtil.formatResultJsonObject(jsonObject,SysErrorDefine.RECOVER_SUCCESS);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
      *@Author : xdn
      *@Description : 部门树
      *@Return :
      **/
    @RequestMapping(value = "/dataTree", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject dataTree(){
        JSONObject jsonObject = new JSONObject();
        try {
            List<DataTree> dataTreeList = deptService.findDataTreeList();

            DataTree root = new DataTree();
            List<DataTree> dataTrees = new ArrayList<DataTree>();
            root.setNodeId("");
            root.setNodeCode("root");
            root.setNodeName("根目录");
            root.setChildNodes(dataTreeList);
            dataTrees.add(root);

            jsonObject.put("code",1);
            jsonObject.put("data",dataTrees);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

    /**
     *@Author : zmz
     *@Description : 部门树（剔除根节点）
     *@Return :
     **/
    @RequestMapping(value = "/dataTreeNotRoot", method = RequestMethod.POST)
    @ResponseBody
    public JSONObject dataTreeNotRoot(){
        JSONObject jsonObject = new JSONObject();
        try {
            List<DataTree> dataTreeList = deptService.findDataTreeList();

            jsonObject.put("code",1);
            jsonObject.put("data",dataTreeList);
        } catch (Exception e) {
            ExceptionUtil.formatResultJsonObject(jsonObject, e);
        }
        return jsonObject;
    }

}
