package com.okay.framework.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.User;
import com.okay.framework.entity.dto.SysUserDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    int deleteByPrimaryKey(String userId);

    int insert(User user);

    int updateByPrimaryKey(User user);


    /**
     * 选择性新增.
     * @param user 用户对象.
     * @return 返回新增成功数.
     */
    int insertSelective(User user);

    /**
     * 用户信息选择性更新.
     * @param user 用户对象.
     * @return 返回更新成功数.
     */
    int updateByPrimaryKeySelective(User user);

    /**
     * 列表用户信息更新.
     * @param user 用户对象.
     * @return 返回更新成功数.
     */
    int updateUserInfoByKey(User user);

    /**
     * 个人信息更新.
     * @param user 用户对象.
     * @return 返回更新成功数.
     */
    int updatePersonalInfoByKey(User user);

    /**
     * 根据用户账号查询.
     * @param account 用户账号.
     * @return 返回用户信息.
     */
    User selectByAccount(@Param("account") String account);

    /**
     *  根据主键查询.
     * @param userId 用户主键.
     * @return 返回对应用户信息.
     */
    User selectByPrimaryKey(String userId);

    /**
     * 查询用户列表.
     * @param page 分页对象进行查询.
     * @return 返回查询的用户信息列表集合.
     */
    List<Map<String,String>> selectDataList(Page page);

    /**
     * 查询用户列表.
     * @param page 分页对象进行查询.
     * @param dto 查询条件
     * @return 返回查询的用户信息列表集合.
     */
    IPage<Map<String,Object>> contactUserList(com.baomidou.mybatisplus.extension.plugins.pagination.Page page,
                                              @Param(value = "dto") SysUserDTO dto);

    /**
     *  多条件删除.
     * @param map 删除条件Map集合.
     * @return 返回删除成功条数.
     */
    Integer deleteByParams(Map<String, Object> map);

    /**
     * 多条件更新.
     * @param map 更新条件Map集合.
     * @return 返回更新成功条数.
     */
    Integer updateByParams(Map<String, Object> map);

    /**
     * 查询用户Map集合
     * @param userId 用户id
     * @return 返回用户Map集合
     */
    Map<String,Object> selectForMapById(String userId);

    /**
     * 根据部门查询用户信息.
     * @param deptId 部门主键.
     * @return 返回用户信息.
     **/
    List<User> findUserByDeptId(String deptId);

    /**
     * 根据部门查询用户信息.
     * @param roleId 角色主键.
     * @return 返回用户信息.
     **/
    List<User> findUserByRoleId(String roleId);

    /**
     * 多条件查询.
     * @param query 查询条件.
     * @return 返回用户信息List集合.
     */
    List<User> selectUserWithDeptByQuery(Map<String,Object> query);

    /**
     * 按部门返回用户的列表数据
     * 作用于前端的用户选择组件的数据加载
     * @param map
     * @return
     */
    List<Map> selectUserInDept(Map<String, Object> map);
}