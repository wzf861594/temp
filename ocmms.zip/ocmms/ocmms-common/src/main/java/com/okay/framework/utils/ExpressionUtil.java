package com.okay.framework.utils;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.util.Map;
import java.util.Set;

/**
 * @ClassName: ExpressionUtil.java
 * @Description: 表达式工具.
 * @author: zhongmz
 * @date: 2019年1月5日 下午2:08:17
 * @version: V1.0
 */
public class ExpressionUtil {
	
	private final static String STARTSIGN = "${";
	
	private final static String ENDSIGN = "}";
	
	/**
	 * 判断表达式正误   如${num == 1}
	 * @param express   表达式
	 * @param variables 参数
	 * @return
	 * @throws Exception 
	 */
	public static Boolean judge(String express, Map<String,Object> variables) throws Exception{
		Boolean flag = false;
		if(ValidateUtil.isNull(express)){
			throw new Exception("表达式为空!");
		}
		
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("javascript");
		// 取得引用的表达式
		Set<String> expressValue = DataUtil.getReplaceKeys(express, STARTSIGN, ENDSIGN);
		for(String value : expressValue) {
			//遍历参数key值，设置到engine
			for(String name : variables.keySet()){
				engine.put(name, variables.get(name));
			}
			
			flag = (Boolean)engine.eval(value);
		}
		return flag;
	}
}
