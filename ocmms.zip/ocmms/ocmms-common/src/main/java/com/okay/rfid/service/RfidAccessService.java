package com.okay.rfid.service;

import com.okay.rfid.info.RfidAccess;
import com.okay.rfid.query.RfidAccessQuery;

import java.util.Collection;
import java.util.List;

public interface RfidAccessService {

    /**
     * 创建RFID接入.
     * @param rfid 必填，接入的RFID.
     * @param accessBusiness 必填，接入业务,值根据业务具体输入.
     * @return
     */
    RfidAccess createRfidAccess(String rfid, String accessBusiness);

    /**
     * 创建RFID接入.
     * @param rfid 必填，接入的RFID.
     * @param accessBusiness 必填，接入业务,值根据业务具体输入.
     * @return
     */
    RfidAccess createRfidAccess(String rfid, String accessBusiness, String type, String businessId, String businessType, String createdBy);

    /**
     * 创建RFID接入唯一.
     * @param rfid 必填，接入的RFID.
     * @param accessBusiness 必填，接入业务,值根据业务具体输入.
     * @return
     */
    RfidAccess createRfidAccessUnique(String rfid, String accessBusiness);

    /**
     * 创建RFID接入唯一.
     * @param rfid 必填，接入的RFID.
     * @param accessBusiness 必填，接入业务,值根据业务具体输入.
     * @return
     */
    RfidAccess createRfidAccessUnique(String rfid, String accessBusiness, String type, String businessId, String businessType, String createdBy);

    /**
     * 删除RFID接入.
     * @param ids 必填，根据ID删除.
     * @return
     */
    List<? extends RfidAccess> deleteRfidAccess(Collection<String> ids);

    /**
     * 获取RFID借入.
     * <p/> 一般由与业务的需要才会调用该接口，判断已存在的接入情况而做不同的决策.
     * <p/> 常见于判断只允许有一个业务的情况.
     * @param rfid 必填，根据RFID获取.
     * @return
     */
    List<? extends RfidAccess> getRfidAccess(String rfid);


    RfidAccessQuery createRfidAccessQuery();

}
