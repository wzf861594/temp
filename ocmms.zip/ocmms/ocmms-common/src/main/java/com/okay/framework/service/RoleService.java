package com.okay.framework.service;

import com.okay.framework.entity.DataTree;
import com.okay.framework.entity.Page;
import com.okay.framework.entity.Role;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: RoleService
 * @Description: 角色管理接口
 * @author: HQ.ZHU
 * @date: 2019-04-25 18:37
 * @version: V1.0
 */  
public interface RoleService {
    Page findList(Page page);
    Role findById(String roleId);
    List<String> findSelectedUser(String roleId);
    List<DataTree> findDataTreeList();
    Integer add(Role role);
    Integer modify(Role role);
    Integer remove(String roleId);
    int removeBatch(ArrayList<String> idList);
    int removeUserFormRole(String roleId, List<String> userIdList);
    int cancel(Role role);
    int recover(Role role);
    void savePermission(String id, List<Map<String, String>> rolePermissionList);
    void saveSelectedUsers(String id, List<Map<String, String>> roleUserList);
}
