package com.okay.rfid.impl;

import com.okay.rfid.impl.entity.RfidTellBusinessEntityImpl;

public class DefaultRfidTellBusiness extends RfidTellBusinessEntityImpl {

    @Deprecated
    private boolean isNotLog;

    private Object param;

    @Deprecated
    public void setNotLog() {

    }

    @Deprecated
    public boolean isNotLog() {
        return false;
    }

    public Object getParam() {
        return param;
    }

    public void setParam(Object param) {
        this.param = param;
    }

}
