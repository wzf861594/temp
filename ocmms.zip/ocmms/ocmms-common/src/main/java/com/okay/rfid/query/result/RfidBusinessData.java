package com.okay.rfid.query.result;

public interface RfidBusinessData {

    Object getBusinessData();

    void setBusinessData(Object data);
}
