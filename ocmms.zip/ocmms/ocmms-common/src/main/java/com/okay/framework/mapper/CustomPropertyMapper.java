package com.okay.framework.mapper;

import com.okay.framework.entity.CustomProperty;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface CustomPropertyMapper {
    int deleteByPrimaryKey(String customId);

    int insert(CustomProperty record);

    int insertSelective(CustomProperty record);

    CustomProperty selectByPrimaryKey(String customId);

    int updateByPrimaryKeySelective(CustomProperty record);

    int updateByPrimaryKeyWithBLOBs(CustomProperty record);

    int updateByPrimaryKey(CustomProperty record);

    List<CustomProperty> selectByCustomResourceId(String customResourceId);

    int updateByCustomResourceIdSelective(CustomProperty customProperty);
}